
import junit.framework.*;

public class RandoopTest7 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test1"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
    var0.mapDatasetToDomainAxis(100, 0);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var7 = var6.getPlotType();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var6.setLegendLabelURLGenerator(var8);
    java.awt.Graphics2D var10 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var15 = null;
    var13.setToolTipGenerator(var15);
    java.awt.Font var17 = var13.getLabelFont();
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var17);
    var18.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var24 = var18.getURLText();
    org.jfree.chart.util.VerticalAlignment var25 = var18.getVerticalAlignment();
    java.awt.geom.Rectangle2D var26 = var18.getBounds();
    var6.drawBackgroundImage(var10, var26);
    java.util.List var28 = null;
    var0.drawRangeTickBands(var5, var26, var28);
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    var31.setForegroundAlpha(1.0f);
    java.awt.Font var34 = var31.getNoDataMessageFont();
    var31.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var31);
    java.awt.Paint var38 = var37.getBackgroundPaint();
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var41 = var40.clone();
    org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var40};
    var39.setDomainAxes(var42);
    org.jfree.data.xy.XYDataset var45 = var39.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
    var39.setRenderer(100, var47, false);
    java.awt.Color var54 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var55 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var54);
    org.jfree.chart.util.HorizontalAlignment var56 = null;
    org.jfree.chart.util.VerticalAlignment var57 = null;
    org.jfree.chart.block.ColumnArrangement var60 = new org.jfree.chart.block.ColumnArrangement(var56, var57, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var63 = null;
    var61.setDomainAxisLocation(1, var63, false);
    java.awt.Stroke var66 = var61.getRangeCrosshairStroke();
    boolean var67 = var60.equals((java.lang.Object)var66);
    java.awt.Color var71 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var72 = null;
    org.jfree.chart.plot.ValueMarker var74 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var54, var66, (java.awt.Paint)var71, var72, 1.0f);
    java.lang.Object var75 = var74.clone();
    var39.addDomainMarker((org.jfree.chart.plot.Marker)var74);
    boolean var77 = var37.equals((java.lang.Object)var74);
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var74);
    java.awt.Paint var79 = var0.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Pie 3D Plot"+ "'", var7.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test2"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    var0.configureRangeAxes();
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var0.getCategoriesForAxis(var7);
    var0.clearDomainMarkers();
    var0.setRangeCrosshairVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test3"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     var4.setSectionOutlinesVisible(true);
//     java.awt.Paint var8 = var4.getBaseSectionPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.plot.PiePlotState var11 = var0.initialise(var1, var2, var4, (java.lang.Integer)0, var10);
//     var0.setSeparatorsVisible(true);
//     java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var17);
//     int var19 = var17.getGreen();
//     java.lang.String var20 = var17.toString();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     org.jfree.chart.util.RectangleInsets var23 = var22.getLabelPadding();
//     boolean var24 = var22.getLabelLinksVisible();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var26 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var22.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var26);
//     org.jfree.chart.labels.PieSectionLabelGenerator var28 = var22.getLegendLabelToolTipGenerator();
//     var22.setLabelLinkMargin(4.0d);
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var33 = var32.getUpperMargin();
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     org.jfree.chart.util.RectangleInsets var36 = var35.getLabelPadding();
//     var35.setSectionOutlinesVisible(true);
//     java.awt.Paint var39 = var35.getBaseSectionPaint();
//     java.awt.Paint var41 = var35.getSectionPaint((java.lang.Comparable)100.0d);
//     java.awt.Stroke var42 = var35.getLabelLinkStroke();
//     var32.setTickMarkStroke(var42);
//     var22.setLabelOutlineStroke(var42);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     var45.setForegroundAlpha(1.0f);
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var52 = var51.clone();
//     org.jfree.chart.axis.ValueAxis[] var53 = new org.jfree.chart.axis.ValueAxis[] { var51};
//     var50.setDomainAxes(var53);
//     org.jfree.data.xy.XYDataset var56 = var50.getDataset(100);
//     org.jfree.chart.plot.PlotRenderingInfo var58 = null;
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var60 = var59.getQuadrantOrigin();
//     var50.zoomRangeAxes(0.0d, var58, var60, false);
//     var45.zoomDomainAxes((-7.0d), var49, var60);
//     org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var65 = var64.getLabelURL();
//     var64.configure();
//     java.awt.Paint var67 = var64.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var68 = var64.getTickLabelInsets();
//     double var70 = var68.calculateRightInset(0.05d);
//     var45.setAxisOffset(var68);
//     org.jfree.chart.block.LineBorder var72 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var17, var42, var68);
//     java.lang.Object var73 = null;
//     boolean var74 = var72.equals(var73);
//     java.awt.Stroke var75 = var72.getStroke();
//     var0.setLabelOutlineStroke(var75);
//     
//     // Checks the contract:  equals-hashcode on var4 and var35
//     assertTrue("Contract failed: equals-hashcode on var4 and var35", var4.equals(var35) ? var4.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var4
//     assertTrue("Contract failed: equals-hashcode on var35 and var4", var35.equals(var4) ? var35.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test4"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, (-48.29999999999999d), 100.0d);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test5"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     java.awt.Shape var3 = var1.getLeftArrow();
//     org.jfree.chart.renderer.PolarItemRenderer var4 = null;
//     org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var11 = var10.clone();
//     org.jfree.chart.axis.ValueAxis[] var12 = new org.jfree.chart.axis.ValueAxis[] { var10};
//     var9.setDomainAxes(var12);
//     java.awt.geom.Point2D var14 = var9.getQuadrantOrigin();
//     var5.zoomDomainAxes(0.2d, 2.0d, var8, var14);
//     boolean var16 = var5.isAngleGridlinesVisible();
//     boolean var17 = var5.isDomainZoomable();
//     java.awt.Paint var18 = var5.getAngleGridlinePaint();
//     java.awt.Paint var19 = var5.getRadiusGridlinePaint();
//     org.jfree.data.xy.XYDataset var20 = null;
//     var5.setDataset(var20);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var26 = var25.clone();
//     org.jfree.chart.axis.ValueAxis[] var27 = new org.jfree.chart.axis.ValueAxis[] { var25};
//     var24.setDomainAxes(var27);
//     java.awt.geom.Point2D var29 = var24.getQuadrantOrigin();
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = var24.getRenderer((-65536));
//     org.jfree.chart.plot.Plot var32 = var24.getRootPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var38 = null;
//     var36.setDomainAxisLocation(1, var38, false);
//     java.awt.Stroke var41 = var36.getRangeCrosshairStroke();
//     var36.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     var36.setRenderer(var44);
//     org.jfree.chart.axis.AxisSpace var46 = var36.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     var49.setForegroundAlpha(1.0f);
//     java.awt.Font var52 = var49.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var53 = null;
//     org.jfree.chart.plot.PiePlot var54 = new org.jfree.chart.plot.PiePlot(var53);
//     org.jfree.chart.util.RectangleInsets var55 = var54.getLabelPadding();
//     var54.setSectionOutlinesVisible(true);
//     java.awt.Paint var58 = var54.getBaseSectionPaint();
//     var49.setRangeCrosshairPaint(var58);
//     java.lang.Object var60 = var49.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var62 = null;
//     org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var64 = null;
//     var63.datasetChanged(var64);
//     java.awt.Paint var66 = var63.getRangeZeroBaselinePaint();
//     var63.setRangeGridlinesVisible(true);
//     var63.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var72 = null;
//     org.jfree.chart.plot.XYPlot var73 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var74 = var73.getQuadrantOrigin();
//     var63.zoomRangeAxes(0.0d, var72, var74);
//     var49.zoomDomainAxes((-1.0d), var62, var74);
//     var36.zoomRangeAxes(100.0d, var48, var74);
//     var24.zoomRangeAxes(0.2d, (-51.29999999999999d), var35, var74);
//     var5.zoomRangeAxes(10.5d, var23, var74);
//     
//     // Checks the contract:  equals-hashcode on var9 and var24
//     assertTrue("Contract failed: equals-hashcode on var9 and var24", var9.equals(var24) ? var9.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var9
//     assertTrue("Contract failed: equals-hashcode on var24 and var9", var24.equals(var9) ? var24.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test6"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.BasicProjectInfo var6 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var6.addOptionalLibrary("");
    var0.addOptionalLibrary((org.jfree.chart.ui.Library)var6);
    java.lang.String var10 = var0.getLicenceText();
    org.jfree.chart.ui.ProjectInfo var11 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var14 = null;
    var12.setDomainAxisLocation(1, var14, false);
    java.awt.Stroke var17 = var12.getRangeCrosshairStroke();
    org.jfree.chart.util.Layer var19 = null;
    java.util.Collection var20 = var12.getRangeMarkers(10, var19);
    java.util.List var21 = var12.getAnnotations();
    var11.setContributors(var21);
    java.lang.String var23 = var11.getVersion();
    var0.addLibrary((org.jfree.chart.ui.Library)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test7"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    var4.mapDatasetToDomainAxis(100, 0);
    java.awt.Paint var9 = var4.getDomainCrosshairPaint();
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("Multiple Pie Plot", var3, var9);
    org.jfree.data.general.PieDataset var15 = null;
    org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
    org.jfree.chart.util.RectangleInsets var17 = var16.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var18 = null;
    var16.setToolTipGenerator(var18);
    java.awt.Font var20 = var16.getLabelFont();
    org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var20);
    org.jfree.chart.text.TextLine var22 = new org.jfree.chart.text.TextLine("Other", var20);
    java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var27);
    org.jfree.chart.util.HorizontalAlignment var29 = null;
    org.jfree.chart.util.VerticalAlignment var30 = null;
    org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement(var29, var30, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var36 = null;
    var34.setDomainAxisLocation(1, var36, false);
    java.awt.Stroke var39 = var34.getRangeCrosshairStroke();
    boolean var40 = var33.equals((java.lang.Object)var39);
    java.awt.Color var44 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var45 = null;
    org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var27, var39, (java.awt.Paint)var44, var45, 1.0f);
    float var48 = var47.getAlpha();
    java.awt.Paint var49 = var47.getLabelPaint();
    java.awt.Paint var50 = var47.getPaint();
    org.jfree.chart.text.TextFragment var52 = new org.jfree.chart.text.TextFragment("", var20, var50, (-1.0f));
    org.jfree.chart.text.TextLine var53 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", var20);
    var10.addLine(var53);
    org.jfree.chart.util.HorizontalAlignment var55 = var10.getLineAlignment();
    org.jfree.chart.text.TextLine var56 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var57 = var56.getFirstTextFragment();
    var10.addLine(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test8"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    org.jfree.chart.event.MarkerChangeEvent var25 = null;
    var24.notifyListeners(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test9"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = Pie 3D Plot");
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("HorizontalAlignment.CENTER");
    java.awt.Font var6 = var4.getTickLabelFont((java.lang.Comparable)"Rotation.CLOCKWISE");
    org.jfree.chart.text.TextLine var7 = new org.jfree.chart.text.TextLine("poly", var6);
    var1.setFont(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test10"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var13 = var12.clone();
    org.jfree.data.Range var14 = var12.getRange();
    org.jfree.data.Range var15 = org.jfree.data.Range.combine(var10, var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setForegroundAlpha(1.0f);
    java.awt.Paint var19 = var16.getRangeCrosshairPaint();
    boolean var20 = var15.equals((java.lang.Object)var16);
    var16.setDomainGridlinesVisible(false);
    java.lang.Object var23 = var16.clone();
    var16.configureRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test11"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var2 = var0.getLeftArrow();
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "Pie 3D Plot");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var6 = var5.clone();
    java.awt.Shape var7 = var5.getLeftArrow();
    org.jfree.chart.entity.ChartEntity var9 = new org.jfree.chart.entity.ChartEntity(var7, "Pie 3D Plot");
    var4.setArea(var7);
    var4.setToolTipText("Range[0.0,1.0]");
    java.lang.String var13 = var4.getShapeCoords();
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var16.setDomainAxisLocation(1, var18, false);
    java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
    java.awt.Font var22 = var16.getNoDataMessageFont();
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Color var27 = var26.darker();
    org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var22, (java.awt.Paint)var26);
    org.jfree.chart.text.TextLine var29 = new org.jfree.chart.text.TextLine("", var22);
    org.jfree.chart.text.TextFragment var30 = var29.getLastTextFragment();
    boolean var31 = var4.equals((java.lang.Object)var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "0,0,2,-2,2,2,2,2"+ "'", var13.equals("0,0,2,-2,2,2,2,2"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test12"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setToolTipText("Multiple Pie Plot");
    org.jfree.chart.util.RectangleEdge var10 = var7.getPosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test13"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var0.setRangeCrosshairPaint(var9);
    java.awt.Image var11 = null;
    var0.setBackgroundImage(var11);
    var0.clearRangeMarkers((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test14"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var3 = var2.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var4 = null;
    var2.setTickUnit(var4, false, true);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var9 = var8.getTickMarkPosition();
    var2.setTickMarkPosition(var9);
    var0.setTickMarkPosition(var9);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var13 = var12.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var15 = var14.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var16 = null;
    var14.setTickUnit(var16, false, true);
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var21 = var20.getTickMarkPosition();
    var14.setTickMarkPosition(var21);
    var12.setTickMarkPosition(var21);
    var12.setInverted(true);
    org.jfree.chart.axis.DateTickUnit var26 = var12.getTickUnit();
    java.util.Date var27 = var0.calculateHighestVisibleTickValue(var26);
    var0.setAutoTickUnitSelection(true, false);
    java.text.DateFormat var31 = var0.getDateFormatOverride();
    java.text.DateFormat var32 = var0.getDateFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test15"); }


    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var3 = var2.getUpperMargin();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    java.awt.Paint var11 = var5.getSectionPaint((java.lang.Comparable)100.0d);
    java.awt.Stroke var12 = var5.getLabelLinkStroke();
    var2.setTickMarkStroke(var12);
    java.awt.Font var14 = var2.getTickLabelFont();
    java.awt.Color var19 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var19);
    org.jfree.chart.util.HorizontalAlignment var21 = null;
    org.jfree.chart.util.VerticalAlignment var22 = null;
    org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement(var21, var22, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var28 = null;
    var26.setDomainAxisLocation(1, var28, false);
    java.awt.Stroke var31 = var26.getRangeCrosshairStroke();
    boolean var32 = var25.equals((java.lang.Object)var31);
    java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var37 = null;
    org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var19, var31, (java.awt.Paint)var36, var37, 1.0f);
    org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var19);
    org.jfree.chart.util.HorizontalAlignment var41 = var40.getLineAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test16"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setUpperBound(10.0d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test17"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
    var0.mapDatasetToDomainAxis(100, 0);
    java.awt.Paint var5 = var0.getDomainCrosshairPaint();
    var0.setRangeGridlinesVisible(true);
    boolean var8 = var0.isRangeCrosshairLockedOnData();
    java.awt.Paint var9 = var0.getDomainGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test18"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearAnnotations();
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var6 = var5.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var8 = var7.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var9 = null;
    var7.setTickUnit(var9, false, true);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var14 = var13.getTickMarkPosition();
    var7.setTickMarkPosition(var14);
    var5.setTickMarkPosition(var14);
    var5.setInverted(true);
    org.jfree.chart.axis.DateTickUnit var19 = var5.getTickUnit();
    var0.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var22 = null;
    var21.datasetChanged(var22);
    org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
    var21.setRenderer(1, var25);
    org.jfree.chart.util.RectangleEdge var28 = var21.getDomainAxisEdge(10);
    boolean var30 = var21.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var32 = var21.getRangeAxisLocation(0);
    java.awt.Graphics2D var33 = null;
    java.awt.geom.Rectangle2D var34 = null;
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    org.jfree.chart.plot.CrosshairState var37 = null;
    boolean var38 = var21.render(var33, var34, 100, var36, var37);
    var21.configureDomainAxes();
    java.awt.Stroke var40 = var21.getDomainZeroBaselineStroke();
    var0.setDomainZeroBaselineStroke(var40);
    org.jfree.chart.axis.AxisLocation var43 = var0.getDomainAxisLocation(4);
    java.awt.Stroke var44 = var0.getRangeGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test19"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var3 = var2.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var4 = null;
    var2.setTickUnit(var4, false, true);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var9 = var8.getTickMarkPosition();
    var2.setTickMarkPosition(var9);
    var0.setTickMarkPosition(var9);
    org.jfree.chart.axis.DateTickUnit var12 = null;
    var0.setTickUnit(var12);
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var15 = null;
    var14.datasetChanged(var15);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    var14.setRenderer(1, var18);
    org.jfree.chart.util.RectangleEdge var21 = var14.getDomainAxisEdge(10);
    boolean var23 = var14.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var25 = var14.getRangeAxisLocation(0);
    var14.setRangeCrosshairVisible(false);
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    var14.drawBackgroundImage(var28, var29);
    java.lang.String var31 = var14.getPlotType();
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var34 = var33.getTickMarkPosition();
    var33.configure();
    var14.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var33, false);
    org.jfree.chart.axis.Timeline var38 = null;
    var33.setTimeline(var38);
    org.jfree.data.general.PieDataset var40 = null;
    org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
    org.jfree.chart.util.RectangleInsets var42 = var41.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var43 = null;
    var41.setToolTipGenerator(var43);
    org.jfree.chart.labels.PieSectionLabelGenerator var45 = var41.getLegendLabelToolTipGenerator();
    var41.setLabelLinkMargin(100.0d);
    org.jfree.chart.labels.PieSectionLabelGenerator var48 = var41.getLabelGenerator();
    java.awt.Paint var49 = var41.getLabelPaint();
    org.jfree.chart.axis.DateAxis var50 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var51 = var50.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var52 = null;
    var50.setTickUnit(var52, false, true);
    org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var57 = var56.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var59 = var58.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var60 = null;
    var58.setTickUnit(var60, false, true);
    org.jfree.chart.axis.DateAxis var64 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var65 = var64.getTickMarkPosition();
    var58.setTickMarkPosition(var65);
    var56.setTickMarkPosition(var65);
    org.jfree.chart.axis.DateAxis var68 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var69 = var68.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var70 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var71 = var70.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var72 = null;
    var70.setTickUnit(var72, false, true);
    org.jfree.chart.axis.DateAxis var76 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var77 = var76.getTickMarkPosition();
    var70.setTickMarkPosition(var77);
    var68.setTickMarkPosition(var77);
    var68.setInverted(true);
    org.jfree.chart.axis.DateTickUnit var82 = var68.getTickUnit();
    java.util.Date var83 = var56.calculateHighestVisibleTickValue(var82);
    var50.setTickUnit(var82);
    org.jfree.chart.axis.DateTickUnit var85 = var50.getTickUnit();
    java.awt.Paint var86 = var41.getSectionOutlinePaint((java.lang.Comparable)var85);
    var33.setTickUnit(var85, true, false);
    java.util.Date var90 = var0.calculateLowestVisibleTickValue(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "XY Plot"+ "'", var31.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test20"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.data.general.WaferMapDataset var3 = var2.getDataset();
    java.lang.String var4 = var2.getPlotType();
    org.jfree.data.general.WaferMapDataset var5 = null;
    var2.setDataset(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "WMAP_Plot"+ "'", var4.equals("WMAP_Plot"));

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test21"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var1 = null;
//     var0.datasetChanged(var1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     var0.setRenderer(1, var4);
//     org.jfree.chart.util.RectangleEdge var7 = var0.getDomainAxisEdge(10);
//     boolean var9 = var0.equals((java.lang.Object)(-1));
//     org.jfree.chart.axis.AxisLocation var11 = var0.getRangeAxisLocation(0);
//     var0.setRangeCrosshairVisible(false);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var0.drawBackgroundImage(var14, var15);
//     java.lang.String var17 = var0.getPlotType();
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.DateTickMarkPosition var20 = var19.getTickMarkPosition();
//     var19.configure();
//     var0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var19, false);
//     org.jfree.chart.axis.Timeline var24 = null;
//     var19.setTimeline(var24);
//     var19.setUpperMargin(0.0d);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test22"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
//     var0.setRangeCrosshairValue(10.0d, true);
//     boolean var5 = var0.isDomainZeroBaselineVisible();
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRendererForDataset(var6);
//     boolean var8 = var0.isDomainCrosshairVisible();
//     java.awt.Stroke var9 = var0.getOutlineStroke();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setForegroundAlpha(1.0f);
//     java.awt.Font var14 = var11.getNoDataMessageFont();
//     var11.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var11);
//     java.awt.Paint var18 = var17.getBackgroundPaint();
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
//     org.jfree.chart.util.RectangleInsets var21 = var20.getLabelPadding();
//     org.jfree.chart.util.UnitType var22 = var21.getUnitType();
//     var17.setPadding(var21);
//     org.jfree.chart.title.TextTitle var24 = var17.getTitle();
//     var24.setHeight(0.08d);
//     org.jfree.chart.block.BlockFrame var27 = var24.getFrame();
//     boolean var28 = var0.equals((java.lang.Object)var24);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.setForegroundAlpha(1.0f);
//     java.awt.Font var33 = var30.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     org.jfree.chart.util.RectangleInsets var36 = var35.getLabelPadding();
//     var35.setSectionOutlinesVisible(true);
//     java.awt.Paint var39 = var35.getBaseSectionPaint();
//     var30.setRangeCrosshairPaint(var39);
//     java.lang.Object var41 = var30.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var45 = null;
//     var44.datasetChanged(var45);
//     java.awt.Paint var47 = var44.getRangeZeroBaselinePaint();
//     var44.setRangeGridlinesVisible(true);
//     var44.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var55 = var54.getQuadrantOrigin();
//     var44.zoomRangeAxes(0.0d, var53, var55);
//     var30.zoomDomainAxes((-1.0d), var43, var55);
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var63 = var62.clone();
//     org.jfree.chart.axis.ValueAxis[] var64 = new org.jfree.chart.axis.ValueAxis[] { var62};
//     var61.setDomainAxes(var64);
//     java.awt.geom.Point2D var66 = var61.getQuadrantOrigin();
//     var30.zoomDomainAxes(0.2d, 1.0E-5d, var60, var66);
//     org.jfree.chart.axis.AxisLocation var69 = var30.getDomainAxisLocation((-2));
//     var0.setRangeAxisLocation(2, var69);
//     
//     // Checks the contract:  equals-hashcode on var20 and var35
//     assertTrue("Contract failed: equals-hashcode on var20 and var35", var20.equals(var35) ? var20.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var20
//     assertTrue("Contract failed: equals-hashcode on var35 and var20", var35.equals(var20) ? var35.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test23"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
//     var0.setDomainAxes(var3);
//     java.awt.geom.Point2D var5 = var0.getQuadrantOrigin();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRenderer((-65536));
//     org.jfree.chart.plot.Plot var8 = var0.getRootPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     var0.handleClick((-8372160), 11, var11);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test24"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 3.0d, 100.0d);
    var4.clear();
    org.jfree.chart.block.BlockContainer var6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    org.jfree.chart.block.FlowArrangement var7 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var8 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var12 = var11.clone();
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot(var13);
    org.jfree.chart.util.RectangleInsets var15 = var14.getLabelPadding();
    var14.setSectionOutlinesVisible(true);
    java.awt.Paint var18 = var14.getBaseSectionPaint();
    var11.setAxisLinePaint(var18);
    double var20 = var11.getLowerMargin();
    boolean var21 = var11.isVerticalTickLabels();
    var11.setPositiveArrowVisible(true);
    org.jfree.data.Range var24 = var11.getRange();
    org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(3.0d, var24);
    org.jfree.chart.util.Size2D var26 = var7.arrange(var8, var9, var25);
    org.jfree.chart.block.Arrangement var27 = var8.getArrangement();
    var8.clear();
    java.lang.Object var29 = null;
    var6.add((org.jfree.chart.block.Block)var8, var29);
    double var31 = var6.getWidth();
    boolean var32 = var6.isEmpty();
    var6.setID("RectangleAnchor.TOP_LEFT");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test25"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getDepthFactor();
    double var2 = var0.getDepthFactor();
    java.awt.Paint var3 = null;
    var0.setLabelBackgroundPaint(var3);
    org.jfree.chart.plot.AbstractPieLabelDistributor var5 = var0.getLabelDistributor();
    int var6 = var0.getPieIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test26"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    var0.setAnchorValue(0.0d);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var19 = var0.getDomainAxisIndex(var18);
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var21 = null;
    var20.setMarkerBand(var21);
    boolean var23 = var18.equals((java.lang.Object)var21);
    var18.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test27"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
    java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var12);
    var1.setDomainGridlinePaint((java.awt.Paint)var12);
    org.jfree.chart.plot.CategoryMarker var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addDomainMarker(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test28"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.BasicProjectInfo var6 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var6.addOptionalLibrary("");
    var0.addOptionalLibrary((org.jfree.chart.ui.Library)var6);
    var0.setVersion("HorizontalAlignment.CENTER");

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test29"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.Plot var5 = var4.getPlot();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.setForegroundAlpha(1.0f);
    java.awt.Font var10 = var7.getNoDataMessageFont();
    var7.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var7);
    java.awt.Paint var14 = var13.getBackgroundPaint();
    org.jfree.data.general.PieDataset var15 = null;
    org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
    org.jfree.chart.util.RectangleInsets var17 = var16.getLabelPadding();
    org.jfree.chart.util.UnitType var18 = var17.getUnitType();
    var13.setPadding(var17);
    var4.setChart(var13);
    org.jfree.chart.event.ChartChangeEventType var21 = null;
    var4.setType(var21);
    org.jfree.chart.plot.Plot var23 = var4.getPlot();
    org.jfree.chart.JFreeChart var24 = var4.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test30"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    var0.setRenderer(var5);
    java.awt.Stroke var7 = var0.getRangeCrosshairStroke();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var10 = var9.getLabelURL();
    var9.resizeRange(10.0d);
    java.awt.Paint var13 = var9.getTickMarkPaint();
    var9.setLabelAngle((-1.0d));
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var9);
    var9.setTickMarksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test31"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 10.0d, (-1.0d));
    var4.clear();

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test32"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var0.setRangeCrosshairPaint(var9);
    java.lang.Object var11 = var0.clone();
    org.jfree.chart.LegendItemCollection var12 = var0.getLegendItems();
    var0.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var15 = null;
    var0.setFixedDomainAxisSpace(var15);
    int var17 = var0.getDatasetCount();
    var0.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var20 = var19.clone();
    org.jfree.chart.util.RectangleInsets var21 = var19.getLabelInsets();
    double var23 = var21.calculateRightOutset(100.0d);
    java.lang.String var24 = var21.toString();
    double var26 = var21.extendHeight(0.0d);
    double var28 = var21.calculateLeftOutset(100.0d);
    double var30 = var21.calculateBottomOutset(100.0d);
    var0.setAxisOffset(var21);
    org.jfree.chart.util.RectangleInsets var32 = var0.getAxisOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var24.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test33"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    var0.setRenderer(1, var4);
    org.jfree.chart.util.RectangleEdge var7 = var0.getDomainAxisEdge(10);
    boolean var9 = var0.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var11 = var0.getRangeAxisLocation(0);
    boolean var12 = var0.isDomainCrosshairLockedOnData();
    var0.setDomainZeroBaselineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test34"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("Range[0.0,1.0]");

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test35"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     java.awt.Shape var3 = var1.getLeftArrow();
//     org.jfree.chart.renderer.PolarItemRenderer var4 = null;
//     org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var11 = var10.clone();
//     org.jfree.chart.axis.ValueAxis[] var12 = new org.jfree.chart.axis.ValueAxis[] { var10};
//     var9.setDomainAxes(var12);
//     java.awt.geom.Point2D var14 = var9.getQuadrantOrigin();
//     var5.zoomDomainAxes(0.2d, 2.0d, var8, var14);
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var17.getLabelPadding();
//     boolean var19 = var17.getLabelLinksVisible();
//     java.awt.Stroke var20 = var17.getBaseSectionOutlineStroke();
//     var5.setRadiusGridlineStroke(var20);
//     org.jfree.chart.axis.ValueAxis var22 = var5.getAxis();
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var30 = var29.getQuadrantOrigin();
//     var25.zoomDomainAxes((-1.0d), 3.0d, var28, var30);
//     var5.zoomRangeAxes((-1.88d), var24, var30);
//     org.jfree.chart.plot.PlotOrientation var33 = var5.getOrientation();
//     java.awt.Graphics2D var34 = null;
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot(var36);
//     org.jfree.chart.util.RectangleInsets var38 = var37.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var39 = null;
//     var37.setToolTipGenerator(var39);
//     java.awt.Font var41 = var37.getLabelFont();
//     org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var41);
//     var42.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var48 = var42.getURLText();
//     org.jfree.chart.util.VerticalAlignment var49 = var42.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var50 = var42.getBounds();
//     org.jfree.chart.entity.ChartEntity var52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var50, "");
//     java.awt.geom.Point2D var53 = null;
//     org.jfree.chart.plot.PlotState var54 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var55 = null;
//     var5.draw(var34, var50, var53, var54, var55);
//     
//     // Checks the contract:  equals-hashcode on var17 and var37
//     assertTrue("Contract failed: equals-hashcode on var17 and var37", var17.equals(var37) ? var17.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var17
//     assertTrue("Contract failed: equals-hashcode on var37 and var17", var37.equals(var17) ? var37.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test36"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.data.xy.XYDataset var6 = var0.getDataset(100);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var9 = null;
    var7.setDomainAxisLocation(1, var9, false);
    java.awt.Stroke var12 = var7.getRangeCrosshairStroke();
    var7.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.LegendItemCollection var15 = var7.getLegendItems();
    org.jfree.chart.util.Layer var17 = null;
    java.util.Collection var18 = var7.getRangeMarkers((-65536), var17);
    java.awt.Stroke var19 = var7.getDomainZeroBaselineStroke();
    var0.setDomainGridlineStroke(var19);
    var0.setRangeCrosshairValue(6.0d, false);
    var0.configureRangeAxes();
    org.jfree.chart.axis.AxisSpace var25 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    var27.setForegroundAlpha(1.0f);
    java.awt.Font var30 = var27.getNoDataMessageFont();
    var27.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var27);
    org.jfree.chart.axis.AxisLocation var34 = var27.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var35 = var27.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var36 = null;
    org.jfree.chart.util.VerticalAlignment var37 = null;
    org.jfree.chart.block.ColumnArrangement var40 = new org.jfree.chart.block.ColumnArrangement(var36, var37, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var41 = null;
    org.jfree.chart.util.VerticalAlignment var42 = null;
    org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27, (org.jfree.chart.block.Arrangement)var40, (org.jfree.chart.block.Arrangement)var45);
    org.jfree.data.general.PieDataset var47 = null;
    org.jfree.chart.plot.PiePlot var48 = new org.jfree.chart.plot.PiePlot(var47);
    org.jfree.chart.util.RectangleInsets var49 = var48.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var50 = null;
    var48.setToolTipGenerator(var50);
    java.awt.Stroke var52 = var48.getBaseSectionOutlineStroke();
    java.awt.Paint var53 = var48.getLabelLinkPaint();
    var46.setItemPaint(var53);
    java.awt.Paint var55 = var46.getItemPaint();
    java.awt.Paint var56 = var46.getItemPaint();
    var0.setDomainZeroBaselinePaint(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test37"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var16.setDomainAxisLocation(1, var18, false);
    java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
    boolean var22 = var15.equals((java.lang.Object)var21);
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var27 = null;
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var9, var21, (java.awt.Paint)var26, var27, 1.0f);
    org.jfree.chart.event.MarkerChangeListener var30 = null;
    var29.addChangeListener(var30);
    org.jfree.chart.util.Layer var32 = null;
    boolean var33 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var29, var32);
    var0.mapDatasetToRangeAxis(10, 3);
    var0.clearDomainMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test38"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     org.jfree.chart.util.RectangleInsets var23 = var22.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var24 = null;
//     var22.setToolTipGenerator(var24);
//     java.awt.Stroke var26 = var22.getBaseSectionOutlineStroke();
//     java.awt.Paint var27 = var22.getLabelLinkPaint();
//     var20.setItemPaint(var27);
//     java.awt.Paint var29 = var20.getItemPaint();
//     java.awt.Paint var30 = var20.getItemPaint();
//     org.jfree.chart.block.BlockContainer var31 = new org.jfree.chart.block.BlockContainer();
//     var20.setWrapper(var31);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.setForegroundAlpha(1.0f);
//     java.awt.Font var37 = var34.getNoDataMessageFont();
//     var34.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var34);
//     org.jfree.chart.axis.AxisLocation var41 = var34.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var42 = var34.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var43 = null;
//     org.jfree.chart.util.VerticalAlignment var44 = null;
//     org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement(var43, var44, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var48 = null;
//     org.jfree.chart.util.VerticalAlignment var49 = null;
//     org.jfree.chart.block.ColumnArrangement var52 = new org.jfree.chart.block.ColumnArrangement(var48, var49, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34, (org.jfree.chart.block.Arrangement)var47, (org.jfree.chart.block.Arrangement)var52);
//     org.jfree.chart.LegendItemSource[] var54 = var53.getSources();
//     org.jfree.chart.util.RectangleAnchor var55 = var53.getLegendItemGraphicAnchor();
//     var20.setLegendItemGraphicLocation(var55);
//     
//     // Checks the contract:  equals-hashcode on var1 and var34
//     assertTrue("Contract failed: equals-hashcode on var1 and var34", var1.equals(var34) ? var1.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var1
//     assertTrue("Contract failed: equals-hashcode on var34 and var1", var34.equals(var1) ? var34.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var40
//     assertTrue("Contract failed: equals-hashcode on var7 and var40", var7.equals(var40) ? var7.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var7
//     assertTrue("Contract failed: equals-hashcode on var40 and var7", var40.equals(var7) ? var40.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var47
//     assertTrue("Contract failed: equals-hashcode on var14 and var47", var14.equals(var47) ? var14.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var52
//     assertTrue("Contract failed: equals-hashcode on var19 and var52", var19.equals(var52) ? var19.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var14
//     assertTrue("Contract failed: equals-hashcode on var47 and var14", var47.equals(var14) ? var47.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var19
//     assertTrue("Contract failed: equals-hashcode on var52 and var19", var52.equals(var19) ? var52.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test39"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var1 = null;
    var0.setMarkerBand(var1);
    java.awt.Font var3 = var0.getTickLabelFont();
    var0.setTickLabelsVisible(true);
    java.awt.Color var10 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var19 = null;
    var17.setDomainAxisLocation(1, var19, false);
    java.awt.Stroke var22 = var17.getRangeCrosshairStroke();
    boolean var23 = var16.equals((java.lang.Object)var22);
    java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var28 = null;
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var10, var22, (java.awt.Paint)var27, var28, 1.0f);
    int var31 = var27.getTransparency();
    var0.setLabelPaint((java.awt.Paint)var27);
    java.awt.Color var33 = var27.darker();
    float[] var35 = new float[] { 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var36 = var27.getColorComponents(var35);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test40"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.clearCategoryLabelToolTips();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var4 = var3.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var6 = var5.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var7 = null;
    var5.setTickUnit(var7, false, true);
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var12 = var11.getTickMarkPosition();
    var5.setTickMarkPosition(var12);
    var3.setTickMarkPosition(var12);
    org.jfree.chart.axis.DateTickUnit var15 = null;
    var3.setTickUnit(var15);
    org.jfree.chart.axis.DateTickUnit var17 = null;
    var3.setTickUnit(var17, true, false);
    double var21 = var3.getLowerBound();
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var23 = null;
    var22.setFixedLegendItems(var23);
    java.awt.Graphics2D var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    boolean var29 = var22.render(var25, var26, 10, var28);
    org.jfree.chart.axis.AxisLocation var30 = var22.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var34 = var33.getUpperMargin();
    var22.setDomainAxis(10, var33, false);
    var33.setCategoryLabelPositionOffset((-65536));
    java.awt.Font var39 = var33.getTickLabelFont();
    org.jfree.data.xy.XYDataset var40 = null;
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var42 = var41.clone();
    java.awt.Shape var43 = var41.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var44 = null;
    org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot(var40, (org.jfree.chart.axis.ValueAxis)var41, var44);
    org.jfree.chart.plot.PlotRenderingInfo var48 = null;
    org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var51 = var50.clone();
    org.jfree.chart.axis.ValueAxis[] var52 = new org.jfree.chart.axis.ValueAxis[] { var50};
    var49.setDomainAxes(var52);
    java.awt.geom.Point2D var54 = var49.getQuadrantOrigin();
    var45.zoomDomainAxes(0.2d, 2.0d, var48, var54);
    boolean var56 = var45.isAngleGridlinesVisible();
    boolean var57 = var45.isDomainZoomable();
    var45.setAngleLabelsVisible(true);
    java.lang.Object var60 = var45.clone();
    int var61 = var45.getSeriesCount();
    org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var63 = var62.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var64 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var65 = var64.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var66 = null;
    var64.setTickUnit(var66, false, true);
    org.jfree.chart.axis.DateAxis var70 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var71 = var70.getTickMarkPosition();
    var64.setTickMarkPosition(var71);
    var62.setTickMarkPosition(var71);
    java.text.DateFormat var74 = var62.getDateFormatOverride();
    var62.setAutoTickUnitSelection(false);
    org.jfree.chart.axis.DateAxis var77 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var78 = var77.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var79 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var80 = var79.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var81 = null;
    var79.setTickUnit(var81, false, true);
    org.jfree.chart.axis.DateAxis var85 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var86 = var85.getTickMarkPosition();
    var79.setTickMarkPosition(var86);
    var77.setTickMarkPosition(var86);
    var77.setInverted(true);
    org.jfree.chart.axis.DateTickUnit var91 = var77.getTickUnit();
    var62.setTickUnit(var91);
    var45.setAngleTickUnit((org.jfree.chart.axis.TickUnit)var91);
    var33.removeCategoryLabelToolTip((java.lang.Comparable)var91);
    java.util.Date var95 = var3.calculateLowestVisibleTickValue(var91);
    var1.removeCategoryLabelToolTip((java.lang.Comparable)var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test41"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var1 = var0.getLabelURL();
    var0.resizeRange(10.0d);
    java.awt.Paint var4 = var0.getTickMarkPaint();
    var0.setLowerMargin(2.0d);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    var7.setTickMarksVisible(false);
    org.jfree.data.Range var10 = var7.getRange();
    var0.setRangeWithMargins(var10, false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test42"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.chart.axis.AxisLocation var9 = var0.getRangeAxisLocation();
    org.jfree.chart.util.Layer var11 = null;
    java.util.Collection var12 = var0.getDomainMarkers(1, var11);
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var0.getRangeMarkers(var13);
    org.jfree.chart.plot.CategoryMarker var15 = null;
    org.jfree.chart.util.Layer var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test43"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.block.RectangleConstraint var12 = var11.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var14 = var11.toFixedHeight(0.05d);
    org.jfree.data.Range var15 = var14.getHeightRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test44"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    boolean var3 = var1.getLabelLinksVisible();
    java.awt.Stroke var4 = var1.getBaseSectionOutlineStroke();
    double var5 = var1.getMaximumLabelWidth();
    org.jfree.chart.util.Rotation var6 = var1.getDirection();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var9 = var8.getUpperMargin();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var11 = var10.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var13 = var12.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var14 = null;
    var12.setTickUnit(var14, false, true);
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var19 = var18.getTickMarkPosition();
    var12.setTickMarkPosition(var19);
    var10.setTickMarkPosition(var19);
    var10.setInverted(true);
    org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var25 = var24.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var27 = var26.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var28 = null;
    var26.setTickUnit(var28, false, true);
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var33 = var32.getTickMarkPosition();
    var26.setTickMarkPosition(var33);
    var24.setTickMarkPosition(var33);
    java.util.TimeZone var36 = var24.getTimeZone();
    var10.setTimeZone(var36);
    org.jfree.chart.axis.Timeline var38 = var10.getTimeline();
    org.jfree.chart.axis.DateTickUnit var39 = var10.getTickUnit();
    java.awt.Font var40 = var8.getTickLabelFont((java.lang.Comparable)var39);
    boolean var41 = var6.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test45"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var13 = var7.getURLText();
    var7.setURLText("RectangleConstraintType.RANGE");
    var7.setNotify(true);
    java.awt.Paint var18 = null;
    var7.setBackgroundPaint(var18);
    double var20 = var7.getContentYOffset();
    java.lang.Object var21 = var7.clone();
    java.lang.String var22 = var7.getID();
    java.awt.Paint var23 = null;
    var7.setBackgroundPaint(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test46"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
    var3.setSectionOutlinesVisible(true);
    java.awt.Paint var7 = var3.getBaseSectionPaint();
    var0.setAxisLinePaint(var7);
    double var9 = var0.getLowerMargin();
    boolean var10 = var0.isVerticalTickLabels();
    var0.setPositiveArrowVisible(true);
    org.jfree.data.Range var13 = var0.getRange();
    double var14 = var0.getLabelAngle();
    org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var16 = var15.getNextFillPaint();
    java.awt.Stroke var17 = var15.getNextOutlineStroke();
    java.awt.Stroke var18 = var15.getNextStroke();
    java.awt.Shape var19 = var15.getNextShape();
    var0.setUpArrow(var19);
    boolean var21 = var0.isAutoTickUnitSelection();
    var0.setFixedDimension(6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test47"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    boolean var3 = var1.getLabelLinksVisible();
    java.awt.Stroke var4 = var1.getBaseSectionOutlineStroke();
    double var5 = var1.getMaximumLabelWidth();
    org.jfree.chart.util.Rotation var6 = var1.getDirection();
    double var7 = var6.getFactor();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.setForegroundAlpha(1.0f);
    java.awt.Paint var11 = var8.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var12 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var8);
    var8.configureRangeAxes();
    boolean var14 = var8.isDomainZoomable();
    org.jfree.chart.axis.CategoryAxis var15 = null;
    java.util.List var16 = var8.getCategoriesForAxis(var15);
    java.awt.Paint var17 = var8.getRangeCrosshairPaint();
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var19 = null;
    var18.datasetChanged(var19);
    java.awt.Stroke var21 = var18.getRangeGridlineStroke();
    var8.setDomainGridlineStroke(var21);
    org.jfree.chart.plot.Plot var23 = var8.getParent();
    boolean var24 = var6.equals((java.lang.Object)var8);
    double var25 = var6.getFactor();
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var28 = var27.getLabelURL();
    var27.configure();
    java.awt.Paint var30 = var27.getTickLabelPaint();
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
    var31.setTickMarksVisible(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.axis.ValueAxis)var31, var34);
    double var36 = var31.getAutoRangeMinimumSize();
    var31.setVerticalTickLabels(false);
    var31.setLabelToolTip("");
    boolean var41 = var31.getAutoRangeIncludesZero();
    boolean var42 = var6.equals((java.lang.Object)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test48"); }


    java.awt.Color var2 = java.awt.Color.getColor("Category Plot", 10);
    int var3 = var2.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test49"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.MarkerAxisBand var1 = null;
//     var0.setMarkerBand(var1);
//     var0.setUpperBound(1.0d);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var9.setCategoryLabelPositionOffset(1);
//     var9.setFixedDimension(0.0d);
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var17 = var16.clone();
//     org.jfree.chart.util.RectangleInsets var18 = var16.getLabelInsets();
//     double var20 = var18.calculateRightOutset(100.0d);
//     java.lang.String var21 = var18.toString();
//     double var23 = var18.extendHeight(0.0d);
//     double var25 = var18.calculateLeftOutset(100.0d);
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     org.jfree.chart.util.RectangleInsets var29 = var28.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var30 = null;
//     var28.setToolTipGenerator(var30);
//     java.awt.Font var32 = var28.getLabelFont();
//     org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var32);
//     var33.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var39 = var33.getURLText();
//     org.jfree.chart.util.VerticalAlignment var40 = var33.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var41 = var33.getBounds();
//     var18.trim(var41);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     var43.setForegroundAlpha(1.0f);
//     java.awt.Font var46 = var43.getNoDataMessageFont();
//     var43.setAnchorValue(0.0d, false);
//     org.jfree.chart.util.RectangleEdge var51 = var43.getDomainAxisEdge(10);
//     double var52 = var9.getCategoryStart(10, 0, var41, var51);
//     org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var54 = null;
//     var53.setFixedDomainAxisSpace(var54, true);
//     var53.clearDomainMarkers(100);
//     org.jfree.chart.util.RectangleEdge var60 = var53.getRangeAxisEdge(0);
//     boolean var61 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var60);
//     boolean var62 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var60);
//     double var63 = org.jfree.chart.util.RectangleEdge.coordinate(var41, var60);
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
//     var64.setForegroundAlpha(1.0f);
//     org.jfree.chart.plot.PlotRenderingInfo var68 = null;
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var71 = var70.clone();
//     org.jfree.chart.axis.ValueAxis[] var72 = new org.jfree.chart.axis.ValueAxis[] { var70};
//     var69.setDomainAxes(var72);
//     org.jfree.data.xy.XYDataset var75 = var69.getDataset(100);
//     org.jfree.chart.plot.PlotRenderingInfo var77 = null;
//     org.jfree.chart.plot.XYPlot var78 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var79 = var78.getQuadrantOrigin();
//     var69.zoomRangeAxes(0.0d, var77, var79, false);
//     var64.zoomDomainAxes((-7.0d), var68, var79);
//     org.jfree.chart.axis.NumberAxis var83 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var84 = var83.getLabelURL();
//     var83.configure();
//     java.awt.Paint var86 = var83.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var87 = var83.getTickLabelInsets();
//     double var89 = var87.calculateRightInset(0.05d);
//     var64.setAxisOffset(var87);
//     org.jfree.chart.axis.ValueAxis var92 = var64.getRangeAxis(15);
//     org.jfree.chart.util.RectangleEdge var94 = var64.getDomainAxisEdge((-65536));
//     boolean var95 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var94);
//     org.jfree.chart.plot.PlotRenderingInfo var96 = null;
//     org.jfree.chart.axis.AxisState var97 = var0.draw(var5, 6.18d, var7, var41, var94, var96);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test50"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 3.0d, 100.0d);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.setForegroundAlpha(1.0f);
    java.awt.Font var9 = var6.getNoDataMessageFont();
    var6.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var6);
    org.jfree.chart.axis.AxisLocation var13 = var6.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var14 = var6.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var20 = null;
    org.jfree.chart.util.VerticalAlignment var21 = null;
    org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var19, (org.jfree.chart.block.Arrangement)var24);
    org.jfree.data.general.PieDataset var26 = null;
    org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
    org.jfree.chart.util.RectangleInsets var28 = var27.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var29 = null;
    var27.setToolTipGenerator(var29);
    java.awt.Stroke var31 = var27.getBaseSectionOutlineStroke();
    java.awt.Paint var32 = var27.getLabelLinkPaint();
    var25.setItemPaint(var32);
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var36 = null;
    var34.setDomainAxisLocation(1, var36, false);
    java.awt.Stroke var39 = var34.getRangeCrosshairStroke();
    var34.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.Plot var42 = var34.getRootPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    var34.setRenderer(var43);
    java.awt.Paint var45 = var34.getDomainZeroBaselinePaint();
    var25.setItemPaint(var45);
    var25.setHeight(0.0d);
    java.lang.Object var49 = null;
    var4.add((org.jfree.chart.block.Block)var25, var49);
    java.awt.Paint var51 = var25.getBackgroundPaint();
    org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var53 = null;
    var52.setFixedLegendItems(var53);
    java.awt.Graphics2D var55 = null;
    java.awt.geom.Rectangle2D var56 = null;
    org.jfree.chart.plot.PlotRenderingInfo var58 = null;
    boolean var59 = var52.render(var55, var56, 10, var58);
    org.jfree.chart.axis.AxisLocation var60 = var52.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var63 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var64 = var63.getUpperMargin();
    var52.setDomainAxis(10, var63, false);
    var52.setAnchorValue(0.0d);
    org.jfree.chart.renderer.category.CategoryItemRenderer var69 = var52.getRenderer();
    var52.setOutlineVisible(true);
    org.jfree.chart.axis.AxisSpace var72 = var52.getFixedRangeAxisSpace();
    org.jfree.chart.util.RectangleEdge var73 = var52.getDomainAxisEdge();
    var25.setLegendItemGraphicEdge(var73);
    org.jfree.chart.block.BlockContainer var75 = var25.getItemContainer();
    boolean var76 = var75.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test51"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.block.LengthConstraintType var12 = var11.getHeightConstraintType();
    double var13 = var11.getHeight();
    org.jfree.data.Range var14 = var11.getWidthRange();
    org.jfree.data.Range var15 = var11.getWidthRange();
    org.jfree.chart.block.RectangleConstraint var16 = var11.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var17 = var16.toUnconstrainedHeight();
    double var18 = var16.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test52"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    var0.setAnchorValue(0.0d);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var19 = var0.getDomainAxisIndex(var18);
    java.awt.Paint var20 = var0.getRangeGridlinePaint();
    org.jfree.data.category.CategoryDataset var21 = var0.getDataset();
    var0.setRangeCrosshairVisible(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxis((-254), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test53"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    java.awt.Stroke var3 = var0.getOutlineStroke();
    java.awt.Paint var4 = var0.getRangeZeroBaselinePaint();
    java.awt.Stroke var5 = var0.getOutlineStroke();
    var0.mapDatasetToRangeAxis(100, 0);
    boolean var9 = var0.isDomainZoomable();
    var0.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test54"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.geom.Point2D var5 = var0.getQuadrantOrigin();
    int var6 = var0.getWeight();
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var0.getRangeMarkers(var7);
    org.jfree.chart.util.RectangleEdge var9 = var0.getRangeAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test55"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
    java.lang.String var2 = var1.getPlotType();
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    var1.setRenderer(var3);
    org.jfree.chart.event.RendererChangeEvent var5 = null;
    var1.rendererChanged(var5);
    org.jfree.data.general.WaferMapDataset var7 = null;
    var1.setDataset(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "WMAP_Plot"+ "'", var2.equals("WMAP_Plot"));

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test56"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.util.List var1 = var0.getContributors();
    java.lang.String var2 = var0.getLicenceText();
    java.util.List var3 = var0.getContributors();
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var8);
    org.jfree.chart.util.HorizontalAlignment var10 = null;
    org.jfree.chart.util.VerticalAlignment var11 = null;
    org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setDomainAxisLocation(1, var17, false);
    java.awt.Stroke var20 = var15.getRangeCrosshairStroke();
    boolean var21 = var14.equals((java.lang.Object)var20);
    java.awt.Color var25 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var26 = null;
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var8, var20, (java.awt.Paint)var25, var26, 1.0f);
    java.lang.Object var29 = var28.clone();
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var31 = var30.getQuadrantOrigin();
    var30.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var35 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = var30.getRendererForDataset(var35);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
    var38.setForegroundAlpha(1.0f);
    java.awt.Font var41 = var38.getNoDataMessageFont();
    var38.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var38);
    org.jfree.chart.axis.AxisLocation var45 = var38.getDomainAxisLocation();
    var30.setRangeAxisLocation(var45);
    boolean var47 = var28.equals((java.lang.Object)var30);
    java.awt.Paint var48 = var30.getDomainZeroBaselinePaint();
    org.jfree.data.xy.XYDataset var50 = null;
    var30.setDataset(0, var50);
    java.util.List var52 = var30.getAnnotations();
    var0.setContributors(var52);
    java.lang.String var54 = var0.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test57"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
    var0.mapDatasetToDomainAxis(100, 0);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var7 = var6.getPlotType();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var6.setLegendLabelURLGenerator(var8);
    java.awt.Graphics2D var10 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var15 = null;
    var13.setToolTipGenerator(var15);
    java.awt.Font var17 = var13.getLabelFont();
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var17);
    var18.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var24 = var18.getURLText();
    org.jfree.chart.util.VerticalAlignment var25 = var18.getVerticalAlignment();
    java.awt.geom.Rectangle2D var26 = var18.getBounds();
    var6.drawBackgroundImage(var10, var26);
    java.util.List var28 = null;
    var0.drawRangeTickBands(var5, var26, var28);
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    var31.setForegroundAlpha(1.0f);
    java.awt.Font var34 = var31.getNoDataMessageFont();
    var31.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var31);
    java.awt.Paint var38 = var37.getBackgroundPaint();
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var41 = var40.clone();
    org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var40};
    var39.setDomainAxes(var42);
    org.jfree.data.xy.XYDataset var45 = var39.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
    var39.setRenderer(100, var47, false);
    java.awt.Color var54 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var55 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var54);
    org.jfree.chart.util.HorizontalAlignment var56 = null;
    org.jfree.chart.util.VerticalAlignment var57 = null;
    org.jfree.chart.block.ColumnArrangement var60 = new org.jfree.chart.block.ColumnArrangement(var56, var57, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var63 = null;
    var61.setDomainAxisLocation(1, var63, false);
    java.awt.Stroke var66 = var61.getRangeCrosshairStroke();
    boolean var67 = var60.equals((java.lang.Object)var66);
    java.awt.Color var71 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var72 = null;
    org.jfree.chart.plot.ValueMarker var74 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var54, var66, (java.awt.Paint)var71, var72, 1.0f);
    java.lang.Object var75 = var74.clone();
    var39.addDomainMarker((org.jfree.chart.plot.Marker)var74);
    boolean var77 = var37.equals((java.lang.Object)var74);
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var74);
    org.jfree.chart.util.Layer var79 = null;
    java.util.Collection var80 = var0.getRangeMarkers(var79);
    org.jfree.chart.renderer.xy.XYItemRenderer var82 = var0.getRenderer(15);
    var0.setDomainCrosshairVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Pie 3D Plot"+ "'", var7.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test58"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    java.awt.Shape var3 = var1.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var11 = var10.clone();
    org.jfree.chart.axis.ValueAxis[] var12 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var9.setDomainAxes(var12);
    java.awt.geom.Point2D var14 = var9.getQuadrantOrigin();
    var5.zoomDomainAxes(0.2d, 2.0d, var8, var14);
    boolean var16 = var5.isAngleGridlinesVisible();
    boolean var17 = var5.isDomainZoomable();
    java.awt.Paint var18 = var5.getAngleGridlinePaint();
    boolean var19 = var5.isRangeZoomable();
    java.awt.Font var20 = var5.getAngleLabelFont();
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.setForegroundAlpha(1.0f);
    java.awt.Font var24 = var21.getNoDataMessageFont();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var26 = null;
    var25.setMarkerBand(var26);
    org.jfree.data.Range var28 = var21.getDataRange((org.jfree.chart.axis.ValueAxis)var25);
    var25.setLabelAngle((-1.0d));
    boolean var31 = var25.getAutoRangeIncludesZero();
    double var32 = var25.getUpperMargin();
    org.jfree.data.Range var33 = var5.getDataRange((org.jfree.chart.axis.ValueAxis)var25);
    java.lang.String var34 = var25.getLabelURL();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test59"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var8 = var7.getBackgroundPaint();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
    org.jfree.chart.util.UnitType var12 = var11.getUnitType();
    var7.setPadding(var11);
    var7.setBorderVisible(true);
    var7.setBackgroundImageAlpha(10.0f);
    int var18 = var7.getSubtitleCount();
    float var19 = var7.getBackgroundImageAlpha();
    org.jfree.chart.plot.CategoryPlot var20 = var7.getCategoryPlot();
    int var21 = var7.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 15);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test60"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    var0.configureRangeAxes();
    boolean var6 = var0.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var8 = var0.getDataset(10);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var0.getRangeMarkers((-65536), var10);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var13 = var12.getLabelURL();
    var12.configure();
    java.awt.Paint var15 = var12.getTickLabelPaint();
    var12.setUpperBound((-7.0d));
    java.awt.Shape var18 = var12.getRightArrow();
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.setForegroundAlpha(1.0f);
    java.awt.Font var24 = var21.getNoDataMessageFont();
    var21.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var21);
    java.awt.Paint var28 = var27.getBackgroundPaint();
    var27.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var30 = var27.getPadding();
    var27.setAntiAlias(true);
    int var33 = var27.getSubtitleCount();
    var27.clearSubtitles();
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var37 = var36.clone();
    org.jfree.chart.axis.ValueAxis[] var38 = new org.jfree.chart.axis.ValueAxis[] { var36};
    var35.setDomainAxes(var38);
    org.jfree.data.xy.XYDataset var41 = var35.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    var35.setRenderer(100, var43, false);
    java.awt.Color var50 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var51 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var50);
    org.jfree.chart.util.HorizontalAlignment var52 = null;
    org.jfree.chart.util.VerticalAlignment var53 = null;
    org.jfree.chart.block.ColumnArrangement var56 = new org.jfree.chart.block.ColumnArrangement(var52, var53, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var59 = null;
    var57.setDomainAxisLocation(1, var59, false);
    java.awt.Stroke var62 = var57.getRangeCrosshairStroke();
    boolean var63 = var56.equals((java.lang.Object)var62);
    java.awt.Color var67 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var68 = null;
    org.jfree.chart.plot.ValueMarker var70 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var50, var62, (java.awt.Paint)var67, var68, 1.0f);
    java.lang.Object var71 = var70.clone();
    var35.addDomainMarker((org.jfree.chart.plot.Marker)var70);
    java.awt.Paint var73 = var70.getOutlinePaint();
    var27.setBorderPaint(var73);
    var12.setTickLabelPaint(var73);
    var12.setRangeAboutValue(2.2d, 1.05d);
    double var79 = var12.getFixedAutoRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test61"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var1 = var0.getPlotType();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var3 = null;
    var2.setFixedDomainAxisSpace(var3, true);
    var2.clearDomainMarkers(100);
    var2.setOutlineVisible(true);
    org.jfree.data.general.DatasetGroup var10 = var2.getDatasetGroup();
    boolean var11 = var2.isDomainCrosshairVisible();
    java.awt.Color var16 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var16);
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    org.jfree.chart.util.VerticalAlignment var19 = null;
    org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement(var18, var19, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var25 = null;
    var23.setDomainAxisLocation(1, var25, false);
    java.awt.Stroke var28 = var23.getRangeCrosshairStroke();
    boolean var29 = var22.equals((java.lang.Object)var28);
    java.awt.Color var33 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var34 = null;
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var16, var28, (java.awt.Paint)var33, var34, 1.0f);
    java.awt.color.ColorSpace var37 = var16.getColorSpace();
    var2.setDomainCrosshairPaint((java.awt.Paint)var16);
    var0.setBaseSectionOutlinePaint((java.awt.Paint)var16);
    var0.setDepthFactor((-7.0d));
    org.jfree.chart.util.Rotation var42 = var0.getDirection();
    double var43 = var42.getFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Pie 3D Plot"+ "'", var1.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-1.0d));

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test62"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var1 = var0.getPlotType();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var3 = null;
    var2.setFixedDomainAxisSpace(var3, true);
    var2.clearDomainMarkers(100);
    var2.setOutlineVisible(true);
    org.jfree.data.general.DatasetGroup var10 = var2.getDatasetGroup();
    boolean var11 = var2.isDomainCrosshairVisible();
    java.awt.Color var16 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var16);
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    org.jfree.chart.util.VerticalAlignment var19 = null;
    org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement(var18, var19, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var25 = null;
    var23.setDomainAxisLocation(1, var25, false);
    java.awt.Stroke var28 = var23.getRangeCrosshairStroke();
    boolean var29 = var22.equals((java.lang.Object)var28);
    java.awt.Color var33 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var34 = null;
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var16, var28, (java.awt.Paint)var33, var34, 1.0f);
    java.awt.color.ColorSpace var37 = var16.getColorSpace();
    var2.setDomainCrosshairPaint((java.awt.Paint)var16);
    var0.setBaseSectionOutlinePaint((java.awt.Paint)var16);
    int var40 = var16.getTransparency();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Pie 3D Plot"+ "'", var1.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test63"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Paint var4 = var1.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var5 = var1.getRowRenderingOrder();
    java.awt.Color var10 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var19 = null;
    var17.setDomainAxisLocation(1, var19, false);
    java.awt.Stroke var22 = var17.getRangeCrosshairStroke();
    boolean var23 = var16.equals((java.lang.Object)var22);
    java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var28 = null;
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var10, var22, (java.awt.Paint)var27, var28, 1.0f);
    org.jfree.chart.event.MarkerChangeListener var31 = null;
    var30.addChangeListener(var31);
    var1.addRangeMarker((org.jfree.chart.plot.Marker)var30);
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
    var35.setForegroundAlpha(1.0f);
    java.awt.Font var38 = var35.getNoDataMessageFont();
    var35.setAnchorValue(100.0d);
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var42.setMaximumCategoryLabelLines((-1));
    int var45 = var35.getDomainAxisIndex(var42);
    var1.setDomainAxis(100, var42);
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var49 = var48.getTickLabelFont();
    var48.setAutoRange(false);
    java.text.NumberFormat var52 = var48.getNumberFormatOverride();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var42, (org.jfree.chart.axis.ValueAxis)var48, var53);
    java.awt.Paint var55 = var42.getTickLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test64"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Font var1 = var0.getLabelFont();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.setForegroundAlpha(1.0f);
    java.awt.Paint var6 = var3.getRangeCrosshairPaint();
    var0.setSectionPaint((java.lang.Comparable)0.12d, var6);
    double var9 = var0.getExplodePercent((java.lang.Comparable)(-65536));
    boolean var10 = var0.getIgnoreZeroValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test65"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    var0.configureRangeAxes();
    boolean var6 = var0.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var8 = var0.getDataset(10);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var0.getRangeMarkers((-65536), var10);
    org.jfree.chart.util.Layer var12 = null;
    java.util.Collection var13 = var0.getRangeMarkers(var12);
    org.jfree.chart.plot.CategoryMarker var15 = null;
    org.jfree.chart.util.Layer var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(0, var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test66"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.chart.plot.PiePlotState var11 = var0.initialise(var1, var2, var4, (java.lang.Integer)0, var10);
    java.awt.geom.Rectangle2D var12 = var11.getLinkArea();
    double var13 = var11.getPieCenterY();
    int var14 = var11.getPassesRequired();
    int var15 = var11.getPassesRequired();
    java.awt.geom.Rectangle2D var16 = var11.getExplodedPieArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test67"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.chart.plot.PiePlotState var11 = var0.initialise(var1, var2, var4, (java.lang.Integer)0, var10);
    var0.setSeparatorsVisible(true);
    java.lang.Object var14 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test68"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    boolean var3 = var1.getLabelLinksVisible();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var5);
    org.jfree.chart.labels.PieSectionLabelGenerator var7 = var1.getLegendLabelToolTipGenerator();
    boolean var8 = var1.getSectionOutlinesVisible();
    var1.setCircular(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test69"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    boolean var3 = var1.getLabelLinksVisible();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var5);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var9 = null;
    var7.setDomainAxisLocation(1, var9, false);
    java.awt.Stroke var12 = var7.getRangeCrosshairStroke();
    var7.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.LegendItemCollection var15 = var7.getLegendItems();
    java.awt.Color var20 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var20);
    org.jfree.chart.util.HorizontalAlignment var22 = null;
    org.jfree.chart.util.VerticalAlignment var23 = null;
    org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var29 = null;
    var27.setDomainAxisLocation(1, var29, false);
    java.awt.Stroke var32 = var27.getRangeCrosshairStroke();
    boolean var33 = var26.equals((java.lang.Object)var32);
    java.awt.Color var37 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var38 = null;
    org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var20, var32, (java.awt.Paint)var37, var38, 1.0f);
    var7.addDomainMarker((org.jfree.chart.plot.Marker)var40);
    java.awt.Stroke var42 = var7.getRangeGridlineStroke();
    var1.setLabelOutlineStroke(var42);
    org.jfree.chart.labels.PieSectionLabelGenerator var44 = var1.getLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test70"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.Range var2 = var0.getRange();
    var0.setUpperBound(0.0d);
    var0.setRange(0.12d, 6.0d);
    var0.setAutoRangeIncludesZero(false);
    org.jfree.chart.axis.TickUnitSource var10 = var0.getStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test71"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    double var3 = var0.getRangeCrosshairValue();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = var0.getRendererForDataset(var4);
    float var6 = var0.getBackgroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test72"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var5.setLicenceName("hi!");
    org.jfree.chart.ui.ProjectInfo var8 = new org.jfree.chart.ui.ProjectInfo();
    java.util.List var9 = var8.getContributors();
    var5.addOptionalLibrary((org.jfree.chart.ui.Library)var8);
    var8.setInfo("Multiple Pie Plot");
    java.lang.String var13 = var8.getName();
    var8.addOptionalLibrary("Other");
    java.util.List var16 = var8.getContributors();
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.BasicProjectInfo var23 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var23.addOptionalLibrary("");
    var17.addOptionalLibrary((org.jfree.chart.ui.Library)var23);
    var8.addLibrary((org.jfree.chart.ui.Library)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test73"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
//     boolean var3 = var1.getLabelLinksVisible();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var5);
//     org.jfree.chart.labels.PieSectionLabelGenerator var7 = var1.getLegendLabelToolTipGenerator();
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     org.jfree.chart.util.RectangleInsets var10 = var9.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var11 = null;
//     var9.setToolTipGenerator(var11);
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var15 = null;
//     var13.setDomainAxisLocation(1, var15, false);
//     java.awt.Stroke var18 = var13.getRangeCrosshairStroke();
//     var9.setBaseSectionOutlineStroke(var18);
//     java.awt.Paint var20 = var9.getLabelShadowPaint();
//     var1.setLabelBackgroundPaint(var20);
//     org.jfree.chart.util.RectangleInsets var22 = var1.getLabelPadding();
//     var1.setLabelLinksVisible(true);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var27 = var26.clone();
//     org.jfree.chart.axis.ValueAxis[] var28 = new org.jfree.chart.axis.ValueAxis[] { var26};
//     var25.setDomainAxes(var28);
//     org.jfree.data.xy.XYDataset var31 = var25.getDataset(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     var25.setRenderer(100, var33, false);
//     java.awt.Color var40 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var40);
//     org.jfree.chart.util.HorizontalAlignment var42 = null;
//     org.jfree.chart.util.VerticalAlignment var43 = null;
//     org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement(var42, var43, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var49 = null;
//     var47.setDomainAxisLocation(1, var49, false);
//     java.awt.Stroke var52 = var47.getRangeCrosshairStroke();
//     boolean var53 = var46.equals((java.lang.Object)var52);
//     java.awt.Color var57 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var58 = null;
//     org.jfree.chart.plot.ValueMarker var60 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var40, var52, (java.awt.Paint)var57, var58, 1.0f);
//     java.lang.Object var61 = var60.clone();
//     var25.addDomainMarker((org.jfree.chart.plot.Marker)var60);
//     java.awt.Paint var63 = var60.getOutlinePaint();
//     var1.setLabelPaint(var63);
//     
//     // Checks the contract:  equals-hashcode on var13 and var47
//     assertTrue("Contract failed: equals-hashcode on var13 and var47", var13.equals(var47) ? var13.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var13
//     assertTrue("Contract failed: equals-hashcode on var47 and var13", var47.equals(var13) ? var47.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test74"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    java.lang.Object var25 = var24.clone();
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var27 = var26.getQuadrantOrigin();
    var26.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = var26.getRendererForDataset(var31);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    var34.setForegroundAlpha(1.0f);
    java.awt.Font var37 = var34.getNoDataMessageFont();
    var34.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var34);
    org.jfree.chart.axis.AxisLocation var41 = var34.getDomainAxisLocation();
    var26.setRangeAxisLocation(var41);
    boolean var43 = var24.equals((java.lang.Object)var26);
    java.awt.Paint var44 = var26.getDomainZeroBaselinePaint();
    org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var47 = var46.clone();
    double var48 = var46.getLowerBound();
    var26.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var46);
    int var50 = var26.getDatasetCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test75"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    var0.setRenderer(var5);
    org.jfree.chart.util.RectangleEdge var8 = var0.getRangeAxisEdge(0);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var0.setFixedRangeAxisSpace(var9, false);
    org.jfree.data.general.DatasetChangeEvent var12 = null;
    var0.datasetChanged(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test76"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisSpace var8 = var0.getFixedDomainAxisSpace();
    java.awt.Paint var9 = var0.getDomainZeroBaselinePaint();
    var0.setDomainCrosshairLockedOnData(false);
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var14.setCategoryLabelPositionOffset(1);
    var14.setUpperMargin(0.0d);
    java.awt.Paint var20 = var14.getTickLabelPaint((java.lang.Comparable)3.0d);
    org.jfree.chart.block.FlowArrangement var23 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var24 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var28 = var27.clone();
    org.jfree.data.general.PieDataset var29 = null;
    org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot(var29);
    org.jfree.chart.util.RectangleInsets var31 = var30.getLabelPadding();
    var30.setSectionOutlinesVisible(true);
    java.awt.Paint var34 = var30.getBaseSectionPaint();
    var27.setAxisLinePaint(var34);
    double var36 = var27.getLowerMargin();
    boolean var37 = var27.isVerticalTickLabels();
    var27.setPositiveArrowVisible(true);
    org.jfree.data.Range var40 = var27.getRange();
    org.jfree.chart.block.RectangleConstraint var41 = new org.jfree.chart.block.RectangleConstraint(3.0d, var40);
    org.jfree.chart.util.Size2D var42 = var23.arrange(var24, var25, var41);
    org.jfree.chart.util.RectangleAnchor var45 = null;
    java.awt.geom.Rectangle2D var46 = org.jfree.chart.util.RectangleAnchor.createRectangle(var42, 2.0d, 10.5d, var45);
    java.lang.String var47 = var42.toString();
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
    var51.setForegroundAlpha(1.0f);
    java.awt.Font var54 = var51.getNoDataMessageFont();
    var51.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var57 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var51);
    org.jfree.chart.axis.AxisLocation var58 = var51.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var59 = var51.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var60 = null;
    org.jfree.chart.util.VerticalAlignment var61 = null;
    org.jfree.chart.block.ColumnArrangement var64 = new org.jfree.chart.block.ColumnArrangement(var60, var61, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var65 = null;
    org.jfree.chart.util.VerticalAlignment var66 = null;
    org.jfree.chart.block.ColumnArrangement var69 = new org.jfree.chart.block.ColumnArrangement(var65, var66, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var70 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var51, (org.jfree.chart.block.Arrangement)var64, (org.jfree.chart.block.Arrangement)var69);
    org.jfree.chart.util.RectangleEdge var71 = var70.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var72 = var70.getLegendItemGraphicAnchor();
    java.awt.geom.Rectangle2D var73 = org.jfree.chart.util.RectangleAnchor.createRectangle(var42, 3.0d, (-45.29999999999999d), var72);
    org.jfree.chart.util.RectangleEdge var74 = null;
    double var75 = var14.getCategoryMiddle(3, 0, var73, var74);
    org.jfree.chart.plot.PlotRenderingInfo var76 = null;
    var0.drawAnnotations(var12, var73, var76);
    var0.zoom((-4.88d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "Size2D[width=3.0, height=0.0]"+ "'", var47.equals("Size2D[width=3.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test77"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    var0.setAnchorValue(0.0d);
    org.jfree.chart.util.RectangleEdge var18 = var0.getDomainAxisEdge((-65536));
    org.jfree.chart.util.RectangleEdge var19 = var0.getDomainAxisEdge();
    var0.setRangeCrosshairVisible(false);
    org.jfree.chart.plot.PlotOrientation var22 = var0.getOrientation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test78"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    org.jfree.chart.labels.PieSectionLabelGenerator var5 = var1.getLegendLabelToolTipGenerator();
    var1.setLabelLinkMargin(100.0d);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var13 = var12.getQuadrantOrigin();
    var8.zoomDomainAxes((-1.0d), 3.0d, var11, var13);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setForegroundAlpha(1.0f);
    java.awt.Font var19 = var16.getNoDataMessageFont();
    var16.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var16);
    org.jfree.chart.axis.AxisLocation var23 = var16.getDomainAxisLocation();
    var8.setDomainAxisLocation(var23);
    java.awt.Stroke var25 = var8.getRangeCrosshairStroke();
    var1.setLabelLinkStroke(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test79"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(3);
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    var1.set(3, (java.lang.Object)var4);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test80"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(2);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test81"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var3 = var2.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var4 = null;
    var2.setTickUnit(var4, false, true);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var9 = var8.getTickMarkPosition();
    var2.setTickMarkPosition(var9);
    var0.setTickMarkPosition(var9);
    var0.setInverted(true);
    double var14 = var0.getLowerBound();
    java.util.TimeZone var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTimeZone(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test82"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var0.setRangeCrosshairPaint(var9);
    java.lang.Object var11 = var0.clone();
    org.jfree.chart.LegendItemCollection var12 = var0.getLegendItems();
    java.awt.Paint var13 = var0.getRangeCrosshairPaint();
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.axis.AxisLocation var16 = var0.getRangeAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test83"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var13 = var7.getURLText();
    var7.setURLText("RectangleConstraintType.RANGE");
    var7.setNotify(true);
    java.lang.String var18 = var7.getURLText();
    var7.setPadding(1.05d, 10.0d, 12.18d, (-7.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var18.equals("RectangleConstraintType.RANGE"));

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test84"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var10 = null;
    org.jfree.chart.util.VerticalAlignment var11 = null;
    org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
    org.jfree.chart.util.RectangleInsets var23 = var22.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var24 = null;
    var22.setToolTipGenerator(var24);
    java.awt.Stroke var26 = var22.getBaseSectionOutlineStroke();
    java.awt.Paint var27 = var22.getLabelLinkPaint();
    var20.setItemPaint(var27);
    java.awt.Paint var29 = var20.getItemPaint();
    java.awt.Paint var30 = var20.getItemPaint();
    org.jfree.chart.LegendItemSource[] var31 = var20.getSources();
    org.jfree.chart.util.RectangleInsets var32 = var20.getMargin();
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var34 = var33.clone();
    org.jfree.chart.util.RectangleInsets var35 = var33.getLabelInsets();
    double var37 = var35.calculateBottomOutset(10.0d);
    double var39 = var35.calculateLeftOutset(100.0d);
    double var41 = var35.trimWidth(0.12d);
    double var43 = var35.calculateTopOutset(100.0d);
    var20.setItemLabelPadding(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-5.88d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 3.0d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test85"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.util.List var1 = var0.getCategories();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var5 = null;
    var4.datasetChanged(var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var4.setRenderer(1, var8);
    org.jfree.chart.util.RectangleEdge var11 = var4.getDomainAxisEdge(10);
    boolean var13 = var4.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var15 = var4.getRangeAxisLocation(0);
    var4.setRangeCrosshairVisible(false);
    java.awt.Graphics2D var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    var4.drawBackgroundImage(var18, var19);
    java.lang.String var21 = var4.getPlotType();
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var24 = var23.getTickMarkPosition();
    var23.configure();
    var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var23, false);
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var32 = null;
    var30.setDomainAxisLocation(1, var32, false);
    java.awt.Stroke var35 = var30.getRangeCrosshairStroke();
    var30.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var41 = var40.getQuadrantOrigin();
    var30.zoomRangeAxes(0.0d, var39, var41, false);
    var4.zoomDomainAxes((-45.29999999999999d), var29, var41);
    var0.zoomRangeAxes((-5.95d), var3, var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "XY Plot"+ "'", var21.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test86"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
    java.lang.String var9 = var1.getPlotType();
    var1.mapDatasetToRangeAxis(0, 0);
    java.awt.Paint var13 = var1.getRangeGridlinePaint();
    java.util.List var14 = var1.getCategories();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "Category Plot"+ "'", var9.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test87"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var0.getRangeMarkers(10, var7);
    java.util.List var9 = var0.getAnnotations();
    org.jfree.chart.plot.PlotOrientation var10 = var0.getOrientation();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setForegroundAlpha(1.0f);
    java.awt.Font var15 = var12.getNoDataMessageFont();
    var12.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var12);
    org.jfree.chart.axis.AxisLocation var19 = var12.getDomainAxisLocation();
    var0.setRangeAxisLocation(var19);
    org.jfree.data.xy.XYDataset var21 = null;
    var0.setDataset(var21);
    int var23 = var0.getDomainAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test88"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    var1.setSectionOutlinesVisible(true);
    java.awt.Paint var5 = var1.getBaseSectionPaint();
    java.awt.Paint var7 = var1.getSectionPaint((java.lang.Comparable)100.0d);
    var1.setShadowXOffset(9.223372036854776E18d);
    java.awt.Shape var10 = var1.getLegendItemShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test89"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(var8);
    org.jfree.chart.axis.AxisSpace var10 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.setForegroundAlpha(1.0f);
    java.awt.Font var16 = var13.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
    org.jfree.chart.util.RectangleInsets var19 = var18.getLabelPadding();
    var18.setSectionOutlinesVisible(true);
    java.awt.Paint var22 = var18.getBaseSectionPaint();
    var13.setRangeCrosshairPaint(var22);
    java.lang.Object var24 = var13.clone();
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var28 = null;
    var27.datasetChanged(var28);
    java.awt.Paint var30 = var27.getRangeZeroBaselinePaint();
    var27.setRangeGridlinesVisible(true);
    var27.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var38 = var37.getQuadrantOrigin();
    var27.zoomRangeAxes(0.0d, var36, var38);
    var13.zoomDomainAxes((-1.0d), var26, var38);
    var0.zoomRangeAxes(100.0d, var12, var38);
    var0.setRangeCrosshairValue(0.03937499999999999d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test90"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-45.29999999999999d), 2.0d, 0.0d, 90.0d);
    java.lang.String var5 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleInsets[t=-45.29999999999999,l=2.0,b=0.0,r=90.0]"+ "'", var5.equals("RectangleInsets[t=-45.29999999999999,l=2.0,b=0.0,r=90.0]"));

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test91"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var0.setRangeCrosshairPaint(var9);
    boolean var11 = var0.isOutlineVisible();
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var0.getRangeMarkers((-8372160), var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test92"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = var0.getRenderer();
    org.jfree.chart.util.RectangleEdge var10 = var0.getRangeAxisEdge();
    var0.clearRangeMarkers();
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    java.awt.Paint var14 = var13.getLabelPaint();
    var0.setRangeCrosshairPaint(var14);
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test93"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("ChartChangeEventType.GENERAL", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "PlotOrientation.VERTICAL", "Size2D[width=3.0, height=0.0]", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Multiple Pie Plot\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test94"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var6 = null;
    var5.setMarkerBand(var6);
    org.jfree.data.Range var8 = var1.getDataRange((org.jfree.chart.axis.ValueAxis)var5);
    var5.setLabelAngle((-1.0d));
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var12 = var11.clone();
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot(var13);
    org.jfree.chart.util.RectangleInsets var15 = var14.getLabelPadding();
    var14.setSectionOutlinesVisible(true);
    java.awt.Paint var18 = var14.getBaseSectionPaint();
    var11.setAxisLinePaint(var18);
    org.jfree.data.Range var20 = var11.getDefaultAutoRange();
    java.lang.String var21 = var20.toString();
    org.jfree.data.Range var23 = org.jfree.data.Range.expandToInclude(var20, 10.0d);
    var5.setRange(var23, false, false);
    java.lang.String var27 = var23.toString();
    org.jfree.data.Range var30 = org.jfree.data.Range.shift(var23, (-51.29999999999999d), true);
    var0.setRange(var30, true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Range[0.0,1.0]"+ "'", var21.equals("Range[0.0,1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "Range[0.0,10.0]"+ "'", var27.equals("Range[0.0,10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test95"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    var0.clearRangeMarkers((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxis((-8372160), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test96"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.chart.plot.PiePlotState var11 = var0.initialise(var1, var2, var4, (java.lang.Integer)0, var10);
    var0.setSeparatorsVisible(true);
    java.awt.Paint var14 = var0.getBaseSectionOutlinePaint();
    java.awt.Paint var16 = var0.getSectionOutlinePaint((java.lang.Comparable)"Size2D[width=0.0, height=0.0]");
    double var17 = var0.getInnerSeparatorExtension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test97"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     java.awt.Shape var3 = var1.getLeftArrow();
//     org.jfree.chart.renderer.PolarItemRenderer var4 = null;
//     org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var11 = var10.clone();
//     org.jfree.chart.axis.ValueAxis[] var12 = new org.jfree.chart.axis.ValueAxis[] { var10};
//     var9.setDomainAxes(var12);
//     java.awt.geom.Point2D var14 = var9.getQuadrantOrigin();
//     var5.zoomDomainAxes(0.2d, 2.0d, var8, var14);
//     boolean var16 = var5.isAngleGridlinesVisible();
//     boolean var17 = var5.isDomainZoomable();
//     java.awt.Paint var18 = var5.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotOrientation var19 = var5.getOrientation();
//     boolean var20 = var5.isAngleGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var25 = null;
//     var24.datasetChanged(var25);
//     var24.mapDatasetToDomainAxis((-1), 10);
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var34 = var33.clone();
//     org.jfree.chart.axis.ValueAxis[] var35 = new org.jfree.chart.axis.ValueAxis[] { var33};
//     var32.setDomainAxes(var35);
//     org.jfree.data.xy.XYDataset var38 = var32.getDataset(100);
//     org.jfree.chart.plot.PlotRenderingInfo var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var42 = var41.getQuadrantOrigin();
//     var32.zoomRangeAxes(0.0d, var40, var42, false);
//     var24.zoomRangeAxes(0.03937499999999999d, var31, var42, false);
//     var5.zoomRangeAxes(10.5d, 0.0d, var23, var42);
//     
//     // Checks the contract:  equals-hashcode on var9 and var32
//     assertTrue("Contract failed: equals-hashcode on var9 and var32", var9.equals(var32) ? var9.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var9
//     assertTrue("Contract failed: equals-hashcode on var32 and var9", var32.equals(var9) ? var32.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test98"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    double var2 = var0.getLowerBound();
    var0.setUpperBound(0.14d);
    var0.setAutoRangeStickyZero(false);
    var0.zoomRange(9.0d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test99"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisSpace var8 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var0.rendererChanged(var9);
    boolean var11 = var0.isDomainCrosshairVisible();
    org.jfree.chart.plot.SeriesRenderingOrder var12 = var0.getSeriesRenderingOrder();
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var14 = var13.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var16 = var15.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var17 = null;
    var15.setTickUnit(var17, false, true);
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var22 = var21.getTickMarkPosition();
    var15.setTickMarkPosition(var22);
    var13.setTickMarkPosition(var22);
    var13.setAutoRangeMinimumSize(10.0d);
    org.jfree.chart.axis.Timeline var27 = var13.getTimeline();
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var13);
    var0.configureDomainAxes();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var31 = var0.getQuadrantPaint((-8028032));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test100"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    java.lang.Object var1 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test101"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    var0.setRenderer(1, var4);
    org.jfree.chart.util.RectangleEdge var7 = var0.getDomainAxisEdge(10);
    boolean var9 = var0.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var11 = var0.getRangeAxisLocation(0);
    boolean var12 = var0.isDomainCrosshairLockedOnData();
    var0.setDomainZeroBaselineVisible(true);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setForegroundAlpha(1.0f);
    java.awt.Font var19 = var16.getNoDataMessageFont();
    var16.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var16);
    org.jfree.chart.axis.AxisLocation var23 = var16.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var24 = var16.getDomainAxisLocation();
    var0.setRangeAxisLocation(var24);
    var0.configureRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test102"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     var0.configureRangeAxes();
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var0.getCategoriesForAxis(var7);
//     java.awt.Paint var9 = var0.getRangeCrosshairPaint();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     org.jfree.chart.util.RectangleInsets var12 = var11.getLabelPadding();
//     org.jfree.chart.event.AxisChangeEvent var13 = null;
//     var11.axisChanged(var13);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var16 = null;
//     var15.datasetChanged(var16);
//     java.awt.Stroke var18 = var15.getOutlineStroke();
//     var11.setBaseSectionOutlineStroke(var18);
//     var0.setRangeGridlineStroke(var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.setForegroundAlpha(1.0f);
//     java.awt.Font var26 = var23.getNoDataMessageFont();
//     var23.setAnchorValue(0.0d, false);
//     org.jfree.chart.util.RectangleEdge var31 = var23.getDomainAxisEdge(10);
//     org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var36 = var35.getQuadrantOrigin();
//     var35.mapDatasetToDomainAxis(100, 0);
//     java.awt.Graphics2D var40 = null;
//     org.jfree.chart.plot.PiePlot3D var41 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var42 = var41.getPlotType();
//     org.jfree.chart.urls.PieURLGenerator var43 = null;
//     var41.setLegendLabelURLGenerator(var43);
//     java.awt.Graphics2D var45 = null;
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.PiePlot var48 = new org.jfree.chart.plot.PiePlot(var47);
//     org.jfree.chart.util.RectangleInsets var49 = var48.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var50 = null;
//     var48.setToolTipGenerator(var50);
//     java.awt.Font var52 = var48.getLabelFont();
//     org.jfree.chart.title.TextTitle var53 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var52);
//     var53.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var59 = var53.getURLText();
//     org.jfree.chart.util.VerticalAlignment var60 = var53.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var61 = var53.getBounds();
//     var41.drawBackgroundImage(var45, var61);
//     java.util.List var63 = null;
//     var35.drawRangeTickBands(var40, var61, var63);
//     org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot();
//     var66.setForegroundAlpha(1.0f);
//     java.awt.Font var69 = var66.getNoDataMessageFont();
//     var66.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var72 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var66);
//     org.jfree.chart.axis.AxisLocation var73 = var66.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var74 = var66.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var75 = null;
//     org.jfree.chart.util.VerticalAlignment var76 = null;
//     org.jfree.chart.block.ColumnArrangement var79 = new org.jfree.chart.block.ColumnArrangement(var75, var76, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var80 = null;
//     org.jfree.chart.util.VerticalAlignment var81 = null;
//     org.jfree.chart.block.ColumnArrangement var84 = new org.jfree.chart.block.ColumnArrangement(var80, var81, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var85 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var66, (org.jfree.chart.block.Arrangement)var79, (org.jfree.chart.block.Arrangement)var84);
//     var85.setID("hi!");
//     java.awt.Paint var88 = var85.getBackgroundPaint();
//     org.jfree.chart.util.RectangleAnchor var89 = var85.getLegendItemGraphicAnchor();
//     java.awt.geom.Point2D var90 = org.jfree.chart.util.RectangleAnchor.coordinates(var61, var89);
//     var23.zoomDomainAxes(100.0d, var34, var90);
//     var0.zoomDomainAxes(0.18d, var22, var90);
//     
//     // Checks the contract:  equals-hashcode on var11 and var48
//     assertTrue("Contract failed: equals-hashcode on var11 and var48", var11.equals(var48) ? var11.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var11
//     assertTrue("Contract failed: equals-hashcode on var48 and var11", var48.equals(var11) ? var48.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test103"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
//     var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var7.setURLText("Range[0.0,1.0]");
//     var7.setURLText("");
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var21 = var20.getPlotType();
//     org.jfree.chart.urls.PieURLGenerator var22 = null;
//     var20.setLegendLabelURLGenerator(var22);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
//     org.jfree.chart.util.RectangleInsets var28 = var27.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var29 = null;
//     var27.setToolTipGenerator(var29);
//     java.awt.Font var31 = var27.getLabelFont();
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var31);
//     var32.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var38 = var32.getURLText();
//     org.jfree.chart.util.VerticalAlignment var39 = var32.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var40 = var32.getBounds();
//     var20.drawBackgroundImage(var24, var40);
//     var7.draw(var19, var40);
//     
//     // Checks the contract:  equals-hashcode on var2 and var27
//     assertTrue("Contract failed: equals-hashcode on var2 and var27", var2.equals(var27) ? var2.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var2
//     assertTrue("Contract failed: equals-hashcode on var27 and var2", var27.equals(var2) ? var27.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test104"); }


    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var3 = var2.getUpperMargin();
    var2.addCategoryLabelToolTip((java.lang.Comparable)10.0d, "RectangleConstraintType.RANGE");
    float var7 = var2.getMaximumCategoryLabelWidthRatio();
    var2.setLowerMargin(3.0d);
    int var10 = var2.getCategoryLabelPositionOffset();
    java.awt.Font var12 = var2.getTickLabelFont((java.lang.Comparable)1L);
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var14 = var13.getQuadrantOrigin();
    var13.mapDatasetToDomainAxis(100, 0);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var20 = var19.getPlotType();
    org.jfree.chart.urls.PieURLGenerator var21 = null;
    var19.setLegendLabelURLGenerator(var21);
    java.awt.Graphics2D var23 = null;
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    org.jfree.chart.util.RectangleInsets var27 = var26.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var28 = null;
    var26.setToolTipGenerator(var28);
    java.awt.Font var30 = var26.getLabelFont();
    org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var30);
    var31.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var37 = var31.getURLText();
    org.jfree.chart.util.VerticalAlignment var38 = var31.getVerticalAlignment();
    java.awt.geom.Rectangle2D var39 = var31.getBounds();
    var19.drawBackgroundImage(var23, var39);
    java.util.List var41 = null;
    var13.drawRangeTickBands(var18, var39, var41);
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
    var44.setForegroundAlpha(1.0f);
    java.awt.Font var47 = var44.getNoDataMessageFont();
    var44.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var44);
    java.awt.Paint var51 = var50.getBackgroundPaint();
    org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var54 = var53.clone();
    org.jfree.chart.axis.ValueAxis[] var55 = new org.jfree.chart.axis.ValueAxis[] { var53};
    var52.setDomainAxes(var55);
    org.jfree.data.xy.XYDataset var58 = var52.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
    var52.setRenderer(100, var60, false);
    java.awt.Color var67 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var68 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var67);
    org.jfree.chart.util.HorizontalAlignment var69 = null;
    org.jfree.chart.util.VerticalAlignment var70 = null;
    org.jfree.chart.block.ColumnArrangement var73 = new org.jfree.chart.block.ColumnArrangement(var69, var70, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var74 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var76 = null;
    var74.setDomainAxisLocation(1, var76, false);
    java.awt.Stroke var79 = var74.getRangeCrosshairStroke();
    boolean var80 = var73.equals((java.lang.Object)var79);
    java.awt.Color var84 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var85 = null;
    org.jfree.chart.plot.ValueMarker var87 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var67, var79, (java.awt.Paint)var84, var85, 1.0f);
    java.lang.Object var88 = var87.clone();
    var52.addDomainMarker((org.jfree.chart.plot.Marker)var87);
    boolean var90 = var50.equals((java.lang.Object)var87);
    var13.addDomainMarker((org.jfree.chart.plot.Marker)var87);
    org.jfree.chart.util.Layer var92 = null;
    java.util.Collection var93 = var13.getRangeMarkers(var92);
    java.awt.Paint var94 = var13.getDomainCrosshairPaint();
    org.jfree.chart.text.TextFragment var96 = new org.jfree.chart.text.TextFragment("PlotOrientation.HORIZONTAL", var12, var94, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Pie 3D Plot"+ "'", var20.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test105"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var7 = var6.clone();
    org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var6};
    var5.setDomainAxes(var8);
    org.jfree.data.xy.XYDataset var11 = var5.getDataset(100);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
    var5.zoomRangeAxes(0.0d, var13, var15, false);
    var0.zoomDomainAxes((-7.0d), var4, var15);
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var20 = var19.getLabelURL();
    var19.configure();
    java.awt.Paint var22 = var19.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var23 = var19.getTickLabelInsets();
    double var25 = var23.calculateRightInset(0.05d);
    var0.setAxisOffset(var23);
    boolean var27 = var0.isRangeCrosshairVisible();
    var0.setDrawSharedDomainAxis(true);
    org.jfree.chart.util.Layer var30 = null;
    java.util.Collection var31 = var0.getRangeMarkers(var30);
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
    var32.setForegroundAlpha(1.0f);
    java.awt.Paint var35 = var32.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var36 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var32);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    var37.setForegroundAlpha(1.0f);
    java.awt.Font var40 = var37.getNoDataMessageFont();
    var37.setAnchorValue(100.0d);
    org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var44.setMaximumCategoryLabelLines((-1));
    int var47 = var37.getDomainAxisIndex(var44);
    int var48 = var32.getDomainAxisIndex(var44);
    var0.setDomainAxis(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-1));

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test106"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisSpace var8 = var0.getFixedDomainAxisSpace();
    java.awt.Paint var9 = var0.getDomainZeroBaselinePaint();
    var0.setDomainCrosshairLockedOnData(false);
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var14.setCategoryLabelPositionOffset(1);
    var14.setUpperMargin(0.0d);
    java.awt.Paint var20 = var14.getTickLabelPaint((java.lang.Comparable)3.0d);
    org.jfree.chart.block.FlowArrangement var23 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var24 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var28 = var27.clone();
    org.jfree.data.general.PieDataset var29 = null;
    org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot(var29);
    org.jfree.chart.util.RectangleInsets var31 = var30.getLabelPadding();
    var30.setSectionOutlinesVisible(true);
    java.awt.Paint var34 = var30.getBaseSectionPaint();
    var27.setAxisLinePaint(var34);
    double var36 = var27.getLowerMargin();
    boolean var37 = var27.isVerticalTickLabels();
    var27.setPositiveArrowVisible(true);
    org.jfree.data.Range var40 = var27.getRange();
    org.jfree.chart.block.RectangleConstraint var41 = new org.jfree.chart.block.RectangleConstraint(3.0d, var40);
    org.jfree.chart.util.Size2D var42 = var23.arrange(var24, var25, var41);
    org.jfree.chart.util.RectangleAnchor var45 = null;
    java.awt.geom.Rectangle2D var46 = org.jfree.chart.util.RectangleAnchor.createRectangle(var42, 2.0d, 10.5d, var45);
    java.lang.String var47 = var42.toString();
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
    var51.setForegroundAlpha(1.0f);
    java.awt.Font var54 = var51.getNoDataMessageFont();
    var51.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var57 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var51);
    org.jfree.chart.axis.AxisLocation var58 = var51.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var59 = var51.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var60 = null;
    org.jfree.chart.util.VerticalAlignment var61 = null;
    org.jfree.chart.block.ColumnArrangement var64 = new org.jfree.chart.block.ColumnArrangement(var60, var61, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var65 = null;
    org.jfree.chart.util.VerticalAlignment var66 = null;
    org.jfree.chart.block.ColumnArrangement var69 = new org.jfree.chart.block.ColumnArrangement(var65, var66, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var70 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var51, (org.jfree.chart.block.Arrangement)var64, (org.jfree.chart.block.Arrangement)var69);
    org.jfree.chart.util.RectangleEdge var71 = var70.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var72 = var70.getLegendItemGraphicAnchor();
    java.awt.geom.Rectangle2D var73 = org.jfree.chart.util.RectangleAnchor.createRectangle(var42, 3.0d, (-45.29999999999999d), var72);
    org.jfree.chart.util.RectangleEdge var74 = null;
    double var75 = var14.getCategoryMiddle(3, 0, var73, var74);
    org.jfree.chart.plot.PlotRenderingInfo var76 = null;
    var0.drawAnnotations(var12, var73, var76);
    org.jfree.chart.event.PlotChangeEvent var78 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "Size2D[width=3.0, height=0.0]"+ "'", var47.equals("Size2D[width=3.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test107"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = var0.getRenderer();
    org.jfree.chart.util.RectangleEdge var10 = var0.getRangeAxisEdge();
    org.jfree.data.general.DatasetChangeEvent var11 = null;
    var0.datasetChanged(var11);
    org.jfree.chart.LegendItemCollection var13 = var0.getLegendItems();
    boolean var14 = var0.isRangeCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test108"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Paint var8 = var7.getBackgroundPaint();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
//     org.jfree.chart.util.UnitType var12 = var11.getUnitType();
//     var7.setPadding(var11);
//     org.jfree.chart.title.TextTitle var14 = var7.getTitle();
//     var14.setHeight(0.08d);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.setForegroundAlpha(1.0f);
//     java.awt.Font var22 = var19.getNoDataMessageFont();
//     var19.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var19);
//     org.jfree.chart.event.ChartProgressEvent var28 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-65536), var25, 0, 0);
//     org.jfree.chart.title.LegendTitle var29 = var25.getLegend();
//     double var30 = var29.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var32 = var31.getLabelURL();
//     var31.resizeRange(10.0d);
//     java.awt.Paint var35 = var31.getTickMarkPaint();
//     java.awt.Color var39 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var39);
//     int var41 = var39.getGreen();
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     var42.setForegroundAlpha(1.0f);
//     java.awt.Font var45 = var42.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot(var46);
//     org.jfree.chart.util.RectangleInsets var48 = var47.getLabelPadding();
//     var47.setSectionOutlinesVisible(true);
//     java.awt.Paint var51 = var47.getBaseSectionPaint();
//     var42.setRangeCrosshairPaint(var51);
//     java.lang.Object var53 = var42.clone();
//     org.jfree.chart.LegendItemCollection var54 = var42.getLegendItems();
//     boolean var55 = var39.equals((java.lang.Object)var42);
//     boolean var56 = var31.equals((java.lang.Object)var39);
//     org.jfree.data.general.PieDataset var57 = null;
//     org.jfree.chart.plot.PiePlot var58 = new org.jfree.chart.plot.PiePlot(var57);
//     org.jfree.chart.util.RectangleInsets var59 = var58.getLabelPadding();
//     boolean var60 = var58.getLabelLinksVisible();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var62 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var58.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var62);
//     org.jfree.chart.labels.PieSectionLabelGenerator var64 = var58.getLegendLabelToolTipGenerator();
//     org.jfree.data.general.PieDataset var65 = null;
//     org.jfree.chart.plot.PiePlot var66 = new org.jfree.chart.plot.PiePlot(var65);
//     org.jfree.chart.util.RectangleInsets var67 = var66.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var68 = null;
//     var66.setToolTipGenerator(var68);
//     org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var72 = null;
//     var70.setDomainAxisLocation(1, var72, false);
//     java.awt.Stroke var75 = var70.getRangeCrosshairStroke();
//     var66.setBaseSectionOutlineStroke(var75);
//     java.awt.Paint var77 = var66.getLabelShadowPaint();
//     var58.setLabelBackgroundPaint(var77);
//     var31.setLabelPaint(var77);
//     var29.setItemPaint(var77);
//     var14.setPaint(var77);
//     
//     // Checks the contract:  equals-hashcode on var1 and var19
//     assertTrue("Contract failed: equals-hashcode on var1 and var19", var1.equals(var19) ? var1.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var1
//     assertTrue("Contract failed: equals-hashcode on var19 and var1", var19.equals(var1) ? var19.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var47
//     assertTrue("Contract failed: equals-hashcode on var10 and var47", var10.equals(var47) ? var10.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var10
//     assertTrue("Contract failed: equals-hashcode on var47 and var10", var47.equals(var10) ? var47.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test109"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.chart.plot.PiePlotState var11 = var0.initialise(var1, var2, var4, (java.lang.Integer)0, var10);
    double var12 = var11.getPieCenterY();
    java.awt.geom.Rectangle2D var13 = null;
    var11.setLinkArea(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test110"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "RectangleInsets[t=-45.29999999999999,l=2.0,b=0.0,r=90.0]", var3);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test111"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    var0.setAnchorValue(0.0d, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = var0.getRenderer();
    java.awt.Stroke var8 = var0.getOutlineStroke();
    org.jfree.chart.axis.AxisSpace var9 = var0.getFixedDomainAxisSpace();
    int var10 = var0.getWeight();
    org.jfree.chart.axis.AxisLocation var12 = var0.getRangeAxisLocation((-8372160));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test112"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var5 = var4.clone();
    float var6 = var4.getTickMarkInsideLength();
    boolean var7 = var4.isAutoRange();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var9 = var8.clone();
    org.jfree.data.Range var10 = var8.getRange();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var8, var11);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var14 = var13.getLabelURL();
    var13.configure();
    java.awt.Paint var16 = var13.getTickLabelPaint();
    var13.setUpperBound((-7.0d));
    java.awt.Shape var19 = var13.getRightArrow();
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var13, var20);
    org.jfree.chart.renderer.PolarItemRenderer var22 = null;
    org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var8, var22);
    java.awt.Font var24 = var8.getTickLabelFont();
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    org.jfree.chart.util.RectangleInsets var27 = var26.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var28 = null;
    var26.setToolTipGenerator(var28);
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var32 = null;
    var30.setDomainAxisLocation(1, var32, false);
    java.awt.Stroke var35 = var30.getRangeCrosshairStroke();
    var26.setBaseSectionOutlineStroke(var35);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    var37.setForegroundAlpha(1.0f);
    java.awt.Font var40 = var37.getNoDataMessageFont();
    var26.setLabelFont(var40);
    java.awt.Paint var42 = var26.getBaseSectionPaint();
    org.jfree.chart.text.TextBlock var43 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=255,g=0,b=0]", var24, var42);
    org.jfree.chart.text.TextLine var44 = var43.getLastLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test113"); }


    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var4 = null;
    var3.setFixedDomainAxisSpace(var4, true);
    var3.clearDomainMarkers(100);
    var3.setOutlineVisible(true);
    org.jfree.chart.axis.ValueAxis var12 = var3.getRangeAxis(0);
    java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var17);
    org.jfree.chart.util.HorizontalAlignment var19 = null;
    org.jfree.chart.util.VerticalAlignment var20 = null;
    org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement(var19, var20, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var26 = null;
    var24.setDomainAxisLocation(1, var26, false);
    java.awt.Stroke var29 = var24.getRangeCrosshairStroke();
    boolean var30 = var23.equals((java.lang.Object)var29);
    java.awt.Color var34 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var35 = null;
    org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var17, var29, (java.awt.Paint)var34, var35, 1.0f);
    var3.setDomainGridlinePaint((java.awt.Paint)var17);
    java.awt.Color var42 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Color var43 = var42.darker();
    float[] var47 = new float[] { 100.0f, 100.0f, (-1.0f)};
    float[] var48 = var43.getRGBColorComponents(var47);
    float[] var49 = var17.getRGBColorComponents(var47);
    float[] var50 = java.awt.Color.RGBtoHSB(0, 15, (-8372160), var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test114"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var2 = var1.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var4 = var3.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var5 = null;
    var3.setTickUnit(var5, false, true);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var10 = var9.getTickMarkPosition();
    var3.setTickMarkPosition(var10);
    var1.setTickMarkPosition(var10);
    var1.setInverted(true);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var16 = var15.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var18 = var17.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var19 = null;
    var17.setTickUnit(var19, false, true);
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var24 = var23.getTickMarkPosition();
    var17.setTickMarkPosition(var24);
    var15.setTickMarkPosition(var24);
    java.util.TimeZone var27 = var15.getTimeZone();
    var1.setTimeZone(var27);
    org.jfree.chart.axis.TickUnitSource var29 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var27);
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("UnitType.ABSOLUTE", var27);
    double var31 = var30.getAutoRangeMinimumSize();
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var33 = var32.getTickMarkPosition();
    var30.setTickMarkPosition(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test115"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("Size2D[width=0.0, height=0.0]");

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test116"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    java.text.AttributedString var3 = var1.getAttributedLabel(1);
    java.lang.Object var4 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test117"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.data.xy.XYDataset var6 = var0.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(100, var8, false);
    java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var24 = null;
    var22.setDomainAxisLocation(1, var24, false);
    java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
    boolean var28 = var21.equals((java.lang.Object)var27);
    java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var33 = null;
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
    java.lang.Object var36 = var35.clone();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var35);
    int var38 = var0.getSeriesCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test118"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var2 = var0.getLeftArrow();
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "Pie 3D Plot");
    org.jfree.chart.entity.ChartEntity var5 = new org.jfree.chart.entity.ChartEntity(var2);
    java.lang.String var6 = var5.getURLText();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var8 = null;
    var7.setMarkerBand(var8);
    var7.setUpperBound(1.0d);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var13 = var12.clone();
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelPadding();
    var15.setSectionOutlinesVisible(true);
    java.awt.Paint var19 = var15.getBaseSectionPaint();
    var12.setAxisLinePaint(var19);
    org.jfree.data.Range var21 = var12.getDefaultAutoRange();
    java.lang.String var22 = var21.toString();
    var7.setRangeWithMargins(var21);
    boolean var24 = var5.equals((java.lang.Object)var21);
    java.lang.String var25 = var5.getURLText();
    java.lang.String var26 = var5.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "Range[0.0,1.0]"+ "'", var22.equals("Range[0.0,1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test119"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    var0.zoomDomainAxes((-1.0d), 3.0d, var3, var5);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.setForegroundAlpha(1.0f);
    java.awt.Font var11 = var8.getNoDataMessageFont();
    var8.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.AxisLocation var15 = var8.getDomainAxisLocation();
    var0.setDomainAxisLocation(var15);
    java.awt.Stroke var17 = var0.getRangeCrosshairStroke();
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    var0.setRenderer(var18);
    java.awt.Paint var20 = var0.getNoDataMessagePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test120"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.LegendItemCollection var8 = var0.getLegendItems();
    org.jfree.data.general.DatasetChangeEvent var9 = null;
    var0.datasetChanged(var9);
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var12 = null;
    var11.setFixedDomainAxisSpace(var12, true);
    var11.clearDomainMarkers(100);
    org.jfree.chart.axis.AxisLocation var17 = var11.getRangeAxisLocation();
    var0.setDomainAxisLocation(var17);
    org.jfree.chart.axis.ValueAxis var19 = var0.getRangeAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test121"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var4 = var0.getRowRenderingOrder();
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var16.setDomainAxisLocation(1, var18, false);
    java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
    boolean var22 = var15.equals((java.lang.Object)var21);
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var27 = null;
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var9, var21, (java.awt.Paint)var26, var27, 1.0f);
    org.jfree.chart.event.MarkerChangeListener var30 = null;
    var29.addChangeListener(var30);
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var29);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    var34.setForegroundAlpha(1.0f);
    java.awt.Font var37 = var34.getNoDataMessageFont();
    var34.setAnchorValue(100.0d);
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var41.setMaximumCategoryLabelLines((-1));
    int var44 = var34.getDomainAxisIndex(var41);
    var0.setDomainAxis(100, var41);
    org.jfree.chart.renderer.category.CategoryItemRenderer var46 = null;
    int var47 = var0.getIndexOf(var46);
    var0.setRangeCrosshairLockedOnData(false);
    var0.clearRangeMarkers(0);
    org.jfree.data.general.DatasetChangeEvent var52 = null;
    var0.datasetChanged(var52);
    org.jfree.chart.axis.ValueAxis var55 = var0.getRangeAxisForDataset((-65537));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test122"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(var8);
    org.jfree.chart.axis.ValueAxis var11 = var0.getRangeAxisForDataset(0);
    var0.configureDomainAxes();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var0.setRenderer(0, var14);
    var0.setForegroundAlpha(100.0f);
    boolean var18 = var0.isDomainZeroBaselineVisible();
    var0.clearRangeMarkers(0);
    java.awt.Stroke var21 = var0.getRangeCrosshairStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test123"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.setForegroundAlpha(1.0f);
//     java.awt.Font var6 = var3.getNoDataMessageFont();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var8 = null;
//     var7.datasetChanged(var8);
//     java.awt.Stroke var10 = var7.getOutlineStroke();
//     java.awt.Paint var11 = var7.getRangeZeroBaselinePaint();
//     org.jfree.chart.text.TextLine var12 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6, var11);
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("RectangleConstraintType.RANGE", var6);
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
//     var14.mapDatasetToDomainAxis(100, 0);
//     java.awt.Paint var19 = var14.getDomainCrosshairPaint();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.text.G2TextMeasurer var22 = new org.jfree.chart.text.G2TextMeasurer(var21);
//     org.jfree.chart.text.TextBlock var23 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var19, 10.0f, (org.jfree.chart.text.TextMeasurer)var22);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.text.TextBlockAnchor var27 = null;
//     var23.draw(var24, 1.0f, 2.0f, var27, 100.0f, 0.0f, 3.0d);
//     org.jfree.chart.util.HorizontalAlignment var32 = var23.getLineAlignment();
//     java.lang.String var33 = var32.toString();
//     java.lang.String var34 = var32.toString();
//     java.lang.String var35 = var32.toString();
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     org.jfree.chart.util.RectangleInsets var39 = var38.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var40 = null;
//     var38.setToolTipGenerator(var40);
//     java.awt.Font var42 = var38.getLabelFont();
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var42);
//     var43.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var43.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var43.setWidth((-1.0d));
//     org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var54 = null;
//     var53.datasetChanged(var54);
//     java.awt.Paint var56 = var53.getRangeZeroBaselinePaint();
//     var43.setPaint(var56);
//     org.jfree.chart.util.VerticalAlignment var58 = var43.getVerticalAlignment();
//     org.jfree.chart.block.FlowArrangement var61 = new org.jfree.chart.block.FlowArrangement(var32, var58, 0.0d, 5.0d);
//     
//     // Checks the contract:  equals-hashcode on var7 and var53
//     assertTrue("Contract failed: equals-hashcode on var7 and var53", var7.equals(var53) ? var7.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var7
//     assertTrue("Contract failed: equals-hashcode on var53 and var7", var53.equals(var7) ? var53.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test124"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var10 = var9.clone();
//     org.jfree.chart.axis.ValueAxis[] var11 = new org.jfree.chart.axis.ValueAxis[] { var9};
//     var8.setDomainAxes(var11);
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     var8.setRenderer(var13);
//     java.awt.Stroke var15 = var8.getRangeCrosshairStroke();
//     var7.setBorderStroke(var15);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var21);
//     org.jfree.chart.util.HorizontalAlignment var23 = null;
//     org.jfree.chart.util.VerticalAlignment var24 = null;
//     org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var30 = null;
//     var28.setDomainAxisLocation(1, var30, false);
//     java.awt.Stroke var33 = var28.getRangeCrosshairStroke();
//     boolean var34 = var27.equals((java.lang.Object)var33);
//     java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var39 = null;
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var21, var33, (java.awt.Paint)var38, var39, 1.0f);
//     float var42 = var41.getAlpha();
//     java.awt.Paint var43 = var41.getLabelPaint();
//     java.awt.Paint var44 = var41.getPaint();
//     boolean var45 = var7.equals((java.lang.Object)var41);
//     java.awt.Paint var46 = var7.getBorderPaint();
//     org.jfree.chart.plot.CategoryPlot var47 = var7.getCategoryPlot();
//     java.lang.String var48 = var47.getPlotType();
//     java.awt.Paint var49 = var47.getDomainGridlinePaint();
//     double var50 = var47.getRangeCrosshairValue();
//     boolean var51 = var47.getDrawSharedDomainAxis();
//     org.jfree.chart.LegendItemCollection var52 = var47.getLegendItems();
//     org.jfree.chart.LegendItemCollection var53 = null;
//     var52.addAll(var53);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test125"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Color var4 = var3.darker();
    float[] var8 = new float[] { 100.0f, 100.0f, (-1.0f)};
    float[] var9 = var4.getRGBColorComponents(var8);
    java.awt.image.ColorModel var10 = null;
    java.awt.Rectangle var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var13 = var12.getQuadrantOrigin();
    var12.mapDatasetToDomainAxis(100, 0);
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var19 = var18.getPlotType();
    org.jfree.chart.urls.PieURLGenerator var20 = null;
    var18.setLegendLabelURLGenerator(var20);
    java.awt.Graphics2D var22 = null;
    org.jfree.data.general.PieDataset var24 = null;
    org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
    org.jfree.chart.util.RectangleInsets var26 = var25.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var27 = null;
    var25.setToolTipGenerator(var27);
    java.awt.Font var29 = var25.getLabelFont();
    org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var29);
    var30.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var36 = var30.getURLText();
    org.jfree.chart.util.VerticalAlignment var37 = var30.getVerticalAlignment();
    java.awt.geom.Rectangle2D var38 = var30.getBounds();
    var18.drawBackgroundImage(var22, var38);
    java.util.List var40 = null;
    var12.drawRangeTickBands(var17, var38, var40);
    java.awt.geom.AffineTransform var42 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
    var44.setForegroundAlpha(1.0f);
    java.awt.Font var47 = var44.getNoDataMessageFont();
    var44.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var44);
    java.awt.RenderingHints var51 = var50.getRenderingHints();
    java.awt.PaintContext var52 = var4.createContext(var10, var11, var38, var42, var51);
    java.awt.Color var53 = var4.darker();
    java.lang.String var54 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "Pie 3D Plot"+ "'", var19.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + "java.awt.Color[r=178,g=0,b=0]"+ "'", var54.equals("java.awt.Color[r=178,g=0,b=0]"));

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test126"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    float var25 = var24.getAlpha();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var27 = var26.clone();
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot(var28);
    org.jfree.chart.util.RectangleInsets var30 = var29.getLabelPadding();
    var29.setSectionOutlinesVisible(true);
    java.awt.Paint var33 = var29.getBaseSectionPaint();
    var26.setAxisLinePaint(var33);
    var24.setPaint(var33);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var37 = var36.clone();
    org.jfree.chart.util.RectangleInsets var38 = var36.getLabelInsets();
    double var40 = var38.calculateRightOutset(100.0d);
    double var41 = var38.getLeft();
    double var42 = var38.getRight();
    var24.setLabelOffset(var38);
    org.jfree.chart.util.LengthAdjustmentType var44 = var24.getLabelOffsetType();
    org.jfree.chart.event.MarkerChangeEvent var45 = null;
    var24.notifyListeners(var45);
    var24.setLabel("Size2D[width=3.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test127"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    var1.setSectionOutlinesVisible(true);
    double var7 = var1.getInteriorGap();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    org.jfree.chart.plot.PiePlotState var14 = var1.initialise(var8, var9, (org.jfree.chart.plot.PiePlot)var11, (java.lang.Integer)0, var13);
    org.jfree.chart.block.LineBorder var15 = new org.jfree.chart.block.LineBorder();
    boolean var16 = var11.equals((java.lang.Object)var15);
    var11.setCircular(false, false);
    boolean var20 = var11.getDarkerSides();
    java.awt.Stroke var21 = var11.getLabelOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test128"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.chart.plot.PiePlotState var11 = var0.initialise(var1, var2, var4, (java.lang.Integer)0, var10);
    java.awt.geom.Rectangle2D var12 = var11.getPieArea();
    int var13 = var11.getPassesRequired();
    var11.setPieHRadius(6.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test129"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    java.lang.Object var25 = var24.clone();
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var27 = var26.getQuadrantOrigin();
    var26.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = var26.getRendererForDataset(var31);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    var34.setForegroundAlpha(1.0f);
    java.awt.Font var37 = var34.getNoDataMessageFont();
    var34.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var34);
    org.jfree.chart.axis.AxisLocation var41 = var34.getDomainAxisLocation();
    var26.setRangeAxisLocation(var41);
    boolean var43 = var24.equals((java.lang.Object)var26);
    java.awt.Paint var44 = var26.getDomainZeroBaselinePaint();
    org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var47 = var46.clone();
    double var48 = var46.getLowerBound();
    var26.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var46);
    org.jfree.chart.axis.DateAxis var50 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var51 = var50.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var53 = var52.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var54 = null;
    var52.setTickUnit(var54, false, true);
    org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var59 = var58.getTickMarkPosition();
    var52.setTickMarkPosition(var59);
    var50.setTickMarkPosition(var59);
    var50.setInverted(true);
    org.jfree.chart.axis.DateAxis var64 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var65 = var64.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var66 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var67 = var66.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var68 = null;
    var66.setTickUnit(var68, false, true);
    org.jfree.chart.axis.DateAxis var72 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var73 = var72.getTickMarkPosition();
    var66.setTickMarkPosition(var73);
    var64.setTickMarkPosition(var73);
    java.util.TimeZone var76 = var64.getTimeZone();
    var50.setTimeZone(var76);
    org.jfree.chart.axis.TickUnitSource var78 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var76);
    var46.setStandardTickUnits(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test130"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var16.setDomainAxisLocation(1, var18, false);
    java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
    boolean var22 = var15.equals((java.lang.Object)var21);
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var27 = null;
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var9, var21, (java.awt.Paint)var26, var27, 1.0f);
    float var30 = var29.getAlpha();
    java.awt.Paint var31 = var29.getLabelPaint();
    double var32 = var29.getValue();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var29);
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var36 = var35.getLabelURL();
    var35.configure();
    java.awt.Paint var38 = var35.getTickLabelPaint();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
    var39.setTickMarksVisible(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var42);
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var46 = var45.clone();
    java.awt.Shape var47 = var45.getLeftArrow();
    var43.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var45, false);
    int var50 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var45);
    boolean var51 = var0.isRangeGridlinesVisible();
    boolean var52 = var0.isDomainCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test131"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    var1.setSectionOutlinesVisible(true);
    double var7 = var1.getInteriorGap();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    org.jfree.chart.plot.PiePlotState var14 = var1.initialise(var8, var9, (org.jfree.chart.plot.PiePlot)var11, (java.lang.Integer)0, var13);
    org.jfree.chart.urls.PieURLGenerator var15 = null;
    var11.setURLGenerator(var15);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var21);
    int var23 = var21.getTransparency();
    var11.setSectionOutlinePaint((java.lang.Comparable)0.2d, (java.awt.Paint)var21);
    java.lang.Object var25 = var11.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test132"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    var0.setAnchorValue(100.0d);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var7.setMaximumCategoryLabelLines((-1));
    int var10 = var0.getDomainAxisIndex(var7);
    java.lang.String var12 = var7.getCategoryLabelToolTip((java.lang.Comparable)(-7.0d));
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var14 = var13.getPlotType();
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var16 = null;
    var15.setFixedDomainAxisSpace(var16, true);
    var15.clearDomainMarkers(100);
    var15.setOutlineVisible(true);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var25 = var24.getTickLabelFont();
    var15.setNoDataMessageFont(var25);
    var13.setLabelFont(var25);
    boolean var28 = var7.hasListener((java.util.EventListener)var13);
    org.jfree.chart.labels.PieSectionLabelGenerator var29 = var13.getLabelGenerator();
    var13.setLabelGap(1.0d);
    boolean var32 = var13.getSectionOutlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "Pie 3D Plot"+ "'", var14.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test133"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     float var25 = var24.getAlpha();
//     float var26 = var24.getAlpha();
//     org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var28 = var27.getNextFillPaint();
//     java.awt.Stroke var29 = var27.getNextOutlineStroke();
//     java.awt.Stroke var30 = var27.getNextStroke();
//     java.awt.Paint var31 = var27.getNextOutlinePaint();
//     java.awt.Paint var32 = var27.getNextPaint();
//     java.awt.Stroke var33 = var27.getNextStroke();
//     java.awt.Paint var34 = var27.getNextPaint();
//     var24.setOutlinePaint(var34);
//     java.awt.Color var40 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var40);
//     org.jfree.chart.util.HorizontalAlignment var42 = null;
//     org.jfree.chart.util.VerticalAlignment var43 = null;
//     org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement(var42, var43, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var49 = null;
//     var47.setDomainAxisLocation(1, var49, false);
//     java.awt.Stroke var52 = var47.getRangeCrosshairStroke();
//     boolean var53 = var46.equals((java.lang.Object)var52);
//     java.awt.Color var57 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var58 = null;
//     org.jfree.chart.plot.ValueMarker var60 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var40, var52, (java.awt.Paint)var57, var58, 1.0f);
//     float var61 = var60.getAlpha();
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var63 = var62.clone();
//     org.jfree.data.general.PieDataset var64 = null;
//     org.jfree.chart.plot.PiePlot var65 = new org.jfree.chart.plot.PiePlot(var64);
//     org.jfree.chart.util.RectangleInsets var66 = var65.getLabelPadding();
//     var65.setSectionOutlinesVisible(true);
//     java.awt.Paint var69 = var65.getBaseSectionPaint();
//     var62.setAxisLinePaint(var69);
//     var60.setPaint(var69);
//     org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var73 = var72.clone();
//     org.jfree.chart.util.RectangleInsets var74 = var72.getLabelInsets();
//     double var76 = var74.calculateRightOutset(100.0d);
//     double var77 = var74.getLeft();
//     double var78 = var74.getRight();
//     var60.setLabelOffset(var74);
//     org.jfree.chart.axis.NumberAxis var82 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var83 = var82.getTickLabelFont();
//     org.jfree.chart.plot.XYPlot var84 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var85 = var84.getQuadrantOrigin();
//     var84.mapDatasetToDomainAxis(100, 0);
//     java.awt.Paint var89 = var84.getDomainCrosshairPaint();
//     org.jfree.chart.text.TextBlock var90 = org.jfree.chart.text.TextUtilities.createTextBlock("Multiple Pie Plot", var83, var89);
//     var60.setLabelFont(var83);
//     org.jfree.chart.plot.ValueMarker var93 = new org.jfree.chart.plot.ValueMarker(0.05d);
//     org.jfree.chart.util.LengthAdjustmentType var94 = var93.getLabelOffsetType();
//     var60.setLabelOffsetType(var94);
//     var24.setLabelOffsetType(var94);
//     
//     // Checks the contract:  equals-hashcode on var5 and var41
//     assertTrue("Contract failed: equals-hashcode on var5 and var41", var5.equals(var41) ? var5.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var5
//     assertTrue("Contract failed: equals-hashcode on var41 and var5", var41.equals(var5) ? var41.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var46
//     assertTrue("Contract failed: equals-hashcode on var10 and var46", var10.equals(var46) ? var10.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var10
//     assertTrue("Contract failed: equals-hashcode on var46 and var10", var46.equals(var10) ? var46.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var47
//     assertTrue("Contract failed: equals-hashcode on var11 and var47", var11.equals(var47) ? var11.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var11
//     assertTrue("Contract failed: equals-hashcode on var47 and var11", var47.equals(var11) ? var47.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test134"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     var4.setSectionOutlinesVisible(true);
//     java.awt.Paint var8 = var4.getBaseSectionPaint();
//     var1.setAxisLinePaint(var8);
//     org.jfree.data.Range var10 = var1.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var13 = var12.clone();
//     org.jfree.data.Range var14 = var12.getRange();
//     org.jfree.data.Range var15 = org.jfree.data.Range.combine(var10, var14);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.setForegroundAlpha(1.0f);
//     java.awt.Paint var19 = var16.getRangeCrosshairPaint();
//     boolean var20 = var15.equals((java.lang.Object)var16);
//     var16.setDomainGridlinesVisible(false);
//     java.lang.Object var23 = var16.clone();
//     boolean var24 = var16.isRangeCrosshairVisible();
//     org.jfree.chart.util.RectangleInsets var25 = var16.getAxisOffset();
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var28 = null;
//     var26.setDomainAxisLocation(1, var28, false);
//     java.awt.Stroke var31 = var26.getRangeCrosshairStroke();
//     var26.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.LegendItemCollection var34 = var26.getLegendItems();
//     java.awt.Color var39 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var39);
//     org.jfree.chart.util.HorizontalAlignment var41 = null;
//     org.jfree.chart.util.VerticalAlignment var42 = null;
//     org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var48 = null;
//     var46.setDomainAxisLocation(1, var48, false);
//     java.awt.Stroke var51 = var46.getRangeCrosshairStroke();
//     boolean var52 = var45.equals((java.lang.Object)var51);
//     java.awt.Color var56 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var57 = null;
//     org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var39, var51, (java.awt.Paint)var56, var57, 1.0f);
//     var26.addDomainMarker((org.jfree.chart.plot.Marker)var59);
//     org.jfree.chart.plot.RingPlot var61 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Graphics2D var62 = null;
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.data.general.PieDataset var64 = null;
//     org.jfree.chart.plot.PiePlot var65 = new org.jfree.chart.plot.PiePlot(var64);
//     org.jfree.chart.util.RectangleInsets var66 = var65.getLabelPadding();
//     var65.setSectionOutlinesVisible(true);
//     java.awt.Paint var69 = var65.getBaseSectionPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     org.jfree.chart.plot.PiePlotState var72 = var61.initialise(var62, var63, var65, (java.lang.Integer)0, var71);
//     var61.setSeparatorsVisible(true);
//     double var75 = var61.getInnerSeparatorExtension();
//     java.awt.Stroke var76 = var61.getSeparatorStroke();
//     org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot();
//     var78.setForegroundAlpha(1.0f);
//     java.awt.Font var81 = var78.getNoDataMessageFont();
//     var78.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var84 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var78);
//     java.awt.Paint var85 = var84.getBackgroundPaint();
//     var84.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var87 = var84.getPadding();
//     var84.setAntiAlias(true);
//     java.awt.Image var90 = var84.getBackgroundImage();
//     var61.addChangeListener((org.jfree.chart.event.PlotChangeListener)var84);
//     java.awt.Stroke var92 = var61.getLabelLinkStroke();
//     var26.setRangeZeroBaselineStroke(var92);
//     var16.setDomainGridlineStroke(var92);
//     
//     // Checks the contract:  equals-hashcode on var4 and var65
//     assertTrue("Contract failed: equals-hashcode on var4 and var65", var4.equals(var65) ? var4.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var4
//     assertTrue("Contract failed: equals-hashcode on var65 and var4", var65.equals(var4) ? var65.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test135"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    double var2 = var0.getMinimumArcAngleToDraw();
    java.awt.Paint var3 = var0.getLabelShadowPaint();
    double var4 = var0.getInnerSeparatorExtension();
    org.jfree.chart.ui.BasicProjectInfo var10 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var10.setLicenceName("hi!");
    org.jfree.chart.ui.ProjectInfo var13 = new org.jfree.chart.ui.ProjectInfo();
    java.util.List var14 = var13.getContributors();
    var10.addOptionalLibrary((org.jfree.chart.ui.Library)var13);
    org.jfree.chart.JFreeChart var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.setForegroundAlpha(1.0f);
    java.awt.Paint var20 = var17.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var17);
    org.jfree.chart.plot.Plot var22 = var21.getPlot();
    org.jfree.chart.event.ChartChangeEventType var23 = var21.getType();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var25 = var24.clone();
    double var26 = var24.getLowerBound();
    boolean var27 = var23.equals((java.lang.Object)var24);
    org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var10, var16, var23);
    boolean var29 = var0.equals((java.lang.Object)var23);
    java.awt.Stroke var30 = var0.getSeparatorStroke();
    var0.setOuterSeparatorExtension((-5.95d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test136"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     var4.setSectionOutlinesVisible(true);
//     java.awt.Paint var8 = var4.getBaseSectionPaint();
//     var1.setAxisLinePaint(var8);
//     org.jfree.data.Range var10 = var1.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
//     org.jfree.chart.block.RectangleConstraint var12 = var11.toUnconstrainedWidth();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var15 = var14.clone();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var17.getLabelPadding();
//     var17.setSectionOutlinesVisible(true);
//     java.awt.Paint var21 = var17.getBaseSectionPaint();
//     var14.setAxisLinePaint(var21);
//     org.jfree.data.Range var23 = var14.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(100.0d, var23);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var26 = var25.clone();
//     org.jfree.data.Range var27 = var25.getRange();
//     org.jfree.data.Range var28 = org.jfree.data.Range.combine(var23, var27);
//     org.jfree.chart.block.RectangleConstraint var29 = var12.toRangeHeight(var27);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test137"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-45.29999999999999d), 0.18d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test138"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    double var4 = var2.calculateRightOutset(100.0d);
    double var5 = var2.getLeft();
    double var6 = var2.getRight();
    double var8 = var2.trimWidth(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-3.0d));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test139"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var7.setURLText("Range[0.0,1.0]");
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var19 = var18.clone();
    org.jfree.chart.axis.ValueAxis[] var20 = new org.jfree.chart.axis.ValueAxis[] { var18};
    var17.setDomainAxes(var20);
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    var17.setRenderer(var22);
    org.jfree.chart.util.RectangleEdge var25 = var17.getRangeAxisEdge(0);
    var7.setPosition(var25);
    double var27 = var7.getHeight();
    org.jfree.chart.util.HorizontalAlignment var28 = var7.getTextAlignment();
    java.lang.String var29 = var7.getToolTipText();
    org.jfree.chart.util.HorizontalAlignment var30 = var7.getTextAlignment();
    org.jfree.chart.util.HorizontalAlignment var31 = var7.getHorizontalAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test140"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.data.xy.XYDataset var6 = var0.getDataset(100);
    java.awt.Stroke var7 = var0.getDomainCrosshairStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test141"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    var0.zoomDomainAxes((-1.0d), 3.0d, var3, var5);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.setForegroundAlpha(1.0f);
    java.awt.Font var11 = var8.getNoDataMessageFont();
    var8.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.AxisLocation var15 = var8.getDomainAxisLocation();
    var0.setDomainAxisLocation(var15);
    org.jfree.chart.axis.ValueAxis var18 = var0.getRangeAxis((-65536));
    boolean var19 = var0.isDomainZoomable();
    var0.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test142"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    java.awt.Shape var3 = var1.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var11 = var10.clone();
    org.jfree.chart.axis.ValueAxis[] var12 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var9.setDomainAxes(var12);
    java.awt.geom.Point2D var14 = var9.getQuadrantOrigin();
    var5.zoomDomainAxes(0.2d, 2.0d, var8, var14);
    boolean var16 = var5.isAngleGridlinesVisible();
    boolean var17 = var5.isDomainZoomable();
    java.awt.Paint var18 = var5.getAngleGridlinePaint();
    java.awt.Paint var19 = var5.getRadiusGridlinePaint();
    org.jfree.chart.LegendItemCollection var20 = var5.getLegendItems();
    int var21 = var5.getSeriesCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test143"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    var1.setSectionOutlinesVisible(true);
    double var7 = var1.getInteriorGap();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    org.jfree.chart.plot.PiePlotState var14 = var1.initialise(var8, var9, (org.jfree.chart.plot.PiePlot)var11, (java.lang.Integer)0, var13);
    double var15 = var14.getTotal();
    double var16 = var14.getLatestAngle();
    var14.setPieCenterX(6.140000000000001d);
    double var19 = var14.getPieHRadius();
    var14.setPieCenterY(9.223372036854776E18d);
    int var22 = var14.getPassesRequired();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test144"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var3 = var2.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var4 = null;
    var2.setTickUnit(var4, false, true);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var9 = var8.getTickMarkPosition();
    var2.setTickMarkPosition(var9);
    var0.setTickMarkPosition(var9);
    var0.setInverted(true);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var15 = var14.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var17 = var16.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var18 = null;
    var16.setTickUnit(var18, false, true);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var23 = var22.getTickMarkPosition();
    var16.setTickMarkPosition(var23);
    var14.setTickMarkPosition(var23);
    java.util.TimeZone var26 = var14.getTimeZone();
    var0.setTimeZone(var26);
    org.jfree.chart.axis.Timeline var28 = var0.getTimeline();
    org.jfree.chart.axis.DateTickUnit var29 = var0.getTickUnit();
    var0.setFixedAutoRange(4.0d);
    float var32 = var0.getTickMarkInsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0f);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test145"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    var0.setAnchorValue(100.0d);
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var8 = null;
    var6.setDomainAxisLocation(1, var8, false);
    java.awt.Stroke var11 = var6.getRangeCrosshairStroke();
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var6.getRangeMarkers(10, var13);
    java.util.List var15 = var6.getAnnotations();
    org.jfree.chart.plot.PlotOrientation var16 = var6.getOrientation();
    var0.setOrientation(var16);
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    var18.setForegroundAlpha(1.0f);
    org.jfree.chart.axis.AxisSpace var21 = null;
    var18.setFixedDomainAxisSpace(var21);
    org.jfree.chart.util.SortOrder var23 = var18.getColumnRenderingOrder();
    var0.setRowRenderingOrder(var23);
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var26 = var25.getQuadrantOrigin();
    var25.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = var25.getRendererForDataset(var30);
    org.jfree.chart.util.Layer var33 = null;
    java.util.Collection var34 = var25.getDomainMarkers(0, var33);
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var37 = var36.clone();
    org.jfree.chart.axis.ValueAxis[] var38 = new org.jfree.chart.axis.ValueAxis[] { var36};
    var35.setDomainAxes(var38);
    org.jfree.data.xy.XYDataset var41 = var35.getDataset(100);
    java.awt.Stroke var42 = var35.getRangeCrosshairStroke();
    var25.setRangeZeroBaselineStroke(var42);
    var0.setRangeGridlineStroke(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test146"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(100);
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test147"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("Multiple Pie Plot");
    var1.setAutoTickUnitSelection(false, true);
    var1.setAutoRange(true);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test148"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     float var25 = var24.getAlpha();
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var27 = var26.clone();
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot(var28);
//     org.jfree.chart.util.RectangleInsets var30 = var29.getLabelPadding();
//     var29.setSectionOutlinesVisible(true);
//     java.awt.Paint var33 = var29.getBaseSectionPaint();
//     var26.setAxisLinePaint(var33);
//     var24.setPaint(var33);
//     java.awt.Paint var36 = var24.getOutlinePaint();
//     var24.setAlpha(0.5f);
//     java.awt.Stroke var39 = var24.getStroke();
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var41 = null;
//     var40.datasetChanged(var41);
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     var40.setRenderer(1, var44);
//     org.jfree.chart.util.RectangleEdge var47 = var40.getDomainAxisEdge(10);
//     org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
//     java.awt.Paint var49 = var48.getItemPaint();
//     org.jfree.chart.util.RectangleAnchor var50 = var48.getLegendItemGraphicAnchor();
//     var24.setLabelAnchor(var50);
//     
//     // Checks the contract:  equals-hashcode on var11 and var40
//     assertTrue("Contract failed: equals-hashcode on var11 and var40", var11.equals(var40) ? var11.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var11
//     assertTrue("Contract failed: equals-hashcode on var40 and var11", var40.equals(var11) ? var40.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test149"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    var0.setRenderer(1, var4);
    org.jfree.chart.util.RectangleEdge var7 = var0.getDomainAxisEdge(10);
    boolean var9 = var0.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var11 = var0.getRangeAxisLocation(0);
    var0.setRangeCrosshairVisible(false);
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var0.drawBackgroundImage(var14, var15);
    java.lang.String var17 = var0.getPlotType();
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var20 = var19.getTickMarkPosition();
    var19.configure();
    var0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var19, false);
    java.util.Date var24 = var19.getMinimumDate();
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var27 = var26.clone();
    org.jfree.chart.axis.ValueAxis[] var28 = new org.jfree.chart.axis.ValueAxis[] { var26};
    var25.setDomainAxes(var28);
    org.jfree.data.xy.XYDataset var31 = var25.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    var25.setRenderer(100, var33, false);
    java.awt.Color var40 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var40);
    org.jfree.chart.util.HorizontalAlignment var42 = null;
    org.jfree.chart.util.VerticalAlignment var43 = null;
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement(var42, var43, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var49 = null;
    var47.setDomainAxisLocation(1, var49, false);
    java.awt.Stroke var52 = var47.getRangeCrosshairStroke();
    boolean var53 = var46.equals((java.lang.Object)var52);
    java.awt.Color var57 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var58 = null;
    org.jfree.chart.plot.ValueMarker var60 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var40, var52, (java.awt.Paint)var57, var58, 1.0f);
    java.lang.Object var61 = var60.clone();
    var25.addDomainMarker((org.jfree.chart.plot.Marker)var60);
    double var63 = var25.getRangeCrosshairValue();
    org.jfree.chart.axis.AxisSpace var64 = var25.getFixedDomainAxisSpace();
    org.jfree.chart.event.AxisChangeEvent var65 = null;
    var25.axisChanged(var65);
    var19.addChangeListener((org.jfree.chart.event.AxisChangeListener)var25);
    org.jfree.chart.axis.AxisSpace var68 = null;
    var25.setFixedRangeAxisSpace(var68, false);
    var25.setDomainCrosshairValue(9.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "XY Plot"+ "'", var17.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test150"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("XY Plot");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test151"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    java.awt.geom.Point2D var8 = var0.getQuadrantOrigin();
    boolean var9 = var0.isDomainGridlinesVisible();
    org.jfree.chart.util.RectangleEdge var11 = var0.getRangeAxisEdge(0);
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var14 = var13.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var16 = var15.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var17 = null;
    var15.setTickUnit(var17, false, true);
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var22 = var21.getTickMarkPosition();
    var15.setTickMarkPosition(var22);
    var13.setTickMarkPosition(var22);
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var27 = var26.getQuadrantOrigin();
    var26.mapDatasetToDomainAxis(100, 0);
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var33 = var32.getPlotType();
    org.jfree.chart.urls.PieURLGenerator var34 = null;
    var32.setLegendLabelURLGenerator(var34);
    java.awt.Graphics2D var36 = null;
    org.jfree.data.general.PieDataset var38 = null;
    org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot(var38);
    org.jfree.chart.util.RectangleInsets var40 = var39.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var41 = null;
    var39.setToolTipGenerator(var41);
    java.awt.Font var43 = var39.getLabelFont();
    org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var43);
    var44.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var50 = var44.getURLText();
    org.jfree.chart.util.VerticalAlignment var51 = var44.getVerticalAlignment();
    java.awt.geom.Rectangle2D var52 = var44.getBounds();
    var32.drawBackgroundImage(var36, var52);
    java.util.List var54 = null;
    var26.drawRangeTickBands(var31, var52, var54);
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
    var56.setForegroundAlpha(1.0f);
    java.awt.Paint var59 = var56.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var60 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var56);
    var56.configureRangeAxes();
    org.jfree.chart.util.RectangleEdge var63 = var56.getDomainAxisEdge(0);
    double var64 = var13.valueToJava2D(0.08d, var52, var63);
    org.jfree.chart.plot.PlotRenderingInfo var66 = null;
    org.jfree.chart.plot.CrosshairState var67 = null;
    boolean var68 = var0.render(var12, var52, (-16777216), var66, var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "Pie 3D Plot"+ "'", var33.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test152"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    java.awt.Stroke var3 = var0.getOutlineStroke();
    org.jfree.chart.plot.SeriesRenderingOrder var4 = var0.getSeriesRenderingOrder();
    java.awt.geom.Point2D var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantOrigin(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test153"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var0.setRangeCrosshairPaint(var9);
    java.lang.Object var11 = var0.clone();
    org.jfree.chart.LegendItemCollection var12 = var0.getLegendItems();
    var0.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var15 = null;
    var0.setFixedDomainAxisSpace(var15);
    int var17 = var0.getDatasetCount();
    org.jfree.data.general.DatasetGroup var18 = var0.getDatasetGroup();
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var22 = null;
    var20.setDomainAxisLocation(1, var22, false);
    java.awt.Stroke var25 = var20.getRangeCrosshairStroke();
    var20.setRangeCrosshairLockedOnData(false);
    java.awt.geom.Point2D var28 = var20.getQuadrantOrigin();
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var30 = var29.getQuadrantOrigin();
    var29.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = var29.getRendererForDataset(var34);
    org.jfree.chart.axis.AxisLocation var37 = var29.getRangeAxisLocation((-65536));
    var20.setRangeAxisLocation(var37);
    var0.setDomainAxisLocation(4, var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test154"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    java.awt.Stroke var2 = var0.getStroke((java.lang.Comparable)1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test155"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var2 = null;
    var1.datasetChanged(var2);
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    var1.setRenderer(1, var5);
    org.jfree.chart.util.RectangleEdge var8 = var1.getDomainAxisEdge(10);
    boolean var10 = var1.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var12 = var1.getRangeAxisLocation(0);
    boolean var13 = var1.isDomainCrosshairLockedOnData();
    var1.setDomainZeroBaselineVisible(true);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.setForegroundAlpha(1.0f);
    java.awt.Font var20 = var17.getNoDataMessageFont();
    var17.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var17);
    org.jfree.chart.axis.AxisLocation var24 = var17.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var25 = var17.getDomainAxisLocation();
    var1.setRangeAxisLocation(var25);
    var1.clearAnnotations();
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot(var28);
    org.jfree.chart.util.RectangleInsets var30 = var29.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var31 = null;
    var29.setToolTipGenerator(var31);
    var29.setSectionOutlinesVisible(true);
    double var35 = var29.getInteriorGap();
    java.awt.Stroke var37 = var29.getSectionOutlineStroke((java.lang.Comparable)0L);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
    var38.setForegroundAlpha(1.0f);
    java.awt.Font var41 = var38.getNoDataMessageFont();
    var38.setAnchorValue(0.0d, false);
    org.jfree.chart.util.RectangleEdge var46 = var38.getDomainAxisEdge(10);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var38);
    java.awt.Stroke var48 = var38.getRangeCrosshairStroke();
    var29.setOutlineStroke(var48);
    var1.setRangeGridlineStroke(var48);
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var53 = null;
    var51.setDomainAxisLocation(1, var53, false);
    java.awt.Stroke var56 = var51.getRangeCrosshairStroke();
    var1.setDomainCrosshairStroke(var56);
    org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var59 = var58.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var60 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var61 = var60.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var62 = null;
    var60.setTickUnit(var62, false, true);
    org.jfree.chart.axis.DateAxis var66 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var67 = var66.getTickMarkPosition();
    var60.setTickMarkPosition(var67);
    var58.setTickMarkPosition(var67);
    org.jfree.chart.axis.DateTickUnit var70 = null;
    var58.setTickUnit(var70);
    org.jfree.chart.axis.DateTickUnit var72 = null;
    var58.setTickUnit(var72, true, false);
    double var76 = var58.getLowerBound();
    org.jfree.data.Range var77 = var1.getDataRange((org.jfree.chart.axis.ValueAxis)var58);
    org.jfree.chart.renderer.PolarItemRenderer var78 = null;
    org.jfree.chart.plot.PolarPlot var79 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var58, var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test156"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedDomainAxisSpace(var3);
//     java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var9);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var18 = null;
//     var16.setDomainAxisLocation(1, var18, false);
//     java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
//     boolean var22 = var15.equals((java.lang.Object)var21);
//     java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var27 = null;
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var9, var21, (java.awt.Paint)var26, var27, 1.0f);
//     java.lang.Object var30 = var29.clone();
//     org.jfree.chart.util.Layer var31 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var29, var31);
//     java.util.List var33 = var0.getAnnotations();
//     java.awt.Color var39 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var39);
//     org.jfree.chart.util.HorizontalAlignment var41 = null;
//     org.jfree.chart.util.VerticalAlignment var42 = null;
//     org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var48 = null;
//     var46.setDomainAxisLocation(1, var48, false);
//     java.awt.Stroke var51 = var46.getRangeCrosshairStroke();
//     boolean var52 = var45.equals((java.lang.Object)var51);
//     java.awt.Color var56 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var57 = null;
//     org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var39, var51, (java.awt.Paint)var56, var57, 1.0f);
//     java.lang.Object var60 = var59.clone();
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var62 = var61.getQuadrantOrigin();
//     var61.setRangeCrosshairValue(10.0d, true);
//     org.jfree.data.xy.XYDataset var66 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var67 = var61.getRendererForDataset(var66);
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot();
//     var69.setForegroundAlpha(1.0f);
//     java.awt.Font var72 = var69.getNoDataMessageFont();
//     var69.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var75 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var69);
//     org.jfree.chart.axis.AxisLocation var76 = var69.getDomainAxisLocation();
//     var61.setRangeAxisLocation(var76);
//     boolean var78 = var59.equals((java.lang.Object)var61);
//     org.jfree.data.xy.XYDataset var79 = null;
//     org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var81 = var80.clone();
//     java.awt.Shape var82 = var80.getLeftArrow();
//     org.jfree.chart.renderer.PolarItemRenderer var83 = null;
//     org.jfree.chart.plot.PolarPlot var84 = new org.jfree.chart.plot.PolarPlot(var79, (org.jfree.chart.axis.ValueAxis)var80, var83);
//     org.jfree.chart.renderer.PolarItemRenderer var85 = var84.getRenderer();
//     org.jfree.chart.axis.NumberAxis var87 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var88 = var87.getTickLabelFont();
//     org.jfree.data.Range var89 = var84.getDataRange((org.jfree.chart.axis.ValueAxis)var87);
//     org.jfree.chart.axis.ValueAxis var90 = var84.getAxis();
//     org.jfree.chart.plot.PlotOrientation var91 = var84.getOrientation();
//     var61.setOrientation(var91);
//     org.jfree.chart.axis.AxisLocation var93 = var61.getRangeAxisLocation();
//     var0.setRangeAxisLocation(0, var93);
//     
//     // Checks the contract:  equals-hashcode on var10 and var40
//     assertTrue("Contract failed: equals-hashcode on var10 and var40", var10.equals(var40) ? var10.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var10
//     assertTrue("Contract failed: equals-hashcode on var40 and var10", var40.equals(var10) ? var40.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var45
//     assertTrue("Contract failed: equals-hashcode on var15 and var45", var15.equals(var45) ? var15.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var15
//     assertTrue("Contract failed: equals-hashcode on var45 and var15", var45.equals(var15) ? var45.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var46
//     assertTrue("Contract failed: equals-hashcode on var16 and var46", var16.equals(var46) ? var16.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var16
//     assertTrue("Contract failed: equals-hashcode on var46 and var16", var46.equals(var16) ? var46.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var59
//     assertTrue("Contract failed: equals-hashcode on var29 and var59", var29.equals(var59) ? var29.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var29
//     assertTrue("Contract failed: equals-hashcode on var59 and var29", var59.equals(var29) ? var59.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var60
//     assertTrue("Contract failed: equals-hashcode on var30 and var60", var30.equals(var60) ? var30.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var30
//     assertTrue("Contract failed: equals-hashcode on var60 and var30", var60.equals(var30) ? var60.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test157"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    var11.setCategoryLabelPositionOffset((-65536));
    java.awt.Paint var18 = null;
    var11.setTickLabelPaint((java.lang.Comparable)"Other", var18);
    var11.clearCategoryLabelToolTips();
    double var21 = var11.getCategoryMargin();
    var11.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test158"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
//     var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var13 = var7.getURLText();
//     var7.setURLText("RectangleConstraintType.RANGE");
//     var7.setNotify(true);
//     java.awt.Paint var18 = null;
//     var7.setBackgroundPaint(var18);
//     double var20 = var7.getContentYOffset();
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var22 = var21.clone();
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot(var23);
//     org.jfree.chart.util.RectangleInsets var25 = var24.getLabelPadding();
//     var24.setSectionOutlinesVisible(true);
//     java.awt.Paint var28 = var24.getBaseSectionPaint();
//     var21.setAxisLinePaint(var28);
//     org.jfree.data.Range var30 = var21.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var33 = var32.getTickLabelFont();
//     var21.setLabelFont(var33);
//     var21.setInverted(false);
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var39 = var38.clone();
//     org.jfree.chart.axis.ValueAxis[] var40 = new org.jfree.chart.axis.ValueAxis[] { var38};
//     var37.setDomainAxes(var40);
//     java.awt.geom.Point2D var42 = var37.getQuadrantOrigin();
//     var21.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var37);
//     var21.setLabelAngle(10.5d);
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var49 = var48.getTickLabelFont();
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var51 = var50.getQuadrantOrigin();
//     var50.mapDatasetToDomainAxis(100, 0);
//     java.awt.Paint var55 = var50.getDomainCrosshairPaint();
//     org.jfree.chart.text.TextBlock var56 = org.jfree.chart.text.TextUtilities.createTextBlock("Multiple Pie Plot", var49, var55);
//     var21.setLabelFont(var49);
//     var7.setFont(var49);
//     
//     // Checks the contract:  equals-hashcode on var2 and var24
//     assertTrue("Contract failed: equals-hashcode on var2 and var24", var2.equals(var24) ? var2.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var2
//     assertTrue("Contract failed: equals-hashcode on var24 and var2", var24.equals(var2) ? var24.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test159"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    float var25 = var24.getAlpha();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var27 = var26.clone();
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot(var28);
    org.jfree.chart.util.RectangleInsets var30 = var29.getLabelPadding();
    var29.setSectionOutlinesVisible(true);
    java.awt.Paint var33 = var29.getBaseSectionPaint();
    var26.setAxisLinePaint(var33);
    var24.setPaint(var33);
    java.awt.Stroke var36 = var24.getStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test160"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.geom.Point2D var5 = var0.getQuadrantOrigin();
    int var6 = var0.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 15);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test161"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.lang.Comparable var2 = var1.getAggregatedItemsKey();
    java.lang.Comparable var3 = var1.getAggregatedItemsKey();
    var1.setLimit(0.08d);
    double var6 = var1.getLimit();
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var10 = null;
    var8.setDomainAxisLocation(1, var10, false);
    java.awt.Stroke var13 = var8.getRangeCrosshairStroke();
    java.awt.Font var14 = var8.getNoDataMessageFont();
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Color var19 = var18.darker();
    org.jfree.chart.text.TextFragment var20 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var14, (java.awt.Paint)var18);
    float[] var21 = null;
    float[] var22 = var18.getRGBColorComponents(var21);
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Color var27 = var26.darker();
    float[] var31 = new float[] { 100.0f, 100.0f, (-1.0f)};
    float[] var32 = var27.getRGBColorComponents(var31);
    float[] var33 = var18.getRGBColorComponents(var31);
    var1.setBackgroundPaint((java.awt.Paint)var18);
    org.jfree.chart.LegendItemCollection var35 = var1.getLegendItems();
    java.awt.Paint var36 = var1.getAggregatedItemsPaint();
    org.jfree.chart.plot.DrawingSupplier var37 = var1.getDrawingSupplier();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Other"+ "'", var2.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Other"+ "'", var3.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test162"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var4 = var0.getRowRenderingOrder();
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var16.setDomainAxisLocation(1, var18, false);
    java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
    boolean var22 = var15.equals((java.lang.Object)var21);
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var27 = null;
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var9, var21, (java.awt.Paint)var26, var27, 1.0f);
    org.jfree.chart.event.MarkerChangeListener var30 = null;
    var29.addChangeListener(var30);
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var29);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    var34.setForegroundAlpha(1.0f);
    java.awt.Font var37 = var34.getNoDataMessageFont();
    var34.setAnchorValue(100.0d);
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var41.setMaximumCategoryLabelLines((-1));
    int var44 = var34.getDomainAxisIndex(var41);
    var0.setDomainAxis(100, var41);
    org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var47 = null;
    var46.setMarkerBand(var47);
    int var49 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var46);
    var0.clearAnnotations();
    boolean var51 = var0.isRangeZoomable();
    org.jfree.chart.axis.AxisSpace var52 = null;
    var0.setFixedDomainAxisSpace(var52);
    org.jfree.chart.plot.PlotOrientation var54 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var54);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test163"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    var2.setSectionOutlinesVisible(true);
    java.awt.Paint var6 = var2.getBaseSectionPaint();
    java.awt.Paint var8 = var2.getSectionPaint((java.lang.Comparable)100.0d);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.util.RectangleInsets var11 = var9.getLabelInsets();
    double var13 = var11.calculateRightOutset(100.0d);
    java.lang.String var14 = var11.toString();
    double var16 = var11.calculateRightOutset((-7.0d));
    double var18 = var11.calculateBottomOutset(0.12d);
    var2.setSimpleLabelOffset(var11);
    java.awt.Paint var20 = var2.getBaseSectionPaint();
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
    org.jfree.chart.util.RectangleInsets var23 = var22.getLabelPadding();
    boolean var24 = var22.getLabelLinksVisible();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var26 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var22.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var26);
    org.jfree.chart.labels.PieSectionLabelGenerator var28 = var22.getLegendLabelToolTipGenerator();
    boolean var29 = var22.getSectionOutlinesVisible();
    java.awt.Stroke var30 = var22.getLabelOutlineStroke();
    org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(1.0E-5d, var20, var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var14.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test164"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    var1.setSectionOutlinesVisible(true);
    double var7 = var1.getInteriorGap();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    org.jfree.chart.plot.PiePlotState var14 = var1.initialise(var8, var9, (org.jfree.chart.plot.PiePlot)var11, (java.lang.Integer)0, var13);
    var14.setPassesRequired((-8372160));
    double var17 = var14.getPieHRadius();
    org.jfree.chart.entity.EntityCollection var18 = var14.getEntityCollection();
    double var19 = var14.getTotal();
    double var20 = var14.getPieHRadius();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test165"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
    var0.configure();
    java.awt.Shape var3 = var0.getRightArrow();
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var9 = var8.clone();
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    org.jfree.chart.util.RectangleInsets var12 = var11.getLabelPadding();
    var11.setSectionOutlinesVisible(true);
    java.awt.Paint var15 = var11.getBaseSectionPaint();
    var8.setAxisLinePaint(var15);
    double var17 = var8.getLowerMargin();
    boolean var18 = var8.isVerticalTickLabels();
    var8.setPositiveArrowVisible(true);
    org.jfree.data.Range var21 = var8.getRange();
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint(3.0d, var21);
    org.jfree.chart.util.Size2D var23 = var4.arrange(var5, var6, var22);
    org.jfree.chart.util.RectangleAnchor var26 = null;
    java.awt.geom.Rectangle2D var27 = org.jfree.chart.util.RectangleAnchor.createRectangle(var23, 2.0d, 10.5d, var26);
    java.lang.String var28 = var23.toString();
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
    var32.setForegroundAlpha(1.0f);
    java.awt.Font var35 = var32.getNoDataMessageFont();
    var32.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var32);
    org.jfree.chart.axis.AxisLocation var39 = var32.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var40 = var32.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var41 = null;
    org.jfree.chart.util.VerticalAlignment var42 = null;
    org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var46 = null;
    org.jfree.chart.util.VerticalAlignment var47 = null;
    org.jfree.chart.block.ColumnArrangement var50 = new org.jfree.chart.block.ColumnArrangement(var46, var47, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var32, (org.jfree.chart.block.Arrangement)var45, (org.jfree.chart.block.Arrangement)var50);
    org.jfree.chart.util.RectangleEdge var52 = var51.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var53 = var51.getLegendItemGraphicAnchor();
    java.awt.geom.Rectangle2D var54 = org.jfree.chart.util.RectangleAnchor.createRectangle(var23, 3.0d, (-45.29999999999999d), var53);
    org.jfree.data.general.PieDataset var55 = null;
    org.jfree.chart.entity.PieSectionEntity var61 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var54, var55, (-1), (-65537), (java.lang.Comparable)"poly", "Range[0.0,1.0]", "Category Plot");
    var0.setRightArrow((java.awt.Shape)var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "Size2D[width=3.0, height=0.0]"+ "'", var28.equals("Size2D[width=3.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test166"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)1.0d, var1, 0, (-1));
    var4.setPercent(100);
    int var7 = var4.getType();
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    var9.setForegroundAlpha(1.0f);
    java.awt.Font var12 = var9.getNoDataMessageFont();
    var9.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var9);
    java.awt.Paint var16 = var15.getBackgroundPaint();
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
    org.jfree.chart.util.RectangleInsets var19 = var18.getLabelPadding();
    org.jfree.chart.util.UnitType var20 = var19.getUnitType();
    var15.setPadding(var19);
    org.jfree.chart.title.TextTitle var22 = var15.getTitle();
    boolean var23 = var15.getAntiAlias();
    var4.setChart(var15);
    org.jfree.chart.JFreeChart var25 = var4.getChart();
    boolean var26 = var25.isNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test167"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     org.jfree.chart.util.RectangleInsets var23 = var22.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var24 = null;
//     var22.setToolTipGenerator(var24);
//     java.awt.Stroke var26 = var22.getBaseSectionOutlineStroke();
//     java.awt.Paint var27 = var22.getLabelLinkPaint();
//     var20.setItemPaint(var27);
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var31 = null;
//     var29.setDomainAxisLocation(1, var31, false);
//     java.awt.Stroke var34 = var29.getRangeCrosshairStroke();
//     var29.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.Plot var37 = var29.getRootPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     var29.setRenderer(var38);
//     java.awt.Paint var40 = var29.getDomainZeroBaselinePaint();
//     var20.setItemPaint(var40);
//     java.awt.Font var42 = var20.getItemFont();
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var44 = var43.clone();
//     org.jfree.data.general.PieDataset var45 = null;
//     org.jfree.chart.plot.PiePlot var46 = new org.jfree.chart.plot.PiePlot(var45);
//     org.jfree.chart.util.RectangleInsets var47 = var46.getLabelPadding();
//     var46.setSectionOutlinesVisible(true);
//     java.awt.Paint var50 = var46.getBaseSectionPaint();
//     var43.setAxisLinePaint(var50);
//     double var52 = var43.getLowerMargin();
//     boolean var53 = var43.isVerticalTickLabels();
//     var43.setPositiveArrowVisible(true);
//     boolean var56 = var20.equals((java.lang.Object)true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var46
//     assertTrue("Contract failed: equals-hashcode on var22 and var46", var22.equals(var46) ? var22.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var22
//     assertTrue("Contract failed: equals-hashcode on var46 and var22", var46.equals(var22) ? var46.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test168"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var3 = var2.clone();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var2.setAxisLinePaint(var9);
    org.jfree.data.Range var11 = var2.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(100.0d, var11);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var14 = var13.clone();
    org.jfree.data.Range var15 = var13.getRange();
    org.jfree.data.Range var16 = org.jfree.data.Range.combine(var11, var15);
    java.lang.String var17 = var15.toString();
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(0.0d, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "Range[0.0,1.0]"+ "'", var17.equals("Range[0.0,1.0]"));

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test169"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var1.setDomainAxisLocation(1, var3, false);
    java.awt.Stroke var6 = var1.getRangeCrosshairStroke();
    var1.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisSpace var9 = var1.getFixedDomainAxisSpace();
    org.jfree.data.xy.XYDataset var10 = var1.getDataset();
    org.jfree.chart.axis.AxisSpace var11 = var1.getFixedRangeAxisSpace();
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = ChartEntity: tooltip = Pie 3D Plot", (org.jfree.chart.plot.Plot)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test170"); }


    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.setForegroundAlpha(1.0f);
    java.awt.Font var6 = var3.getNoDataMessageFont();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var8 = null;
    var7.datasetChanged(var8);
    java.awt.Stroke var10 = var7.getOutlineStroke();
    java.awt.Paint var11 = var7.getRangeZeroBaselinePaint();
    org.jfree.chart.text.TextLine var12 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6, var11);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("RectangleConstraintType.RANGE", var6);
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
    var14.mapDatasetToDomainAxis(100, 0);
    java.awt.Paint var19 = var14.getDomainCrosshairPaint();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.text.G2TextMeasurer var22 = new org.jfree.chart.text.G2TextMeasurer(var21);
    org.jfree.chart.text.TextBlock var23 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var19, 10.0f, (org.jfree.chart.text.TextMeasurer)var22);
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.text.TextBlockAnchor var27 = null;
    var23.draw(var24, 1.0f, 2.0f, var27, 100.0f, 0.0f, 3.0d);
    org.jfree.chart.util.HorizontalAlignment var32 = var23.getLineAlignment();
    org.jfree.chart.util.HorizontalAlignment var33 = var23.getLineAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test171"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedDomainAxisSpace(var1, true);
//     var0.clearDomainMarkers(100);
//     var0.setOutlineVisible(true);
//     org.jfree.data.general.DatasetGroup var8 = var0.getDatasetGroup();
//     boolean var9 = var0.isDomainCrosshairVisible();
//     java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var14);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var21.setDomainAxisLocation(1, var23, false);
//     java.awt.Stroke var26 = var21.getRangeCrosshairStroke();
//     boolean var27 = var20.equals((java.lang.Object)var26);
//     java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var32 = null;
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var14, var26, (java.awt.Paint)var31, var32, 1.0f);
//     java.awt.color.ColorSpace var35 = var14.getColorSpace();
//     var0.setDomainCrosshairPaint((java.awt.Paint)var14);
//     int var37 = var14.getGreen();
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var39 = null;
//     var38.setFixedDomainAxisSpace(var39, true);
//     var38.clearDomainMarkers(100);
//     var38.setOutlineVisible(true);
//     org.jfree.chart.axis.ValueAxis var47 = var38.getRangeAxis(0);
//     java.awt.Color var52 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var53 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var52);
//     org.jfree.chart.util.HorizontalAlignment var54 = null;
//     org.jfree.chart.util.VerticalAlignment var55 = null;
//     org.jfree.chart.block.ColumnArrangement var58 = new org.jfree.chart.block.ColumnArrangement(var54, var55, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var61 = null;
//     var59.setDomainAxisLocation(1, var61, false);
//     java.awt.Stroke var64 = var59.getRangeCrosshairStroke();
//     boolean var65 = var58.equals((java.lang.Object)var64);
//     java.awt.Color var69 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var70 = null;
//     org.jfree.chart.plot.ValueMarker var72 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var52, var64, (java.awt.Paint)var69, var70, 1.0f);
//     var38.setDomainGridlinePaint((java.awt.Paint)var52);
//     int var74 = var52.getRGB();
//     boolean var75 = var14.equals((java.lang.Object)var52);
//     
//     // Checks the contract:  equals-hashcode on var21 and var59
//     assertTrue("Contract failed: equals-hashcode on var21 and var59", var21.equals(var59) ? var21.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var21
//     assertTrue("Contract failed: equals-hashcode on var59 and var21", var59.equals(var21) ? var59.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var53
//     assertTrue("Contract failed: equals-hashcode on var15 and var53", var15.equals(var53) ? var15.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var15
//     assertTrue("Contract failed: equals-hashcode on var53 and var15", var53.equals(var15) ? var53.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var58
//     assertTrue("Contract failed: equals-hashcode on var20 and var58", var20.equals(var58) ? var20.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var20
//     assertTrue("Contract failed: equals-hashcode on var58 and var20", var58.equals(var20) ? var58.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var72
//     assertTrue("Contract failed: equals-hashcode on var34 and var72", var34.equals(var72) ? var34.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var34
//     assertTrue("Contract failed: equals-hashcode on var72 and var34", var72.equals(var34) ? var72.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test172"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
    var0.mapDatasetToDomainAxis(100, 0);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var7 = var6.getPlotType();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var6.setLegendLabelURLGenerator(var8);
    java.awt.Graphics2D var10 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var15 = null;
    var13.setToolTipGenerator(var15);
    java.awt.Font var17 = var13.getLabelFont();
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var17);
    var18.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var24 = var18.getURLText();
    org.jfree.chart.util.VerticalAlignment var25 = var18.getVerticalAlignment();
    java.awt.geom.Rectangle2D var26 = var18.getBounds();
    var6.drawBackgroundImage(var10, var26);
    java.util.List var28 = null;
    var0.drawRangeTickBands(var5, var26, var28);
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    var31.setForegroundAlpha(1.0f);
    java.awt.Font var34 = var31.getNoDataMessageFont();
    var31.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var31);
    org.jfree.chart.axis.AxisLocation var38 = var31.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var39 = var31.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var40 = null;
    org.jfree.chart.util.VerticalAlignment var41 = null;
    org.jfree.chart.block.ColumnArrangement var44 = new org.jfree.chart.block.ColumnArrangement(var40, var41, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var45 = null;
    org.jfree.chart.util.VerticalAlignment var46 = null;
    org.jfree.chart.block.ColumnArrangement var49 = new org.jfree.chart.block.ColumnArrangement(var45, var46, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var49);
    var50.setID("hi!");
    java.awt.Paint var53 = var50.getBackgroundPaint();
    org.jfree.chart.util.RectangleAnchor var54 = var50.getLegendItemGraphicAnchor();
    java.awt.geom.Point2D var55 = org.jfree.chart.util.RectangleAnchor.coordinates(var26, var54);
    org.jfree.chart.entity.ChartEntity var58 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var26, "RectangleConstraint[LengthConstraintType.FIXED: width=3.0, height=0.0]", "0,0,2,-2,2,2,2,2");
    java.lang.String var59 = var58.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Pie 3D Plot"+ "'", var7.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=3.0, height=0.0]"+ "'", var59.equals("RectangleConstraint[LengthConstraintType.FIXED: width=3.0, height=0.0]"));

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test173"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test174"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var7 = var6.clone();
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     org.jfree.chart.util.RectangleInsets var10 = var9.getLabelPadding();
//     var9.setSectionOutlinesVisible(true);
//     java.awt.Paint var13 = var9.getBaseSectionPaint();
//     var6.setAxisLinePaint(var13);
//     org.jfree.data.Range var15 = var6.getDefaultAutoRange();
//     var0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var6);
//     org.jfree.data.general.DatasetChangeEvent var17 = null;
//     var0.datasetChanged(var17);
//     org.jfree.chart.plot.SeriesRenderingOrder var19 = var0.getSeriesRenderingOrder();
//     var0.clearDomainAxes();
//     org.jfree.chart.plot.Marker var21 = null;
//     org.jfree.chart.util.Layer var22 = null;
//     boolean var23 = var0.removeDomainMarker(var21, var22);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test175"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    var0.zoomDomainAxes((-1.0d), 3.0d, var3, var5);
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    var0.setRenderer(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test176"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
    var3.setSectionOutlinesVisible(true);
    java.awt.Paint var7 = var3.getBaseSectionPaint();
    var0.setAxisLinePaint(var7);
    double var9 = var0.getLowerMargin();
    boolean var10 = var0.isVerticalTickLabels();
    var0.setPositiveArrowVisible(true);
    org.jfree.data.Range var13 = var0.getRange();
    double var14 = var0.getLabelAngle();
    org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var16 = var15.getNextFillPaint();
    java.awt.Stroke var17 = var15.getNextOutlineStroke();
    java.awt.Stroke var18 = var15.getNextStroke();
    java.awt.Shape var19 = var15.getNextShape();
    var0.setUpArrow(var19);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.entity.PieSectionEntity var27 = new org.jfree.chart.entity.PieSectionEntity(var19, var21, 0, 100, (java.lang.Comparable)"VerticalAlignment.CENTER", "Multiple Pie Plot", "0,0,2,-2,2,2,2,2");
    java.lang.String var28 = var27.toString();
    org.jfree.data.general.PieDataset var29 = null;
    var27.setDataset(var29);
    java.lang.Comparable var31 = var27.getSectionKey();
    int var32 = var27.getPieIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "PieSection: 0, 100(VerticalAlignment.CENTER)"+ "'", var28.equals("PieSection: 0, 100(VerticalAlignment.CENTER)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "VerticalAlignment.CENTER"+ "'", var31.equals("VerticalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test177"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    boolean var15 = var0.isRangeCrosshairVisible();
    boolean var16 = var0.isDomainZoomable();
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var21);
    org.jfree.chart.util.HorizontalAlignment var23 = null;
    org.jfree.chart.util.VerticalAlignment var24 = null;
    org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var30 = null;
    var28.setDomainAxisLocation(1, var30, false);
    java.awt.Stroke var33 = var28.getRangeCrosshairStroke();
    boolean var34 = var27.equals((java.lang.Object)var33);
    java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var39 = null;
    org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var21, var33, (java.awt.Paint)var38, var39, 1.0f);
    float var42 = var41.getAlpha();
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var44 = var43.clone();
    org.jfree.data.general.PieDataset var45 = null;
    org.jfree.chart.plot.PiePlot var46 = new org.jfree.chart.plot.PiePlot(var45);
    org.jfree.chart.util.RectangleInsets var47 = var46.getLabelPadding();
    var46.setSectionOutlinesVisible(true);
    java.awt.Paint var50 = var46.getBaseSectionPaint();
    var43.setAxisLinePaint(var50);
    var41.setPaint(var50);
    java.awt.Paint var53 = var41.getOutlinePaint();
    org.jfree.chart.util.Layer var54 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var41, var54);
    boolean var56 = var0.isRangeZoomable();
    org.jfree.chart.util.Layer var57 = null;
    java.util.Collection var58 = var0.getDomainMarkers(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test178"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    java.awt.Stroke var3 = var0.getOutlineStroke();
    java.awt.Paint var4 = var0.getRangeZeroBaselinePaint();
    java.awt.Stroke var5 = var0.getOutlineStroke();
    var0.mapDatasetToRangeAxis(100, 0);
    boolean var9 = var0.isDomainZoomable();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var13 = var12.getTickLabelFont();
    var12.setAutoRange(false);
    java.text.NumberFormat var16 = var12.getNumberFormatOverride();
    var12.setUpperBound(100.0d);
    boolean var19 = var12.isAutoTickUnitSelection();
    var0.setDomainAxis(4, (org.jfree.chart.axis.ValueAxis)var12);
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var23 = null;
    var21.setDomainAxisLocation(1, var23, false);
    java.awt.Stroke var26 = var21.getRangeCrosshairStroke();
    var21.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.Plot var29 = var21.getRootPlot();
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var32 = var31.getQuadrantOrigin();
    var31.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var36 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var37 = var31.getRendererForDataset(var36);
    org.jfree.chart.axis.AxisLocation var39 = var31.getRangeAxisLocation((-65536));
    var21.setRangeAxisLocation(0, var39, false);
    var0.setDomainAxisLocation(var39);
    var0.setBackgroundAlpha(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test179"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getDepthFactor();
    java.awt.Paint var2 = var0.getBaseSectionOutlinePaint();
    java.lang.Object var3 = var0.clone();
    boolean var4 = var0.getDarkerSides();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test180"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
    var0.zoom(1.0d);
    var0.configureRangeAxes();
    boolean var5 = var0.isRangeZeroBaselineVisible();
    org.jfree.chart.plot.PlotOrientation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test181"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    java.awt.Shape var3 = var1.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
    org.jfree.chart.renderer.PolarItemRenderer var6 = var5.getRenderer();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var9 = var8.getTickLabelFont();
    org.jfree.data.Range var10 = var5.getDataRange((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.chart.axis.ValueAxis var11 = var5.getAxis();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.setForegroundAlpha(1.0f);
    java.awt.Font var16 = var13.getNoDataMessageFont();
    var13.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var13);
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var22 = var21.clone();
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var21};
    var20.setDomainAxes(var23);
    org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
    var20.setRenderer(var25);
    java.awt.Stroke var27 = var20.getRangeCrosshairStroke();
    var19.setBorderStroke(var27);
    java.awt.Color var33 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var34 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var33);
    org.jfree.chart.util.HorizontalAlignment var35 = null;
    org.jfree.chart.util.VerticalAlignment var36 = null;
    org.jfree.chart.block.ColumnArrangement var39 = new org.jfree.chart.block.ColumnArrangement(var35, var36, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var42 = null;
    var40.setDomainAxisLocation(1, var42, false);
    java.awt.Stroke var45 = var40.getRangeCrosshairStroke();
    boolean var46 = var39.equals((java.lang.Object)var45);
    java.awt.Color var50 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var51 = null;
    org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var33, var45, (java.awt.Paint)var50, var51, 1.0f);
    float var54 = var53.getAlpha();
    java.awt.Paint var55 = var53.getLabelPaint();
    java.awt.Paint var56 = var53.getPaint();
    boolean var57 = var19.equals((java.lang.Object)var53);
    org.jfree.chart.plot.DefaultDrawingSupplier var58 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var59 = var58.getNextFillPaint();
    java.awt.Stroke var60 = var58.getNextOutlineStroke();
    java.awt.Stroke var61 = var58.getNextStroke();
    var53.setOutlineStroke(var61);
    var5.setOutlineStroke(var61);
    org.jfree.chart.LegendItemCollection var64 = var5.getLegendItems();
    org.jfree.chart.plot.PiePlot3D var65 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var66 = var65.getPlotType();
    org.jfree.chart.urls.PieURLGenerator var67 = null;
    var65.setLegendLabelURLGenerator(var67);
    java.awt.Graphics2D var69 = null;
    org.jfree.data.general.PieDataset var71 = null;
    org.jfree.chart.plot.PiePlot var72 = new org.jfree.chart.plot.PiePlot(var71);
    org.jfree.chart.util.RectangleInsets var73 = var72.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var74 = null;
    var72.setToolTipGenerator(var74);
    java.awt.Font var76 = var72.getLabelFont();
    org.jfree.chart.title.TextTitle var77 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var76);
    var77.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var83 = var77.getURLText();
    org.jfree.chart.util.VerticalAlignment var84 = var77.getVerticalAlignment();
    java.awt.geom.Rectangle2D var85 = var77.getBounds();
    var65.drawBackgroundImage(var69, var85);
    var65.setShadowYOffset(0.0d);
    var65.setOutlineVisible(true);
    java.awt.Font var91 = var65.getLabelFont();
    java.awt.Paint var92 = var65.getOutlinePaint();
    var5.setRadiusGridlinePaint(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var66 + "' != '" + "Pie 3D Plot"+ "'", var66.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test182"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var5.setDomainAxisLocation(1, var7, false);
    java.awt.Stroke var10 = var5.getRangeCrosshairStroke();
    var1.setBaseSectionOutlineStroke(var10);
    org.jfree.chart.event.PlotChangeEvent var12 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test183"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var4.setMarkerBand(var5);
    org.jfree.data.Range var7 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var4);
    var4.setLabelAngle((-1.0d));
    boolean var10 = var4.getAutoRangeIncludesZero();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setAutoRangeMinimumSize((-5.95d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test184"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var8 = var7.clone();
    float var9 = var7.getTickMarkInsideLength();
    java.lang.String var10 = var7.getLabelURL();
    var0.setDomainAxis(100, (org.jfree.chart.axis.ValueAxis)var7, true);
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot(var13);
    org.jfree.chart.util.RectangleInsets var15 = var14.getLabelPadding();
    boolean var16 = var14.getLabelLinksVisible();
    java.awt.Stroke var17 = var14.getBaseSectionOutlineStroke();
    boolean var18 = var7.hasListener((java.util.EventListener)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test185"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    boolean var3 = var1.getLabelLinksVisible();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var5);
    org.jfree.chart.labels.PieSectionLabelGenerator var7 = var1.getLegendLabelToolTipGenerator();
    boolean var8 = var1.getSectionOutlinesVisible();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
    var10.setSectionOutlinesVisible(true);
    java.awt.Paint var14 = var10.getShadowPaint();
    var1.setLabelShadowPaint(var14);
    var1.setCircular(false, false);
    java.lang.String var19 = var1.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "Pie Plot"+ "'", var19.equals("Pie Plot"));

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test186"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    org.jfree.chart.labels.PieSectionLabelGenerator var5 = var1.getLegendLabelToolTipGenerator();
    var1.setLabelLinkMargin(100.0d);
    var1.setPieIndex((-1));
    var1.setPieIndex(2);
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var14 = null;
    var12.setDomainAxisLocation(1, var14, false);
    java.awt.Stroke var17 = var12.getRangeCrosshairStroke();
    var12.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.LegendItemCollection var20 = var12.getLegendItems();
    org.jfree.chart.util.Layer var22 = null;
    java.util.Collection var23 = var12.getRangeMarkers((-65536), var22);
    java.awt.Stroke var24 = var12.getDomainZeroBaselineStroke();
    var1.setLabelOutlineStroke(var24);
    java.lang.String var26 = var1.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "Pie Plot"+ "'", var26.equals("Pie Plot"));

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test187"); }
// 
// 
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var5 = null;
//     var3.setToolTipGenerator(var5);
//     java.awt.Font var7 = var3.getLabelFont();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var7);
//     org.jfree.chart.text.TextLine var9 = new org.jfree.chart.text.TextLine("Other", var7);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var13 = var12.getTickLabelFont();
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
//     var14.mapDatasetToDomainAxis(100, 0);
//     java.awt.Paint var19 = var14.getDomainCrosshairPaint();
//     org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("Multiple Pie Plot", var13, var19);
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     org.jfree.chart.util.RectangleInsets var23 = var22.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var24 = null;
//     var22.setToolTipGenerator(var24);
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var28 = null;
//     var26.setDomainAxisLocation(1, var28, false);
//     java.awt.Stroke var31 = var26.getRangeCrosshairStroke();
//     var22.setBaseSectionOutlineStroke(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     var33.setForegroundAlpha(1.0f);
//     java.awt.Font var36 = var33.getNoDataMessageFont();
//     var22.setLabelFont(var36);
//     boolean var38 = var20.equals((java.lang.Object)var22);
//     boolean var39 = var9.equals((java.lang.Object)var20);
//     org.jfree.chart.text.TextLine var40 = var20.getLastLine();
//     org.jfree.chart.text.TextFragment var41 = var40.getLastTextFragment();
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.util.Size2D var43 = var41.calculateDimensions(var42);
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test188"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var3 = var2.getUpperMargin();
    var2.addCategoryLabelToolTip((java.lang.Comparable)10.0d, "RectangleConstraintType.RANGE");
    int var7 = var2.getMaximumCategoryLabelLines();
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
    var10.mapDatasetToDomainAxis(100, 0);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var17 = var16.getPlotType();
    org.jfree.chart.urls.PieURLGenerator var18 = null;
    var16.setLegendLabelURLGenerator(var18);
    java.awt.Graphics2D var20 = null;
    org.jfree.data.general.PieDataset var22 = null;
    org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
    org.jfree.chart.util.RectangleInsets var24 = var23.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var25 = null;
    var23.setToolTipGenerator(var25);
    java.awt.Font var27 = var23.getLabelFont();
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var27);
    var28.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var34 = var28.getURLText();
    org.jfree.chart.util.VerticalAlignment var35 = var28.getVerticalAlignment();
    java.awt.geom.Rectangle2D var36 = var28.getBounds();
    var16.drawBackgroundImage(var20, var36);
    java.util.List var38 = null;
    var10.drawRangeTickBands(var15, var36, var38);
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
    var41.setForegroundAlpha(1.0f);
    java.awt.Font var44 = var41.getNoDataMessageFont();
    var41.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var41);
    org.jfree.chart.axis.AxisLocation var48 = var41.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var49 = var41.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var50 = null;
    org.jfree.chart.util.VerticalAlignment var51 = null;
    org.jfree.chart.block.ColumnArrangement var54 = new org.jfree.chart.block.ColumnArrangement(var50, var51, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var55 = null;
    org.jfree.chart.util.VerticalAlignment var56 = null;
    org.jfree.chart.block.ColumnArrangement var59 = new org.jfree.chart.block.ColumnArrangement(var55, var56, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41, (org.jfree.chart.block.Arrangement)var54, (org.jfree.chart.block.Arrangement)var59);
    var60.setID("hi!");
    java.awt.Paint var63 = var60.getBackgroundPaint();
    org.jfree.chart.util.RectangleAnchor var64 = var60.getLegendItemGraphicAnchor();
    java.awt.geom.Point2D var65 = org.jfree.chart.util.RectangleAnchor.coordinates(var36, var64);
    org.jfree.chart.plot.XYPlot var66 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var68 = null;
    var66.setDomainAxisLocation(1, var68, false);
    java.awt.Stroke var71 = var66.getRangeCrosshairStroke();
    var66.setRangeCrosshairLockedOnData(false);
    java.awt.geom.Point2D var74 = var66.getQuadrantOrigin();
    boolean var75 = var66.isDomainGridlinesVisible();
    org.jfree.chart.util.RectangleEdge var77 = var66.getRangeAxisEdge(0);
    double var78 = var2.getCategoryMiddle(0, 10, var36, var77);
    org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis("XY Plot");
    org.jfree.chart.renderer.category.CategoryItemRenderer var81 = null;
    org.jfree.chart.plot.CategoryPlot var82 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var80, var81);
    var2.setMaximumCategoryLabelLines((-1));
    org.jfree.chart.axis.CategoryLabelPositions var85 = var2.getCategoryLabelPositions();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "Pie 3D Plot"+ "'", var17.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test189"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var7.setURLText("Range[0.0,1.0]");
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var19 = var18.clone();
    org.jfree.chart.axis.ValueAxis[] var20 = new org.jfree.chart.axis.ValueAxis[] { var18};
    var17.setDomainAxes(var20);
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    var17.setRenderer(var22);
    org.jfree.chart.util.RectangleEdge var25 = var17.getRangeAxisEdge(0);
    var7.setPosition(var25);
    java.lang.String var27 = var7.getToolTipText();
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    var7.draw(var28, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test190"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
    org.jfree.data.general.DatasetChangeEvent var2 = null;
    var0.datasetChanged(var2);
    java.awt.Paint var4 = var0.getOutlinePaint();
    int var5 = var0.getDatasetCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test191"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("UnitType.RELATIVE", "0,2,1,-2", "PlotOrientation.HORIZONTAL", "Size2D[width=3.0, height=0.0]");

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test192"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-48.29999999999999d), 4.08d, 0.0d, 4.08d);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test193"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
    var3.setSectionOutlinesVisible(true);
    java.awt.Paint var7 = var3.getBaseSectionPaint();
    var0.setAxisLinePaint(var7);
    org.jfree.data.Range var9 = var0.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var12 = var11.getTickLabelFont();
    var0.setLabelFont(var12);
    var0.setInverted(false);
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var18 = var17.clone();
    org.jfree.chart.axis.ValueAxis[] var19 = new org.jfree.chart.axis.ValueAxis[] { var17};
    var16.setDomainAxes(var19);
    java.awt.geom.Point2D var21 = var16.getQuadrantOrigin();
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
    var16.setRangeCrosshairValue(1.0E-8d, false);
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var29 = null;
    var27.setDomainAxisLocation(1, var29, false);
    java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var36);
    org.jfree.chart.util.HorizontalAlignment var38 = null;
    org.jfree.chart.util.VerticalAlignment var39 = null;
    org.jfree.chart.block.ColumnArrangement var42 = new org.jfree.chart.block.ColumnArrangement(var38, var39, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var45 = null;
    var43.setDomainAxisLocation(1, var45, false);
    java.awt.Stroke var48 = var43.getRangeCrosshairStroke();
    boolean var49 = var42.equals((java.lang.Object)var48);
    java.awt.Color var53 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var54 = null;
    org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var36, var48, (java.awt.Paint)var53, var54, 1.0f);
    float var57 = var56.getAlpha();
    java.awt.Paint var58 = var56.getLabelPaint();
    double var59 = var56.getValue();
    var27.addDomainMarker((org.jfree.chart.plot.Marker)var56);
    org.jfree.data.xy.XYDataset var61 = null;
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var63 = var62.getLabelURL();
    var62.configure();
    java.awt.Paint var65 = var62.getTickLabelPaint();
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis();
    var66.setTickMarksVisible(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var69 = null;
    org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot(var61, (org.jfree.chart.axis.ValueAxis)var62, (org.jfree.chart.axis.ValueAxis)var66, var69);
    org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var73 = var72.clone();
    java.awt.Shape var74 = var72.getLeftArrow();
    var70.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var72, false);
    int var77 = var27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var72);
    var16.setRangeAxis(15, (org.jfree.chart.axis.ValueAxis)var72);
    org.jfree.chart.plot.SeriesRenderingOrder var79 = var16.getSeriesRenderingOrder();
    org.jfree.chart.axis.AxisSpace var80 = var16.getFixedRangeAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var80);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test194"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    org.jfree.chart.event.MarkerChangeListener var25 = null;
    var24.addChangeListener(var25);
    java.awt.Stroke var27 = var24.getStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test195"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    var0.setRenderer(1, var4);
    org.jfree.chart.util.RectangleEdge var7 = var0.getDomainAxisEdge(10);
    int var8 = var0.getRangeAxisCount();
    org.jfree.chart.util.RectangleInsets var9 = var0.getInsets();
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var12 = null;
    var11.setFixedDomainAxisSpace(var12, true);
    var11.clearDomainMarkers(100);
    var11.setOutlineVisible(true);
    org.jfree.chart.plot.DrawingSupplier var19 = var11.getDrawingSupplier();
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var21 = var20.getQuadrantOrigin();
    var20.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = var20.getRendererForDataset(var25);
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    var28.setForegroundAlpha(1.0f);
    java.awt.Font var31 = var28.getNoDataMessageFont();
    var28.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var28);
    org.jfree.chart.axis.AxisLocation var35 = var28.getDomainAxisLocation();
    var20.setRangeAxisLocation(var35);
    var11.setDomainAxisLocation(var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-65536), var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test196"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.lang.Comparable var2 = var1.getAggregatedItemsKey();
    java.lang.Comparable var3 = var1.getAggregatedItemsKey();
    var1.setLimit(0.08d);
    double var6 = var1.getLimit();
    org.jfree.chart.util.TableOrder var7 = var1.getDataExtractOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Other"+ "'", var2.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Other"+ "'", var3.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test197"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(-0.5d), 6.140000000000001d, 15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test198"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.event.ChartProgressListener var8 = null;
    var7.addProgressListener(var8);
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var11 = null;
    var10.datasetChanged(var11);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var10.setRenderer(1, var14);
    org.jfree.chart.util.RectangleEdge var17 = var10.getDomainAxisEdge(10);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
    java.awt.Paint var19 = var18.getItemPaint();
    var7.addLegend(var18);
    java.lang.Object var21 = var18.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test199"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.chart.plot.PiePlotState var11 = var0.initialise(var1, var2, var4, (java.lang.Integer)0, var10);
    var11.setTotal(2.0d);
    double var14 = var11.getPieCenterX();
    double var15 = var11.getPieCenterY();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test200"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var2.setCategoryLabelPositionOffset(1);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setForegroundAlpha(1.0f);
//     java.awt.Font var10 = var7.getNoDataMessageFont();
//     var7.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var7);
//     org.jfree.chart.axis.AxisLocation var14 = var7.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var15 = var7.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var21 = null;
//     org.jfree.chart.util.VerticalAlignment var22 = null;
//     org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement(var21, var22, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7, (org.jfree.chart.block.Arrangement)var20, (org.jfree.chart.block.Arrangement)var25);
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     org.jfree.chart.util.RectangleInsets var29 = var28.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var30 = null;
//     var28.setToolTipGenerator(var30);
//     java.awt.Stroke var32 = var28.getBaseSectionOutlineStroke();
//     java.awt.Paint var33 = var28.getLabelLinkPaint();
//     var26.setItemPaint(var33);
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var37 = null;
//     var35.setDomainAxisLocation(1, var37, false);
//     java.awt.Stroke var40 = var35.getRangeCrosshairStroke();
//     var35.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.Plot var43 = var35.getRootPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     var35.setRenderer(var44);
//     java.awt.Paint var46 = var35.getDomainZeroBaselinePaint();
//     var26.setItemPaint(var46);
//     java.awt.Font var48 = var26.getItemFont();
//     var2.setTickLabelFont((java.lang.Comparable)0.5f, var48);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     var50.setForegroundAlpha(1.0f);
//     java.awt.Paint var53 = var50.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var54 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var50);
//     var50.configureRangeAxes();
//     boolean var56 = var50.isDomainZoomable();
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var60 = null;
//     var58.setDomainAxisLocation(1, var60, false);
//     java.awt.Stroke var63 = var58.getRangeCrosshairStroke();
//     java.awt.Font var64 = var58.getNoDataMessageFont();
//     java.awt.Color var68 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Color var69 = var68.darker();
//     org.jfree.chart.text.TextFragment var70 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var64, (java.awt.Paint)var68);
//     var50.setNoDataMessagePaint((java.awt.Paint)var68);
//     int var72 = var68.getBlue();
//     org.jfree.chart.text.TextLine var73 = new org.jfree.chart.text.TextLine("XY Plot", var48, (java.awt.Paint)var68);
//     org.jfree.data.general.PieDataset var75 = null;
//     org.jfree.chart.plot.PiePlot var76 = new org.jfree.chart.plot.PiePlot(var75);
//     org.jfree.chart.util.RectangleInsets var77 = var76.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var78 = null;
//     var76.setToolTipGenerator(var78);
//     java.awt.Font var80 = var76.getLabelFont();
//     java.awt.Color var83 = java.awt.Color.getColor("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", 0);
//     org.jfree.chart.text.TextFragment var84 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", var80, (java.awt.Paint)var83);
//     var73.addFragment(var84);
//     
//     // Checks the contract:  equals-hashcode on var28 and var76
//     assertTrue("Contract failed: equals-hashcode on var28 and var76", var28.equals(var76) ? var28.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var28
//     assertTrue("Contract failed: equals-hashcode on var76 and var28", var76.equals(var28) ? var76.hashCode() == var28.hashCode() : true);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test201"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearAnnotations();
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var6 = var5.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var8 = var7.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var9 = null;
    var7.setTickUnit(var9, false, true);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var14 = var13.getTickMarkPosition();
    var7.setTickMarkPosition(var14);
    var5.setTickMarkPosition(var14);
    var5.setInverted(true);
    org.jfree.chart.axis.DateTickUnit var19 = var5.getTickUnit();
    var0.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var22 = null;
    var21.datasetChanged(var22);
    org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
    var21.setRenderer(1, var25);
    org.jfree.chart.util.RectangleEdge var28 = var21.getDomainAxisEdge(10);
    boolean var30 = var21.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var32 = var21.getRangeAxisLocation(0);
    java.awt.Graphics2D var33 = null;
    java.awt.geom.Rectangle2D var34 = null;
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    org.jfree.chart.plot.CrosshairState var37 = null;
    boolean var38 = var21.render(var33, var34, 100, var36, var37);
    var21.configureDomainAxes();
    java.awt.Stroke var40 = var21.getDomainZeroBaselineStroke();
    var0.setDomainZeroBaselineStroke(var40);
    org.jfree.chart.axis.ValueAxis var42 = null;
    int var43 = var0.getRangeAxisIndex(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test202"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    var1.setSectionOutlinesVisible(true);
    java.awt.Paint var5 = var1.getShadowPaint();
    var1.setMinimumArcAngleToDraw(0.05d);
    java.lang.String var8 = var1.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Pie Plot"+ "'", var8.equals("Pie Plot"));

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test203"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    var4.mapDatasetToDomainAxis(100, 0);
    java.awt.Paint var9 = var4.getDomainCrosshairPaint();
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("Multiple Pie Plot", var3, var9);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    org.jfree.chart.util.RectangleInsets var13 = var12.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var14 = null;
    var12.setToolTipGenerator(var14);
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var16.setDomainAxisLocation(1, var18, false);
    java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
    var12.setBaseSectionOutlineStroke(var21);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.setForegroundAlpha(1.0f);
    java.awt.Font var26 = var23.getNoDataMessageFont();
    var12.setLabelFont(var26);
    boolean var28 = var10.equals((java.lang.Object)var12);
    org.jfree.chart.util.HorizontalAlignment var29 = var10.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var30 = null;
    org.jfree.chart.block.FlowArrangement var33 = new org.jfree.chart.block.FlowArrangement(var29, var30, (-7.0d), (-3.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test204"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var3 = var2.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var4 = null;
    var2.setTickUnit(var4, false, true);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var9 = var8.getTickMarkPosition();
    var2.setTickMarkPosition(var9);
    var0.setTickMarkPosition(var9);
    java.text.DateFormat var12 = var0.getDateFormatOverride();
    var0.setAutoTickUnitSelection(false);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var16 = var15.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var18 = var17.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var19 = null;
    var17.setTickUnit(var19, false, true);
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var24 = var23.getTickMarkPosition();
    var17.setTickMarkPosition(var24);
    var15.setTickMarkPosition(var24);
    var15.setInverted(true);
    org.jfree.chart.axis.DateTickUnit var29 = var15.getTickUnit();
    var0.setTickUnit(var29);
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var32 = null;
    var31.setMarkerBand(var32);
    java.awt.Font var34 = var31.getTickLabelFont();
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var36 = var35.clone();
    var35.setVisible(false);
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var41 = var40.clone();
    org.jfree.data.general.PieDataset var42 = null;
    org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot(var42);
    org.jfree.chart.util.RectangleInsets var44 = var43.getLabelPadding();
    var43.setSectionOutlinesVisible(true);
    java.awt.Paint var47 = var43.getBaseSectionPaint();
    var40.setAxisLinePaint(var47);
    org.jfree.data.Range var49 = var40.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var50 = new org.jfree.chart.block.RectangleConstraint(100.0d, var49);
    org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var52 = var51.clone();
    org.jfree.data.Range var53 = var51.getRange();
    org.jfree.data.Range var54 = org.jfree.data.Range.combine(var49, var53);
    var35.setRangeWithMargins(var53);
    var31.setRange(var53);
    org.jfree.data.Range var59 = org.jfree.data.Range.expand(var53, 9.223372036854776E18d, (-5.88d));
    org.jfree.chart.plot.XYPlot var60 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var61 = null;
    var60.datasetChanged(var61);
    org.jfree.chart.renderer.xy.XYItemRenderer var64 = null;
    var60.setRenderer(1, var64);
    org.jfree.chart.util.RectangleEdge var67 = var60.getDomainAxisEdge(10);
    boolean var69 = var60.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var71 = var60.getRangeAxisLocation(0);
    boolean var72 = var60.isDomainCrosshairLockedOnData();
    var60.setDomainZeroBaselineVisible(true);
    org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
    var76.setForegroundAlpha(1.0f);
    java.awt.Font var79 = var76.getNoDataMessageFont();
    var76.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var82 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var76);
    org.jfree.chart.axis.AxisLocation var83 = var76.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var84 = var76.getDomainAxisLocation();
    var60.setRangeAxisLocation(var84);
    boolean var86 = var59.equals((java.lang.Object)var84);
    org.jfree.data.Range var88 = org.jfree.data.Range.expandToInclude(var59, 10.0d);
    var0.setRange(var88, true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test205"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var10 = null;
    org.jfree.chart.util.VerticalAlignment var11 = null;
    org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
    org.jfree.chart.util.RectangleInsets var23 = var22.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var24 = null;
    var22.setToolTipGenerator(var24);
    java.awt.Stroke var26 = var22.getBaseSectionOutlineStroke();
    java.awt.Paint var27 = var22.getLabelLinkPaint();
    var20.setItemPaint(var27);
    java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Color var33 = var32.darker();
    var20.setBackgroundPaint((java.awt.Paint)var33);
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var36 = null;
    var35.setFixedDomainAxisSpace(var36, true);
    var35.clearDomainMarkers(100);
    org.jfree.chart.util.RectangleEdge var42 = var35.getRangeAxisEdge(0);
    boolean var43 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var42);
    boolean var44 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var42);
    var20.setLegendItemGraphicEdge(var42);
    org.jfree.chart.util.RectangleAnchor var46 = null;
    var20.setLegendItemGraphicLocation(var46);
    java.lang.String var48 = var20.getID();
    org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var50 = null;
    var49.setFixedLegendItems(var50);
    java.awt.Graphics2D var52 = null;
    java.awt.geom.Rectangle2D var53 = null;
    org.jfree.chart.plot.PlotRenderingInfo var55 = null;
    boolean var56 = var49.render(var52, var53, 10, var55);
    org.jfree.chart.axis.AxisLocation var57 = var49.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var60 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var61 = var60.getUpperMargin();
    var49.setDomainAxis(10, var60, false);
    var49.setAnchorValue(0.0d);
    org.jfree.chart.util.RectangleEdge var67 = var49.getDomainAxisEdge((-65536));
    org.jfree.chart.util.RectangleEdge var68 = var49.getDomainAxisEdge();
    var20.setLegendItemGraphicEdge(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test206"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var0.setRangeCrosshairPaint(var9);
    java.awt.Image var11 = null;
    var0.setBackgroundImage(var11);
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var15 = var14.clone();
    org.jfree.chart.axis.ValueAxis[] var16 = new org.jfree.chart.axis.ValueAxis[] { var14};
    var13.setDomainAxes(var16);
    var0.setRangeAxes(var16);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var20.setMaximumCategoryLabelLines((-1));
    var0.setDomainAxis(var20);
    org.jfree.chart.axis.AxisLocation var25 = var0.getDomainAxisLocation((-1));
    var0.setBackgroundAlpha(0.5f);
    org.jfree.chart.axis.CategoryAnchor var28 = var0.getDomainGridlinePosition();
    org.jfree.chart.axis.CategoryAxis var30 = var0.getDomainAxis(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test207"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=255,g=0,b=0]", "WMAP_Plot", "Range[0.0,1.0]", var3, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    java.awt.Image var8 = var7.getLogo();
    var7.setLicenceName("");
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    org.jfree.chart.util.RectangleInsets var13 = var12.getLabelPadding();
    var12.setSectionOutlinesVisible(true);
    var12.zoom(10.0d);
    var12.setPieIndex(15);
    boolean var20 = var7.equals((java.lang.Object)15);
    java.lang.String var21 = var7.getInfo();
    var7.addOptionalLibrary("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    java.lang.String var24 = var7.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Range[0.0,1.0]"+ "'", var21.equals("Range[0.0,1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "WMAP_Plot"+ "'", var24.equals("WMAP_Plot"));

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test208"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.Plot var8 = var0.getRootPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(var9);
    java.awt.Paint var11 = var0.getDomainZeroBaselinePaint();
    org.jfree.chart.event.RendererChangeEvent var12 = null;
    var0.rendererChanged(var12);
    java.awt.Image var14 = var0.getBackgroundImage();
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.plot.MultiplePiePlot var16 = new org.jfree.chart.plot.MultiplePiePlot(var15);
    java.lang.Comparable var17 = var16.getAggregatedItemsKey();
    java.lang.String var18 = var16.getPlotType();
    org.jfree.data.category.CategoryDataset var19 = null;
    var16.setDataset(var19);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
    org.jfree.chart.util.RectangleInsets var23 = var22.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var24 = null;
    var22.setToolTipGenerator(var24);
    java.awt.Stroke var26 = var22.getBaseSectionOutlineStroke();
    java.awt.Paint var27 = var22.getLabelLinkPaint();
    var16.setAggregatedItemsPaint(var27);
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var30 = var29.getQuadrantOrigin();
    var29.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = var29.getRendererForDataset(var34);
    org.jfree.chart.axis.AxisLocation var37 = var29.getRangeAxisLocation((-65536));
    java.awt.Paint var38 = var29.getRangeZeroBaselinePaint();
    boolean var39 = var16.equals((java.lang.Object)var38);
    var0.setDomainTickBandPaint(var38);
    java.awt.Stroke var41 = var0.getRangeGridlineStroke();
    org.jfree.chart.util.RectangleEdge var43 = var0.getDomainAxisEdge((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "Other"+ "'", var17.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "Multiple Pie Plot"+ "'", var18.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test209"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var13 = var7.getText();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    var15.setForegroundAlpha(1.0f);
    java.awt.Font var18 = var15.getNoDataMessageFont();
    var15.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var15);
    java.awt.Paint var22 = var21.getBackgroundPaint();
    var21.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var24 = var21.getPadding();
    var7.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var21);
    org.jfree.chart.util.VerticalAlignment var26 = var7.getVerticalAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var13.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test210"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
//     var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var13 = var7.getURLText();
//     org.jfree.chart.block.BlockFrame var14 = var7.getFrame();
//     var7.setMargin((-5.88d), (-5.88d), (-5.88d), 3.0d);
//     org.jfree.chart.plot.PiePlot3D var21 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var22 = var21.getPlotType();
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var24 = null;
//     var23.setFixedDomainAxisSpace(var24, true);
//     var23.clearDomainMarkers(100);
//     var23.setOutlineVisible(true);
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var33 = var32.getTickLabelFont();
//     var23.setNoDataMessageFont(var33);
//     var21.setLabelFont(var33);
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.plot.MultiplePiePlot var37 = new org.jfree.chart.plot.MultiplePiePlot(var36);
//     java.lang.String var38 = var37.getPlotType();
//     java.awt.Paint var39 = var37.getAggregatedItemsPaint();
//     org.jfree.chart.text.TextLine var40 = new org.jfree.chart.text.TextLine("", var33, var39);
//     var7.setPaint(var39);
//     org.jfree.chart.util.HorizontalAlignment var42 = var7.getTextAlignment();
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     var45.setForegroundAlpha(1.0f);
//     java.awt.Font var48 = var45.getNoDataMessageFont();
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var50 = null;
//     var49.datasetChanged(var50);
//     java.awt.Stroke var52 = var49.getOutlineStroke();
//     java.awt.Paint var53 = var49.getRangeZeroBaselinePaint();
//     org.jfree.chart.text.TextLine var54 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var48, var53);
//     org.jfree.chart.title.TextTitle var55 = new org.jfree.chart.title.TextTitle("RectangleConstraintType.RANGE", var48);
//     org.jfree.data.general.PieDataset var57 = null;
//     org.jfree.chart.plot.PiePlot var58 = new org.jfree.chart.plot.PiePlot(var57);
//     org.jfree.chart.util.RectangleInsets var59 = var58.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var60 = null;
//     var58.setToolTipGenerator(var60);
//     java.awt.Font var62 = var58.getLabelFont();
//     org.jfree.chart.title.TextTitle var63 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var62);
//     var63.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var69 = var63.getURLText();
//     org.jfree.chart.block.BlockFrame var70 = var63.getFrame();
//     var55.setFrame(var70);
//     org.jfree.chart.util.VerticalAlignment var72 = var55.getVerticalAlignment();
//     java.lang.String var73 = var72.toString();
//     java.lang.String var74 = var72.toString();
//     org.jfree.chart.block.FlowArrangement var77 = new org.jfree.chart.block.FlowArrangement(var42, var72, 1.0d, 1.0E-5d);
//     
//     // Checks the contract:  equals-hashcode on var2 and var58
//     assertTrue("Contract failed: equals-hashcode on var2 and var58", var2.equals(var58) ? var2.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var2
//     assertTrue("Contract failed: equals-hashcode on var58 and var2", var58.equals(var2) ? var58.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test211"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    float var25 = var24.getAlpha();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var27 = var26.clone();
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot(var28);
    org.jfree.chart.util.RectangleInsets var30 = var29.getLabelPadding();
    var29.setSectionOutlinesVisible(true);
    java.awt.Paint var33 = var29.getBaseSectionPaint();
    var26.setAxisLinePaint(var33);
    var24.setPaint(var33);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var37 = var36.clone();
    org.jfree.chart.util.RectangleInsets var38 = var36.getLabelInsets();
    double var40 = var38.calculateRightOutset(100.0d);
    double var41 = var38.getLeft();
    double var42 = var38.getRight();
    var24.setLabelOffset(var38);
    var24.setValue(6.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 3.0d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test212"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.data.xy.XYDataset var6 = var0.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(100, var8, false);
    java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var24 = null;
    var22.setDomainAxisLocation(1, var24, false);
    java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
    boolean var28 = var21.equals((java.lang.Object)var27);
    java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var33 = null;
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
    java.lang.Object var36 = var35.clone();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var35);
    var0.clearRangeMarkers();
    org.jfree.data.category.CategoryDataset var39 = null;
    org.jfree.chart.plot.MultiplePiePlot var40 = new org.jfree.chart.plot.MultiplePiePlot(var39);
    java.lang.String var41 = var40.getPlotType();
    java.awt.Paint var42 = var40.getAggregatedItemsPaint();
    double var43 = var40.getLimit();
    org.jfree.chart.LegendItemCollection var44 = var40.getLegendItems();
    var0.setFixedLegendItems(var44);
    boolean var46 = var0.isDomainCrosshairLockedOnData();
    org.jfree.chart.util.RectangleEdge var48 = var0.getDomainAxisEdge(100);
    int var49 = var0.getDomainAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "Multiple Pie Plot"+ "'", var41.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test213"); }


    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.setForegroundAlpha(1.0f);
    java.awt.Font var5 = var2.getNoDataMessageFont();
    var2.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.event.ChartProgressEvent var11 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-65536), var8, 0, 0);
    org.jfree.chart.title.LegendTitle var12 = var8.getLegend();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var14 = var13.clone();
    org.jfree.chart.util.RectangleInsets var15 = var13.getLabelInsets();
    double var17 = var15.calculateBottomOutset(10.0d);
    double var19 = var15.calculateTopOutset(0.12d);
    var12.setMargin(var15);
    org.jfree.chart.LegendItemSource[] var21 = var12.getSources();
    org.jfree.chart.util.RectangleInsets var22 = var12.getLegendItemGraphicPadding();
    double var23 = var12.getContentYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 5.0d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test214"); }


    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.setForegroundAlpha(1.0f);
    java.awt.Font var5 = var2.getNoDataMessageFont();
    var2.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.event.ChartProgressEvent var11 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-65536), var8, 0, 0);
    org.jfree.chart.title.LegendTitle var12 = var8.getLegend();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var14 = var13.clone();
    org.jfree.chart.util.RectangleInsets var15 = var13.getLabelInsets();
    double var17 = var15.calculateBottomOutset(10.0d);
    double var19 = var15.calculateTopOutset(0.12d);
    var12.setMargin(var15);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.setForegroundAlpha(1.0f);
    java.awt.Font var24 = var21.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    org.jfree.chart.util.RectangleInsets var27 = var26.getLabelPadding();
    var26.setSectionOutlinesVisible(true);
    java.awt.Paint var30 = var26.getBaseSectionPaint();
    var21.setRangeCrosshairPaint(var30);
    java.lang.Object var32 = var21.clone();
    org.jfree.chart.LegendItemCollection var33 = var21.getLegendItems();
    var21.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var36 = null;
    var21.setFixedDomainAxisSpace(var36);
    boolean var38 = var21.isSubplot();
    var21.clearAnnotations();
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
    var40.setForegroundAlpha(1.0f);
    java.awt.Paint var43 = var40.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var44 = var40.getRowRenderingOrder();
    var40.clearDomainAxes();
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var40);
    org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var48 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var47};
    var40.setRenderers(var48);
    var21.setRenderers(var48);
    var12.setSources((org.jfree.chart.LegendItemSource[])var48);
    java.awt.Color var56 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var57 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var56);
    org.jfree.chart.util.HorizontalAlignment var58 = null;
    org.jfree.chart.util.VerticalAlignment var59 = null;
    org.jfree.chart.block.ColumnArrangement var62 = new org.jfree.chart.block.ColumnArrangement(var58, var59, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var65 = null;
    var63.setDomainAxisLocation(1, var65, false);
    java.awt.Stroke var68 = var63.getRangeCrosshairStroke();
    boolean var69 = var62.equals((java.lang.Object)var68);
    java.awt.Color var73 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var74 = null;
    org.jfree.chart.plot.ValueMarker var76 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var56, var68, (java.awt.Paint)var73, var74, 1.0f);
    float var77 = var76.getAlpha();
    java.awt.Paint var78 = var76.getLabelPaint();
    double var79 = var76.getValue();
    boolean var80 = var12.equals((java.lang.Object)var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test215"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    var0.clearDomainAxes();
    var0.clearAnnotations();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    int var6 = var0.getIndexOf(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test216"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.util.List var1 = var0.getContributors();
    var0.setInfo("hi!");
    java.util.List var4 = null;
    var0.setContributors(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test217"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    java.awt.Shape var3 = var1.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var11 = var10.clone();
    org.jfree.chart.axis.ValueAxis[] var12 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var9.setDomainAxes(var12);
    java.awt.geom.Point2D var14 = var9.getQuadrantOrigin();
    var5.zoomDomainAxes(0.2d, 2.0d, var8, var14);
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var16.setDomainAxisLocation(1, var18, false);
    java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
    var16.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.LegendItemCollection var24 = var16.getLegendItems();
    java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var29);
    org.jfree.chart.util.HorizontalAlignment var31 = null;
    org.jfree.chart.util.VerticalAlignment var32 = null;
    org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement(var31, var32, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var38 = null;
    var36.setDomainAxisLocation(1, var38, false);
    java.awt.Stroke var41 = var36.getRangeCrosshairStroke();
    boolean var42 = var35.equals((java.lang.Object)var41);
    java.awt.Color var46 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var47 = null;
    org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var29, var41, (java.awt.Paint)var46, var47, 1.0f);
    var16.addDomainMarker((org.jfree.chart.plot.Marker)var49);
    java.lang.String var51 = var49.getLabel();
    boolean var52 = var5.equals((java.lang.Object)var49);
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var54 = var53.clone();
    var53.setVisible(false);
    var5.setAxis((org.jfree.chart.axis.ValueAxis)var53);
    var5.setAngleGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test218"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     java.awt.Shape var3 = var1.getLeftArrow();
//     org.jfree.chart.renderer.PolarItemRenderer var4 = null;
//     org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var11 = var10.clone();
//     org.jfree.chart.axis.ValueAxis[] var12 = new org.jfree.chart.axis.ValueAxis[] { var10};
//     var9.setDomainAxes(var12);
//     java.awt.geom.Point2D var14 = var9.getQuadrantOrigin();
//     var5.zoomDomainAxes(0.2d, 2.0d, var8, var14);
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var18 = var17.getLabelURL();
//     var17.configure();
//     java.awt.Paint var20 = var17.getTickLabelPaint();
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     var21.setTickMarksVisible(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var16, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var21, var24);
//     var21.setRangeWithMargins((-1.0d), 6.0d);
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var31 = var30.clone();
//     org.jfree.chart.axis.ValueAxis[] var32 = new org.jfree.chart.axis.ValueAxis[] { var30};
//     var29.setDomainAxes(var32);
//     org.jfree.chart.util.HorizontalAlignment var34 = null;
//     org.jfree.chart.util.VerticalAlignment var35 = null;
//     org.jfree.chart.block.ColumnArrangement var38 = new org.jfree.chart.block.ColumnArrangement(var34, var35, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var41 = null;
//     var39.setDomainAxisLocation(1, var41, false);
//     java.awt.Stroke var44 = var39.getRangeCrosshairStroke();
//     boolean var45 = var38.equals((java.lang.Object)var44);
//     var29.setRangeGridlineStroke(var44);
//     var21.setTickMarkStroke(var44);
//     var5.setAngleGridlineStroke(var44);
//     
//     // Checks the contract:  equals-hashcode on var9 and var29
//     assertTrue("Contract failed: equals-hashcode on var9 and var29", var9.equals(var29) ? var9.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var9
//     assertTrue("Contract failed: equals-hashcode on var29 and var9", var29.equals(var9) ? var29.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test219"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var4.setMarkerBand(var5);
    org.jfree.data.Range var7 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var4);
    var0.setAnchorValue(0.08d);
    var0.clearRangeAxes();
    boolean var11 = var0.isRangeCrosshairVisible();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var13 = null;
    var12.setMarkerBand(var13);
    boolean var15 = var12.isInverted();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var17 = var16.clone();
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
    org.jfree.chart.util.RectangleInsets var20 = var19.getLabelPadding();
    var19.setSectionOutlinesVisible(true);
    java.awt.Paint var23 = var19.getBaseSectionPaint();
    var16.setAxisLinePaint(var23);
    org.jfree.data.Range var25 = var16.getDefaultAutoRange();
    java.lang.String var26 = var25.toString();
    org.jfree.data.Range var28 = org.jfree.data.Range.expandToInclude(var25, 10.0d);
    org.jfree.data.Range var30 = org.jfree.data.Range.expandToInclude(var28, 106.0d);
    var12.setDefaultAutoRange(var30);
    int var32 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "Range[0.0,1.0]"+ "'", var26.equals("Range[0.0,1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-1));

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test220"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.plot.Plot var5 = var4.getPlot();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setForegroundAlpha(1.0f);
//     java.awt.Font var10 = var7.getNoDataMessageFont();
//     var7.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var7);
//     java.awt.Paint var14 = var13.getBackgroundPaint();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
//     org.jfree.chart.util.RectangleInsets var17 = var16.getLabelPadding();
//     org.jfree.chart.util.UnitType var18 = var17.getUnitType();
//     var13.setPadding(var17);
//     var4.setChart(var13);
//     org.jfree.chart.plot.PiePlot3D var22 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var23 = var22.getPlotType();
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var25 = null;
//     var24.setFixedDomainAxisSpace(var25, true);
//     var24.clearDomainMarkers(100);
//     var24.setOutlineVisible(true);
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var34 = var33.getTickLabelFont();
//     var24.setNoDataMessageFont(var34);
//     var22.setLabelFont(var34);
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var39 = var38.clone();
//     org.jfree.chart.axis.ValueAxis[] var40 = new org.jfree.chart.axis.ValueAxis[] { var38};
//     var37.setDomainAxes(var40);
//     org.jfree.data.xy.XYDataset var43 = var37.getDataset(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     var37.setRenderer(100, var45, false);
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=106.0, height=0.0]", var34, (org.jfree.chart.plot.Plot)var37, false);
//     var4.setChart(var49);
//     org.jfree.data.general.PieDataset var52 = null;
//     org.jfree.chart.plot.PiePlot var53 = new org.jfree.chart.plot.PiePlot(var52);
//     org.jfree.chart.util.RectangleInsets var54 = var53.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var55 = null;
//     var53.setToolTipGenerator(var55);
//     java.awt.Font var57 = var53.getLabelFont();
//     org.jfree.chart.title.TextTitle var58 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var57);
//     var58.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var58.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var58.setURLText("Range[0.0,1.0]");
//     org.jfree.chart.plot.XYPlot var68 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var70 = var69.clone();
//     org.jfree.chart.axis.ValueAxis[] var71 = new org.jfree.chart.axis.ValueAxis[] { var69};
//     var68.setDomainAxes(var71);
//     org.jfree.chart.renderer.xy.XYItemRenderer var73 = null;
//     var68.setRenderer(var73);
//     org.jfree.chart.util.RectangleEdge var76 = var68.getRangeAxisEdge(0);
//     var58.setPosition(var76);
//     double var78 = var58.getHeight();
//     org.jfree.chart.util.HorizontalAlignment var79 = var58.getTextAlignment();
//     java.awt.Font var80 = var58.getFont();
//     var49.setTitle(var58);
//     
//     // Checks the contract:  equals-hashcode on var16 and var53
//     assertTrue("Contract failed: equals-hashcode on var16 and var53", var16.equals(var53) ? var16.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var16
//     assertTrue("Contract failed: equals-hashcode on var53 and var16", var53.equals(var16) ? var53.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var68
//     assertTrue("Contract failed: equals-hashcode on var37 and var68", var37.equals(var68) ? var37.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var37
//     assertTrue("Contract failed: equals-hashcode on var68 and var37", var68.equals(var37) ? var68.hashCode() == var37.hashCode() : true);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test221"); }


    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.setForegroundAlpha(1.0f);
    java.awt.Font var5 = var2.getNoDataMessageFont();
    var2.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.event.ChartProgressEvent var11 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-65536), var8, 0, 0);
    org.jfree.chart.title.LegendTitle var12 = var8.getLegend();
    double var13 = var12.getContentXOffset();
    var12.setPadding(4.08d, (-7.0d), 0.0d, 4.08d);
    org.jfree.chart.util.RectangleInsets var19 = var12.getItemLabelPadding();
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var21 = var20.getQuadrantOrigin();
    var20.mapDatasetToDomainAxis(100, 0);
    java.awt.Paint var25 = var20.getDomainCrosshairPaint();
    var20.setRangeGridlinesVisible(true);
    java.lang.String var28 = var20.getPlotType();
    java.awt.Paint var29 = var20.getDomainGridlinePaint();
    org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder(var19, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "XY Plot"+ "'", var28.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test222"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
//     var0.setDomainAxes(var3);
//     org.jfree.data.xy.XYDataset var6 = var0.getDataset(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     var0.setRenderer(100, var8, false);
//     java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setDomainAxisLocation(1, var24, false);
//     java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
//     boolean var28 = var21.equals((java.lang.Object)var27);
//     java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var33 = null;
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
//     java.lang.Object var36 = var35.clone();
//     var0.addDomainMarker((org.jfree.chart.plot.Marker)var35);
//     var0.clearRangeMarkers();
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.plot.MultiplePiePlot var40 = new org.jfree.chart.plot.MultiplePiePlot(var39);
//     java.lang.String var41 = var40.getPlotType();
//     java.awt.Paint var42 = var40.getAggregatedItemsPaint();
//     double var43 = var40.getLimit();
//     org.jfree.chart.LegendItemCollection var44 = var40.getLegendItems();
//     var0.setFixedLegendItems(var44);
//     boolean var46 = var0.isDomainCrosshairLockedOnData();
//     org.jfree.data.xy.XYDataset var47 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = var0.getRendererForDataset(var47);
//     java.awt.Color var54 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var55 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var54);
//     org.jfree.chart.util.HorizontalAlignment var56 = null;
//     org.jfree.chart.util.VerticalAlignment var57 = null;
//     org.jfree.chart.block.ColumnArrangement var60 = new org.jfree.chart.block.ColumnArrangement(var56, var57, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var63 = null;
//     var61.setDomainAxisLocation(1, var63, false);
//     java.awt.Stroke var66 = var61.getRangeCrosshairStroke();
//     boolean var67 = var60.equals((java.lang.Object)var66);
//     java.awt.Color var71 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var72 = null;
//     org.jfree.chart.plot.ValueMarker var74 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var54, var66, (java.awt.Paint)var71, var72, 1.0f);
//     float var75 = var74.getAlpha();
//     java.awt.Paint var76 = var74.getLabelPaint();
//     org.jfree.chart.util.Layer var77 = null;
//     var0.addRangeMarker(0, (org.jfree.chart.plot.Marker)var74, var77);
//     
//     // Checks the contract:  equals-hashcode on var22 and var61
//     assertTrue("Contract failed: equals-hashcode on var22 and var61", var22.equals(var61) ? var22.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var22
//     assertTrue("Contract failed: equals-hashcode on var61 and var22", var61.equals(var22) ? var61.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var55
//     assertTrue("Contract failed: equals-hashcode on var16 and var55", var16.equals(var55) ? var16.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var16
//     assertTrue("Contract failed: equals-hashcode on var55 and var16", var55.equals(var16) ? var55.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var60
//     assertTrue("Contract failed: equals-hashcode on var21 and var60", var21.equals(var60) ? var21.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var21
//     assertTrue("Contract failed: equals-hashcode on var60 and var21", var60.equals(var21) ? var60.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var74
//     assertTrue("Contract failed: equals-hashcode on var35 and var74", var35.equals(var74) ? var35.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var35
//     assertTrue("Contract failed: equals-hashcode on var74 and var35", var74.equals(var35) ? var74.hashCode() == var35.hashCode() : true);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test223"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var13 = var12.clone();
    org.jfree.data.Range var14 = var12.getRange();
    org.jfree.data.Range var15 = org.jfree.data.Range.combine(var10, var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setForegroundAlpha(1.0f);
    java.awt.Paint var19 = var16.getRangeCrosshairPaint();
    boolean var20 = var15.equals((java.lang.Object)var16);
    var16.setDomainGridlinesVisible(false);
    org.jfree.chart.util.SortOrder var23 = var16.getRowRenderingOrder();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = var16.getRendererForDataset(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test224"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var10 = null;
    org.jfree.chart.util.VerticalAlignment var11 = null;
    org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
    org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var24 = null;
    var22.setDomainAxisLocation(1, var24, false);
    java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
    var22.setRangeCrosshairLockedOnData(false);
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
    org.jfree.chart.util.RectangleInsets var32 = var31.getLabelPadding();
    var22.setAxisOffset(var32);
    var20.setItemLabelPadding(var32);
    org.jfree.chart.util.RectangleInsets var35 = var20.getMargin();
    org.jfree.chart.block.BlockContainer var36 = var20.getItemContainer();
    var36.clear();
    java.util.List var38 = var36.getBlocks();
    java.util.List var39 = var36.getBlocks();
    org.jfree.chart.block.BlockFrame var40 = var36.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test225"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    var11.setCategoryLabelPositionOffset((-65536));
    java.awt.Font var17 = var11.getTickLabelFont();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var20 = var19.getPercentFormat();
    org.jfree.data.general.PieDataset var21 = null;
    java.lang.String var23 = var19.generateSectionLabel(var21, (java.lang.Comparable)6.0d);
    java.text.NumberFormat var24 = var19.getPercentFormat();
    java.lang.Object var25 = var19.clone();
    org.jfree.data.general.PieDataset var26 = null;
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var28 = var27.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var30 = var29.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var31 = null;
    var29.setTickUnit(var31, false, true);
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var36 = var35.getTickMarkPosition();
    var29.setTickMarkPosition(var36);
    var27.setTickMarkPosition(var36);
    org.jfree.chart.axis.DateTickUnit var39 = null;
    var27.setTickUnit(var39);
    org.jfree.chart.axis.DateTickUnit var41 = null;
    var27.setTickUnit(var41, true, false);
    java.lang.Object var45 = var27.clone();
    org.jfree.data.general.PieDataset var46 = null;
    org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot(var46);
    org.jfree.chart.util.RectangleInsets var48 = var47.getLabelPadding();
    var47.setSectionOutlinesVisible(true);
    var47.zoom(10.0d);
    java.awt.Paint var53 = var47.getNoDataMessagePaint();
    org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var55 = var54.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var56 = null;
    var54.setTickUnit(var56, false, true);
    org.jfree.chart.axis.DateAxis var60 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var61 = var60.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var63 = var62.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var64 = null;
    var62.setTickUnit(var64, false, true);
    org.jfree.chart.axis.DateAxis var68 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var69 = var68.getTickMarkPosition();
    var62.setTickMarkPosition(var69);
    var60.setTickMarkPosition(var69);
    org.jfree.chart.axis.DateAxis var72 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var73 = var72.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var74 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var75 = var74.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var76 = null;
    var74.setTickUnit(var76, false, true);
    org.jfree.chart.axis.DateAxis var80 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var81 = var80.getTickMarkPosition();
    var74.setTickMarkPosition(var81);
    var72.setTickMarkPosition(var81);
    var72.setInverted(true);
    org.jfree.chart.axis.DateTickUnit var86 = var72.getTickUnit();
    java.util.Date var87 = var60.calculateHighestVisibleTickValue(var86);
    var54.setTickUnit(var86);
    org.jfree.chart.axis.DateTickUnit var89 = var54.getTickUnit();
    boolean var90 = var47.equals((java.lang.Object)var89);
    java.util.Date var91 = var27.calculateLowestVisibleTickValue(var89);
    java.lang.String var92 = var19.generateSectionLabel(var26, (java.lang.Comparable)var91);
    java.awt.Paint var93 = var11.getTickLabelPaint((java.lang.Comparable)var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test226"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = var0.getRenderer();
    org.jfree.chart.util.RectangleEdge var10 = var0.getRangeAxisEdge();
    org.jfree.data.general.DatasetChangeEvent var11 = null;
    var0.datasetChanged(var11);
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = var0.getRenderer();
    boolean var14 = var0.isRangeCrosshairLockedOnData();
    var0.setWeight((-8372160));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test227"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var10, (-7.0d));
    double var15 = var13.constrain(106.0d);
    java.lang.String var16 = var13.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Range[-7.0,1.0]"+ "'", var16.equals("Range[-7.0,1.0]"));

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test228"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.Plot var5 = var4.getPlot();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.setForegroundAlpha(1.0f);
    java.awt.Font var10 = var7.getNoDataMessageFont();
    var7.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var7);
    java.awt.Paint var14 = var13.getBackgroundPaint();
    org.jfree.data.general.PieDataset var15 = null;
    org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
    org.jfree.chart.util.RectangleInsets var17 = var16.getLabelPadding();
    org.jfree.chart.util.UnitType var18 = var17.getUnitType();
    var13.setPadding(var17);
    var4.setChart(var13);
    org.jfree.chart.util.RectangleInsets var21 = var13.getPadding();
    double var23 = var21.extendWidth(1.0d);
    double var25 = var21.trimHeight(6.2d);
    double var26 = var21.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.0d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test229"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
    var3.setSectionOutlinesVisible(true);
    java.awt.Paint var7 = var3.getBaseSectionPaint();
    var0.setAxisLinePaint(var7);
    double var9 = var0.getLowerMargin();
    boolean var10 = var0.isVerticalTickLabels();
    var0.setPositiveArrowVisible(true);
    double var13 = var0.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test230"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedDimension();
    org.jfree.data.RangeType var2 = var0.getRangeType();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var6 = var5.clone();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    org.jfree.chart.util.RectangleInsets var9 = var8.getLabelPadding();
    var8.setSectionOutlinesVisible(true);
    java.awt.Paint var12 = var8.getBaseSectionPaint();
    var5.setAxisLinePaint(var12);
    org.jfree.data.Range var14 = var5.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint(100.0d, var14);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var17 = var16.clone();
    org.jfree.data.Range var18 = var16.getRange();
    org.jfree.data.Range var19 = org.jfree.data.Range.combine(var14, var18);
    boolean var21 = var19.contains(100.0d);
    double var22 = var19.getLength();
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint(106.0d, var19);
    var0.setDefaultAutoRange(var19);
    org.jfree.data.Range var26 = org.jfree.data.Range.expandToInclude(var19, 90.0d);
    boolean var29 = var19.intersects(0.0d, 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test231"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    java.awt.Shape var3 = var1.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var11 = var10.clone();
    org.jfree.chart.axis.ValueAxis[] var12 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var9.setDomainAxes(var12);
    java.awt.geom.Point2D var14 = var9.getQuadrantOrigin();
    var5.zoomDomainAxes(0.2d, 2.0d, var8, var14);
    boolean var16 = var5.isAngleGridlinesVisible();
    boolean var17 = var5.isDomainZoomable();
    java.awt.Paint var18 = var5.getAngleGridlinePaint();
    java.awt.Paint var19 = var5.getRadiusGridlinePaint();
    org.jfree.data.general.DatasetChangeEvent var20 = null;
    var5.datasetChanged(var20);
    org.jfree.chart.LegendItemCollection var22 = var5.getLegendItems();
    java.lang.String var23 = var5.getPlotType();
    boolean var24 = var5.isAngleGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "Polar Plot"+ "'", var23.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test232"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getUpperMargin();
    var1.setCategoryLabelPositionOffset(15);
    double var5 = var1.getFixedDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test233"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
    var3.setSectionOutlinesVisible(true);
    java.awt.Paint var7 = var3.getBaseSectionPaint();
    var0.setAxisLinePaint(var7);
    double var9 = var0.getLowerMargin();
    boolean var10 = var0.isVerticalTickLabels();
    var0.setPositiveArrowVisible(true);
    org.jfree.data.Range var13 = var0.getRange();
    double var14 = var0.getLabelAngle();
    org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var16 = var15.getNextFillPaint();
    java.awt.Stroke var17 = var15.getNextOutlineStroke();
    java.awt.Stroke var18 = var15.getNextStroke();
    java.awt.Shape var19 = var15.getNextShape();
    var0.setUpArrow(var19);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.entity.PieSectionEntity var27 = new org.jfree.chart.entity.PieSectionEntity(var19, var21, 0, 100, (java.lang.Comparable)"VerticalAlignment.CENTER", "Multiple Pie Plot", "0,0,2,-2,2,2,2,2");
    java.lang.String var28 = var27.toString();
    java.lang.String var29 = var27.toString();
    java.lang.String var30 = var27.getToolTipText();
    int var31 = var27.getSectionIndex();
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var33 = var32.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var35 = var34.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var36 = null;
    var34.setTickUnit(var36, false, true);
    org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var41 = var40.getTickMarkPosition();
    var34.setTickMarkPosition(var41);
    var32.setTickMarkPosition(var41);
    var32.setInverted(true);
    org.jfree.chart.axis.DateTickUnit var46 = var32.getTickUnit();
    var27.setSectionKey((java.lang.Comparable)var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "PieSection: 0, 100(VerticalAlignment.CENTER)"+ "'", var28.equals("PieSection: 0, 100(VerticalAlignment.CENTER)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "PieSection: 0, 100(VerticalAlignment.CENTER)"+ "'", var29.equals("PieSection: 0, 100(VerticalAlignment.CENTER)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "Multiple Pie Plot"+ "'", var30.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test234"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var5.setLicenceName("hi!");
    java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var12);
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setDomainAxisLocation(1, var21, false);
    java.awt.Stroke var24 = var19.getRangeCrosshairStroke();
    boolean var25 = var18.equals((java.lang.Object)var24);
    java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var30 = null;
    org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var24, (java.awt.Paint)var29, var30, 1.0f);
    java.lang.Object var33 = var32.clone();
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var35 = var34.getQuadrantOrigin();
    var34.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var40 = var34.getRendererForDataset(var39);
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    var42.setForegroundAlpha(1.0f);
    java.awt.Font var45 = var42.getNoDataMessageFont();
    var42.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var42);
    org.jfree.chart.axis.AxisLocation var49 = var42.getDomainAxisLocation();
    var34.setRangeAxisLocation(var49);
    boolean var51 = var32.equals((java.lang.Object)var34);
    boolean var52 = var5.equals((java.lang.Object)var32);
    java.awt.Paint var53 = var32.getPaint();
    org.jfree.chart.text.TextAnchor var54 = var32.getLabelTextAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test235"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var13 = var12.clone();
    org.jfree.data.Range var14 = var12.getRange();
    org.jfree.data.Range var15 = org.jfree.data.Range.combine(var10, var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setForegroundAlpha(1.0f);
    java.awt.Paint var19 = var16.getRangeCrosshairPaint();
    boolean var20 = var15.equals((java.lang.Object)var16);
    org.jfree.data.Range var23 = org.jfree.data.Range.expand(var15, 4.0d, 0.5d);
    org.jfree.data.Range var25 = org.jfree.data.Range.expandToInclude(var23, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test236"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    int var9 = var0.getIndexOf(var8);
    org.jfree.chart.util.RectangleEdge var11 = var0.getRangeAxisEdge(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test237"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(1);
    var1.distributeLabels(4.08d, 0.12d);
    var1.distributeLabels(100.0d, 0.2d);
    java.lang.String var8 = var1.toString();
    java.lang.String var9 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + ""+ "'", var8.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test238"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)"WMAP_Plot");
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test239"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var2 = var1.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var4 = var3.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var5 = null;
    var3.setTickUnit(var5, false, true);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var10 = var9.getTickMarkPosition();
    var3.setTickMarkPosition(var10);
    var1.setTickMarkPosition(var10);
    var1.setInverted(true);
    org.jfree.chart.axis.DateTickUnit var15 = var1.getTickUnit();
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var16, var17);
    java.util.TimeZone var19 = var1.getTimeZone();
    org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var21 = var20.getPlotType();
    java.awt.Stroke var22 = var20.getLabelOutlineStroke();
    java.lang.Object var23 = var20.clone();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Pie 3D Plot"+ "'", var21.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test240"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var5.setLicenceName("hi!");
    org.jfree.chart.ui.ProjectInfo var8 = new org.jfree.chart.ui.ProjectInfo();
    java.util.List var9 = var8.getContributors();
    var5.addOptionalLibrary((org.jfree.chart.ui.Library)var8);
    var5.addOptionalLibrary("Pie 3D Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test241"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.block.LengthConstraintType var12 = var11.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var13 = var11.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var14 = var11.toUnconstrainedWidth();
    org.jfree.data.Range var15 = var11.getWidthRange();
    org.jfree.chart.block.LengthConstraintType var16 = var11.getWidthConstraintType();
    java.lang.Object var17 = null;
    boolean var18 = var16.equals(var17);
    org.jfree.chart.text.TextLine var19 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var20 = null;
    java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var27);
    org.jfree.chart.util.HorizontalAlignment var29 = null;
    org.jfree.chart.util.VerticalAlignment var30 = null;
    org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement(var29, var30, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var36 = null;
    var34.setDomainAxisLocation(1, var36, false);
    java.awt.Stroke var39 = var34.getRangeCrosshairStroke();
    boolean var40 = var33.equals((java.lang.Object)var39);
    java.awt.Color var44 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var45 = null;
    org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var27, var39, (java.awt.Paint)var44, var45, 1.0f);
    java.lang.Object var48 = var47.clone();
    org.jfree.chart.text.TextAnchor var49 = var47.getLabelTextAnchor();
    java.lang.String var50 = var49.toString();
    java.lang.String var51 = var49.toString();
    var19.draw(var20, 1.0f, 0.0f, var49, 10.0f, 10.0f, 0.12d);
    java.awt.Graphics2D var56 = null;
    org.jfree.chart.text.TextAnchor var59 = null;
    var19.draw(var56, 0.0f, 0.0f, var59, 100.0f, 10.0f, (-1.88d));
    boolean var64 = var16.equals((java.lang.Object)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + "TextAnchor.CENTER"+ "'", var50.equals("TextAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "TextAnchor.CENTER"+ "'", var51.equals("TextAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test242"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    java.awt.Shape var3 = var1.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var11 = var10.clone();
    org.jfree.chart.axis.ValueAxis[] var12 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var9.setDomainAxes(var12);
    java.awt.geom.Point2D var14 = var9.getQuadrantOrigin();
    var5.zoomDomainAxes(0.2d, 2.0d, var8, var14);
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var16.setDomainAxisLocation(1, var18, false);
    java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
    var16.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.LegendItemCollection var24 = var16.getLegendItems();
    java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var29);
    org.jfree.chart.util.HorizontalAlignment var31 = null;
    org.jfree.chart.util.VerticalAlignment var32 = null;
    org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement(var31, var32, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var38 = null;
    var36.setDomainAxisLocation(1, var38, false);
    java.awt.Stroke var41 = var36.getRangeCrosshairStroke();
    boolean var42 = var35.equals((java.lang.Object)var41);
    java.awt.Color var46 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var47 = null;
    org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var29, var41, (java.awt.Paint)var46, var47, 1.0f);
    var16.addDomainMarker((org.jfree.chart.plot.Marker)var49);
    java.lang.String var51 = var49.getLabel();
    boolean var52 = var5.equals((java.lang.Object)var49);
    org.jfree.data.general.PieDataset var53 = null;
    org.jfree.chart.plot.PiePlot var54 = new org.jfree.chart.plot.PiePlot(var53);
    org.jfree.chart.util.RectangleInsets var55 = var54.getLabelPadding();
    boolean var56 = var54.getLabelLinksVisible();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var58 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var54.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var58);
    org.jfree.chart.labels.PieSectionLabelGenerator var60 = var54.getLegendLabelToolTipGenerator();
    var54.setLabelLinkMargin(4.0d);
    org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var65 = var64.getUpperMargin();
    org.jfree.data.general.PieDataset var66 = null;
    org.jfree.chart.plot.PiePlot var67 = new org.jfree.chart.plot.PiePlot(var66);
    org.jfree.chart.util.RectangleInsets var68 = var67.getLabelPadding();
    var67.setSectionOutlinesVisible(true);
    java.awt.Paint var71 = var67.getBaseSectionPaint();
    java.awt.Paint var73 = var67.getSectionPaint((java.lang.Comparable)100.0d);
    java.awt.Stroke var74 = var67.getLabelLinkStroke();
    var64.setTickMarkStroke(var74);
    var54.setLabelOutlineStroke(var74);
    java.awt.Paint var77 = var54.getLabelPaint();
    var49.setPaint(var77);
    java.awt.Stroke var79 = var49.getStroke();
    double var80 = var49.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 10.0d);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test243"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 1.0d);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.setForegroundAlpha(1.0f);
//     java.awt.Font var9 = var6.getNoDataMessageFont();
//     var6.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var6);
//     java.awt.Paint var13 = var12.getBackgroundPaint();
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     org.jfree.chart.util.RectangleInsets var16 = var15.getLabelPadding();
//     org.jfree.chart.util.UnitType var17 = var16.getUnitType();
//     var12.setPadding(var16);
//     org.jfree.chart.title.TextTitle var19 = var12.getTitle();
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var21 = var20.clone();
//     org.jfree.data.Range var22 = var20.getRange();
//     var20.setNegativeArrowVisible(false);
//     var4.add((org.jfree.chart.block.Block)var19, (java.lang.Object)var20);
//     var4.clear();
//     org.jfree.chart.plot.RingPlot var27 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Font var28 = var27.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.setForegroundAlpha(1.0f);
//     java.awt.Paint var33 = var30.getRangeCrosshairPaint();
//     var27.setSectionPaint((java.lang.Comparable)0.12d, var33);
//     double var36 = var27.getExplodePercent((java.lang.Comparable)(-65536));
//     boolean var37 = var4.equals((java.lang.Object)var36);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.setForegroundAlpha(1.0f);
//     java.awt.Font var42 = var39.getNoDataMessageFont();
//     var39.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var39);
//     org.jfree.chart.axis.AxisLocation var46 = var39.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var47 = var39.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var48 = null;
//     org.jfree.chart.util.VerticalAlignment var49 = null;
//     org.jfree.chart.block.ColumnArrangement var52 = new org.jfree.chart.block.ColumnArrangement(var48, var49, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var53 = null;
//     org.jfree.chart.util.VerticalAlignment var54 = null;
//     org.jfree.chart.block.ColumnArrangement var57 = new org.jfree.chart.block.ColumnArrangement(var53, var54, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39, (org.jfree.chart.block.Arrangement)var52, (org.jfree.chart.block.Arrangement)var57);
//     org.jfree.chart.util.RectangleEdge var59 = var58.getLegendItemGraphicEdge();
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var62 = var61.getLabelURL();
//     var61.configure();
//     java.awt.Paint var64 = var61.getTickLabelPaint();
//     org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis();
//     var65.setTickMarksVisible(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var68 = null;
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot(var60, (org.jfree.chart.axis.ValueAxis)var61, (org.jfree.chart.axis.ValueAxis)var65, var68);
//     var4.add((org.jfree.chart.block.Block)var58, (java.lang.Object)var65);
//     
//     // Checks the contract:  equals-hashcode on var4 and var57
//     assertTrue("Contract failed: equals-hashcode on var4 and var57", var4.equals(var57) ? var4.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var4
//     assertTrue("Contract failed: equals-hashcode on var57 and var4", var57.equals(var4) ? var57.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var39
//     assertTrue("Contract failed: equals-hashcode on var6 and var39", var6.equals(var39) ? var6.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var6
//     assertTrue("Contract failed: equals-hashcode on var39 and var6", var39.equals(var6) ? var39.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test244"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    org.jfree.chart.labels.PieSectionLabelGenerator var5 = var1.getLegendLabelToolTipGenerator();
    var1.setLabelLinkMargin(100.0d);
    boolean var8 = var1.isCircular();
    org.jfree.chart.urls.PieURLGenerator var9 = var1.getLegendLabelURLGenerator();
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    java.awt.Font var17 = var11.getNoDataMessageFont();
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Color var22 = var21.darker();
    org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var17, (java.awt.Paint)var21);
    var1.setLabelPaint((java.awt.Paint)var21);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    var26.setForegroundAlpha(1.0f);
    java.awt.Font var29 = var26.getNoDataMessageFont();
    var26.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var26);
    org.jfree.data.general.PieDataset var34 = null;
    org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
    org.jfree.chart.util.RectangleInsets var36 = var35.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var37 = null;
    var35.setToolTipGenerator(var37);
    java.awt.Font var39 = var35.getLabelFont();
    org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var39);
    var40.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var40.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var40.setURLText("Range[0.0,1.0]");
    var32.setTitle(var40);
    java.awt.RenderingHints var51 = var32.getRenderingHints();
    org.jfree.chart.title.LegendTitle var53 = var32.getLegend((-65536));
    var32.setBackgroundImageAlignment(15);
    java.lang.Object var56 = var32.getTextAntiAlias();
    org.jfree.chart.plot.Plot var57 = var32.getPlot();
    org.jfree.chart.ui.BasicProjectInfo var63 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var63.setLicenceName("hi!");
    org.jfree.chart.ui.ProjectInfo var66 = new org.jfree.chart.ui.ProjectInfo();
    java.util.List var67 = var66.getContributors();
    var63.addOptionalLibrary((org.jfree.chart.ui.Library)var66);
    org.jfree.chart.JFreeChart var69 = null;
    org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot();
    var70.setForegroundAlpha(1.0f);
    java.awt.Paint var73 = var70.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var74 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var70);
    org.jfree.chart.plot.Plot var75 = var74.getPlot();
    org.jfree.chart.event.ChartChangeEventType var76 = var74.getType();
    org.jfree.chart.axis.NumberAxis var77 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var78 = var77.clone();
    double var79 = var77.getLowerBound();
    boolean var80 = var76.equals((java.lang.Object)var77);
    org.jfree.chart.event.ChartChangeEvent var81 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var63, var69, var76);
    org.jfree.chart.event.ChartChangeEvent var82 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var21, var32, var76);
    java.awt.Image var83 = var32.getBackgroundImage();
    org.jfree.chart.plot.CategoryPlot var84 = var32.getCategoryPlot();
    boolean var85 = var32.getAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test245"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeCrosshairVisible();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = null;
    var3.setFixedLegendItems(var4);
    java.awt.Graphics2D var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.plot.PlotRenderingInfo var9 = null;
    boolean var10 = var3.render(var6, var7, 10, var9);
    java.awt.Stroke var11 = var3.getDomainGridlineStroke();
    org.jfree.chart.axis.AxisLocation var12 = var3.getRangeAxisLocation();
    var0.setDomainAxisLocation(1, var12);
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var16 = var15.clone();
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
    org.jfree.chart.util.RectangleInsets var19 = var18.getLabelPadding();
    var18.setSectionOutlinesVisible(true);
    java.awt.Paint var22 = var18.getBaseSectionPaint();
    var15.setAxisLinePaint(var22);
    double var24 = var15.getLowerMargin();
    boolean var25 = var15.isVerticalTickLabels();
    var15.setPositiveArrowVisible(true);
    java.lang.String var28 = var15.getLabelURL();
    double var29 = var15.getFixedAutoRange();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxis((-16777216), (org.jfree.chart.axis.ValueAxis)var15, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test246"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.LegendItemCollection var8 = var0.getLegendItems();
    org.jfree.data.general.DatasetChangeEvent var9 = null;
    var0.datasetChanged(var9);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var12 = null;
    var11.setMarkerBand(var12);
    org.jfree.data.Range var14 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var11);
    org.jfree.chart.event.RendererChangeEvent var15 = null;
    var0.rendererChanged(var15);
    java.awt.Paint var17 = null;
    var0.setBackgroundPaint(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test247"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Font var3 = var0.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
//     var5.setSectionOutlinesVisible(true);
//     java.awt.Paint var9 = var5.getBaseSectionPaint();
//     var0.setRangeCrosshairPaint(var9);
//     java.lang.Object var11 = var0.clone();
//     org.jfree.chart.LegendItemCollection var12 = var0.getLegendItems();
//     var0.setRangeCrosshairVisible(true);
//     org.jfree.chart.axis.AxisSpace var15 = null;
//     var0.setFixedDomainAxisSpace(var15);
//     int var17 = var0.getDatasetCount();
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var22 = var21.clone();
//     java.awt.Shape var23 = var21.getLeftArrow();
//     org.jfree.chart.renderer.PolarItemRenderer var24 = null;
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var20, (org.jfree.chart.axis.ValueAxis)var21, var24);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var31 = var30.clone();
//     org.jfree.chart.axis.ValueAxis[] var32 = new org.jfree.chart.axis.ValueAxis[] { var30};
//     var29.setDomainAxes(var32);
//     java.awt.geom.Point2D var34 = var29.getQuadrantOrigin();
//     var25.zoomDomainAxes(0.2d, 2.0d, var28, var34);
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var37 = var36.getLabelURL();
//     var36.resizeRange(10.0d);
//     java.awt.Paint var40 = var36.getTickMarkPaint();
//     var25.setAngleLabelPaint(var40);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var45 = null;
//     var44.datasetChanged(var45);
//     java.awt.Paint var47 = var44.getRangeZeroBaselinePaint();
//     var44.setRangeGridlinesVisible(true);
//     var44.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var55 = var54.getQuadrantOrigin();
//     var44.zoomRangeAxes(0.0d, var53, var55);
//     var25.zoomRangeAxes(4.08d, var43, var55);
//     org.jfree.chart.plot.PlotState var58 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var59 = null;
//     var0.draw(var18, var19, var55, var58, var59);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test248"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    float var3 = var1.getTickMarkInsideLength();
    boolean var4 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var6 = var5.clone();
    org.jfree.data.Range var7 = var5.getRange();
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var8);
    java.awt.Stroke var10 = var9.getDomainZeroBaselineStroke();
    var9.setDomainCrosshairVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test249"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    var0.setAnchorValue(0.0d, false);
    org.jfree.chart.util.RectangleEdge var7 = var0.getRangeAxisEdge();
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    java.awt.Paint var9 = var0.getRangeGridlinePaint();
    org.jfree.data.category.CategoryDataset var11 = null;
    var0.setDataset(4, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test250"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var7.setWidth((-1.0d));
    java.lang.Object var17 = var7.clone();
    java.awt.Paint var18 = var7.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test251"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var3 = var2.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var4 = null;
    var2.setTickUnit(var4, false, true);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var9 = var8.getTickMarkPosition();
    var2.setTickMarkPosition(var9);
    var0.setTickMarkPosition(var9);
    var0.setAutoRangeMinimumSize(10.0d);
    var0.setRange(1.0E-8d, 0.08d);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var19 = var18.clone();
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
    org.jfree.chart.util.RectangleInsets var22 = var21.getLabelPadding();
    var21.setSectionOutlinesVisible(true);
    java.awt.Paint var25 = var21.getBaseSectionPaint();
    var18.setAxisLinePaint(var25);
    double var27 = var18.getLowerMargin();
    boolean var28 = var18.isVerticalTickLabels();
    var18.setPositiveArrowVisible(true);
    org.jfree.data.Range var31 = var18.getRange();
    org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(3.0d, var31);
    org.jfree.chart.block.RectangleConstraint var34 = new org.jfree.chart.block.RectangleConstraint(var31, 6.0d);
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var37 = var36.clone();
    org.jfree.chart.axis.ValueAxis[] var38 = new org.jfree.chart.axis.ValueAxis[] { var36};
    var35.setDomainAxes(var38);
    org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
    var35.setRenderer(var40);
    java.awt.Stroke var42 = var35.getRangeCrosshairStroke();
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var45 = var44.getLabelURL();
    var44.resizeRange(10.0d);
    java.awt.Paint var48 = var44.getTickMarkPaint();
    var44.setLabelAngle((-1.0d));
    var35.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var44);
    org.jfree.data.Range var52 = var44.getRange();
    org.jfree.chart.block.RectangleConstraint var53 = var34.toRangeHeight(var52);
    org.jfree.chart.block.RectangleConstraint var55 = new org.jfree.chart.block.RectangleConstraint(var52, 6.0d);
    org.jfree.data.Range var56 = var55.getWidthRange();
    var0.setRange(var56, false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test252"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var3 = var2.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var4 = null;
    var2.setTickUnit(var4, false, true);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var9 = var8.getTickMarkPosition();
    var2.setTickMarkPosition(var9);
    var0.setTickMarkPosition(var9);
    var0.setAutoRangeMinimumSize(10.0d);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var15 = var14.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var17 = var16.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var18 = null;
    var16.setTickUnit(var18, false, true);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var23 = var22.getTickMarkPosition();
    var16.setTickMarkPosition(var23);
    var14.setTickMarkPosition(var23);
    org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var27 = var26.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var29 = var28.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var30 = null;
    var28.setTickUnit(var30, false, true);
    org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var35 = var34.getTickMarkPosition();
    var28.setTickMarkPosition(var35);
    var26.setTickMarkPosition(var35);
    var26.setInverted(true);
    org.jfree.chart.axis.DateTickUnit var40 = var26.getTickUnit();
    java.util.Date var41 = var14.calculateHighestVisibleTickValue(var40);
    var0.setTickUnit(var40);
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var44 = var43.clone();
    var43.setVisible(false);
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var49 = var48.clone();
    org.jfree.data.general.PieDataset var50 = null;
    org.jfree.chart.plot.PiePlot var51 = new org.jfree.chart.plot.PiePlot(var50);
    org.jfree.chart.util.RectangleInsets var52 = var51.getLabelPadding();
    var51.setSectionOutlinesVisible(true);
    java.awt.Paint var55 = var51.getBaseSectionPaint();
    var48.setAxisLinePaint(var55);
    org.jfree.data.Range var57 = var48.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var58 = new org.jfree.chart.block.RectangleConstraint(100.0d, var57);
    org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var60 = var59.clone();
    org.jfree.data.Range var61 = var59.getRange();
    org.jfree.data.Range var62 = org.jfree.data.Range.combine(var57, var61);
    var43.setRangeWithMargins(var61);
    double var64 = var61.getLowerBound();
    var0.setRange(var61);
    org.jfree.chart.axis.DateAxis var67 = new org.jfree.chart.axis.DateAxis("Category Plot");
    java.util.TimeZone var68 = var67.getTimeZone();
    var0.setTimeZone(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test253"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var1 = var0.getPlotType();
    java.awt.Paint var2 = var0.getLabelPaint();
    java.awt.Paint var3 = var0.getLabelBackgroundPaint();
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var8);
    org.jfree.chart.util.HorizontalAlignment var10 = null;
    org.jfree.chart.util.VerticalAlignment var11 = null;
    org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setDomainAxisLocation(1, var17, false);
    java.awt.Stroke var20 = var15.getRangeCrosshairStroke();
    boolean var21 = var14.equals((java.lang.Object)var20);
    java.awt.Color var25 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var26 = null;
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var8, var20, (java.awt.Paint)var25, var26, 1.0f);
    java.lang.Object var29 = var28.clone();
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var31 = var30.getQuadrantOrigin();
    var30.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var35 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = var30.getRendererForDataset(var35);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
    var38.setForegroundAlpha(1.0f);
    java.awt.Font var41 = var38.getNoDataMessageFont();
    var38.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var38);
    org.jfree.chart.axis.AxisLocation var45 = var38.getDomainAxisLocation();
    var30.setRangeAxisLocation(var45);
    boolean var47 = var28.equals((java.lang.Object)var30);
    org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
    var49.setForegroundAlpha(1.0f);
    boolean var52 = var49.isDomainGridlinesVisible();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    var49.setRenderer(var53, true);
    org.jfree.chart.axis.AxisLocation var57 = var49.getRangeAxisLocation((-1));
    var30.setDomainAxisLocation(0, var57, true);
    java.awt.Stroke var60 = var30.getDomainZeroBaselineStroke();
    var0.setLabelOutlineStroke(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Pie 3D Plot"+ "'", var1.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test254"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.data.general.PieDataset var2 = var1.getDataset();
    org.jfree.chart.util.RectangleInsets var3 = new org.jfree.chart.util.RectangleInsets();
    var1.setLabelPadding(var3);
    boolean var5 = var1.isCircular();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.setForegroundAlpha(1.0f);
    java.awt.Font var10 = var7.getNoDataMessageFont();
    var7.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.axis.AxisLocation var14 = var7.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var15 = var7.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var21 = null;
    org.jfree.chart.util.VerticalAlignment var22 = null;
    org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement(var21, var22, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7, (org.jfree.chart.block.Arrangement)var20, (org.jfree.chart.block.Arrangement)var25);
    org.jfree.data.general.PieDataset var27 = null;
    org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
    org.jfree.chart.util.RectangleInsets var29 = var28.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var30 = null;
    var28.setToolTipGenerator(var30);
    java.awt.Stroke var32 = var28.getBaseSectionOutlineStroke();
    java.awt.Paint var33 = var28.getLabelLinkPaint();
    var26.setItemPaint(var33);
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var37 = null;
    var35.setDomainAxisLocation(1, var37, false);
    java.awt.Stroke var40 = var35.getRangeCrosshairStroke();
    var35.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.Plot var43 = var35.getRootPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    var35.setRenderer(var44);
    java.awt.Paint var46 = var35.getDomainZeroBaselinePaint();
    var26.setItemPaint(var46);
    var26.setHeight(0.0d);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var51 = var50.getLabelURL();
    var50.configure();
    java.awt.Paint var53 = var50.getTickLabelPaint();
    var26.setBackgroundPaint(var53);
    var1.setLabelOutlinePaint(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test255"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
    var0.configure();
    org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var4 = var3.getNextFillPaint();
    java.awt.Stroke var5 = var3.getNextOutlineStroke();
    java.awt.Stroke var6 = var3.getNextStroke();
    java.awt.Paint var7 = var3.getNextOutlinePaint();
    java.awt.Paint var8 = var3.getNextPaint();
    java.lang.Object var9 = null;
    boolean var10 = var3.equals(var9);
    java.awt.Paint var11 = var3.getNextPaint();
    java.lang.Object var12 = var3.clone();
    boolean var13 = var0.equals((java.lang.Object)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test256"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    boolean var3 = var1.getLabelLinksVisible();
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var6 = var5.getLabelURL();
    var5.configure();
    java.awt.Paint var8 = var5.getTickLabelPaint();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    var9.setTickMarksVisible(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var9, var12);
    java.awt.Paint var14 = var9.getTickMarkPaint();
    var1.setLabelPaint(var14);
    boolean var16 = var1.getSectionOutlinesVisible();
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
    org.jfree.chart.util.RectangleInsets var19 = var18.getLabelPadding();
    boolean var20 = var18.getLabelLinksVisible();
    java.awt.Stroke var21 = var18.getBaseSectionOutlineStroke();
    double var22 = var18.getMaximumLabelWidth();
    org.jfree.chart.util.Rotation var23 = var18.getDirection();
    java.lang.String var24 = var23.toString();
    var1.setDirection(var23);
    double var26 = var23.getFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "Rotation.CLOCKWISE"+ "'", var24.equals("Rotation.CLOCKWISE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1.0d));

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test257"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var8 = var7.getBackgroundPaint();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
    org.jfree.chart.util.UnitType var12 = var11.getUnitType();
    var7.setPadding(var11);
    var7.setBorderVisible(true);
    org.jfree.chart.plot.CategoryPlot var16 = var7.getCategoryPlot();
    var7.setNotify(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test258"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    boolean var15 = var0.isRangeCrosshairVisible();
    boolean var16 = var0.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.plot.MultiplePiePlot var18 = new org.jfree.chart.plot.MultiplePiePlot(var17);
    java.lang.Comparable var19 = var18.getAggregatedItemsKey();
    java.awt.Paint var20 = var18.getAggregatedItemsPaint();
    var0.setDomainGridlinePaint(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "Other"+ "'", var19.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test259"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
    java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var12);
    var1.setDomainGridlinePaint((java.awt.Paint)var12);
    java.lang.String var15 = var12.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "java.awt.Color[r=255,g=0,b=0]"+ "'", var15.equals("java.awt.Color[r=255,g=0,b=0]"));

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test260"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var7.setURLText("Range[0.0,1.0]");
    org.jfree.chart.util.HorizontalAlignment var17 = var7.getHorizontalAlignment();
    var7.setID("Range[0.0,1.0]");
    boolean var20 = var7.getExpandToFitSpace();
    var7.setText("");
    org.jfree.chart.event.TitleChangeEvent var23 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test261"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var12 = null;
//     var10.setToolTipGenerator(var12);
//     java.awt.Font var14 = var10.getLabelFont();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var14);
//     var15.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var15.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var15.setURLText("Range[0.0,1.0]");
//     var7.setTitle(var15);
//     java.awt.RenderingHints var26 = var7.getRenderingHints();
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.setForegroundAlpha(1.0f);
//     java.awt.Font var31 = var28.getNoDataMessageFont();
//     var28.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var28);
//     org.jfree.chart.axis.AxisLocation var35 = var28.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var36 = var28.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var37 = null;
//     org.jfree.chart.util.VerticalAlignment var38 = null;
//     org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement(var37, var38, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var42 = null;
//     org.jfree.chart.util.VerticalAlignment var43 = null;
//     org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement(var42, var43, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28, (org.jfree.chart.block.Arrangement)var41, (org.jfree.chart.block.Arrangement)var46);
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot(var48);
//     org.jfree.chart.util.RectangleInsets var50 = var49.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var51 = null;
//     var49.setToolTipGenerator(var51);
//     java.awt.Stroke var53 = var49.getBaseSectionOutlineStroke();
//     java.awt.Paint var54 = var49.getLabelLinkPaint();
//     var47.setItemPaint(var54);
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var58 = null;
//     var56.setDomainAxisLocation(1, var58, false);
//     java.awt.Stroke var61 = var56.getRangeCrosshairStroke();
//     var56.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.Plot var64 = var56.getRootPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var65 = null;
//     var56.setRenderer(var65);
//     java.awt.Paint var67 = var56.getDomainZeroBaselinePaint();
//     var47.setItemPaint(var67);
//     java.awt.Font var69 = var47.getItemFont();
//     double var70 = var47.getContentXOffset();
//     org.jfree.chart.util.RectangleInsets var71 = var47.getItemLabelPadding();
//     org.jfree.chart.event.TitleChangeEvent var72 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var47);
//     var7.titleChanged(var72);
//     
//     // Checks the contract:  equals-hashcode on var1 and var28
//     assertTrue("Contract failed: equals-hashcode on var1 and var28", var1.equals(var28) ? var1.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var1
//     assertTrue("Contract failed: equals-hashcode on var28 and var1", var28.equals(var1) ? var28.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var49
//     assertTrue("Contract failed: equals-hashcode on var10 and var49", var10.equals(var49) ? var10.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var10
//     assertTrue("Contract failed: equals-hashcode on var49 and var10", var49.equals(var10) ? var49.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test262"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.block.LengthConstraintType var12 = var11.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var13 = var11.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var14 = var11.toUnconstrainedWidth();
    org.jfree.data.Range var15 = var11.getWidthRange();
    org.jfree.data.Range var16 = var11.getHeightRange();
    org.jfree.data.Range var18 = org.jfree.data.Range.expandToInclude(var16, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test263"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var1 = var0.getLabelURL();
    var0.resizeRange(10.0d);
    java.awt.Paint var4 = var0.getTickMarkPaint();
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var8);
    int var10 = var8.getGreen();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setForegroundAlpha(1.0f);
    java.awt.Font var14 = var11.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var15 = null;
    org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
    org.jfree.chart.util.RectangleInsets var17 = var16.getLabelPadding();
    var16.setSectionOutlinesVisible(true);
    java.awt.Paint var20 = var16.getBaseSectionPaint();
    var11.setRangeCrosshairPaint(var20);
    java.lang.Object var22 = var11.clone();
    org.jfree.chart.LegendItemCollection var23 = var11.getLegendItems();
    boolean var24 = var8.equals((java.lang.Object)var11);
    boolean var25 = var0.equals((java.lang.Object)var8);
    var0.setLowerBound(0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test264"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]");
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     double var3 = var2.getDepthFactor();
//     var2.setCircular(true, true);
//     double var7 = var2.getDepthFactor();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.setForegroundAlpha(1.0f);
//     java.awt.Font var13 = var10.getNoDataMessageFont();
//     var10.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var10);
//     org.jfree.chart.axis.AxisLocation var17 = var10.getDomainAxisLocation();
//     java.lang.String var18 = var10.getPlotType();
//     var10.mapDatasetToRangeAxis(0, 0);
//     java.awt.Paint var22 = var10.getRangeGridlinePaint();
//     var2.setSectionPaint((java.lang.Comparable)"XY Plot", var22);
//     boolean var24 = var1.equals((java.lang.Object)var22);
//     java.awt.Graphics2D var25 = null;
//     java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var32);
//     org.jfree.chart.util.HorizontalAlignment var34 = null;
//     org.jfree.chart.util.VerticalAlignment var35 = null;
//     org.jfree.chart.block.ColumnArrangement var38 = new org.jfree.chart.block.ColumnArrangement(var34, var35, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var41 = null;
//     var39.setDomainAxisLocation(1, var41, false);
//     java.awt.Stroke var44 = var39.getRangeCrosshairStroke();
//     boolean var45 = var38.equals((java.lang.Object)var44);
//     java.awt.Color var49 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var50 = null;
//     org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var32, var44, (java.awt.Paint)var49, var50, 1.0f);
//     java.lang.Object var53 = var52.clone();
//     org.jfree.chart.text.TextAnchor var54 = var52.getLabelTextAnchor();
//     var1.draw(var25, 2.0f, 10.0f, var54, 0.0f, 0.0f, (-1.0d));
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test265"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var2.rendererChanged(var3);
    org.jfree.chart.event.RendererChangeEvent var5 = null;
    var2.rendererChanged(var5);
    org.jfree.chart.util.HorizontalAlignment var7 = null;
    org.jfree.chart.util.VerticalAlignment var8 = null;
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement(var7, var8, 3.0d, 100.0d);
    org.jfree.chart.block.Block var12 = null;
    java.lang.Object var13 = null;
    var11.add(var12, var13);
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, (-7.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var19);
    org.jfree.chart.event.RendererChangeEvent var21 = null;
    var2.rendererChanged(var21);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test266"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var1 = var0.getPlotType();
    org.jfree.chart.urls.PieURLGenerator var2 = null;
    var0.setLegendLabelURLGenerator(var2);
    java.awt.Graphics2D var4 = null;
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var9 = null;
    var7.setToolTipGenerator(var9);
    java.awt.Font var11 = var7.getLabelFont();
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var11);
    var12.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var18 = var12.getURLText();
    org.jfree.chart.util.VerticalAlignment var19 = var12.getVerticalAlignment();
    java.awt.geom.Rectangle2D var20 = var12.getBounds();
    var0.drawBackgroundImage(var4, var20);
    var0.setShadowYOffset(0.0d);
    var0.zoom(0.0d);
    org.jfree.data.general.PieDataset var26 = var0.getDataset();
    double var27 = var0.getMaximumExplodePercent();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Pie 3D Plot"+ "'", var1.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test267"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(var8);
    org.jfree.chart.axis.ValueAxis var11 = var0.getRangeAxisForDataset(0);
    org.jfree.chart.LegendItemCollection var12 = var0.getLegendItems();
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var14 = var13.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var16 = var15.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var17 = null;
    var15.setTickUnit(var17, false, true);
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var22 = var21.getTickMarkPosition();
    var15.setTickMarkPosition(var22);
    var13.setTickMarkPosition(var22);
    org.jfree.chart.axis.DateTickUnit var25 = null;
    var13.setTickUnit(var25);
    var13.configure();
    int var28 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var13);
    var13.setRangeAboutValue(10.0d, 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test268"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    var0.setAnchorValue(0.0d);
    var0.configureRangeAxes();
    var0.clearDomainAxes();
    var0.clearRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test269"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.axis.ValueAxis[] var11 = new org.jfree.chart.axis.ValueAxis[] { var9};
    var8.setDomainAxes(var11);
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    var8.setRenderer(var13);
    java.awt.Stroke var15 = var8.getRangeCrosshairStroke();
    var7.setBorderStroke(var15);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var21);
    org.jfree.chart.util.HorizontalAlignment var23 = null;
    org.jfree.chart.util.VerticalAlignment var24 = null;
    org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var30 = null;
    var28.setDomainAxisLocation(1, var30, false);
    java.awt.Stroke var33 = var28.getRangeCrosshairStroke();
    boolean var34 = var27.equals((java.lang.Object)var33);
    java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var39 = null;
    org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var21, var33, (java.awt.Paint)var38, var39, 1.0f);
    float var42 = var41.getAlpha();
    java.awt.Paint var43 = var41.getLabelPaint();
    java.awt.Paint var44 = var41.getPaint();
    boolean var45 = var7.equals((java.lang.Object)var41);
    java.awt.Paint var46 = var7.getBorderPaint();
    org.jfree.chart.plot.CategoryPlot var47 = var7.getCategoryPlot();
    java.lang.String var48 = var47.getPlotType();
    java.awt.Paint var49 = var47.getDomainGridlinePaint();
    double var50 = var47.getRangeCrosshairValue();
    boolean var51 = var47.getDrawSharedDomainAxis();
    org.jfree.chart.LegendItemCollection var52 = var47.getLegendItems();
    org.jfree.chart.plot.Plot var53 = var47.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var55 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var47.setDomainAxis((-16777216), var55, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "Category Plot"+ "'", var48.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test270"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.util.List var1 = var0.getContributors();
    java.lang.String var2 = var0.getLicenceText();
    org.jfree.chart.ui.BasicProjectInfo var8 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var8.addOptionalLibrary("");
    var0.addOptionalLibrary((org.jfree.chart.ui.Library)var8);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var14 = var13.getLabelURL();
    var13.configure();
    java.awt.Paint var16 = var13.getTickLabelPaint();
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    var17.setTickMarksVisible(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var17, var20);
    double var22 = var17.getLowerBound();
    boolean var23 = var0.equals((java.lang.Object)var17);
    java.lang.String var24 = var0.toString();
    java.util.List var25 = var0.getContributors();
    var0.setLicenceName("RectangleAnchor.CENTER");
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
    var32.setForegroundAlpha(1.0f);
    java.awt.Font var35 = var32.getNoDataMessageFont();
    var32.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var32);
    java.awt.Paint var39 = var38.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var40 = var38.getPadding();
    org.jfree.chart.title.LegendTitle var42 = var38.getLegend(255);
    var38.setBackgroundImageAlpha(0.0f);
    java.awt.image.BufferedImage var47 = var38.createBufferedImage(255, 15);
    org.jfree.chart.ui.ProjectInfo var51 = new org.jfree.chart.ui.ProjectInfo("UnitType.ABSOLUTE", "TextAnchor.CENTER", "hi!", (java.awt.Image)var47, "WMAP_Plot", "UnitType.ABSOLUTE", "TextAnchor.CENTER");
    var0.setLogo((java.awt.Image)var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"+ "'", var24.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test271"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    java.awt.Shape var3 = var1.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
    org.jfree.chart.renderer.PolarItemRenderer var6 = var5.getRenderer();
    java.lang.Object var7 = var5.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test272"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryLabelPositionOffset(1);
    var1.setLabelAngle(0.0d);
    var1.clearCategoryLabelToolTips();
    java.awt.Paint var8 = var1.getTickLabelPaint((java.lang.Comparable)0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test273"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    java.awt.Shape var3 = var1.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var11 = var10.clone();
    org.jfree.chart.axis.ValueAxis[] var12 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var9.setDomainAxes(var12);
    java.awt.geom.Point2D var14 = var9.getQuadrantOrigin();
    var5.zoomDomainAxes(0.2d, 2.0d, var8, var14);
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
    org.jfree.chart.util.RectangleInsets var18 = var17.getLabelPadding();
    boolean var19 = var17.getLabelLinksVisible();
    java.awt.Stroke var20 = var17.getBaseSectionOutlineStroke();
    var5.setRadiusGridlineStroke(var20);
    org.jfree.chart.axis.ValueAxis var22 = var5.getAxis();
    org.jfree.chart.plot.PlotRenderingInfo var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var30 = var29.getQuadrantOrigin();
    var25.zoomDomainAxes((-1.0d), 3.0d, var28, var30);
    var5.zoomRangeAxes((-1.88d), var24, var30);
    boolean var33 = var5.isAngleLabelsVisible();
    boolean var34 = var5.isAngleGridlinesVisible();
    int var35 = var5.getSeriesCount();
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var37 = var36.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var39 = var38.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var40 = null;
    var38.setTickUnit(var40, false, true);
    org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var45 = var44.getTickMarkPosition();
    var38.setTickMarkPosition(var45);
    var36.setTickMarkPosition(var45);
    java.text.DateFormat var48 = var36.getDateFormatOverride();
    var36.setAutoTickUnitSelection(false);
    org.jfree.chart.axis.DateAxis var51 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var52 = var51.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var53 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var54 = var53.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var55 = null;
    var53.setTickUnit(var55, false, true);
    org.jfree.chart.axis.DateAxis var59 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var60 = var59.getTickMarkPosition();
    var53.setTickMarkPosition(var60);
    var51.setTickMarkPosition(var60);
    var51.setInverted(true);
    org.jfree.chart.axis.DateTickUnit var65 = var51.getTickUnit();
    var36.setTickUnit(var65);
    var5.setAngleTickUnit((org.jfree.chart.axis.TickUnit)var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test274"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var5 = var4.clone();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     org.jfree.chart.util.RectangleInsets var8 = var7.getLabelPadding();
//     var7.setSectionOutlinesVisible(true);
//     java.awt.Paint var11 = var7.getBaseSectionPaint();
//     var4.setAxisLinePaint(var11);
//     double var13 = var4.getLowerMargin();
//     boolean var14 = var4.isVerticalTickLabels();
//     var4.setPositiveArrowVisible(true);
//     org.jfree.data.Range var17 = var4.getRange();
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(3.0d, var17);
//     org.jfree.chart.util.Size2D var19 = var0.arrange(var1, var2, var18);
//     var1.clear();
//     var1.clear();
//     org.jfree.data.general.WaferMapDataset var22 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var23 = null;
//     org.jfree.chart.plot.WaferMapPlot var24 = new org.jfree.chart.plot.WaferMapPlot(var22, var23);
//     org.jfree.chart.event.RendererChangeEvent var25 = null;
//     var24.rendererChanged(var25);
//     org.jfree.chart.event.RendererChangeEvent var27 = null;
//     var24.rendererChanged(var27);
//     org.jfree.chart.util.HorizontalAlignment var29 = null;
//     org.jfree.chart.util.VerticalAlignment var30 = null;
//     org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement(var29, var30, 3.0d, 100.0d);
//     org.jfree.chart.block.Block var34 = null;
//     java.lang.Object var35 = null;
//     var33.add(var34, var35);
//     org.jfree.chart.util.HorizontalAlignment var37 = null;
//     org.jfree.chart.util.VerticalAlignment var38 = null;
//     org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement(var37, var38, (-7.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24, (org.jfree.chart.block.Arrangement)var33, (org.jfree.chart.block.Arrangement)var41);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     var44.setForegroundAlpha(1.0f);
//     java.awt.Font var47 = var44.getNoDataMessageFont();
//     var44.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var44);
//     org.jfree.chart.axis.AxisLocation var51 = var44.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var52 = var44.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var53 = null;
//     org.jfree.chart.util.VerticalAlignment var54 = null;
//     org.jfree.chart.block.ColumnArrangement var57 = new org.jfree.chart.block.ColumnArrangement(var53, var54, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var58 = null;
//     org.jfree.chart.util.VerticalAlignment var59 = null;
//     org.jfree.chart.block.ColumnArrangement var62 = new org.jfree.chart.block.ColumnArrangement(var58, var59, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var44, (org.jfree.chart.block.Arrangement)var57, (org.jfree.chart.block.Arrangement)var62);
//     org.jfree.data.general.PieDataset var64 = null;
//     org.jfree.chart.plot.PiePlot var65 = new org.jfree.chart.plot.PiePlot(var64);
//     org.jfree.chart.util.RectangleInsets var66 = var65.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var67 = null;
//     var65.setToolTipGenerator(var67);
//     java.awt.Stroke var69 = var65.getBaseSectionOutlineStroke();
//     java.awt.Paint var70 = var65.getLabelLinkPaint();
//     var63.setItemPaint(var70);
//     org.jfree.data.general.PieDataset var72 = null;
//     org.jfree.chart.plot.PiePlot var73 = new org.jfree.chart.plot.PiePlot(var72);
//     org.jfree.chart.util.RectangleInsets var74 = var73.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var75 = null;
//     var73.setToolTipGenerator(var75);
//     org.jfree.chart.plot.XYPlot var77 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var79 = null;
//     var77.setDomainAxisLocation(1, var79, false);
//     java.awt.Stroke var82 = var77.getRangeCrosshairStroke();
//     var73.setBaseSectionOutlineStroke(var82);
//     java.awt.Paint var84 = var73.getLabelShadowPaint();
//     var63.setItemPaint(var84);
//     org.jfree.chart.plot.CategoryPlot var86 = new org.jfree.chart.plot.CategoryPlot();
//     var86.setForegroundAlpha(1.0f);
//     org.jfree.chart.axis.AxisSpace var89 = null;
//     var86.setFixedDomainAxisSpace(var89);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var91 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var92 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var91};
//     var86.setRenderers(var92);
//     var63.setSources((org.jfree.chart.LegendItemSource[])var92);
//     var42.setSources((org.jfree.chart.LegendItemSource[])var92);
//     var1.add((org.jfree.chart.block.Block)var42);
//     
//     // Checks the contract:  equals-hashcode on var7 and var65
//     assertTrue("Contract failed: equals-hashcode on var7 and var65", var7.equals(var65) ? var7.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var7
//     assertTrue("Contract failed: equals-hashcode on var65 and var7", var65.equals(var7) ? var65.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test275"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearDomainMarkers(100);
    var0.setOutlineVisible(true);
    org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxis(0);
    java.awt.Paint var10 = var0.getRangeGridlinePaint();
    org.jfree.chart.util.Layer var11 = null;
    java.util.Collection var12 = var0.getDomainMarkers(var11);
    java.awt.Paint var14 = var0.getQuadrantPaint(2);
    org.jfree.chart.axis.ValueAxis var16 = var0.getRangeAxis(0);
    var0.setDomainCrosshairLockedOnData(false);
    var0.setRangeGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test276"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var7.setURLText("Range[0.0,1.0]");
    boolean var17 = var7.getNotify();
    var7.setHeight(0.0d);
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var23 = var22.clone();
    org.jfree.data.general.PieDataset var24 = null;
    org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
    org.jfree.chart.util.RectangleInsets var26 = var25.getLabelPadding();
    var25.setSectionOutlinesVisible(true);
    java.awt.Paint var29 = var25.getBaseSectionPaint();
    var22.setAxisLinePaint(var29);
    org.jfree.data.Range var31 = var22.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(100.0d, var31);
    org.jfree.chart.block.LengthConstraintType var33 = var32.getHeightConstraintType();
    double var34 = var32.getHeight();
    double var35 = var32.getWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var36 = var7.arrange(var20, var32);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 100.0d);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test277"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var5.setLicenceName("hi!");
    java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var12);
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setDomainAxisLocation(1, var21, false);
    java.awt.Stroke var24 = var19.getRangeCrosshairStroke();
    boolean var25 = var18.equals((java.lang.Object)var24);
    java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var30 = null;
    org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var24, (java.awt.Paint)var29, var30, 1.0f);
    java.lang.Object var33 = var32.clone();
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var35 = var34.getQuadrantOrigin();
    var34.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var40 = var34.getRendererForDataset(var39);
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    var42.setForegroundAlpha(1.0f);
    java.awt.Font var45 = var42.getNoDataMessageFont();
    var42.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var42);
    org.jfree.chart.axis.AxisLocation var49 = var42.getDomainAxisLocation();
    var34.setRangeAxisLocation(var49);
    boolean var51 = var32.equals((java.lang.Object)var34);
    boolean var52 = var5.equals((java.lang.Object)var32);
    java.awt.Paint var53 = var32.getPaint();
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
    var54.setForegroundAlpha(1.0f);
    java.awt.Font var57 = var54.getNoDataMessageFont();
    var54.clearAnnotations();
    boolean var59 = var54.isDomainZoomable();
    org.jfree.chart.renderer.category.CategoryItemRenderer var61 = var54.getRenderer(0);
    var32.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var54);
    var32.setLabel("org.jfree.chart.event.ChartProgressEvent[source=1.0]");
    org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var66 = var65.clone();
    org.jfree.chart.util.RectangleInsets var67 = var65.getLabelInsets();
    double var69 = var67.calculateRightOutset(100.0d);
    java.lang.String var70 = var67.toString();
    double var72 = var67.extendHeight(0.0d);
    var32.setLabelOffset(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var70 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var70.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 6.0d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test278"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.chart.plot.PiePlotState var11 = var0.initialise(var1, var2, var4, (java.lang.Integer)0, var10);
    double var12 = var11.getPieCenterX();
    var11.setPieCenterX(0.14d);
    java.awt.geom.Rectangle2D var15 = var11.getLinkArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test279"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    java.awt.Shape var3 = var1.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var11 = var10.clone();
    org.jfree.chart.axis.ValueAxis[] var12 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var9.setDomainAxes(var12);
    java.awt.geom.Point2D var14 = var9.getQuadrantOrigin();
    var5.zoomDomainAxes(0.2d, 2.0d, var8, var14);
    boolean var16 = var5.isAngleGridlinesVisible();
    boolean var17 = var5.isDomainZoomable();
    java.awt.Paint var18 = var5.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotOrientation var19 = var5.getOrientation();
    java.awt.Paint var20 = var5.getRadiusGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test280"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    org.jfree.chart.plot.PlotRenderingInfo var2 = var1.getInfo();
    org.jfree.chart.entity.EntityCollection var3 = var1.getEntityCollection();
    double var4 = var1.getPieCenterY();
    var1.setLatestAngle(9.0d);
    var1.setPieHRadius(2.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test281"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var6 = null;
//     var4.setDomainAxisLocation(1, var6, false);
//     java.awt.Stroke var9 = var4.getRangeCrosshairStroke();
//     var4.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.LegendItemCollection var12 = var4.getLegendItems();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var17);
//     org.jfree.chart.util.HorizontalAlignment var19 = null;
//     org.jfree.chart.util.VerticalAlignment var20 = null;
//     org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement(var19, var20, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var26 = null;
//     var24.setDomainAxisLocation(1, var26, false);
//     java.awt.Stroke var29 = var24.getRangeCrosshairStroke();
//     boolean var30 = var23.equals((java.lang.Object)var29);
//     java.awt.Color var34 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var35 = null;
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var17, var29, (java.awt.Paint)var34, var35, 1.0f);
//     var4.addDomainMarker((org.jfree.chart.plot.Marker)var37);
//     org.jfree.chart.text.TextAnchor var39 = var37.getLabelTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("ChartEntity: tooltip = null", var1, 0.0f, 2.0f, var39, 0.0d, (-1.0f), 0.0f);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test282"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Font var3 = var0.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
//     var5.setSectionOutlinesVisible(true);
//     java.awt.Paint var9 = var5.getBaseSectionPaint();
//     var0.setRangeCrosshairPaint(var9);
//     java.awt.Image var11 = null;
//     var0.setBackgroundImage(var11);
//     org.jfree.chart.LegendItemCollection var13 = var0.getLegendItems();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var15 = null;
//     var14.setFixedLegendItems(var15);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     boolean var21 = var14.render(var17, var18, 10, var20);
//     org.jfree.chart.axis.AxisLocation var22 = var14.getDomainAxisLocation();
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var26 = var25.getUpperMargin();
//     var14.setDomainAxis(10, var25, false);
//     boolean var29 = var14.isRangeCrosshairVisible();
//     boolean var30 = var14.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     java.util.List var32 = var14.getCategoriesForAxis(var31);
//     java.awt.Color var37 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var37);
//     org.jfree.chart.util.HorizontalAlignment var39 = null;
//     org.jfree.chart.util.VerticalAlignment var40 = null;
//     org.jfree.chart.block.ColumnArrangement var43 = new org.jfree.chart.block.ColumnArrangement(var39, var40, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var46 = null;
//     var44.setDomainAxisLocation(1, var46, false);
//     java.awt.Stroke var49 = var44.getRangeCrosshairStroke();
//     boolean var50 = var43.equals((java.lang.Object)var49);
//     java.awt.Color var54 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var55 = null;
//     org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var37, var49, (java.awt.Paint)var54, var55, 1.0f);
//     float var58 = var57.getAlpha();
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var60 = var59.clone();
//     org.jfree.data.general.PieDataset var61 = null;
//     org.jfree.chart.plot.PiePlot var62 = new org.jfree.chart.plot.PiePlot(var61);
//     org.jfree.chart.util.RectangleInsets var63 = var62.getLabelPadding();
//     var62.setSectionOutlinesVisible(true);
//     java.awt.Paint var66 = var62.getBaseSectionPaint();
//     var59.setAxisLinePaint(var66);
//     var57.setPaint(var66);
//     org.jfree.chart.util.RectangleInsets var69 = var57.getLabelOffset();
//     var14.addRangeMarker((org.jfree.chart.plot.Marker)var57);
//     org.jfree.chart.axis.CategoryAnchor var71 = var14.getDomainGridlinePosition();
//     var0.setDomainGridlinePosition(var71);
//     
//     // Checks the contract:  equals-hashcode on var5 and var62
//     assertTrue("Contract failed: equals-hashcode on var5 and var62", var5.equals(var62) ? var5.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var5
//     assertTrue("Contract failed: equals-hashcode on var62 and var5", var62.equals(var5) ? var62.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test283"); }


    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.setForegroundAlpha(1.0f);
    java.awt.Font var7 = var4.getNoDataMessageFont();
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var9 = null;
    var8.datasetChanged(var9);
    java.awt.Stroke var11 = var8.getOutlineStroke();
    java.awt.Paint var12 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.text.TextLine var13 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var7, var12);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("RectangleConstraintType.RANGE", var7);
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var16 = var15.getQuadrantOrigin();
    var15.mapDatasetToDomainAxis(100, 0);
    java.awt.Paint var20 = var15.getDomainCrosshairPaint();
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.text.G2TextMeasurer var23 = new org.jfree.chart.text.G2TextMeasurer(var22);
    org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var20, 10.0f, (org.jfree.chart.text.TextMeasurer)var23);
    org.jfree.chart.text.TextLine var25 = var24.getLastLine();
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.text.TextBlockAnchor var29 = null;
    var24.draw(var26, 0.0f, 0.0f, var29);
    org.jfree.chart.text.TextLine var32 = new org.jfree.chart.text.TextLine("");
    var24.addLine(var32);
    org.jfree.chart.text.TextFragment var34 = var32.getLastTextFragment();
    java.awt.Font var35 = var34.getFont();
    float var36 = var34.getBaselineOffset();
    java.awt.Font var37 = var34.getFont();
    org.jfree.chart.text.TextFragment var38 = new org.jfree.chart.text.TextFragment("ChartChangeEventType.GENERAL", var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test284"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    var0.setDepthFactor(0.05d);
    java.awt.Paint var3 = var0.getShadowPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test285"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getDepthFactor();
    var0.setCircular(true, true);
    var0.setDarkerSides(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.12d);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test286"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryLabelPositionOffset(10);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    var1.setUpperMargin(90.0d);
    var1.setUpperMargin(5.0d);
    var1.removeCategoryLabelToolTip((java.lang.Comparable)0.8f);
    var1.setUpperMargin(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test287"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.setForegroundAlpha(1.0f);
    java.awt.Font var8 = var5.getNoDataMessageFont();
    var5.setAnchorValue(100.0d);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var12.setMaximumCategoryLabelLines((-1));
    int var15 = var5.getDomainAxisIndex(var12);
    int var16 = var0.getDomainAxisIndex(var12);
    var0.setRangeGridlinesVisible(true);
    boolean var19 = var0.isDomainZoomable();
    var0.setDomainGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test288"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    boolean var1 = var0.isEmpty();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.setForegroundAlpha(1.0f);
    java.awt.Font var6 = var3.getNoDataMessageFont();
    var3.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.axis.AxisLocation var10 = var3.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var11 = var3.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
    org.jfree.chart.LegendItemSource[] var23 = var22.getSources();
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var25 = null;
    var24.datasetChanged(var25);
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    var24.setRenderer(1, var28);
    org.jfree.chart.util.RectangleEdge var31 = var24.getDomainAxisEdge(10);
    var22.setLegendItemGraphicEdge(var31);
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
    var35.setForegroundAlpha(1.0f);
    java.awt.Font var38 = var35.getNoDataMessageFont();
    var35.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var35);
    org.jfree.chart.event.ChartProgressEvent var44 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-65536), var41, 0, 0);
    org.jfree.chart.title.LegendTitle var45 = var41.getLegend();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var22, (java.lang.Object)var45);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test289"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var2 = var1.getLabelURL();
    var1.configure();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    var5.setTickMarksVisible(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var8);
    var5.setRangeWithMargins((-1.0d), 6.0d);
    var5.configure();
    java.lang.Object var14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
    double var15 = var5.getUpperMargin();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.setForegroundAlpha(1.0f);
    java.awt.Font var20 = var17.getNoDataMessageFont();
    var17.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var17);
    java.awt.Paint var24 = var23.getBackgroundPaint();
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    org.jfree.chart.util.RectangleInsets var27 = var26.getLabelPadding();
    org.jfree.chart.util.UnitType var28 = var27.getUnitType();
    var23.setPadding(var27);
    org.jfree.chart.title.TextTitle var30 = var23.getTitle();
    var30.setHeight(0.08d);
    org.jfree.chart.block.BlockFrame var33 = var30.getFrame();
    org.jfree.data.general.PieDataset var34 = null;
    org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
    org.jfree.chart.util.RectangleInsets var36 = var35.getLabelPadding();
    var35.setSectionOutlinesVisible(true);
    java.awt.Paint var39 = var35.getBaseSectionPaint();
    java.awt.Paint var41 = var35.getSectionPaint((java.lang.Comparable)100.0d);
    org.jfree.chart.urls.PieURLGenerator var42 = null;
    var35.setLegendLabelURLGenerator(var42);
    boolean var44 = var35.isCircular();
    double var45 = var35.getShadowXOffset();
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var47 = var46.getQuadrantOrigin();
    var46.setRangeCrosshairValue(10.0d, true);
    boolean var51 = var46.isDomainZeroBaselineVisible();
    org.jfree.chart.plot.DatasetRenderingOrder var52 = var46.getDatasetRenderingOrder();
    int var53 = var46.getRangeAxisCount();
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var55 = null;
    var54.setFixedLegendItems(var55);
    java.awt.Graphics2D var57 = null;
    java.awt.geom.Rectangle2D var58 = null;
    org.jfree.chart.plot.PlotRenderingInfo var60 = null;
    boolean var61 = var54.render(var57, var58, 10, var60);
    org.jfree.chart.axis.AxisLocation var62 = var54.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var65 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var66 = var65.getUpperMargin();
    var54.setDomainAxis(10, var65, false);
    org.jfree.chart.plot.DefaultDrawingSupplier var69 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var70 = var69.getNextFillPaint();
    var65.setAxisLinePaint(var70);
    var46.setBackgroundPaint(var70);
    var35.setLabelShadowPaint(var70);
    org.jfree.chart.util.RectangleInsets var74 = var35.getInsets();
    var30.setPadding(var74);
    var5.setLabelInsets(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test290"); }


    org.jfree.chart.plot.DefaultDrawingSupplier var0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var1 = var0.getNextFillPaint();
    java.awt.Stroke var2 = var0.getNextOutlineStroke();
    java.awt.Stroke var3 = var0.getNextOutlineStroke();
    java.awt.Paint var4 = var0.getNextOutlinePaint();
    java.awt.Shape var5 = var0.getNextShape();
    java.awt.Paint var6 = var0.getNextPaint();
    java.lang.Object var7 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test291"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.LegendItemCollection var8 = var0.getLegendItems();
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var0.getRangeMarkers((-65536), var10);
    java.awt.Stroke var12 = var0.getDomainZeroBaselineStroke();
    java.awt.Color var16 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var16);
    int var18 = var16.getTransparency();
    var0.setDomainCrosshairPaint((java.awt.Paint)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test292"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var2 = var1.getTickLabelFont();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var4 = var3.clone();
    java.awt.Shape var5 = var3.getLeftArrow();
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Pie 3D Plot");
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var9 = var8.clone();
    java.awt.Shape var10 = var8.getLeftArrow();
    org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity(var10, "Pie 3D Plot");
    var7.setArea(var10);
    var1.setUpArrow(var10);
    var1.resizeRange(1.0d);
    var1.setAutoRangeMinimumSize(0.12d, false);
    boolean var20 = var1.getAutoRangeStickyZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test293"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    var11.setCategoryLabelPositionOffset((-65536));
    java.awt.Paint var18 = null;
    var11.setTickLabelPaint((java.lang.Comparable)"Other", var18);
    org.jfree.chart.JFreeChart var20 = null;
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"Other", var20);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.setForegroundAlpha(1.0f);
    java.awt.Font var26 = var23.getNoDataMessageFont();
    var23.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var23);
    java.awt.Paint var30 = var29.getBackgroundPaint();
    var29.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var32 = var29.getPadding();
    var29.setAntiAlias(true);
    int var35 = var29.getSubtitleCount();
    org.jfree.chart.util.RectangleInsets var36 = var29.getPadding();
    org.jfree.chart.title.LegendTitle var37 = var29.getLegend();
    var21.setChart(var29);
    java.awt.Paint var39 = var29.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test294"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var6 = null;
    var5.datasetChanged(var6);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    java.awt.Paint var9 = var5.getRangeZeroBaselinePaint();
    org.jfree.chart.text.TextLine var10 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var4, var9);
    org.jfree.chart.text.TextFragment var11 = null;
    var10.removeFragment(var11);
    org.jfree.chart.text.TextFragment var13 = var10.getFirstTextFragment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test295"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    var0.setAnchorValue(0.0d);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var19 = var0.getDomainAxisIndex(var18);
    java.awt.Paint var20 = var0.getRangeGridlinePaint();
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.setForegroundAlpha(1.0f);
    java.awt.Paint var24 = var21.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var25 = var21.getRowRenderingOrder();
    java.awt.Color var30 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var30);
    org.jfree.chart.util.HorizontalAlignment var32 = null;
    org.jfree.chart.util.VerticalAlignment var33 = null;
    org.jfree.chart.block.ColumnArrangement var36 = new org.jfree.chart.block.ColumnArrangement(var32, var33, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var39 = null;
    var37.setDomainAxisLocation(1, var39, false);
    java.awt.Stroke var42 = var37.getRangeCrosshairStroke();
    boolean var43 = var36.equals((java.lang.Object)var42);
    java.awt.Color var47 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var48 = null;
    org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var30, var42, (java.awt.Paint)var47, var48, 1.0f);
    org.jfree.chart.event.MarkerChangeListener var51 = null;
    var50.addChangeListener(var51);
    var21.addRangeMarker((org.jfree.chart.plot.Marker)var50);
    org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
    var55.setForegroundAlpha(1.0f);
    java.awt.Font var58 = var55.getNoDataMessageFont();
    var55.setAnchorValue(100.0d);
    org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var62.setMaximumCategoryLabelLines((-1));
    int var65 = var55.getDomainAxisIndex(var62);
    var21.setDomainAxis(100, var62);
    org.jfree.chart.axis.CategoryAxis var69 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var21.setDomainAxis(1, var69, true);
    var0.setDomainAxis(var69);
    org.jfree.chart.axis.ValueAxis var74 = null;
    var0.setRangeAxis(1, var74);
    org.jfree.data.category.CategoryDataset var76 = null;
    var0.setDataset(var76);
    org.jfree.chart.axis.ValueAxis var79 = var0.getRangeAxisForDataset((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var79);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test296"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.lang.Comparable var2 = var1.getAggregatedItemsKey();
    java.lang.String var3 = var1.getPlotType();
    org.jfree.data.category.CategoryDataset var4 = null;
    var1.setDataset(var4);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var9 = null;
    var7.setToolTipGenerator(var9);
    java.awt.Stroke var11 = var7.getBaseSectionOutlineStroke();
    java.awt.Paint var12 = var7.getLabelLinkPaint();
    var1.setAggregatedItemsPaint(var12);
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
    var14.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = var14.getRendererForDataset(var19);
    org.jfree.chart.axis.AxisLocation var22 = var14.getRangeAxisLocation((-65536));
    java.awt.Paint var23 = var14.getRangeZeroBaselinePaint();
    boolean var24 = var1.equals((java.lang.Object)var23);
    org.jfree.chart.event.PlotChangeEvent var25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Other"+ "'", var2.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Multiple Pie Plot"+ "'", var3.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test297"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(1.0d, (-7.0d), (-4.88d), 6.140000000000001d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test298"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearAnnotations();
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    var0.setRenderer(var5);
    org.jfree.chart.axis.AxisLocation var7 = var0.getDomainAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test299"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    var0.setVisible(false);
    var0.resizeRange(0.0d);
    java.awt.Shape var6 = var0.getRightArrow();
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test300"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var3 = var2.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var4 = null;
    var2.setTickUnit(var4, false, true);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var9 = var8.getTickMarkPosition();
    var2.setTickMarkPosition(var9);
    var0.setTickMarkPosition(var9);
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var14 = var13.getQuadrantOrigin();
    var13.mapDatasetToDomainAxis(100, 0);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var20 = var19.getPlotType();
    org.jfree.chart.urls.PieURLGenerator var21 = null;
    var19.setLegendLabelURLGenerator(var21);
    java.awt.Graphics2D var23 = null;
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    org.jfree.chart.util.RectangleInsets var27 = var26.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var28 = null;
    var26.setToolTipGenerator(var28);
    java.awt.Font var30 = var26.getLabelFont();
    org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var30);
    var31.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var37 = var31.getURLText();
    org.jfree.chart.util.VerticalAlignment var38 = var31.getVerticalAlignment();
    java.awt.geom.Rectangle2D var39 = var31.getBounds();
    var19.drawBackgroundImage(var23, var39);
    java.util.List var41 = null;
    var13.drawRangeTickBands(var18, var39, var41);
    org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
    var43.setForegroundAlpha(1.0f);
    java.awt.Paint var46 = var43.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var47 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var43);
    var43.configureRangeAxes();
    org.jfree.chart.util.RectangleEdge var50 = var43.getDomainAxisEdge(0);
    double var51 = var0.valueToJava2D(0.08d, var39, var50);
    boolean var52 = var0.isTickLabelsVisible();
    double var53 = var0.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Pie 3D Plot"+ "'", var20.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test301"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.plot.AbstractPieLabelDistributor var3 = var1.getLabelDistributor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test302"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("PlotOrientation.HORIZONTAL");

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test303"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
    var3.setSectionOutlinesVisible(true);
    java.awt.Paint var7 = var3.getBaseSectionPaint();
    var0.setAxisLinePaint(var7);
    org.jfree.data.Range var9 = var0.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var12 = var11.getTickLabelFont();
    var0.setLabelFont(var12);
    var0.setInverted(false);
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var18 = var17.clone();
    org.jfree.chart.axis.ValueAxis[] var19 = new org.jfree.chart.axis.ValueAxis[] { var17};
    var16.setDomainAxes(var19);
    java.awt.geom.Point2D var21 = var16.getQuadrantOrigin();
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var24 = var23.clone();
    java.awt.Shape var25 = var23.getLeftArrow();
    var0.setRightArrow(var25);
    java.text.NumberFormat var27 = var0.getNumberFormatOverride();
    java.awt.Shape var28 = var0.getUpArrow();
    org.jfree.chart.entity.ChartEntity var30 = new org.jfree.chart.entity.ChartEntity(var28, "Range[0.0,10.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test304"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var5.setLicenceName("hi!");
    java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var12);
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setDomainAxisLocation(1, var21, false);
    java.awt.Stroke var24 = var19.getRangeCrosshairStroke();
    boolean var25 = var18.equals((java.lang.Object)var24);
    java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var30 = null;
    org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var24, (java.awt.Paint)var29, var30, 1.0f);
    java.lang.Object var33 = var32.clone();
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var35 = var34.getQuadrantOrigin();
    var34.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var40 = var34.getRendererForDataset(var39);
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    var42.setForegroundAlpha(1.0f);
    java.awt.Font var45 = var42.getNoDataMessageFont();
    var42.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var42);
    org.jfree.chart.axis.AxisLocation var49 = var42.getDomainAxisLocation();
    var34.setRangeAxisLocation(var49);
    boolean var51 = var32.equals((java.lang.Object)var34);
    boolean var52 = var5.equals((java.lang.Object)var32);
    java.awt.Paint var53 = var32.getPaint();
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
    var54.setForegroundAlpha(1.0f);
    java.awt.Font var57 = var54.getNoDataMessageFont();
    var54.clearAnnotations();
    boolean var59 = var54.isDomainZoomable();
    org.jfree.chart.renderer.category.CategoryItemRenderer var61 = var54.getRenderer(0);
    var32.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var54);
    org.jfree.data.xy.XYDataset var63 = null;
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var65 = var64.clone();
    java.awt.Shape var66 = var64.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var67 = null;
    org.jfree.chart.plot.PolarPlot var68 = new org.jfree.chart.plot.PolarPlot(var63, (org.jfree.chart.axis.ValueAxis)var64, var67);
    org.jfree.chart.renderer.PolarItemRenderer var69 = var68.getRenderer();
    org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var72 = var71.getTickLabelFont();
    org.jfree.data.Range var73 = var68.getDataRange((org.jfree.chart.axis.ValueAxis)var71);
    java.awt.Paint var74 = var68.getAngleLabelPaint();
    java.lang.Object var75 = var68.clone();
    java.awt.Stroke var76 = var68.getAngleGridlineStroke();
    var54.setOutlineStroke(var76);
    var54.clearRangeMarkers((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test305"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
    var3.setSectionOutlinesVisible(true);
    java.awt.Paint var7 = var3.getBaseSectionPaint();
    var0.setAxisLinePaint(var7);
    double var9 = var0.getLowerMargin();
    boolean var10 = var0.isVerticalTickLabels();
    var0.setPositiveArrowVisible(true);
    org.jfree.data.Range var13 = var0.getRange();
    double var14 = var0.getLabelAngle();
    org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var16 = var15.getNextFillPaint();
    java.awt.Stroke var17 = var15.getNextOutlineStroke();
    java.awt.Stroke var18 = var15.getNextStroke();
    java.awt.Shape var19 = var15.getNextShape();
    var0.setUpArrow(var19);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.entity.PieSectionEntity var27 = new org.jfree.chart.entity.PieSectionEntity(var19, var21, 0, 100, (java.lang.Comparable)"VerticalAlignment.CENTER", "Multiple Pie Plot", "0,0,2,-2,2,2,2,2");
    java.lang.String var28 = var27.toString();
    java.lang.String var29 = var27.toString();
    java.lang.String var30 = var27.getToolTipText();
    int var31 = var27.getSectionIndex();
    java.awt.Shape var32 = var27.getArea();
    org.jfree.chart.entity.ChartEntity var33 = new org.jfree.chart.entity.ChartEntity(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "PieSection: 0, 100(VerticalAlignment.CENTER)"+ "'", var28.equals("PieSection: 0, 100(VerticalAlignment.CENTER)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "PieSection: 0, 100(VerticalAlignment.CENTER)"+ "'", var29.equals("PieSection: 0, 100(VerticalAlignment.CENTER)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "Multiple Pie Plot"+ "'", var30.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test306"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    java.awt.Shape var3 = var1.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var11 = var10.clone();
    org.jfree.chart.axis.ValueAxis[] var12 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var9.setDomainAxes(var12);
    java.awt.geom.Point2D var14 = var9.getQuadrantOrigin();
    var5.zoomDomainAxes(0.2d, 2.0d, var8, var14);
    boolean var16 = var5.isAngleGridlinesVisible();
    boolean var17 = var5.isDomainZoomable();
    java.awt.Paint var18 = var5.getAngleGridlinePaint();
    java.awt.Paint var19 = var5.getRadiusGridlinePaint();
    org.jfree.chart.LegendItemCollection var20 = var5.getLegendItems();
    java.awt.Stroke var21 = var5.getRadiusGridlineStroke();
    java.awt.Paint var22 = var5.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test307"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    var0.setRenderer(1, var4);
    org.jfree.chart.util.RectangleEdge var7 = var0.getDomainAxisEdge(10);
    boolean var9 = var0.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var11 = var0.getRangeAxisLocation(0);
    var0.setRangeCrosshairVisible(false);
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var0.drawBackgroundImage(var14, var15);
    java.lang.String var17 = var0.getPlotType();
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var20 = var19.getTickMarkPosition();
    var19.configure();
    var0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var19, false);
    org.jfree.chart.axis.Timeline var24 = null;
    var19.setTimeline(var24);
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var27 = var26.clone();
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var29 = var28.clone();
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
    org.jfree.chart.util.RectangleInsets var32 = var31.getLabelPadding();
    var31.setSectionOutlinesVisible(true);
    java.awt.Paint var35 = var31.getBaseSectionPaint();
    var28.setAxisLinePaint(var35);
    org.jfree.data.Range var37 = var28.getDefaultAutoRange();
    java.lang.String var38 = var37.toString();
    org.jfree.data.Range var40 = org.jfree.data.Range.expandToInclude(var37, 10.0d);
    var26.setRangeWithMargins(var37);
    var19.setRangeWithMargins(var37, true, true);
    org.jfree.chart.axis.DateTickMarkPosition var45 = var19.getTickMarkPosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "XY Plot"+ "'", var17.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "Range[0.0,1.0]"+ "'", var38.equals("Range[0.0,1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test308"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var1 = var0.getPlotType();
    org.jfree.chart.urls.PieURLGenerator var2 = null;
    var0.setLegendLabelURLGenerator(var2);
    java.awt.Graphics2D var4 = null;
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var9 = null;
    var7.setToolTipGenerator(var9);
    java.awt.Font var11 = var7.getLabelFont();
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var11);
    var12.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var18 = var12.getURLText();
    org.jfree.chart.util.VerticalAlignment var19 = var12.getVerticalAlignment();
    java.awt.geom.Rectangle2D var20 = var12.getBounds();
    var0.drawBackgroundImage(var4, var20);
    var0.setShadowYOffset(0.0d);
    var0.setOutlineVisible(true);
    java.awt.Stroke var26 = var0.getLabelOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Pie 3D Plot"+ "'", var1.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test309"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
    var3.setSectionOutlinesVisible(true);
    java.awt.Paint var7 = var3.getBaseSectionPaint();
    var0.setAxisLinePaint(var7);
    org.jfree.data.Range var9 = var0.getDefaultAutoRange();
    java.lang.String var10 = var9.toString();
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var9, 10.0d);
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 106.0d);
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var17 = var16.clone();
    org.jfree.data.Range var18 = var16.getRange();
    var16.setUpperBound(0.0d);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var22 = null;
    var21.setMarkerBand(var22);
    java.awt.Font var24 = var21.getTickLabelFont();
    var21.setTickLabelsVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.axis.ValueAxis)var21, var27);
    org.jfree.data.Range var29 = var21.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint(var14, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "Range[0.0,1.0]"+ "'", var10.equals("Range[0.0,1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test310"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.data.xy.XYDataset var6 = var0.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(100, var8, false);
    java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var24 = null;
    var22.setDomainAxisLocation(1, var24, false);
    java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
    boolean var28 = var21.equals((java.lang.Object)var27);
    java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var33 = null;
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
    java.lang.Object var36 = var35.clone();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var35);
    int var38 = var0.getDatasetCount();
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var41 = var40.getPlotType();
    org.jfree.chart.urls.PieURLGenerator var42 = null;
    var40.setLegendLabelURLGenerator(var42);
    java.awt.Graphics2D var44 = null;
    org.jfree.data.general.PieDataset var46 = null;
    org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot(var46);
    org.jfree.chart.util.RectangleInsets var48 = var47.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var49 = null;
    var47.setToolTipGenerator(var49);
    java.awt.Font var51 = var47.getLabelFont();
    org.jfree.chart.title.TextTitle var52 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var51);
    var52.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var58 = var52.getURLText();
    org.jfree.chart.util.VerticalAlignment var59 = var52.getVerticalAlignment();
    java.awt.geom.Rectangle2D var60 = var52.getBounds();
    var40.drawBackgroundImage(var44, var60);
    org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot();
    var63.setForegroundAlpha(1.0f);
    java.awt.Font var66 = var63.getNoDataMessageFont();
    var63.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var69 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var63);
    org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var72 = var71.clone();
    org.jfree.chart.axis.ValueAxis[] var73 = new org.jfree.chart.axis.ValueAxis[] { var71};
    var70.setDomainAxes(var73);
    org.jfree.chart.renderer.xy.XYItemRenderer var75 = null;
    var70.setRenderer(var75);
    java.awt.Stroke var77 = var70.getRangeCrosshairStroke();
    var69.setBorderStroke(var77);
    java.util.List var79 = var69.getSubtitles();
    var0.drawDomainTickBands(var39, var60, var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "Pie 3D Plot"+ "'", var41.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test311"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     var4.setSectionOutlinesVisible(true);
//     java.awt.Paint var8 = var4.getBaseSectionPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.plot.PiePlotState var11 = var0.initialise(var1, var2, var4, (java.lang.Integer)0, var10);
//     var0.setSeparatorsVisible(true);
//     double var14 = var0.getInnerSeparatorExtension();
//     java.awt.Stroke var15 = var0.getSeparatorStroke();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.setForegroundAlpha(1.0f);
//     java.awt.Font var20 = var17.getNoDataMessageFont();
//     var17.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var17);
//     java.awt.Paint var24 = var23.getBackgroundPaint();
//     var23.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var26 = var23.getPadding();
//     var23.setAntiAlias(true);
//     java.awt.Image var29 = var23.getBackgroundImage();
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var23);
//     double var31 = var0.getInteriorGap();
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     org.jfree.chart.util.RectangleInsets var34 = var33.getLabelPadding();
//     var33.setSectionOutlinesVisible(true);
//     java.awt.Paint var37 = var33.getBaseSectionPaint();
//     java.awt.Paint var39 = var33.getSectionPaint((java.lang.Comparable)100.0d);
//     org.jfree.chart.urls.PieURLGenerator var40 = null;
//     var33.setLegendLabelURLGenerator(var40);
//     boolean var42 = var33.isCircular();
//     double var43 = var33.getShadowXOffset();
//     org.jfree.chart.util.Rotation var44 = var33.getDirection();
//     java.lang.String var45 = var44.toString();
//     var0.setDirection(var44);
//     
//     // Checks the contract:  equals-hashcode on var4 and var33
//     assertTrue("Contract failed: equals-hashcode on var4 and var33", var4.equals(var33) ? var4.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var4
//     assertTrue("Contract failed: equals-hashcode on var33 and var4", var33.equals(var4) ? var33.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test312"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    java.lang.Object var25 = var24.clone();
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var27 = var26.getQuadrantOrigin();
    var26.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = var26.getRendererForDataset(var31);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    var34.setForegroundAlpha(1.0f);
    java.awt.Font var37 = var34.getNoDataMessageFont();
    var34.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var34);
    org.jfree.chart.axis.AxisLocation var41 = var34.getDomainAxisLocation();
    var26.setRangeAxisLocation(var41);
    boolean var43 = var24.equals((java.lang.Object)var26);
    java.awt.Paint var44 = var26.getDomainZeroBaselinePaint();
    java.lang.Object var45 = var26.clone();
    java.awt.Stroke var46 = var26.getRangeZeroBaselineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test313"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    var0.zoomDomainAxes((-1.0d), 3.0d, var3, var5);
    org.jfree.chart.axis.AxisSpace var7 = null;
    var0.setFixedRangeAxisSpace(var7);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
    org.jfree.chart.util.UnitType var12 = var11.getUnitType();
    var0.setAxisOffset(var11);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.plot.MultiplePiePlot var15 = new org.jfree.chart.plot.MultiplePiePlot(var14);
    var15.setAggregatedItemsKey((java.lang.Comparable)0.05d);
    java.awt.Paint var18 = var15.getAggregatedItemsPaint();
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    var20.setForegroundAlpha(1.0f);
    java.awt.Font var23 = var20.getNoDataMessageFont();
    var20.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var20);
    org.jfree.chart.axis.AxisLocation var27 = var20.getDomainAxisLocation();
    java.lang.String var28 = var20.getPlotType();
    var20.mapDatasetToRangeAxis(0, 0);
    java.awt.Paint var32 = var20.getRangeGridlinePaint();
    var15.setAggregatedItemsPaint(var32);
    var0.setRangeGridlinePaint(var32);
    org.jfree.chart.axis.AxisSpace var35 = null;
    var0.setFixedRangeAxisSpace(var35);
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var39 = var38.getTickLabelFont();
    var38.setAutoRange(false);
    java.text.NumberFormat var42 = var38.getNumberFormatOverride();
    org.jfree.chart.axis.TickUnitSource var43 = var38.getStandardTickUnits();
    var38.setVerticalTickLabels(true);
    var38.setTickMarksVisible(false);
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var38);
    org.jfree.chart.util.RectangleEdge var50 = var0.getRangeAxisEdge((-8028032));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "Category Plot"+ "'", var28.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test314"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var2 = var1.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var4 = var3.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var5 = null;
    var3.setTickUnit(var5, false, true);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var10 = var9.getTickMarkPosition();
    var3.setTickMarkPosition(var10);
    var1.setTickMarkPosition(var10);
    var1.setInverted(true);
    org.jfree.chart.axis.DateTickUnit var15 = var1.getTickUnit();
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var16, var17);
    int var19 = var18.getWeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test315"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    var0.clearRangeAxes();
    var0.clearDomainMarkers();
    java.lang.Object var17 = var0.clone();
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var22 = null;
    var20.setDomainAxisLocation(1, var22, false);
    java.awt.Stroke var25 = var20.getRangeCrosshairStroke();
    var20.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.Plot var28 = var20.getRootPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    var20.setRenderer(var29);
    org.jfree.chart.plot.PlotRenderingInfo var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
    var33.setForegroundAlpha(1.0f);
    java.awt.Font var36 = var33.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var37 = null;
    org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
    org.jfree.chart.util.RectangleInsets var39 = var38.getLabelPadding();
    var38.setSectionOutlinesVisible(true);
    java.awt.Paint var42 = var38.getBaseSectionPaint();
    var33.setRangeCrosshairPaint(var42);
    java.lang.Object var44 = var33.clone();
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var48 = null;
    var47.datasetChanged(var48);
    java.awt.Paint var50 = var47.getRangeZeroBaselinePaint();
    var47.setRangeGridlinesVisible(true);
    var47.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.PlotRenderingInfo var56 = null;
    org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var58 = var57.getQuadrantOrigin();
    var47.zoomRangeAxes(0.0d, var56, var58);
    var33.zoomDomainAxes((-1.0d), var46, var58);
    var20.zoomDomainAxes(1.0E-5d, var32, var58, true);
    var0.zoomRangeAxes(3.0d, var19, var58);
    java.awt.Paint var64 = var0.getRangeGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test316"); }


    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.setForegroundAlpha(1.0f);
    java.awt.Font var6 = var3.getNoDataMessageFont();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var8 = null;
    var7.datasetChanged(var8);
    java.awt.Stroke var10 = var7.getOutlineStroke();
    java.awt.Paint var11 = var7.getRangeZeroBaselinePaint();
    org.jfree.chart.text.TextLine var12 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6, var11);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("RectangleConstraintType.RANGE", var6);
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
    var14.mapDatasetToDomainAxis(100, 0);
    java.awt.Paint var19 = var14.getDomainCrosshairPaint();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.text.G2TextMeasurer var22 = new org.jfree.chart.text.G2TextMeasurer(var21);
    org.jfree.chart.text.TextBlock var23 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var19, 10.0f, (org.jfree.chart.text.TextMeasurer)var22);
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.util.Size2D var25 = var23.calculateDimensions(var24);
    org.jfree.data.general.PieDataset var27 = null;
    org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
    org.jfree.chart.util.RectangleInsets var29 = var28.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var30 = null;
    var28.setToolTipGenerator(var30);
    java.awt.Font var32 = var28.getLabelFont();
    org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var32);
    var33.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var33.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var33.setURLText("Range[0.0,1.0]");
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var45 = var44.clone();
    org.jfree.chart.axis.ValueAxis[] var46 = new org.jfree.chart.axis.ValueAxis[] { var44};
    var43.setDomainAxes(var46);
    org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
    var43.setRenderer(var48);
    org.jfree.chart.util.RectangleEdge var51 = var43.getRangeAxisEdge(0);
    var33.setPosition(var51);
    double var53 = var33.getHeight();
    org.jfree.chart.util.HorizontalAlignment var54 = var33.getTextAlignment();
    java.lang.String var55 = var33.getToolTipText();
    org.jfree.chart.util.HorizontalAlignment var56 = var33.getTextAlignment();
    var23.setLineAlignment(var56);
    java.awt.Graphics2D var58 = null;
    org.jfree.chart.text.TextBlockAnchor var61 = null;
    java.awt.Shape var65 = var23.calculateBounds(var58, (-1.0f), 0.0f, var61, 0.0f, 1.0f, 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test317"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    var1.setInverted(true);
    java.awt.Font var6 = var1.getLabelFont();
    org.jfree.data.general.WaferMapDataset var7 = null;
    org.jfree.chart.renderer.WaferMapRenderer var8 = null;
    org.jfree.chart.plot.WaferMapPlot var9 = new org.jfree.chart.plot.WaferMapPlot(var7, var8);
    org.jfree.chart.event.RendererChangeEvent var10 = null;
    var9.rendererChanged(var10);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("Size2D[width=3.0, height=0.0]", var6, (org.jfree.chart.plot.Plot)var9, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test318"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Font var3 = var0.getNoDataMessageFont();
//     var0.setAnchorValue(100.0d);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var6.setDomainAxisLocation(1, var8, false);
//     java.awt.Stroke var11 = var6.getRangeCrosshairStroke();
//     org.jfree.chart.util.Layer var13 = null;
//     java.util.Collection var14 = var6.getRangeMarkers(10, var13);
//     java.util.List var15 = var6.getAnnotations();
//     org.jfree.chart.plot.PlotOrientation var16 = var6.getOrientation();
//     var0.setOrientation(var16);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.setForegroundAlpha(1.0f);
//     org.jfree.chart.axis.AxisSpace var21 = null;
//     var18.setFixedDomainAxisSpace(var21);
//     org.jfree.chart.util.SortOrder var23 = var18.getColumnRenderingOrder();
//     var0.setRowRenderingOrder(var23);
//     var0.clearRangeMarkers();
//     java.util.List var26 = var0.getAnnotations();
//     java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var32 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var31);
//     org.jfree.chart.util.HorizontalAlignment var33 = null;
//     org.jfree.chart.util.VerticalAlignment var34 = null;
//     org.jfree.chart.block.ColumnArrangement var37 = new org.jfree.chart.block.ColumnArrangement(var33, var34, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var40 = null;
//     var38.setDomainAxisLocation(1, var40, false);
//     java.awt.Stroke var43 = var38.getRangeCrosshairStroke();
//     boolean var44 = var37.equals((java.lang.Object)var43);
//     java.awt.Color var48 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var49 = null;
//     org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var31, var43, (java.awt.Paint)var48, var49, 1.0f);
//     float var52 = var51.getAlpha();
//     float var53 = var51.getAlpha();
//     org.jfree.chart.text.TextAnchor var54 = var51.getLabelTextAnchor();
//     boolean var55 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var51);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test319"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
    var3.setSectionOutlinesVisible(true);
    java.awt.Paint var7 = var3.getBaseSectionPaint();
    var0.setAxisLinePaint(var7);
    double var9 = var0.getLowerMargin();
    boolean var10 = var0.isVerticalTickLabels();
    var0.setPositiveArrowVisible(true);
    org.jfree.data.Range var13 = var0.getRange();
    double var14 = var0.getLabelAngle();
    org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var16 = var15.getNextFillPaint();
    java.awt.Stroke var17 = var15.getNextOutlineStroke();
    java.awt.Stroke var18 = var15.getNextStroke();
    java.awt.Shape var19 = var15.getNextShape();
    var0.setUpArrow(var19);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.entity.PieSectionEntity var27 = new org.jfree.chart.entity.PieSectionEntity(var19, var21, 0, 100, (java.lang.Comparable)"VerticalAlignment.CENTER", "Multiple Pie Plot", "0,0,2,-2,2,2,2,2");
    java.lang.String var28 = var27.toString();
    java.lang.Comparable var29 = var27.getSectionKey();
    var27.setSectionKey((java.lang.Comparable)"UnitType.RELATIVE");
    java.lang.String var32 = var27.getShapeCoords();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "PieSection: 0, 100(VerticalAlignment.CENTER)"+ "'", var28.equals("PieSection: 0, 100(VerticalAlignment.CENTER)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "VerticalAlignment.CENTER"+ "'", var29.equals("VerticalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "-3,-3,3,3"+ "'", var32.equals("-3,-3,3,3"));

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test320"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    var0.setRenderer(1, var4);
    org.jfree.chart.util.RectangleEdge var7 = var0.getDomainAxisEdge(10);
    boolean var9 = var0.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var11 = var0.getRangeAxisLocation(0);
    boolean var12 = var0.isDomainCrosshairLockedOnData();
    var0.setDomainZeroBaselineVisible(true);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setForegroundAlpha(1.0f);
    java.awt.Font var19 = var16.getNoDataMessageFont();
    var16.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var16);
    org.jfree.chart.axis.AxisLocation var23 = var16.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var24 = var16.getDomainAxisLocation();
    var0.setRangeAxisLocation(var24);
    var0.clearAnnotations();
    var0.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test321"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var2 = var1.getTickLabelFont();
    var1.setAutoRange(false);
    java.text.NumberFormat var5 = var1.getNumberFormatOverride();
    org.jfree.chart.axis.TickUnitSource var6 = var1.getStandardTickUnits();
    var1.setRangeWithMargins(6.140000000000001d, 9.0d);
    var1.setLabelToolTip("RectangleAnchor.CENTER");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test322"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    java.awt.Shape var3 = var1.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var11 = var10.clone();
    org.jfree.chart.axis.ValueAxis[] var12 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var9.setDomainAxes(var12);
    java.awt.geom.Point2D var14 = var9.getQuadrantOrigin();
    var5.zoomDomainAxes(0.2d, 2.0d, var8, var14);
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
    org.jfree.chart.util.RectangleInsets var18 = var17.getLabelPadding();
    boolean var19 = var17.getLabelLinksVisible();
    java.awt.Stroke var20 = var17.getBaseSectionOutlineStroke();
    var5.setRadiusGridlineStroke(var20);
    org.jfree.chart.axis.ValueAxis var22 = var5.getAxis();
    org.jfree.chart.plot.PlotRenderingInfo var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var30 = var29.getQuadrantOrigin();
    var25.zoomDomainAxes((-1.0d), 3.0d, var28, var30);
    var5.zoomRangeAxes((-1.88d), var24, var30);
    boolean var33 = var5.isAngleLabelsVisible();
    java.awt.Font var34 = var5.getAngleLabelFont();
    org.jfree.chart.renderer.PolarItemRenderer var35 = null;
    var5.setRenderer(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test323"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var1 = var0.getLabelURL();
    var0.resizeRange(10.0d);
    java.awt.Paint var4 = var0.getTickMarkPaint();
    var0.setAutoRange(true);
    var0.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test324"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var5.setInfo("Category Plot");
    var5.addOptionalLibrary("poly");
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.BasicProjectInfo var16 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var16.addOptionalLibrary("");
    var10.addOptionalLibrary((org.jfree.chart.ui.Library)var16);
    var5.addLibrary((org.jfree.chart.ui.Library)var10);
    java.util.List var21 = null;
    var10.setContributors(var21);
    org.jfree.chart.ui.Library var27 = new org.jfree.chart.ui.Library("", "Size2D[width=6.0, height=0.0]", "ChartEntity: tooltip = Pie 3D Plot", "RectangleConstraint[LengthConstraintType.FIXED: width=3.0, height=0.0]");
    var10.addOptionalLibrary(var27);
    java.util.List var29 = var10.getContributors();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test325"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var5 = var4.clone();
    float var6 = var4.getTickMarkInsideLength();
    boolean var7 = var4.isAutoRange();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var9 = var8.clone();
    org.jfree.data.Range var10 = var8.getRange();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var8, var11);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var14 = var13.getLabelURL();
    var13.configure();
    java.awt.Paint var16 = var13.getTickLabelPaint();
    var13.setUpperBound((-7.0d));
    java.awt.Shape var19 = var13.getRightArrow();
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var13, var20);
    org.jfree.chart.renderer.PolarItemRenderer var22 = null;
    org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var8, var22);
    java.awt.Font var24 = var8.getTickLabelFont();
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    org.jfree.chart.util.RectangleInsets var27 = var26.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var28 = null;
    var26.setToolTipGenerator(var28);
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var32 = null;
    var30.setDomainAxisLocation(1, var32, false);
    java.awt.Stroke var35 = var30.getRangeCrosshairStroke();
    var26.setBaseSectionOutlineStroke(var35);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    var37.setForegroundAlpha(1.0f);
    java.awt.Font var40 = var37.getNoDataMessageFont();
    var26.setLabelFont(var40);
    java.awt.Paint var42 = var26.getBaseSectionPaint();
    org.jfree.chart.text.TextBlock var43 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=255,g=0,b=0]", var24, var42);
    org.jfree.chart.util.HorizontalAlignment var44 = var43.getLineAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test326"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    java.awt.geom.Point2D var5 = var0.getQuadrantOrigin();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var7 = var6.getLabelURL();
    var6.resizeRange(10.0d);
    java.awt.Paint var10 = var6.getTickMarkPaint();
    var6.setLowerMargin(2.0d);
    org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var6);
    java.awt.Paint var14 = var6.getLabelPaint();
    boolean var15 = var6.isTickLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test327"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var5.setDomainAxisLocation(1, var7, false);
    java.awt.Stroke var10 = var5.getRangeCrosshairStroke();
    boolean var11 = var4.equals((java.lang.Object)var10);
    org.jfree.chart.block.BlockContainer var12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test328"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    org.jfree.chart.axis.AxisSpace var3 = null;
    var0.setFixedDomainAxisSpace(var3);
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var16.setDomainAxisLocation(1, var18, false);
    java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
    boolean var22 = var15.equals((java.lang.Object)var21);
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var27 = null;
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var9, var21, (java.awt.Paint)var26, var27, 1.0f);
    java.lang.Object var30 = var29.clone();
    org.jfree.chart.util.Layer var31 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var29, var31);
    org.jfree.chart.axis.AxisLocation var33 = var0.getDomainAxisLocation();
    org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test329"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     var4.setSectionOutlinesVisible(true);
//     java.awt.Paint var8 = var4.getBaseSectionPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.plot.PiePlotState var11 = var0.initialise(var1, var2, var4, (java.lang.Integer)0, var10);
//     double var12 = var11.getPieCenterY();
//     java.awt.geom.Rectangle2D var13 = var11.getExplodedPieArea();
//     org.jfree.chart.entity.EntityCollection var14 = var11.getEntityCollection();
//     java.awt.geom.Rectangle2D var15 = var11.getExplodedPieArea();
//     var11.setPieHRadius((-3.0d));
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var19 = var18.getQuadrantOrigin();
//     var18.mapDatasetToDomainAxis(100, 0);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var25 = var24.getPlotType();
//     org.jfree.chart.urls.PieURLGenerator var26 = null;
//     var24.setLegendLabelURLGenerator(var26);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
//     org.jfree.chart.util.RectangleInsets var32 = var31.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var33 = null;
//     var31.setToolTipGenerator(var33);
//     java.awt.Font var35 = var31.getLabelFont();
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var35);
//     var36.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var42 = var36.getURLText();
//     org.jfree.chart.util.VerticalAlignment var43 = var36.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var44 = var36.getBounds();
//     var24.drawBackgroundImage(var28, var44);
//     java.util.List var46 = null;
//     var18.drawRangeTickBands(var23, var44, var46);
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     var49.setForegroundAlpha(1.0f);
//     java.awt.Font var52 = var49.getNoDataMessageFont();
//     var49.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var49);
//     org.jfree.chart.axis.AxisLocation var56 = var49.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var57 = var49.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var58 = null;
//     org.jfree.chart.util.VerticalAlignment var59 = null;
//     org.jfree.chart.block.ColumnArrangement var62 = new org.jfree.chart.block.ColumnArrangement(var58, var59, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var63 = null;
//     org.jfree.chart.util.VerticalAlignment var64 = null;
//     org.jfree.chart.block.ColumnArrangement var67 = new org.jfree.chart.block.ColumnArrangement(var63, var64, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var68 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49, (org.jfree.chart.block.Arrangement)var62, (org.jfree.chart.block.Arrangement)var67);
//     var68.setID("hi!");
//     java.awt.Paint var71 = var68.getBackgroundPaint();
//     org.jfree.chart.util.RectangleAnchor var72 = var68.getLegendItemGraphicAnchor();
//     java.awt.geom.Point2D var73 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var72);
//     var11.setExplodedPieArea(var44);
//     
//     // Checks the contract:  equals-hashcode on var4 and var31
//     assertTrue("Contract failed: equals-hashcode on var4 and var31", var4.equals(var31) ? var4.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var4
//     assertTrue("Contract failed: equals-hashcode on var31 and var4", var31.equals(var4) ? var31.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test330"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var1 = var0.getPlotType();
    java.awt.Paint var2 = var0.getLabelPaint();
    double var3 = var0.getMinimumArcAngleToDraw();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Pie 3D Plot"+ "'", var1.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0E-5d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test331"); }


    org.jfree.chart.PaintMap var0 = new org.jfree.chart.PaintMap();
    java.awt.Paint var2 = var0.getPaint((java.lang.Comparable)100L);
    java.awt.Paint var4 = var0.getPaint((java.lang.Comparable)10);
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var6 = var5.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var7 = null;
    var5.setTickUnit(var7, false, true);
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var12 = var11.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var14 = var13.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var15 = null;
    var13.setTickUnit(var15, false, true);
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var20 = var19.getTickMarkPosition();
    var13.setTickMarkPosition(var20);
    var11.setTickMarkPosition(var20);
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var24 = var23.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var26 = var25.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var27 = null;
    var25.setTickUnit(var27, false, true);
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var32 = var31.getTickMarkPosition();
    var25.setTickMarkPosition(var32);
    var23.setTickMarkPosition(var32);
    var23.setInverted(true);
    org.jfree.chart.axis.DateTickUnit var37 = var23.getTickUnit();
    java.util.Date var38 = var11.calculateHighestVisibleTickValue(var37);
    var5.setTickUnit(var37);
    boolean var40 = var0.containsKey((java.lang.Comparable)var37);
    org.jfree.data.general.PieDataset var41 = null;
    org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot(var41);
    org.jfree.chart.util.RectangleInsets var43 = var42.getLabelPadding();
    boolean var44 = var42.getLabelLinksVisible();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var46 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var42.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var46);
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var50 = null;
    var48.setDomainAxisLocation(1, var50, false);
    java.awt.Stroke var53 = var48.getRangeCrosshairStroke();
    var48.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.LegendItemCollection var56 = var48.getLegendItems();
    java.awt.Color var61 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var62 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var61);
    org.jfree.chart.util.HorizontalAlignment var63 = null;
    org.jfree.chart.util.VerticalAlignment var64 = null;
    org.jfree.chart.block.ColumnArrangement var67 = new org.jfree.chart.block.ColumnArrangement(var63, var64, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var68 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var70 = null;
    var68.setDomainAxisLocation(1, var70, false);
    java.awt.Stroke var73 = var68.getRangeCrosshairStroke();
    boolean var74 = var67.equals((java.lang.Object)var73);
    java.awt.Color var78 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var79 = null;
    org.jfree.chart.plot.ValueMarker var81 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var61, var73, (java.awt.Paint)var78, var79, 1.0f);
    var48.addDomainMarker((org.jfree.chart.plot.Marker)var81);
    java.awt.Stroke var83 = var48.getRangeGridlineStroke();
    var42.setLabelOutlineStroke(var83);
    boolean var85 = var0.equals((java.lang.Object)var83);
    java.awt.Paint var87 = var0.getPaint((java.lang.Comparable)"-3,-3,3,3");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var87);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test332"); }


    org.jfree.chart.ui.Licences var0 = org.jfree.chart.ui.Licences.getInstance();
    java.lang.String var1 = var0.getLGPL();
    java.lang.String var2 = var0.getLGPL();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test333"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var1 = var0.getPlotType();
    var0.setMinimumArcAngleToDraw(0.0d);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var9 = null;
    var7.setDomainAxisLocation(1, var9, false);
    java.awt.Stroke var12 = var7.getRangeCrosshairStroke();
    java.awt.Font var13 = var7.getNoDataMessageFont();
    java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Color var18 = var17.darker();
    org.jfree.chart.text.TextFragment var19 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var13, (java.awt.Paint)var17);
    org.jfree.chart.text.TextLine var20 = new org.jfree.chart.text.TextLine("", var13);
    org.jfree.chart.text.TextLine var21 = new org.jfree.chart.text.TextLine("poly", var13);
    var0.setLabelFont(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Pie 3D Plot"+ "'", var1.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test334"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.lang.Comparable var2 = var1.getAggregatedItemsKey();
    org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]");
    org.jfree.chart.text.TextFragment var5 = var4.getLastTextFragment();
    org.jfree.chart.text.TextFragment var6 = var4.getLastTextFragment();
    boolean var7 = var1.equals((java.lang.Object)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Other"+ "'", var2.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test335"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    var0.setRenderer(1, var4);
    org.jfree.chart.util.RectangleEdge var7 = var0.getDomainAxisEdge(10);
    boolean var9 = var0.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var11 = var0.getRangeAxisLocation(0);
    boolean var12 = var0.isDomainCrosshairLockedOnData();
    var0.setDomainZeroBaselineVisible(true);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setForegroundAlpha(1.0f);
    java.awt.Font var19 = var16.getNoDataMessageFont();
    var16.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var16);
    org.jfree.chart.axis.AxisLocation var23 = var16.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var24 = var16.getDomainAxisLocation();
    var0.setRangeAxisLocation(var24);
    var0.clearAnnotations();
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var29 = null;
    var27.setDomainAxisLocation(1, var29, false);
    java.awt.Stroke var32 = var27.getRangeCrosshairStroke();
    var27.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.LegendItemCollection var35 = var27.getLegendItems();
    var0.setFixedLegendItems(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test336"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var2 = var1.getTickLabelFont();
    var1.setAutoRange(false);
    java.text.NumberFormat var5 = var1.getNumberFormatOverride();
    org.jfree.chart.axis.TickUnitSource var6 = var1.getStandardTickUnits();
    var1.setRangeWithMargins(6.140000000000001d, 9.0d);
    org.jfree.chart.axis.NumberTickUnit var10 = var1.getTickUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test337"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.util.List var12 = null;
    var0.drawRangeTickBands(var10, var11, var12);
    float var14 = var0.getForegroundAlpha();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    java.awt.Graphics2D var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    boolean var22 = var15.render(var18, var19, 10, var21);
    org.jfree.chart.axis.AxisLocation var23 = var15.getDomainAxisLocation();
    var0.setDomainAxisLocation(var23);
    var0.setRangeCrosshairValue((-7.0d));
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var0.clearDomainMarkers((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test338"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(var8);
    org.jfree.chart.axis.ValueAxis var11 = var0.getRangeAxisForDataset(0);
    var0.setRangeCrosshairVisible(true);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var16 = var15.clone();
    float var17 = var15.getTickMarkInsideLength();
    boolean var18 = var15.isAutoRange();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var20 = var19.clone();
    org.jfree.data.Range var21 = var19.getRange();
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.axis.ValueAxis)var19, var22);
    var15.setTickMarksVisible(true);
    int var26 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test339"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.data.xy.XYDataset var6 = var0.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(100, var8, false);
    java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var24 = null;
    var22.setDomainAxisLocation(1, var24, false);
    java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
    boolean var28 = var21.equals((java.lang.Object)var27);
    java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var33 = null;
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
    java.lang.Object var36 = var35.clone();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var35);
    int var38 = var0.getDatasetCount();
    java.awt.Paint var39 = var0.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var40 = null;
    var0.axisChanged(var40);
    java.awt.Paint var42 = null;
    var0.setRangeTickBandPaint(var42);
    org.jfree.chart.annotations.XYAnnotation var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test340"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(var8);
    org.jfree.chart.axis.ValueAxis var11 = var0.getRangeAxisForDataset(0);
    org.jfree.chart.LegendItemCollection var12 = var0.getLegendItems();
    java.lang.Object var13 = var12.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test341"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var13 = var12.clone();
    org.jfree.data.Range var14 = var12.getRange();
    org.jfree.data.Range var15 = org.jfree.data.Range.combine(var10, var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setForegroundAlpha(1.0f);
    java.awt.Paint var19 = var16.getRangeCrosshairPaint();
    boolean var20 = var15.equals((java.lang.Object)var16);
    var16.setDomainGridlinesVisible(false);
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var25 = null;
    var23.setDomainAxisLocation(1, var25, false);
    java.awt.Stroke var28 = var23.getRangeCrosshairStroke();
    var23.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.Plot var31 = var23.getRootPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    var23.setRenderer(var32);
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
    var23.setRangeAxis((org.jfree.chart.axis.ValueAxis)var35);
    org.jfree.data.Range var37 = var16.getDataRange((org.jfree.chart.axis.ValueAxis)var35);
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var39 = var38.clone();
    org.jfree.chart.util.RectangleInsets var40 = var38.getLabelInsets();
    var38.setInverted(true);
    var38.setLabel("Multiple Pie Plot");
    var16.setRangeAxis((org.jfree.chart.axis.ValueAxis)var38);
    org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var47.setCategoryLabelPositionOffset(1);
    var47.setCategoryLabelPositionOffset(0);
    var16.setDomainAxis(var47);
    int var53 = var16.getDatasetCount();
    java.util.List var54 = var16.getCategories();
    org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var56.setCategoryLabelPositionOffset(1);
    var56.setLabelAngle(0.0d);
    int var61 = var16.getDomainAxisIndex(var56);
    java.awt.Stroke var62 = var16.getDomainGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test342"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearDomainMarkers(100);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation();
    boolean var7 = var0.isRangeCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test343"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test344"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    java.awt.Stroke var3 = var0.getOutlineStroke();
    java.awt.Stroke var4 = var0.getDomainZeroBaselineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test345"); }


    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.setForegroundAlpha(1.0f);
    java.awt.Font var7 = var4.getNoDataMessageFont();
    var4.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var13 = var12.clone();
    org.jfree.chart.axis.ValueAxis[] var14 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var11.setDomainAxes(var14);
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    var11.setRenderer(var16);
    java.awt.Stroke var18 = var11.getRangeCrosshairStroke();
    var10.setBorderStroke(var18);
    java.awt.Color var24 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var24);
    org.jfree.chart.util.HorizontalAlignment var26 = null;
    org.jfree.chart.util.VerticalAlignment var27 = null;
    org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var33 = null;
    var31.setDomainAxisLocation(1, var33, false);
    java.awt.Stroke var36 = var31.getRangeCrosshairStroke();
    boolean var37 = var30.equals((java.lang.Object)var36);
    java.awt.Color var41 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var42 = null;
    org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var24, var36, (java.awt.Paint)var41, var42, 1.0f);
    float var45 = var44.getAlpha();
    java.awt.Paint var46 = var44.getLabelPaint();
    java.awt.Paint var47 = var44.getPaint();
    boolean var48 = var10.equals((java.lang.Object)var44);
    var10.fireChartChanged();
    org.jfree.chart.ChartRenderingInfo var53 = null;
    java.awt.image.BufferedImage var54 = var10.createBufferedImage(2, 1, 2, var53);
    org.jfree.chart.ui.ProjectInfo var58 = new org.jfree.chart.ui.ProjectInfo("PieSection: 0, 100(VerticalAlignment.CENTER)", "PlotOrientation.VERTICAL", "Category Plot", (java.awt.Image)var54, "Rotation.CLOCKWISE", "poly", "java.awt.Color[r=255,g=0,b=0]");
    java.util.List var59 = var58.getContributors();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test346"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var4.setMarkerBand(var5);
    org.jfree.data.Range var7 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var4);
    var0.setAnchorValue(0.08d);
    var0.clearRangeAxes();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var12 = var11.clone();
    var11.setVisible(false);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var17 = var16.clone();
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
    org.jfree.chart.util.RectangleInsets var20 = var19.getLabelPadding();
    var19.setSectionOutlinesVisible(true);
    java.awt.Paint var23 = var19.getBaseSectionPaint();
    var16.setAxisLinePaint(var23);
    org.jfree.data.Range var25 = var16.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(100.0d, var25);
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var28 = var27.clone();
    org.jfree.data.Range var29 = var27.getRange();
    org.jfree.data.Range var30 = org.jfree.data.Range.combine(var25, var29);
    var11.setRangeWithMargins(var29);
    int var32 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var11);
    org.jfree.chart.axis.AxisLocation var33 = var0.getDomainAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test347"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    double var10 = var1.getLowerMargin();
    boolean var11 = var1.isVerticalTickLabels();
    var1.setPositiveArrowVisible(true);
    org.jfree.data.Range var14 = var1.getRange();
    org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint(3.0d, var14);
    org.jfree.chart.block.RectangleConstraint var16 = var15.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var17 = var16.toUnconstrainedWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test348"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var13 = var7.getURLText();
    org.jfree.chart.util.VerticalAlignment var14 = var7.getVerticalAlignment();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    var15.setForegroundAlpha(1.0f);
    java.awt.Paint var18 = var15.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var15);
    org.jfree.chart.plot.Plot var20 = var19.getPlot();
    org.jfree.chart.event.ChartChangeEventType var21 = var19.getType();
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var23 = var22.clone();
    double var24 = var22.getLowerBound();
    boolean var25 = var21.equals((java.lang.Object)var22);
    var22.setFixedDimension(5.5d);
    boolean var28 = var14.equals((java.lang.Object)5.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test349"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.data.general.WaferMapDataset var3 = var2.getDataset();
//     java.lang.String var4 = var2.getPlotType();
//     java.lang.String var5 = var2.getPlotType();
//     org.jfree.chart.LegendItemCollection var6 = var2.getLegendItems();
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test350"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    var1.setSectionOutlinesVisible(true);
    java.awt.Paint var5 = var1.getBaseSectionPaint();
    java.awt.Paint var7 = var1.getSectionPaint((java.lang.Comparable)100.0d);
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var1.setLegendLabelURLGenerator(var8);
    boolean var10 = var1.isCircular();
    java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var14);
    var1.setBaseSectionOutlinePaint((java.awt.Paint)var14);
    int var17 = var14.getTransparency();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test351"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    double var4 = var2.calculateBottomOutset(10.0d);
    double var6 = var2.calculateLeftOutset(100.0d);
    double var8 = var2.trimWidth(0.12d);
    double var10 = var2.trimWidth(5.5d);
    double var12 = var2.calculateRightOutset(1.0E-8d);
    double var14 = var2.calculateRightOutset((-7.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-5.88d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.5d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.0d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test352"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    var0.setAnchorValue(100.0d);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var7.setMaximumCategoryLabelLines((-1));
    int var10 = var0.getDomainAxisIndex(var7);
    java.lang.String var12 = var7.getCategoryLabelToolTip((java.lang.Comparable)(-7.0d));
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var14 = var13.getPlotType();
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var16 = null;
    var15.setFixedDomainAxisSpace(var16, true);
    var15.clearDomainMarkers(100);
    var15.setOutlineVisible(true);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var25 = var24.getTickLabelFont();
    var15.setNoDataMessageFont(var25);
    var13.setLabelFont(var25);
    boolean var28 = var7.hasListener((java.util.EventListener)var13);
    org.jfree.chart.labels.PieSectionLabelGenerator var29 = var13.getLabelGenerator();
    var13.setLabelGap(1.0d);
    org.jfree.data.general.PieDataset var32 = null;
    org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
    org.jfree.chart.util.RectangleInsets var34 = var33.getLabelPadding();
    boolean var35 = var33.getLabelLinksVisible();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var37 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var33.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var37);
    java.lang.String var39 = var37.getLabelFormat();
    var13.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var37);
    java.awt.Paint var41 = var13.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "Pie 3D Plot"+ "'", var14.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + ""+ "'", var39.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test353"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var0.setRangeCrosshairPaint(var9);
    boolean var11 = var0.isOutlineVisible();
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var14 = var13.clone();
    java.awt.Shape var15 = var13.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var16 = null;
    org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot(var12, (org.jfree.chart.axis.ValueAxis)var13, var16);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var23 = var22.clone();
    org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var22};
    var21.setDomainAxes(var24);
    java.awt.geom.Point2D var26 = var21.getQuadrantOrigin();
    var17.zoomDomainAxes(0.2d, 2.0d, var20, var26);
    boolean var28 = var17.isAngleGridlinesVisible();
    boolean var29 = var17.isDomainZoomable();
    java.awt.Paint var30 = var17.getAngleGridlinePaint();
    java.awt.Paint var31 = var17.getRadiusGridlinePaint();
    var0.setDomainGridlinePaint(var31);
    var0.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test354"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryLabelPositionOffset(10);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    var1.setUpperMargin(90.0d);
    org.jfree.chart.axis.CategoryLabelPositions var7 = var1.getCategoryLabelPositions();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test355"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    boolean var3 = var1.getLabelLinksVisible();
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var6 = var5.getLabelURL();
    var5.configure();
    java.awt.Paint var8 = var5.getTickLabelPaint();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    var9.setTickMarksVisible(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var9, var12);
    java.awt.Paint var14 = var9.getTickMarkPaint();
    var1.setLabelPaint(var14);
    boolean var16 = var1.getSectionOutlinesVisible();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.setForegroundAlpha(1.0f);
    java.awt.Paint var20 = var17.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var17);
    org.jfree.chart.plot.Plot var22 = var21.getPlot();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    var24.setForegroundAlpha(1.0f);
    java.awt.Font var27 = var24.getNoDataMessageFont();
    var24.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var24);
    java.awt.Paint var31 = var30.getBackgroundPaint();
    org.jfree.data.general.PieDataset var32 = null;
    org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
    org.jfree.chart.util.RectangleInsets var34 = var33.getLabelPadding();
    org.jfree.chart.util.UnitType var35 = var34.getUnitType();
    var30.setPadding(var34);
    var21.setChart(var30);
    var30.setBackgroundImageAlignment(10);
    var30.fireChartChanged();
    java.awt.Paint var41 = var30.getBackgroundPaint();
    var1.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var30);
    org.jfree.chart.title.LegendTitle var44 = var30.getLegend(15);
    java.awt.Image var45 = var30.getBackgroundImage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test356"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var7.setURLText("Range[0.0,1.0]");
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var19 = var18.clone();
    org.jfree.chart.axis.ValueAxis[] var20 = new org.jfree.chart.axis.ValueAxis[] { var18};
    var17.setDomainAxes(var20);
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    var17.setRenderer(var22);
    org.jfree.chart.util.RectangleEdge var25 = var17.getRangeAxisEdge(0);
    var7.setPosition(var25);
    double var27 = var7.getHeight();
    org.jfree.chart.util.HorizontalAlignment var28 = var7.getTextAlignment();
    java.lang.String var29 = var7.getToolTipText();
    org.jfree.chart.util.HorizontalAlignment var30 = var7.getTextAlignment();
    org.jfree.chart.util.VerticalAlignment var31 = null;
    org.jfree.chart.block.FlowArrangement var34 = new org.jfree.chart.block.FlowArrangement(var30, var31, 9.0d, 0.18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test357"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    var0.zoomDomainAxes((-1.0d), 3.0d, var3, var5);
    org.jfree.chart.axis.AxisSpace var7 = null;
    var0.setFixedRangeAxisSpace(var7);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
    org.jfree.chart.util.UnitType var12 = var11.getUnitType();
    var0.setAxisOffset(var11);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.plot.MultiplePiePlot var15 = new org.jfree.chart.plot.MultiplePiePlot(var14);
    var15.setAggregatedItemsKey((java.lang.Comparable)0.05d);
    java.awt.Paint var18 = var15.getAggregatedItemsPaint();
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    var20.setForegroundAlpha(1.0f);
    java.awt.Font var23 = var20.getNoDataMessageFont();
    var20.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var20);
    org.jfree.chart.axis.AxisLocation var27 = var20.getDomainAxisLocation();
    java.lang.String var28 = var20.getPlotType();
    var20.mapDatasetToRangeAxis(0, 0);
    java.awt.Paint var32 = var20.getRangeGridlinePaint();
    var15.setAggregatedItemsPaint(var32);
    var0.setRangeGridlinePaint(var32);
    org.jfree.chart.axis.AxisSpace var35 = null;
    var0.setFixedRangeAxisSpace(var35);
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var39 = var38.getTickLabelFont();
    var38.setAutoRange(false);
    java.text.NumberFormat var42 = var38.getNumberFormatOverride();
    org.jfree.chart.axis.TickUnitSource var43 = var38.getStandardTickUnits();
    var38.setVerticalTickLabels(true);
    var38.setTickMarksVisible(false);
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var38);
    org.jfree.data.category.CategoryDataset var49 = var0.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "Category Plot"+ "'", var28.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test358"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    var1.setSectionOutlinesVisible(true);
    double var7 = var1.getInteriorGap();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    org.jfree.chart.plot.PiePlotState var14 = var1.initialise(var8, var9, (org.jfree.chart.plot.PiePlot)var11, (java.lang.Integer)0, var13);
    var14.setPassesRequired((-8372160));
    double var17 = var14.getPieHRadius();
    org.jfree.chart.entity.EntityCollection var18 = var14.getEntityCollection();
    java.awt.geom.Rectangle2D var19 = var14.getExplodedPieArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test359"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    double var4 = var2.calculateRightOutset(100.0d);
    java.lang.String var5 = var2.toString();
    double var7 = var2.extendHeight(0.0d);
    double var9 = var2.calculateLeftOutset(100.0d);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    org.jfree.chart.util.RectangleInsets var13 = var12.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var14 = null;
    var12.setToolTipGenerator(var14);
    java.awt.Font var16 = var12.getLabelFont();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var16);
    var17.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var23 = var17.getURLText();
    org.jfree.chart.util.VerticalAlignment var24 = var17.getVerticalAlignment();
    java.awt.geom.Rectangle2D var25 = var17.getBounds();
    var2.trim(var25);
    org.jfree.chart.entity.ChartEntity var29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var25, "Size2D[width=0.0, height=0.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test360"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     boolean var7 = var0.render(var3, var4, 10, var6);
//     org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var12 = var11.getUpperMargin();
//     var0.setDomainAxis(10, var11, false);
//     var0.setAnchorValue(0.0d);
//     org.jfree.chart.util.RectangleEdge var18 = var0.getDomainAxisEdge((-65536));
//     org.jfree.chart.util.RectangleEdge var19 = var0.getDomainAxisEdge();
//     var0.setRangeCrosshairVisible(false);
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var24.setMaximumCategoryLabelLines((-1));
//     java.lang.Object var27 = var24.clone();
//     var24.setUpperMargin(3.0d);
//     var0.setDomainAxis(0, var24, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var33 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var32};
//     var0.setRenderers(var33);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var39);
//     org.jfree.chart.util.HorizontalAlignment var41 = null;
//     org.jfree.chart.util.VerticalAlignment var42 = null;
//     org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var48 = null;
//     var46.setDomainAxisLocation(1, var48, false);
//     java.awt.Stroke var51 = var46.getRangeCrosshairStroke();
//     boolean var52 = var45.equals((java.lang.Object)var51);
//     java.awt.Color var56 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var57 = null;
//     org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var39, var51, (java.awt.Paint)var56, var57, 1.0f);
//     java.lang.Object var60 = var59.clone();
//     boolean var61 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var59);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test361"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var1.setDomainAxisLocation(1, var3, false);
    java.awt.Stroke var6 = var1.getRangeCrosshairStroke();
    java.awt.Font var7 = var1.getNoDataMessageFont();
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot(var8);
    java.lang.String var10 = var9.getPlotType();
    java.awt.Paint var11 = var9.getAggregatedItemsPaint();
    double var12 = var9.getLimit();
    double var13 = var9.getLimit();
    java.lang.String var14 = var9.getPlotType();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", var7, (org.jfree.chart.plot.Plot)var9, false);
    java.awt.Paint var17 = var9.getAggregatedItemsPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "Multiple Pie Plot"+ "'", var10.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "Multiple Pie Plot"+ "'", var14.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test362"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var1 = var0.getFirstTextFragment();
    org.jfree.chart.text.TextFragment var2 = var0.getFirstTextFragment();
    org.jfree.chart.text.TextFragment var3 = var0.getLastTextFragment();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D(var4);
    java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
    org.jfree.data.general.PieDataset var7 = null;
    var5.setDataset(var7);
    boolean var9 = var0.equals((java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test363"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var13 = var12.clone();
    org.jfree.data.Range var14 = var12.getRange();
    org.jfree.data.Range var15 = org.jfree.data.Range.combine(var10, var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setForegroundAlpha(1.0f);
    java.awt.Paint var19 = var16.getRangeCrosshairPaint();
    boolean var20 = var15.equals((java.lang.Object)var16);
    var16.setDomainGridlinesVisible(false);
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var25 = null;
    var23.setDomainAxisLocation(1, var25, false);
    java.awt.Stroke var28 = var23.getRangeCrosshairStroke();
    var23.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.Plot var31 = var23.getRootPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    var23.setRenderer(var32);
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
    var23.setRangeAxis((org.jfree.chart.axis.ValueAxis)var35);
    org.jfree.data.Range var37 = var16.getDataRange((org.jfree.chart.axis.ValueAxis)var35);
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
    var40.setForegroundAlpha(1.0f);
    java.awt.Font var43 = var40.getNoDataMessageFont();
    var40.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var40);
    org.jfree.chart.axis.AxisLocation var47 = var40.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var48 = var40.getDomainAxisLocation();
    org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var51 = null;
    var49.setDomainAxisLocation(1, var51, false);
    java.awt.Stroke var54 = var49.getRangeCrosshairStroke();
    org.jfree.chart.util.Layer var56 = null;
    java.util.Collection var57 = var49.getRangeMarkers(10, var56);
    java.util.List var58 = var49.getAnnotations();
    org.jfree.chart.plot.PlotOrientation var59 = var49.getOrientation();
    org.jfree.chart.util.RectangleEdge var60 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var48, var59);
    var16.setRangeAxisLocation(1, var48);
    org.jfree.chart.axis.CategoryAnchor var62 = var16.getDomainGridlinePosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test364"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getRangeMarkers(var5);
    int var7 = var0.getBackgroundImageAlignment();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test365"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearDomainMarkers(100);
    var0.setOutlineVisible(true);
    org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxis(0);
    java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var14);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var23 = null;
    var21.setDomainAxisLocation(1, var23, false);
    java.awt.Stroke var26 = var21.getRangeCrosshairStroke();
    boolean var27 = var20.equals((java.lang.Object)var26);
    java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var32 = null;
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var14, var26, (java.awt.Paint)var31, var32, 1.0f);
    var0.setDomainGridlinePaint((java.awt.Paint)var14);
    java.awt.Color var39 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Color var40 = var39.darker();
    float[] var44 = new float[] { 100.0f, 100.0f, (-1.0f)};
    float[] var45 = var40.getRGBColorComponents(var44);
    float[] var46 = var14.getRGBColorComponents(var44);
    org.jfree.chart.util.ObjectList var48 = new org.jfree.chart.util.ObjectList(100);
    boolean var49 = var14.equals((java.lang.Object)100);
    java.awt.Color var50 = var14.brighter();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test366"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(1.0d, 0.0d, (-7.0d), 0.0d);
    org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var7 = null;
    var6.setFixedDomainAxisSpace(var7, true);
    var6.clearDomainMarkers(100);
    var6.setOutlineVisible(true);
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var16 = var15.getTickLabelFont();
    var6.setNoDataMessageFont(var16);
    var6.setDomainZeroBaselineVisible(true);
    boolean var20 = var4.equals((java.lang.Object)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test367"); }
// 
// 
//     org.jfree.chart.PaintMap var0 = new org.jfree.chart.PaintMap();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var6 = null;
//     var4.setToolTipGenerator(var6);
//     java.awt.Font var8 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var8);
//     var9.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var9.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var9.setWidth((-1.0d));
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var20 = null;
//     var19.datasetChanged(var20);
//     java.awt.Paint var22 = var19.getRangeZeroBaselinePaint();
//     var9.setPaint(var22);
//     var0.put((java.lang.Comparable)' ', var22);
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
//     org.jfree.chart.util.RectangleInsets var28 = var27.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var29 = null;
//     var27.setToolTipGenerator(var29);
//     java.awt.Font var31 = var27.getLabelFont();
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var31);
//     var32.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var32.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var32.setURLText("Range[0.0,1.0]");
//     boolean var42 = var32.getNotify();
//     boolean var43 = var0.equals((java.lang.Object)var42);
//     
//     // Checks the contract:  equals-hashcode on var4 and var27
//     assertTrue("Contract failed: equals-hashcode on var4 and var27", var4.equals(var27) ? var4.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var4
//     assertTrue("Contract failed: equals-hashcode on var27 and var4", var27.equals(var4) ? var27.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test368"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(7.0d);
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.setForegroundAlpha(1.0f);
    java.awt.Paint var5 = var2.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var6 = var2.getRowRenderingOrder();
    java.awt.Color var11 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var11);
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var20 = null;
    var18.setDomainAxisLocation(1, var20, false);
    java.awt.Stroke var23 = var18.getRangeCrosshairStroke();
    boolean var24 = var17.equals((java.lang.Object)var23);
    java.awt.Color var28 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var29 = null;
    org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var11, var23, (java.awt.Paint)var28, var29, 1.0f);
    org.jfree.chart.event.MarkerChangeListener var32 = null;
    var31.addChangeListener(var32);
    var2.addRangeMarker((org.jfree.chart.plot.Marker)var31);
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    var36.setForegroundAlpha(1.0f);
    java.awt.Font var39 = var36.getNoDataMessageFont();
    var36.setAnchorValue(100.0d);
    org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var43.setMaximumCategoryLabelLines((-1));
    int var46 = var36.getDomainAxisIndex(var43);
    var2.setDomainAxis(100, var43);
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setDomainAxis(1, var50, true);
    java.awt.Font var54 = var50.getTickLabelFont((java.lang.Comparable)10.0f);
    boolean var55 = var50.isTickMarksVisible();
    boolean var56 = var1.equals((java.lang.Object)var55);
    java.awt.Paint var57 = var1.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test369"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.lang.Object[][] var1 = var0.getContents();
    java.util.Enumeration var2 = var0.getKeys();
    java.util.Locale var3 = var0.getLocale();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test370"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var3 = var2.getUpperMargin();
//     var2.setCategoryLabelPositionOffset(15);
//     var2.setCategoryLabelPositionOffset(3);
//     java.awt.Font var9 = var2.getTickLabelFont((java.lang.Comparable)"RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.plot.MultiplePiePlot var11 = new org.jfree.chart.plot.MultiplePiePlot(var10);
//     java.lang.Comparable var12 = var11.getAggregatedItemsKey();
//     java.lang.Comparable var13 = var11.getAggregatedItemsKey();
//     var11.setLimit(0.08d);
//     double var16 = var11.getLimit();
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var20 = null;
//     var18.setDomainAxisLocation(1, var20, false);
//     java.awt.Stroke var23 = var18.getRangeCrosshairStroke();
//     java.awt.Font var24 = var18.getNoDataMessageFont();
//     java.awt.Color var28 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Color var29 = var28.darker();
//     org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var24, (java.awt.Paint)var28);
//     float[] var31 = null;
//     float[] var32 = var28.getRGBColorComponents(var31);
//     java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Color var37 = var36.darker();
//     float[] var41 = new float[] { 100.0f, 100.0f, (-1.0f)};
//     float[] var42 = var37.getRGBColorComponents(var41);
//     float[] var43 = var28.getRGBColorComponents(var41);
//     var11.setBackgroundPaint((java.awt.Paint)var28);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     var50.setForegroundAlpha(1.0f);
//     java.awt.Font var53 = var50.getNoDataMessageFont();
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var55 = null;
//     var54.datasetChanged(var55);
//     java.awt.Stroke var57 = var54.getOutlineStroke();
//     java.awt.Paint var58 = var54.getRangeZeroBaselinePaint();
//     org.jfree.chart.text.TextLine var59 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var53, var58);
//     org.jfree.chart.title.TextTitle var60 = new org.jfree.chart.title.TextTitle("RectangleConstraintType.RANGE", var53);
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var62 = var61.getQuadrantOrigin();
//     var61.mapDatasetToDomainAxis(100, 0);
//     java.awt.Paint var66 = var61.getDomainCrosshairPaint();
//     java.awt.Graphics2D var68 = null;
//     org.jfree.chart.text.G2TextMeasurer var69 = new org.jfree.chart.text.G2TextMeasurer(var68);
//     org.jfree.chart.text.TextBlock var70 = org.jfree.chart.text.TextUtilities.createTextBlock("", var53, var66, 10.0f, (org.jfree.chart.text.TextMeasurer)var69);
//     org.jfree.chart.text.TextBlock var71 = org.jfree.chart.text.TextUtilities.createTextBlock("UnitType.ABSOLUTE", var9, (java.awt.Paint)var28, (-1.0f), (-8372160), (org.jfree.chart.text.TextMeasurer)var69);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test371"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.util.List var12 = null;
    var0.drawRangeTickBands(var10, var11, var12);
    float var14 = var0.getForegroundAlpha();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    java.awt.Graphics2D var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    boolean var22 = var15.render(var18, var19, 10, var21);
    org.jfree.chart.axis.AxisLocation var23 = var15.getDomainAxisLocation();
    var0.setDomainAxisLocation(var23);
    var0.setRangeCrosshairValue((-7.0d));
    boolean var27 = var0.isDomainZoomable();
    org.jfree.chart.util.Layer var29 = null;
    java.util.Collection var30 = var0.getRangeMarkers(0, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test372"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var10 = null;
    org.jfree.chart.util.VerticalAlignment var11 = null;
    org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
    org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var24 = null;
    var22.setDomainAxisLocation(1, var24, false);
    java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
    var22.setRangeCrosshairLockedOnData(false);
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
    org.jfree.chart.util.RectangleInsets var32 = var31.getLabelPadding();
    var22.setAxisOffset(var32);
    var20.setItemLabelPadding(var32);
    java.awt.Graphics2D var35 = null;
    org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(0.08d, 6.0d);
    org.jfree.chart.util.Size2D var39 = var20.arrange(var35, var38);
    double var40 = var39.getHeight();
    var39.setHeight(0.05d);
    java.lang.Object var43 = var39.clone();
    double var44 = var39.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.05d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test373"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("java.awt.Color[r=255,g=0,b=0]");
    var1.clearCategoryLabelToolTips();
    float var3 = var1.getMaximumCategoryLabelWidthRatio();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var7 = var6.clone();
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
    org.jfree.chart.util.RectangleInsets var10 = var9.getLabelPadding();
    var9.setSectionOutlinesVisible(true);
    java.awt.Paint var13 = var9.getBaseSectionPaint();
    var6.setAxisLinePaint(var13);
    org.jfree.data.Range var15 = var6.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var18 = var17.getTickLabelFont();
    var6.setLabelFont(var18);
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
    org.jfree.chart.util.RectangleInsets var22 = var21.getLabelPadding();
    boolean var23 = var21.getLabelLinksVisible();
    org.jfree.chart.plot.DefaultDrawingSupplier var25 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var26 = var25.getNextFillPaint();
    var21.setSectionOutlinePaint((java.lang.Comparable)"UnitType.ABSOLUTE", var26);
    org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("Size2D[width=3.0, height=0.0]", var18, var26, 2.0f);
    var1.setTickLabelPaint((java.lang.Comparable)(-1L), var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

}
