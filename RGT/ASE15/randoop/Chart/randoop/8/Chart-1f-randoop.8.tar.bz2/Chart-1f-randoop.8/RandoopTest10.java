
import junit.framework.*;

public class RandoopTest10 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test1"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    var2.removeAnnotations();
    var2.clearSeriesPaints(false);
    org.jfree.chart.urls.CategoryURLGenerator var7 = var2.getSeriesURLGenerator(100);
    java.awt.Color var11 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    int var12 = var11.getRGB();
    boolean var14 = var11.equals((java.lang.Object)(-1L));
    int var15 = var11.getRGB();
    java.awt.Color var16 = var11.darker();
    var2.setBaseItemLabelPaint((java.awt.Paint)var11, false);
    boolean var19 = var2.getAutoPopulateSeriesPaint();
    java.awt.Paint var20 = var2.getBaseItemLabelPaint();
    java.awt.Color var24 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    int var25 = var24.getRGB();
    java.awt.color.ColorSpace var26 = var24.getColorSpace();
    var2.setBasePaint((java.awt.Paint)var24, true);
    var2.setSeriesCreateEntities(1, (java.lang.Boolean)true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test2"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    java.awt.Paint var6 = var2.getItemLabelPaint((-8), 10, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var2.setBaseToolTipGenerator(var7, false);
    boolean var10 = var2.getAutoPopulateSeriesShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test3"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    var2.removeAnnotations();
    var2.clearSeriesPaints(false);
    org.jfree.chart.urls.CategoryURLGenerator var7 = var2.getSeriesURLGenerator(100);
    java.awt.Color var11 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    int var12 = var11.getRGB();
    boolean var14 = var11.equals((java.lang.Object)(-1L));
    int var15 = var11.getRGB();
    java.awt.Color var16 = var11.darker();
    var2.setBaseItemLabelPaint((java.awt.Paint)var11, false);
    boolean var19 = var2.getAutoPopulateSeriesShape();
    var2.setAutoPopulateSeriesShape(false);
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var29 = var28.getAutoPopulateSeriesOutlinePaint();
    var28.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var34 = var28.getSeriesCreateEntities((-1));
    java.awt.Stroke var35 = var28.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, (org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
    org.jfree.data.category.CategoryDataset var38 = null;
    var36.setDataset(0, var38);
    org.jfree.chart.util.ShadowGenerator var40 = var36.getShadowGenerator();
    org.jfree.chart.plot.Marker var42 = null;
    org.jfree.chart.util.Layer var43 = null;
    boolean var44 = var36.removeDomainMarker(0, var42, var43);
    java.awt.Paint var45 = var36.getRangeZeroBaselinePaint();
    var2.setSeriesFillPaint(0, var45, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test4"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var6 = var5.getAutoPopulateSeriesOutlinePaint();
    var5.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var11 = var5.getSeriesCreateEntities((-1));
    java.awt.Stroke var12 = var5.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.data.category.CategoryDataset var15 = null;
    var13.setDataset(0, var15);
    var13.clearRangeAxes();
    java.awt.geom.Rectangle2D var20 = null;
    org.jfree.chart.RenderingSource var21 = null;
    var13.select((-1.0d), 0.0d, var20, var21);
    var13.mapDatasetToDomainAxis(1, (-8));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test5"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var7 = var6.getAutoPopulateSeriesOutlinePaint();
    var6.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, false);
    java.awt.Shape var13 = var6.lookupLegendShape(1);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var17 = var16.getAutoPopulateSeriesOutlinePaint();
    org.jfree.chart.labels.ItemLabelPosition var19 = null;
    var16.setSeriesPositiveItemLabelPosition(10, var19, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var26 = var25.getAutoPopulateSeriesOutlinePaint();
    var25.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var31 = var25.getSeriesCreateEntities((-1));
    java.awt.Stroke var32 = var25.getBaseOutlineStroke();
    var16.setSeriesStroke(0, var32, true);
    java.awt.Paint var35 = null;
    org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=100]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100]", "", var13, var32, var35);
    org.jfree.data.category.CategoryDataset var37 = null;
    org.jfree.chart.axis.CategoryAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var43 = var42.getAutoPopulateSeriesOutlinePaint();
    var42.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var48 = var42.getSeriesCreateEntities((-1));
    java.awt.Stroke var49 = var42.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, (org.jfree.chart.renderer.category.CategoryItemRenderer)var42);
    org.jfree.data.category.CategoryDataset var52 = null;
    var50.setDataset(0, var52);
    java.awt.Paint var54 = var50.getDomainGridlinePaint();
    org.jfree.data.category.CategoryDataset var55 = var50.getDataset();
    org.jfree.chart.entity.PlotEntity var58 = new org.jfree.chart.entity.PlotEntity(var13, (org.jfree.chart.plot.Plot)var50, "", "org.jfree.chart.event.ChartChangeEvent[source=100]");
    boolean var59 = var50.isDomainPannable();
    org.jfree.chart.plot.DrawingSupplier var60 = var50.getDrawingSupplier();
    java.awt.Graphics2D var61 = null;
    java.awt.geom.Rectangle2D var62 = null;
    org.jfree.chart.plot.PlotRenderingInfo var64 = null;
    org.jfree.chart.plot.CategoryCrosshairState var65 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var66 = var50.render(var61, var62, (-1), var64, var65);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test6"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    var2.removeAnnotations();
    var2.clearSeriesPaints(false);
    org.jfree.chart.urls.CategoryURLGenerator var7 = var2.getSeriesURLGenerator(100);
    java.awt.Color var11 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    int var12 = var11.getRGB();
    boolean var14 = var11.equals((java.lang.Object)(-1L));
    int var15 = var11.getRGB();
    java.awt.Color var16 = var11.darker();
    var2.setBaseItemLabelPaint((java.awt.Paint)var11, false);
    var2.setItemLabelAnchorOffset(1.0d);
    var2.clearSeriesStrokes(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test7"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    var2.removeAnnotations();
    org.jfree.chart.renderer.RenderAttributes var4 = var2.getSelectedItemAttributes();
    java.awt.Paint var5 = var4.getDefaultFillPaint();
    java.awt.Paint var6 = var4.getDefaultPaint();
    java.awt.Stroke var7 = var4.getDefaultOutlineStroke();
    java.awt.Stroke var9 = var4.getSeriesStroke(100);
    java.awt.Stroke var10 = var4.getDefaultOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test8"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    var2.removeAnnotations();
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var2.setSeriesPositiveItemLabelPosition(0, var5, true);
    java.awt.Paint var11 = var2.getItemPaint(10, 0, true);
    var2.setItemLabelAnchorOffset(10.0d);
    java.awt.Stroke var15 = var2.getSeriesStroke((-8));
    var2.setAutoPopulateSeriesPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test9"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var6 = var5.getAutoPopulateSeriesOutlinePaint();
    var5.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var11 = var5.getSeriesCreateEntities((-1));
    java.awt.Stroke var12 = var5.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.data.category.CategoryDataset var15 = null;
    var13.setDataset(0, var15);
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = var13.getRenderer();
    org.jfree.chart.event.RendererChangeEvent var18 = null;
    var13.rendererChanged(var18);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var26 = var25.getAutoPopulateSeriesOutlinePaint();
    var25.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var31 = var25.getSeriesCreateEntities((-1));
    java.awt.Stroke var32 = var25.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    org.jfree.data.category.CategoryDataset var35 = null;
    var33.setDataset(0, var35);
    org.jfree.chart.util.ShadowGenerator var37 = var33.getShadowGenerator();
    java.awt.Paint var38 = var33.getRangeGridlinePaint();
    var13.setNoDataMessagePaint(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test10"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var6 = var5.getAutoPopulateSeriesOutlinePaint();
    var5.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var11 = var5.getSeriesCreateEntities((-1));
    java.awt.Stroke var12 = var5.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.data.category.CategoryDataset var15 = null;
    var13.setDataset(0, var15);
    org.jfree.chart.util.ShadowGenerator var17 = var13.getShadowGenerator();
    var13.setForegroundAlpha(100.0f);
    org.jfree.chart.util.SortOrder var20 = var13.getColumnRenderingOrder();
    org.jfree.chart.plot.PlotOrientation var21 = var13.getOrientation();
    java.lang.String var22 = var21.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "PlotOrientation.VERTICAL"+ "'", var22.equals("PlotOrientation.VERTICAL"));

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test11"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    java.awt.Shape var3 = var2.getBaseShape();
    java.awt.Shape var5 = var2.getSeriesShape((-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    var8.removeAnnotations();
    var8.clearSeriesPaints(false);
    org.jfree.chart.urls.CategoryURLGenerator var13 = var8.getSeriesURLGenerator(100);
    java.awt.Color var17 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    int var18 = var17.getRGB();
    boolean var20 = var17.equals((java.lang.Object)(-1L));
    int var21 = var17.getRGB();
    java.awt.Color var22 = var17.darker();
    var8.setBaseItemLabelPaint((java.awt.Paint)var17, false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var8.getBaseItemLabelGenerator();
    java.awt.Paint var27 = var8.lookupSeriesOutlinePaint((-8));
    var2.setBaseLegendTextPaint(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test12"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    int var5 = var4.getRGB();
    boolean var7 = var4.equals((java.lang.Object)(-1L));
    int var8 = var4.getRGB();
    java.awt.Color var9 = var4.darker();
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("hi!", (java.awt.Paint)var9);
    java.awt.Paint[] var11 = null;
    java.awt.Color var15 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    int var16 = var15.getRGB();
    boolean var18 = var15.equals((java.lang.Object)(-1L));
    java.awt.Color var19 = var15.brighter();
    java.awt.Paint[] var20 = new java.awt.Paint[] { var19};
    java.awt.Color var24 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    int var25 = var24.getRGB();
    boolean var27 = var24.equals((java.lang.Object)(-1L));
    java.awt.Paint[] var28 = new java.awt.Paint[] { var24};
    java.awt.Stroke var29 = null;
    java.awt.Stroke[] var30 = new java.awt.Stroke[] { var29};
    java.awt.Stroke var31 = null;
    java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
    java.awt.Shape var33 = null;
    java.awt.Shape[] var34 = new java.awt.Shape[] { var33};
    org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier(var11, var20, var28, var30, var32, var34);
    java.awt.Shape var36 = var35.getNextShape();
    boolean var37 = var10.equals((java.lang.Object)var35);
    java.awt.Shape var38 = var35.getNextShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test13"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var6 = var5.getAutoPopulateSeriesOutlinePaint();
    var5.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var11 = var5.getSeriesCreateEntities((-1));
    java.awt.Stroke var12 = var5.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.data.category.CategoryDataset var15 = null;
    var13.setDataset(0, var15);
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = var13.getRenderer();
    org.jfree.chart.event.RendererChangeEvent var18 = null;
    var13.rendererChanged(var18);
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("org.jfree.chart.event.ChartChangeEvent[source=100]");
    var13.setDomainAxis(var21);
    double var23 = var21.getLabelAngle();
    java.lang.String var25 = var21.getCategoryLabelToolTip((java.lang.Comparable)0);
    java.awt.Font var26 = var21.getTickLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test14"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("org.jfree.chart.event.ChartChangeEvent[source=100]");
    double var2 = var1.getUpperMargin();
    org.jfree.chart.util.RectangleInsets var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelInsets(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test15"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    java.awt.Paint var6 = var2.getItemLabelPaint((-8), 10, true);
    java.lang.Boolean var8 = var2.getSeriesCreateEntities(1);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var13 = var12.getAutoPopulateSeriesOutlinePaint();
    var12.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, false);
    java.awt.Shape var19 = var12.lookupLegendShape(1);
    var2.setSeriesShape(1, var19);
    org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test16"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    int var5 = var4.getRGB();
    boolean var7 = var4.equals((java.lang.Object)(-1L));
    org.jfree.chart.util.DefaultShadowGenerator var11 = new org.jfree.chart.util.DefaultShadowGenerator(0, var4, 0.0f, 10, 1.0d);
    float var12 = var11.getShadowOpacity();
    int var13 = var11.getShadowSize();
    int var14 = var11.calculateOffsetY();
    double var15 = var11.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-8));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test17"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var6 = var5.getAutoPopulateSeriesOutlinePaint();
    var5.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var11 = var5.getSeriesCreateEntities((-1));
    java.awt.Stroke var12 = var5.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.data.category.CategoryDataset var15 = null;
    var13.setDataset(0, var15);
    org.jfree.chart.util.ShadowGenerator var17 = var13.getShadowGenerator();
    java.awt.Paint var18 = var13.getRangeGridlinePaint();
    var13.clearRangeMarkers();
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var27 = var26.getAutoPopulateSeriesOutlinePaint();
    var26.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var32 = var26.getSeriesCreateEntities((-1));
    java.awt.Stroke var33 = var26.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, (org.jfree.chart.renderer.category.CategoryItemRenderer)var26);
    org.jfree.data.category.CategoryDataset var36 = null;
    var34.setDataset(0, var36);
    java.awt.Paint var38 = var34.getDomainGridlinePaint();
    org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("", var38);
    var13.setRangeZeroBaselinePaint(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test18"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var6 = var5.getAutoPopulateSeriesOutlinePaint();
    var5.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var11 = var5.getSeriesCreateEntities((-1));
    java.awt.Stroke var12 = var5.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.data.category.CategoryDataset var15 = null;
    var13.setDataset(0, var15);
    org.jfree.chart.util.ShadowGenerator var17 = var13.getShadowGenerator();
    java.awt.Paint var18 = var13.getRangeGridlinePaint();
    double var19 = var13.getAnchorValue();
    org.jfree.chart.axis.ValueAxis var20 = null;
    var13.setRangeAxis(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test19"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var6 = var5.getAutoPopulateSeriesOutlinePaint();
    var5.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var11 = var5.getSeriesCreateEntities((-1));
    java.awt.Stroke var12 = var5.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.data.category.CategoryDataset var15 = null;
    var13.setDataset(0, var15);
    org.jfree.chart.util.ShadowGenerator var17 = var13.getShadowGenerator();
    java.awt.Color var22 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    int var23 = var22.getRGB();
    boolean var25 = var22.equals((java.lang.Object)(-1L));
    int var26 = var22.getRGB();
    java.awt.Color var27 = var22.darker();
    org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("hi!", (java.awt.Paint)var27);
    java.awt.Paint var29 = var28.getLinePaint();
    java.awt.Shape var30 = var28.getLine();
    var28.setSeriesIndex(0);
    java.awt.Stroke var33 = var28.getLineStroke();
    var13.setDomainGridlineStroke(var33);
    org.jfree.chart.plot.DatasetRenderingOrder var35 = var13.getDatasetRenderingOrder();
    java.awt.Graphics2D var36 = null;
    java.awt.geom.Rectangle2D var37 = null;
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    org.jfree.chart.plot.CategoryCrosshairState var40 = null;
    boolean var41 = var13.render(var36, var37, 1, var39, var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test20"); }


    org.jfree.data.SelectableValue var2 = new org.jfree.data.SelectableValue((java.lang.Number)(byte)0, true);
    boolean var3 = var2.isSelected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test21"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var3 = var2.getAutoPopulateSeriesOutlinePaint();
    var2.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, false);
    org.jfree.chart.labels.ItemLabelPosition var8 = var2.getBasePositiveItemLabelPosition();
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var2.setSeriesURLGenerator(10, var10, false);
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    var2.setSeriesURLGenerator(0, var14, false);
    boolean var19 = var2.getItemLineVisible(100, 10);
    org.jfree.chart.labels.ItemLabelPosition var20 = var2.getBaseNegativeItemLabelPosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test22"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var6 = var5.getAutoPopulateSeriesOutlinePaint();
    var5.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var11 = var5.getSeriesCreateEntities((-1));
    java.awt.Stroke var12 = var5.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var17 = var16.getAutoPopulateSeriesOutlinePaint();
    var16.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var22 = var16.getSeriesCreateEntities((-1));
    java.awt.Stroke var23 = var16.getBaseOutlineStroke();
    var13.setDomainCrosshairStroke(var23);
    org.jfree.chart.util.SortOrder var25 = var13.getRowRenderingOrder();
    org.jfree.chart.plot.DatasetRenderingOrder var26 = var13.getDatasetRenderingOrder();
    var13.setForegroundAlpha((-1.0f));
    var13.setCrosshairDatasetIndex(100, false);
    java.awt.geom.GeneralPath var32 = null;
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.RenderingSource var34 = null;
    var13.select(var32, var33, var34);
    org.jfree.chart.plot.PlotRenderingInfo var37 = null;
    java.awt.geom.Point2D var38 = null;
    var13.panRangeAxes((-1.0d), var37, var38);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var43 = var42.getAutoPopulateSeriesOutlinePaint();
    var42.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var48 = var42.getSeriesCreateEntities((-1));
    java.awt.Stroke var49 = var42.getBaseOutlineStroke();
    var13.setOutlineStroke(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test23"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    var2.removeAnnotations();
    var2.clearSeriesPaints(false);
    var2.setSeriesShapesFilled(0, (java.lang.Boolean)true);
    java.awt.Shape var10 = var2.lookupLegendShape(0);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("org.jfree.chart.event.ChartChangeEvent[source=100]");
    java.awt.Font var14 = var13.getLabelFont();
    var2.setSeriesItemLabelFont(10, var14, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test24"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var3 = var2.getAutoPopulateSeriesOutlinePaint();
    var2.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.awt.Color var12 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    int var13 = var12.getRGB();
    boolean var15 = var12.equals((java.lang.Object)(-1L));
    org.jfree.chart.util.DefaultShadowGenerator var19 = new org.jfree.chart.util.DefaultShadowGenerator(0, var12, 0.0f, 10, 1.0d);
    float var20 = var19.getShadowOpacity();
    java.awt.Color var21 = var19.getShadowColor();
    java.awt.image.ColorModel var22 = null;
    java.awt.Rectangle var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    java.awt.geom.AffineTransform var25 = null;
    java.awt.RenderingHints var26 = null;
    java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
    var2.setSeriesOutlinePaint(10, (java.awt.Paint)var21, true);
    org.jfree.chart.LegendItemCollection var30 = var2.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test25"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
//     int var5 = var4.getRGB();
//     boolean var7 = var4.equals((java.lang.Object)(-1L));
//     int var8 = var4.getRGB();
//     java.awt.Color var9 = var4.darker();
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("hi!", (java.awt.Paint)var9);
//     java.awt.Paint var11 = var10.getLinePaint();
//     java.awt.Color var15 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
//     var10.setOutlinePaint((java.awt.Paint)var15);
//     org.jfree.chart.util.GradientPaintTransformer var17 = var10.getFillPaintTransformer();
//     var10.setURLText("hi!");
//     java.awt.Color var24 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
//     int var25 = var24.getRGB();
//     boolean var27 = var24.equals((java.lang.Object)(-1L));
//     int var28 = var24.getRGB();
//     java.awt.Color var29 = var24.darker();
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("hi!", (java.awt.Paint)var29);
//     java.awt.Paint var31 = var30.getLinePaint();
//     java.awt.Color var35 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
//     var30.setOutlinePaint((java.awt.Paint)var35);
//     org.jfree.chart.util.GradientPaintTransformer var37 = var30.getFillPaintTransformer();
//     var10.setFillPaintTransformer(var37);
//     
//     // Checks the contract:  equals-hashcode on var10 and var30
//     assertTrue("Contract failed: equals-hashcode on var10 and var30", var10.equals(var30) ? var10.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var10
//     assertTrue("Contract failed: equals-hashcode on var30 and var10", var30.equals(var10) ? var30.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test26"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var7 = var6.getAutoPopulateSeriesOutlinePaint();
    var6.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, false);
    java.awt.Shape var13 = var6.lookupLegendShape(1);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var17 = var16.getAutoPopulateSeriesOutlinePaint();
    org.jfree.chart.labels.ItemLabelPosition var19 = null;
    var16.setSeriesPositiveItemLabelPosition(10, var19, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var26 = var25.getAutoPopulateSeriesOutlinePaint();
    var25.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var31 = var25.getSeriesCreateEntities((-1));
    java.awt.Stroke var32 = var25.getBaseOutlineStroke();
    var16.setSeriesStroke(0, var32, true);
    java.awt.Paint var35 = null;
    org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=100]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100]", "", var13, var32, var35);
    org.jfree.data.category.CategoryDataset var37 = null;
    org.jfree.chart.axis.CategoryAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    boolean var43 = var42.getAutoPopulateSeriesOutlinePaint();
    var42.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    java.lang.Boolean var48 = var42.getSeriesCreateEntities((-1));
    java.awt.Stroke var49 = var42.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, (org.jfree.chart.renderer.category.CategoryItemRenderer)var42);
    org.jfree.data.category.CategoryDataset var52 = null;
    var50.setDataset(0, var52);
    java.awt.Paint var54 = var50.getDomainGridlinePaint();
    org.jfree.data.category.CategoryDataset var55 = var50.getDataset();
    org.jfree.chart.entity.PlotEntity var58 = new org.jfree.chart.entity.PlotEntity(var13, (org.jfree.chart.plot.Plot)var50, "", "org.jfree.chart.event.ChartChangeEvent[source=100]");
    boolean var59 = var50.isDomainPannable();
    org.jfree.chart.plot.DrawingSupplier var60 = var50.getDrawingSupplier();
    var50.setNotify(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

}
