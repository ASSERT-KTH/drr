
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    org.jfree.data.time.SerialDate var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(var0);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("hi!");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.lang.Class var0 = null;
    java.util.Date var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.RegularTimePeriod var3 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var6 = var4.getTimePeriod(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.lang.Object var1 = null;
    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)(-1L), var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(100, 10, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    var4.removeAgedItems(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var4.getValue(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(var0);
//     
//     // Checks the contract:  var1.equals(var1)
//     assertTrue("Contract failed: var1.equals(var1)", var1.equals(var1));
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var4.getValue(2014);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(var0);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var0, var1);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var1);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-460));

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2014, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     java.lang.Object var29 = var28.clone();
//     org.jfree.data.time.RegularTimePeriod var30 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var28.update(var30, (java.lang.Number)1L);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     java.lang.String var5 = var4.getRangeDescription();
//     int var6 = var4.getItemCount();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var7, 10.0d);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-460), 2014, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(10, 0, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    int var2 = var0.compareTo((java.lang.Object)10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var2);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(100, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var7 = null;
    var4.removePropertyChangeListener(var7);
    boolean var9 = var4.isEmpty();
    var4.setKey((java.lang.Comparable)0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.delete(100, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)(short)1);
//     long var3 = var0.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var7 = null;
    var4.removePropertyChangeListener(var7);
    boolean var9 = var4.isEmpty();
    org.jfree.data.time.RegularTimePeriod var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.delete(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var7 = null;
    var4.removePropertyChangeListener(var7);
    boolean var9 = var4.isEmpty();
    java.lang.Number var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.update(100, var11);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, 1, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var30 = var28.getValue(2014);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var15.fireSeriesChanged();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var15.setMaximumItemAge((-1L));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var19 = var4.getTimePeriod(2014);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(10, var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var3, var4);
// 
//   }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     java.lang.Object var29 = var28.clone();
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     long var31 = var30.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var32 = var30.next();
//     long var33 = var32.getMiddleMillisecond();
//     var28.add(var32, (java.lang.Number)2014L);
// 
//   }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.RegularTimePeriod var45 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var46 = var4.getValue(var45);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     java.lang.Object var29 = var28.clone();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var33);
//     var34.removeAgedItems(true);
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var38 = new org.jfree.data.time.Year();
//     long var39 = var38.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var40 = var38.next();
//     org.jfree.data.time.RegularTimePeriod var41 = var38.previous();
//     org.jfree.data.time.Year var42 = new org.jfree.data.time.Year();
//     long var43 = var42.getMiddleMillisecond();
//     int var44 = var38.compareTo((java.lang.Object)var42);
//     org.jfree.data.time.TimeSeries var45 = var34.createCopy((org.jfree.data.time.RegularTimePeriod)var37, (org.jfree.data.time.RegularTimePeriod)var38);
//     var34.setNotify(true);
//     java.util.List var48 = var34.getItems();
//     org.jfree.data.time.TimePeriodFormatException var50 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var51 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)"");
//     org.jfree.data.time.Day var52 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var54 = var34.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var52, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var52, 0.0d);
//     java.lang.Class var60 = null;
//     org.jfree.data.time.TimeSeries var61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var60);
//     var61.removeAgedItems(true);
//     org.jfree.data.time.Year var64 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var65 = new org.jfree.data.time.Year();
//     long var66 = var65.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var67 = var65.next();
//     org.jfree.data.time.RegularTimePeriod var68 = var65.previous();
//     org.jfree.data.time.Year var69 = new org.jfree.data.time.Year();
//     long var70 = var69.getMiddleMillisecond();
//     int var71 = var65.compareTo((java.lang.Object)var69);
//     org.jfree.data.time.TimeSeries var72 = var61.createCopy((org.jfree.data.time.RegularTimePeriod)var64, (org.jfree.data.time.RegularTimePeriod)var65);
//     var61.setNotify(true);
//     java.util.List var75 = var61.getItems();
//     org.jfree.data.time.TimePeriodFormatException var77 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var78 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var61, (java.lang.Object)"");
//     org.jfree.data.time.Day var79 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var81 = var61.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var79, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var83 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var79, 0.0d);
//     int var84 = var56.compareTo((java.lang.Object)var83);
//     var28.add(var56);
// 
//   }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var32);
//     var33.removeAgedItems(true);
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     long var38 = var37.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var39 = var37.next();
//     org.jfree.data.time.RegularTimePeriod var40 = var37.previous();
//     org.jfree.data.time.Year var41 = new org.jfree.data.time.Year();
//     long var42 = var41.getMiddleMillisecond();
//     int var43 = var37.compareTo((java.lang.Object)var41);
//     org.jfree.data.time.TimeSeries var44 = var33.createCopy((org.jfree.data.time.RegularTimePeriod)var36, (org.jfree.data.time.RegularTimePeriod)var37);
//     var33.setNotify(true);
//     java.util.List var47 = var33.getItems();
//     org.jfree.data.time.TimePeriodFormatException var49 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var50 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var33, (java.lang.Object)"");
//     org.jfree.data.time.Day var51 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var53 = var33.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var51, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var51, 0.0d);
//     var28.add(var55, false);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-1), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     java.util.Calendar var7 = null;
//     long var8 = var0.getFirstMillisecond(var7);
// 
//   }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("1-January-2016", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var28);
//     var29.removeAgedItems(true);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var35 = var33.next();
//     org.jfree.data.time.RegularTimePeriod var36 = var33.previous();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     long var38 = var37.getMiddleMillisecond();
//     int var39 = var33.compareTo((java.lang.Object)var37);
//     org.jfree.data.time.TimeSeries var40 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var32, (org.jfree.data.time.RegularTimePeriod)var33);
//     var29.setNotify(true);
//     java.util.List var43 = var29.getItems();
//     org.jfree.data.time.TimePeriodFormatException var45 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var29, (java.lang.Object)"");
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var49 = var29.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var47, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, 0.0d);
//     java.lang.Class var55 = null;
//     org.jfree.data.time.TimeSeries var56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var55);
//     var56.removeAgedItems(true);
//     org.jfree.data.time.Year var59 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var60 = new org.jfree.data.time.Year();
//     long var61 = var60.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var62 = var60.next();
//     org.jfree.data.time.RegularTimePeriod var63 = var60.previous();
//     org.jfree.data.time.Year var64 = new org.jfree.data.time.Year();
//     long var65 = var64.getMiddleMillisecond();
//     int var66 = var60.compareTo((java.lang.Object)var64);
//     org.jfree.data.time.TimeSeries var67 = var56.createCopy((org.jfree.data.time.RegularTimePeriod)var59, (org.jfree.data.time.RegularTimePeriod)var60);
//     var56.setNotify(true);
//     java.util.List var70 = var56.getItems();
//     org.jfree.data.time.TimePeriodFormatException var72 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var73 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var56, (java.lang.Object)"");
//     org.jfree.data.time.Day var74 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var76 = var56.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var74, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var74, 0.0d);
//     int var79 = var51.compareTo((java.lang.Object)var78);
//     var4.add(var51, false);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    var4.removeAgedItems(true);
    var4.setKey((java.lang.Comparable)(byte)1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.update(100, (java.lang.Number)100.0d);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     var4.removeAgedItems(1419162646880L, true);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addDays(1, var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var8 = var5.getFollowingDayOfWeek((-460));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(2147483647, var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var29 = var25.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(1, var6);
//     java.lang.String var8 = var7.toString();
//     java.lang.String var9 = var7.toString();
//     var7.setDescription("1-January-2016");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(100, var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1-January-2016"+ "'", var8.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "1-January-2016"+ "'", var9.equals("1-January-2016"));
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     long var47 = var46.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var48 = var46.next();
//     java.util.Date var49 = var48.getEnd();
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.createInstance(var49);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var50);
//     var4.setKey((java.lang.Comparable)var51);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var54 = var51.getPreviousDayOfWeek((-460));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(2147483647, 1, (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(byte)100, true);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     long var4 = var3.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var5 = var3.next();
//     java.util.Date var6 = var5.getEnd();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addDays(2014, var8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2014, var8);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(2147483647, var1);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getLastMillisecond();
//     int var2 = var0.getMonth();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("3-January-2016", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var10);
//     var11.removeAgedItems(true);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     long var16 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.previous();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     int var21 = var15.compareTo((java.lang.Object)var19);
//     org.jfree.data.time.TimeSeries var22 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var15);
//     var11.setNotify(true);
//     java.util.List var25 = var11.getItems();
//     org.jfree.data.time.TimePeriodFormatException var27 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)"");
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var29, 10.0d);
//     boolean var32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var29);
//     int var33 = var29.getYear();
//     java.util.Date var34 = var29.getEnd();
//     java.util.Calendar var35 = null;
//     long var36 = var29.getFirstMillisecond(var35);
// 
//   }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     java.util.Calendar var25 = null;
//     long var26 = var22.getLastMillisecond(var25);
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getLastMillisecond(var1);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var10);
//     var11.removeAgedItems(true);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     long var16 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.previous();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     int var21 = var15.compareTo((java.lang.Object)var19);
//     org.jfree.data.time.TimeSeries var22 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var15);
//     var11.setNotify(true);
//     java.util.List var25 = var11.getItems();
//     org.jfree.data.time.TimePeriodFormatException var27 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)"");
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var29, 10.0d);
//     boolean var32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var29);
//     java.util.Calendar var33 = null;
//     var29.peg(var33);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var4);
//     var5.removeAgedItems(true);
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     org.jfree.data.time.RegularTimePeriod var12 = var9.previous();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     long var14 = var13.getMiddleMillisecond();
//     int var15 = var9.compareTo((java.lang.Object)var13);
//     org.jfree.data.time.TimeSeries var16 = var5.createCopy((org.jfree.data.time.RegularTimePeriod)var8, (org.jfree.data.time.RegularTimePeriod)var9);
//     long var17 = var9.getSerialIndex();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(0, var9);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2014L);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)(short)1);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     long var4 = var3.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var5 = var3.next();
//     org.jfree.data.time.RegularTimePeriod var6 = var3.previous();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     long var8 = var7.getMiddleMillisecond();
//     int var9 = var3.compareTo((java.lang.Object)var7);
//     int var10 = var0.compareTo((java.lang.Object)var3);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var14);
//     var15.removeAgedItems(true);
//     var15.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var23);
//     var24.removeAgedItems(true);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     long var29 = var28.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var30 = var28.next();
//     org.jfree.data.time.RegularTimePeriod var31 = var28.previous();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     int var34 = var28.compareTo((java.lang.Object)var32);
//     org.jfree.data.time.TimeSeries var35 = var24.createCopy((org.jfree.data.time.RegularTimePeriod)var27, (org.jfree.data.time.RegularTimePeriod)var28);
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     int var38 = var36.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var39 = var15.createCopy((org.jfree.data.time.RegularTimePeriod)var27, (org.jfree.data.time.RegularTimePeriod)var36);
//     var15.setMaximumItemAge(0L);
//     var15.setMaximumItemCount(10);
//     int var44 = var3.compareTo((java.lang.Object)var15);
//     java.util.Calendar var45 = null;
//     var3.peg(var45);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    java.lang.String[] var0 = org.jfree.data.time.SerialDate.getMonths();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("ERROR : Relative To String");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(10, 10, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addDays(1, var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var8 = var5.getNearestDayOfWeek(0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     java.util.Calendar var27 = null;
//     long var28 = var22.getFirstMillisecond(var27);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     java.lang.String var9 = var4.getRangeDescription();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var12 = null;
//     long var13 = var11.getFirstMillisecond(var12);
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var17);
//     var18.removeAgedItems(true);
//     var18.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var26);
//     var27.removeAgedItems(true);
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     long var32 = var31.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var33 = var31.next();
//     org.jfree.data.time.RegularTimePeriod var34 = var31.previous();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     long var36 = var35.getMiddleMillisecond();
//     int var37 = var31.compareTo((java.lang.Object)var35);
//     org.jfree.data.time.TimeSeries var38 = var27.createCopy((org.jfree.data.time.RegularTimePeriod)var30, (org.jfree.data.time.RegularTimePeriod)var31);
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     int var41 = var39.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var42 = var18.createCopy((org.jfree.data.time.RegularTimePeriod)var30, (org.jfree.data.time.RegularTimePeriod)var39);
//     var18.setMaximumItemAge(0L);
//     int var45 = var11.compareTo((java.lang.Object)var18);
//     java.lang.Class var49 = null;
//     org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var49);
//     var50.removeAgedItems(true);
//     org.jfree.data.time.Year var53 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year();
//     long var55 = var54.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var56 = var54.next();
//     org.jfree.data.time.RegularTimePeriod var57 = var54.previous();
//     org.jfree.data.time.Year var58 = new org.jfree.data.time.Year();
//     long var59 = var58.getMiddleMillisecond();
//     int var60 = var54.compareTo((java.lang.Object)var58);
//     org.jfree.data.time.TimeSeries var61 = var50.createCopy((org.jfree.data.time.RegularTimePeriod)var53, (org.jfree.data.time.RegularTimePeriod)var54);
//     boolean var62 = var11.equals((java.lang.Object)var53);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.update((org.jfree.data.time.RegularTimePeriod)var53, (java.lang.Number)1435867199999L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == false);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     long var4 = var3.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var5 = var3.next();
//     java.util.Date var6 = var5.getEnd();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addDays(2014, var8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2014, var9);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-460), 10, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var3, var5);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     java.lang.String var2 = var0.toString();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.util.Collection var19 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var18);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getFirstMillisecond(var2);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var7);
//     var8.removeAgedItems(true);
//     var8.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var16);
//     var17.removeAgedItems(true);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var23 = var21.next();
//     org.jfree.data.time.RegularTimePeriod var24 = var21.previous();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     long var26 = var25.getMiddleMillisecond();
//     int var27 = var21.compareTo((java.lang.Object)var25);
//     org.jfree.data.time.TimeSeries var28 = var17.createCopy((org.jfree.data.time.RegularTimePeriod)var20, (org.jfree.data.time.RegularTimePeriod)var21);
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     int var31 = var29.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var32 = var8.createCopy((org.jfree.data.time.RegularTimePeriod)var20, (org.jfree.data.time.RegularTimePeriod)var29);
//     var8.setMaximumItemAge(0L);
//     int var35 = var1.compareTo((java.lang.Object)var8);
//     java.util.Calendar var36 = null;
//     var1.peg(var36);
//     java.lang.Class var38 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var36, var38);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.util.Calendar var21 = null;
//     long var22 = var19.getFirstMillisecond(var21);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-460), 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     org.jfree.data.time.RegularTimePeriod var29 = var16.previous();
//     long var30 = var16.getFirstMillisecond();
//     java.util.Calendar var31 = null;
//     var16.peg(var31);
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("ERROR : Relative To String");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var30);
//     var31.removeAgedItems(true);
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     long var36 = var35.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var37 = var35.next();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.previous();
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     long var40 = var39.getMiddleMillisecond();
//     int var41 = var35.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.TimeSeries var42 = var31.createCopy((org.jfree.data.time.RegularTimePeriod)var34, (org.jfree.data.time.RegularTimePeriod)var35);
//     var31.setNotify(true);
//     java.util.List var45 = var31.getItems();
//     org.jfree.data.time.TimePeriodFormatException var47 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var48 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var31, (java.lang.Object)"");
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var31.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 0.0d);
//     int var54 = var26.compareTo((java.lang.Object)var53);
//     java.lang.Class var58 = null;
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var58);
//     var59.removeAgedItems(true);
//     org.jfree.data.time.Year var62 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var63 = new org.jfree.data.time.Year();
//     long var64 = var63.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var65 = var63.next();
//     org.jfree.data.time.RegularTimePeriod var66 = var63.previous();
//     org.jfree.data.time.Year var67 = new org.jfree.data.time.Year();
//     long var68 = var67.getMiddleMillisecond();
//     int var69 = var63.compareTo((java.lang.Object)var67);
//     org.jfree.data.time.TimeSeries var70 = var59.createCopy((org.jfree.data.time.RegularTimePeriod)var62, (org.jfree.data.time.RegularTimePeriod)var63);
//     var59.setNotify(true);
//     java.util.List var73 = var59.getItems();
//     int var74 = var53.compareTo((java.lang.Object)var59);
//     var59.setDomainDescription("");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var78 = var59.getValue(1);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 1);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getLastMillisecond(var2);
// 
//   }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.TimeSeries var47 = var44.createCopy(0, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var50 = var44.createCopy(2147483647, 0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var23 = var21.next();
//     java.util.Date var24 = var23.getEnd();
//     var4.delete(var23);
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var29);
//     var30.removeAgedItems(true);
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     long var35 = var34.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var36 = var34.next();
//     org.jfree.data.time.RegularTimePeriod var37 = var34.previous();
//     org.jfree.data.time.Year var38 = new org.jfree.data.time.Year();
//     long var39 = var38.getMiddleMillisecond();
//     int var40 = var34.compareTo((java.lang.Object)var38);
//     org.jfree.data.time.TimeSeries var41 = var30.createCopy((org.jfree.data.time.RegularTimePeriod)var33, (org.jfree.data.time.RegularTimePeriod)var34);
//     var30.setNotify(true);
//     java.util.List var44 = var30.getItems();
//     org.jfree.data.time.TimePeriodFormatException var46 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var47 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var30, (java.lang.Object)"");
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var50 = var30.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var48, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var48, 0.0d);
//     org.jfree.data.time.FixedMillisecond var53 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Calendar var54 = null;
//     long var55 = var53.getFirstMillisecond(var54);
//     boolean var56 = var52.equals((java.lang.Object)var55);
//     var4.add(var52, true);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)(short)1);
//     int var3 = var0.getYear();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(2014, 12, 2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var24 = null;
//     long var25 = var23.getFirstMillisecond(var24);
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var29);
//     var30.removeAgedItems(true);
//     var30.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var38 = null;
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var38);
//     var39.removeAgedItems(true);
//     org.jfree.data.time.Year var42 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var43 = new org.jfree.data.time.Year();
//     long var44 = var43.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var45 = var43.next();
//     org.jfree.data.time.RegularTimePeriod var46 = var43.previous();
//     org.jfree.data.time.Year var47 = new org.jfree.data.time.Year();
//     long var48 = var47.getMiddleMillisecond();
//     int var49 = var43.compareTo((java.lang.Object)var47);
//     org.jfree.data.time.TimeSeries var50 = var39.createCopy((org.jfree.data.time.RegularTimePeriod)var42, (org.jfree.data.time.RegularTimePeriod)var43);
//     org.jfree.data.time.Year var51 = new org.jfree.data.time.Year();
//     int var53 = var51.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var54 = var30.createCopy((org.jfree.data.time.RegularTimePeriod)var42, (org.jfree.data.time.RegularTimePeriod)var51);
//     var30.setMaximumItemAge(0L);
//     int var57 = var23.compareTo((java.lang.Object)var30);
//     java.lang.Class var61 = null;
//     org.jfree.data.time.TimeSeries var62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var61);
//     var62.removeAgedItems(true);
//     org.jfree.data.time.Year var65 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var66 = new org.jfree.data.time.Year();
//     long var67 = var66.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var68 = var66.next();
//     org.jfree.data.time.RegularTimePeriod var69 = var66.previous();
//     org.jfree.data.time.Year var70 = new org.jfree.data.time.Year();
//     long var71 = var70.getMiddleMillisecond();
//     int var72 = var66.compareTo((java.lang.Object)var70);
//     org.jfree.data.time.TimeSeries var73 = var62.createCopy((org.jfree.data.time.RegularTimePeriod)var65, (org.jfree.data.time.RegularTimePeriod)var66);
//     boolean var74 = var23.equals((java.lang.Object)var65);
//     java.util.Calendar var75 = null;
//     var23.peg(var75);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var23, 0.0d);
// 
//   }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     java.lang.Class var29 = var28.getTimePeriodClass();
//     var28.removeAgedItems(1419162646880L, false);
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     java.util.List var9 = var4.getItems();
//     var4.removeAgedItems(0L, false);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("1-January-2016");
//     java.lang.Throwable var2 = null;
//     var1.addSuppressed(var2);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     int var29 = var4.getMaximumItemCount();
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var31 = var30.next();
//     org.jfree.data.time.Year var32 = var30.getYear();
//     java.lang.Number var33 = null;
//     var4.add((org.jfree.data.time.RegularTimePeriod)var30, var33, false);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)2014);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var3 = var1.getDataItem(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addDays(1, var5);
//     java.lang.String var7 = var6.toString();
//     java.lang.String var8 = var6.getDescription();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var10 = var6.getPreviousDayOfWeek(2014);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "1-January-2016"+ "'", var7.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(100, 100, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getLastMillisecond(var3);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("1-January-2016");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(2147483647, var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var10);
//     var11.removeAgedItems(true);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     long var16 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.previous();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     int var21 = var15.compareTo((java.lang.Object)var19);
//     org.jfree.data.time.TimeSeries var22 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var15);
//     var11.setNotify(true);
//     java.util.List var25 = var11.getItems();
//     org.jfree.data.time.TimePeriodFormatException var27 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)"");
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var29, 10.0d);
//     boolean var32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var29);
//     int var33 = var29.getYear();
//     java.util.Calendar var34 = null;
//     var29.peg(var34);
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     int var28 = var22.compareTo((java.lang.Object)(byte)0);
//     java.util.Calendar var29 = null;
//     long var30 = var22.getLastMillisecond(var29);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(1, var6);
//     java.lang.String var8 = var7.toString();
//     java.lang.String var9 = var7.toString();
//     var7.setDescription("1-January-2016");
//     var7.setDescription("3-January-2016");
//     java.lang.String var14 = var7.getDescription();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1-January-2016"+ "'", var8.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "1-January-2016"+ "'", var9.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "3-January-2016"+ "'", var14.equals("3-January-2016"));
// 
//   }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.delete(0, 2147483647);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     java.util.Calendar var27 = null;
//     long var28 = var22.getLastMillisecond(var27);
// 
//   }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("3-January-2016", var1);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(2147483647, 0, 2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (java.lang.Number)(byte)1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var10);
//     var11.removeAgedItems(true);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     long var16 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.previous();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     int var21 = var15.compareTo((java.lang.Object)var19);
//     org.jfree.data.time.TimeSeries var22 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var15);
//     var11.setNotify(true);
//     java.util.List var25 = var11.getItems();
//     org.jfree.data.time.TimePeriodFormatException var27 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)"");
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var29, 10.0d);
//     boolean var32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var29);
//     long var33 = var29.getSerialIndex();
//     java.util.Calendar var34 = null;
//     long var35 = var29.getLastMillisecond(var34);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addDays(1, var5);
//     java.lang.String var7 = var6.toString();
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     long var11 = var10.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var12 = var10.next();
//     java.util.Date var13 = var12.getEnd();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var14);
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addDays(2014, var15);
//     org.jfree.data.time.SerialDate var17 = var6.getEndOfCurrentMonth(var16);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var19 = var16.getNearestDayOfWeek(12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "1-January-2016"+ "'", var7.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

//  public void test148() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("2014", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(100, 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

//  public void test151() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("December 2014", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("Sun Dec 21 03:50:49 PST 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-1), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addDays(1, var5);
//     java.lang.String var7 = var6.toString();
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     long var11 = var10.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var12 = var10.next();
//     java.util.Date var13 = var12.getEnd();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var14);
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addDays(2014, var15);
//     org.jfree.data.time.SerialDate var17 = var6.getEndOfCurrentMonth(var16);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var19 = var17.getPreviousDayOfWeek(100);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "1-January-2016"+ "'", var7.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     long var29 = var16.getMiddleMillisecond();
//     long var30 = var16.getFirstMillisecond();
//     java.util.Calendar var31 = null;
//     long var32 = var16.getFirstMillisecond(var31);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("3-January-2016", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     java.lang.Comparable var5 = var4.getKey();
//     var4.setMaximumItemCount(12);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var11);
//     var12.removeAgedItems(true);
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     long var17 = var16.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var18 = var16.next();
//     org.jfree.data.time.RegularTimePeriod var19 = var16.previous();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     long var21 = var20.getMiddleMillisecond();
//     int var22 = var16.compareTo((java.lang.Object)var20);
//     org.jfree.data.time.TimeSeries var23 = var12.createCopy((org.jfree.data.time.RegularTimePeriod)var15, (org.jfree.data.time.RegularTimePeriod)var16);
//     var12.setNotify(true);
//     java.util.List var26 = var12.getItems();
//     org.jfree.data.time.TimePeriodFormatException var28 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var12, (java.lang.Object)"");
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var30, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.update((org.jfree.data.time.RegularTimePeriod)var30, (java.lang.Number)1404331199999L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + 100L+ "'", var5.equals(100L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("SerialDate.weekInMonthToString(): invalid code.");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var3);
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var3, var6);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var4);
//     var5.removeAgedItems(true);
//     var5.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     long var11 = var10.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var12 = var10.next();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var5.addOrUpdate(var12, 1.0d);
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var19);
//     var20.removeAgedItems(true);
//     var20.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var28);
//     var29.removeAgedItems(true);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var35 = var33.next();
//     org.jfree.data.time.RegularTimePeriod var36 = var33.previous();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     long var38 = var37.getMiddleMillisecond();
//     int var39 = var33.compareTo((java.lang.Object)var37);
//     org.jfree.data.time.TimeSeries var40 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var32, (org.jfree.data.time.RegularTimePeriod)var33);
//     org.jfree.data.time.Year var41 = new org.jfree.data.time.Year();
//     int var43 = var41.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var44 = var20.createCopy((org.jfree.data.time.RegularTimePeriod)var32, (org.jfree.data.time.RegularTimePeriod)var41);
//     org.jfree.data.time.TimeSeries var45 = var5.addAndOrUpdate(var20);
//     org.jfree.data.time.Year var47 = new org.jfree.data.time.Year();
//     long var48 = var47.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var49 = var47.next();
//     java.util.Date var50 = var49.getEnd();
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(var50);
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var51);
//     var5.setKey((java.lang.Comparable)var52);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2014, var52);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)(short)1);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     long var4 = var3.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var5 = var3.next();
//     org.jfree.data.time.RegularTimePeriod var6 = var3.previous();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     long var8 = var7.getMiddleMillisecond();
//     int var9 = var3.compareTo((java.lang.Object)var7);
//     int var10 = var0.compareTo((java.lang.Object)var3);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var14);
//     var15.removeAgedItems(true);
//     var15.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var23);
//     var24.removeAgedItems(true);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     long var29 = var28.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var30 = var28.next();
//     org.jfree.data.time.RegularTimePeriod var31 = var28.previous();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     int var34 = var28.compareTo((java.lang.Object)var32);
//     org.jfree.data.time.TimeSeries var35 = var24.createCopy((org.jfree.data.time.RegularTimePeriod)var27, (org.jfree.data.time.RegularTimePeriod)var28);
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     int var38 = var36.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var39 = var15.createCopy((org.jfree.data.time.RegularTimePeriod)var27, (org.jfree.data.time.RegularTimePeriod)var36);
//     var15.setMaximumItemAge(0L);
//     var15.setMaximumItemCount(10);
//     int var44 = var3.compareTo((java.lang.Object)var15);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var46 = var15.getValue(1);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     long var30 = var29.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var31 = var29.next();
//     org.jfree.data.time.RegularTimePeriod var32 = var29.previous();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     int var35 = var29.compareTo((java.lang.Object)var33);
//     java.lang.Class var39 = null;
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var39);
//     var40.removeAgedItems(true);
//     org.jfree.data.time.Year var43 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var44 = new org.jfree.data.time.Year();
//     long var45 = var44.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var46 = var44.next();
//     org.jfree.data.time.RegularTimePeriod var47 = var44.previous();
//     org.jfree.data.time.Year var48 = new org.jfree.data.time.Year();
//     long var49 = var48.getMiddleMillisecond();
//     int var50 = var44.compareTo((java.lang.Object)var48);
//     org.jfree.data.time.TimeSeries var51 = var40.createCopy((org.jfree.data.time.RegularTimePeriod)var43, (org.jfree.data.time.RegularTimePeriod)var44);
//     var40.setNotify(true);
//     java.util.List var54 = var40.getItems();
//     org.jfree.data.time.TimePeriodFormatException var56 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var57 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var40, (java.lang.Object)"");
//     org.jfree.data.time.Day var58 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var60 = var40.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var58, 10.0d);
//     boolean var61 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var29, (java.lang.Object)var58);
//     int var62 = var58.getYear();
//     int var63 = var58.getYear();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var58, (java.lang.Number)(-1.0f));
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var7 = null;
    var4.removePropertyChangeListener(var7);
    java.util.List var9 = var4.getItems();
    var4.setRangeDescription("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var13 = var4.getTimePeriod(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(1, var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(12, var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(1, 0, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var3);
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var3, var6);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("31-December-2015");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Sun Dec 21 03:50:49 PST 2014", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getLastMillisecond();
//     int var2 = var0.getMonth();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     long var4 = var0.getSerialIndex();
//     java.util.Calendar var5 = null;
//     long var6 = var0.getMiddleMillisecond(var5);
// 
//   }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(1, var6);
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.next();
//     java.util.Date var14 = var13.getEnd();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var15);
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addDays(2014, var16);
//     org.jfree.data.time.SerialDate var18 = var7.getEndOfCurrentMonth(var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2147483647, var17);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1-January-2016"+ "'", var8.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.TimeSeries var47 = var44.createCopy(0, 100);
//     java.util.List var48 = var47.getItems();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.util.Collection var49 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var48);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("21-December-2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var32);
//     var33.removeAgedItems(true);
//     var33.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var41);
//     var42.removeAgedItems(true);
//     org.jfree.data.time.Year var45 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     long var47 = var46.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var48 = var46.next();
//     org.jfree.data.time.RegularTimePeriod var49 = var46.previous();
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year();
//     long var51 = var50.getMiddleMillisecond();
//     int var52 = var46.compareTo((java.lang.Object)var50);
//     org.jfree.data.time.TimeSeries var53 = var42.createCopy((org.jfree.data.time.RegularTimePeriod)var45, (org.jfree.data.time.RegularTimePeriod)var46);
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year();
//     int var56 = var54.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var57 = var33.createCopy((org.jfree.data.time.RegularTimePeriod)var45, (org.jfree.data.time.RegularTimePeriod)var54);
//     java.lang.Object var58 = var57.clone();
//     boolean var59 = var4.equals((java.lang.Object)var57);
//     java.lang.Class var63 = null;
//     org.jfree.data.time.TimeSeries var64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var63);
//     var64.removeAgedItems(true);
//     java.beans.PropertyChangeListener var67 = null;
//     var64.removePropertyChangeListener(var67);
//     boolean var69 = var64.isEmpty();
//     var64.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var72 = new org.jfree.data.time.Day();
//     boolean var74 = var72.equals((java.lang.Object)(short)1);
//     int var75 = var72.getYear();
//     org.jfree.data.time.RegularTimePeriod var76 = var72.previous();
//     org.jfree.data.time.TimeSeriesDataItem var78 = var64.addOrUpdate(var76, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var79 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var80 = var64.getDataItem((org.jfree.data.time.RegularTimePeriod)var79);
//     java.lang.Class var84 = null;
//     org.jfree.data.time.TimeSeries var85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var84);
//     var85.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var88 = var64.addAndOrUpdate(var85);
//     org.jfree.data.time.Year var89 = new org.jfree.data.time.Year();
//     long var90 = var89.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var91 = var89.next();
//     org.jfree.data.time.RegularTimePeriod var92 = var89.previous();
//     long var93 = var89.getLastMillisecond();
//     var85.delete((org.jfree.data.time.RegularTimePeriod)var89);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var57.update((org.jfree.data.time.RegularTimePeriod)var89, (java.lang.Number)(byte)1);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == 1420099199999L);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("3-January-2016");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var4);
//     var5.removeAgedItems(true);
//     var5.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var13);
//     var14.removeAgedItems(true);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     long var19 = var18.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var20 = var18.next();
//     org.jfree.data.time.RegularTimePeriod var21 = var18.previous();
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     long var23 = var22.getMiddleMillisecond();
//     int var24 = var18.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var25 = var14.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var18);
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     int var28 = var26.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var29 = var5.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var26);
//     long var30 = var17.getMiddleMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var31 = new org.jfree.data.time.Month(2014, var17);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1404331199999L);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     var4.setMaximumItemAge(0L);
//     var4.setMaximumItemCount(10);
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var35 = var33.next();
//     org.jfree.data.time.TimeSeriesDataItem var37 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)1420099199999L);
//     java.util.Calendar var38 = null;
//     long var39 = var33.getFirstMillisecond(var38);
// 
//   }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getLastMillisecond(var2);
// 
//   }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var30 = var25.getTimePeriod(1);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var30);
//     var31.removeAgedItems(true);
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     long var36 = var35.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var37 = var35.next();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.previous();
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     long var40 = var39.getMiddleMillisecond();
//     int var41 = var35.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.TimeSeries var42 = var31.createCopy((org.jfree.data.time.RegularTimePeriod)var34, (org.jfree.data.time.RegularTimePeriod)var35);
//     var31.setNotify(true);
//     java.util.List var45 = var31.getItems();
//     org.jfree.data.time.TimePeriodFormatException var47 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var48 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var31, (java.lang.Object)"");
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var31.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 0.0d);
//     int var54 = var26.compareTo((java.lang.Object)var53);
//     java.lang.Class var58 = null;
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var58);
//     var59.removeAgedItems(true);
//     org.jfree.data.time.Year var62 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var63 = new org.jfree.data.time.Year();
//     long var64 = var63.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var65 = var63.next();
//     org.jfree.data.time.RegularTimePeriod var66 = var63.previous();
//     org.jfree.data.time.Year var67 = new org.jfree.data.time.Year();
//     long var68 = var67.getMiddleMillisecond();
//     int var69 = var63.compareTo((java.lang.Object)var67);
//     org.jfree.data.time.TimeSeries var70 = var59.createCopy((org.jfree.data.time.RegularTimePeriod)var62, (org.jfree.data.time.RegularTimePeriod)var63);
//     var59.setNotify(true);
//     java.util.List var73 = var59.getItems();
//     int var74 = var53.compareTo((java.lang.Object)var59);
//     org.jfree.data.time.TimeSeries var75 = null;
//     java.util.Collection var76 = var59.getTimePeriodsUniqueToOtherSeries(var75);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    var4.removeAgedItems(true);
    var4.setKey((java.lang.Comparable)(byte)1);
    int var9 = var4.getMaximumItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.delete(2147483647, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2147483647);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var7 = null;
    var4.removePropertyChangeListener(var7);
    java.util.List var9 = var4.getItems();
    var4.setKey((java.lang.Comparable)100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(1, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Jan"+ "'", var2.equals("Jan"));

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(0, 0, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     java.lang.Class var45 = var44.getTimePeriodClass();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     long var47 = var46.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var48 = var46.next();
//     org.jfree.data.time.RegularTimePeriod var49 = var46.previous();
//     var44.add(var49, (java.lang.Number)0, true);
// 
//   }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     long var7 = var0.getSerialIndex();
//     int var9 = var0.compareTo((java.lang.Object)1435867199999L);
//     java.util.Calendar var10 = null;
//     long var11 = var0.getLastMillisecond(var10);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Wed Dec 31 16:00:00 PST 1969", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#');
    boolean var2 = var1.getNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update(0, (java.lang.Number)10L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "December"+ "'", var1.equals("December"));

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.TimeSeries var47 = var44.createCopy(0, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var48 = var47.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
// 
//   }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     java.util.Calendar var27 = null;
//     var22.peg(var27);
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var3);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, "1-January-2016", "hi!", var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var11 = var9.getFollowingDayOfWeek(10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(12, 0, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     org.jfree.data.time.RegularTimePeriod var29 = var16.previous();
//     java.util.Calendar var30 = null;
//     long var31 = var16.getFirstMillisecond(var30);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var3, var4);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     java.lang.String var29 = var28.getDescription();
//     org.jfree.data.time.TimeSeries var32 = var28.createCopy(0, 0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var34 = var28.getDataItem(0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var10);
//     var11.removeAgedItems(true);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     long var16 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.previous();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     int var21 = var15.compareTo((java.lang.Object)var19);
//     org.jfree.data.time.TimeSeries var22 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var15);
//     var11.setNotify(true);
//     java.util.List var25 = var11.getItems();
//     org.jfree.data.time.TimePeriodFormatException var27 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)"");
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var29, 10.0d);
//     boolean var32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var29);
//     int var33 = var29.getYear();
//     java.util.Date var34 = var29.getEnd();
//     java.util.TimeZone var35 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var36 = new org.jfree.data.time.Day(var34, var35);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, var5);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var5);
//     java.lang.String var7 = var6.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var9 = var6.getFollowingDayOfWeek(0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "3-January-2016"+ "'", var7.equals("3-January-2016"));
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Calendar var30 = null;
//     long var31 = var29.getFirstMillisecond(var30);
//     java.util.Calendar var32 = null;
//     long var33 = var29.getFirstMillisecond(var32);
//     java.util.Calendar var34 = null;
//     long var35 = var29.getLastMillisecond(var34);
//     org.jfree.data.time.RegularTimePeriod var36 = var29.next();
//     var25.add((org.jfree.data.time.RegularTimePeriod)var29, 100.0d, true);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.lang.String var3 = var0.toString();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getLastMillisecond(var4);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("31-December-2015", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var30);
//     var31.removeAgedItems(true);
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     long var36 = var35.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var37 = var35.next();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.previous();
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     long var40 = var39.getMiddleMillisecond();
//     int var41 = var35.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.TimeSeries var42 = var31.createCopy((org.jfree.data.time.RegularTimePeriod)var34, (org.jfree.data.time.RegularTimePeriod)var35);
//     var31.setNotify(true);
//     java.util.List var45 = var31.getItems();
//     org.jfree.data.time.TimePeriodFormatException var47 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var48 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var31, (java.lang.Object)"");
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var31.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 0.0d);
//     int var54 = var26.compareTo((java.lang.Object)var53);
//     java.lang.Class var58 = null;
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var58);
//     var59.removeAgedItems(true);
//     org.jfree.data.time.Year var62 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var63 = new org.jfree.data.time.Year();
//     long var64 = var63.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var65 = var63.next();
//     org.jfree.data.time.RegularTimePeriod var66 = var63.previous();
//     org.jfree.data.time.Year var67 = new org.jfree.data.time.Year();
//     long var68 = var67.getMiddleMillisecond();
//     int var69 = var63.compareTo((java.lang.Object)var67);
//     org.jfree.data.time.TimeSeries var70 = var59.createCopy((org.jfree.data.time.RegularTimePeriod)var62, (org.jfree.data.time.RegularTimePeriod)var63);
//     var59.setNotify(true);
//     java.util.List var73 = var59.getItems();
//     int var74 = var53.compareTo((java.lang.Object)var59);
//     org.jfree.data.time.FixedMillisecond var76 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var77 = null;
//     var76.peg(var77);
//     org.jfree.data.time.TimeSeriesDataItem var80 = var59.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var76, 0.0d);
//     var59.clear();
//     var59.fireSeriesChanged();
//     boolean var83 = var59.getNotify();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == true);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2147483647);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, "1-January-2016", "December 2014", var6);
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     long var9 = var8.getLastMillisecond();
//     int var10 = var8.getMonth();
//     long var11 = var8.getLastMillisecond();
//     java.lang.String var12 = var8.toString();
//     var7.add((org.jfree.data.time.RegularTimePeriod)var8, 10.0d, false);
// 
//   }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var10);
//     var11.removeAgedItems(true);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     long var16 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.previous();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     int var21 = var15.compareTo((java.lang.Object)var19);
//     org.jfree.data.time.TimeSeries var22 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var15);
//     var11.setNotify(true);
//     java.util.List var25 = var11.getItems();
//     org.jfree.data.time.TimePeriodFormatException var27 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)"");
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var29, 10.0d);
//     boolean var32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var29);
//     java.util.Calendar var33 = null;
//     long var34 = var29.getLastMillisecond(var33);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Sun Dec 21 03:50:49 PST 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var4.removeChangeListener(var16);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var21);
//     var22.removeAgedItems(true);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     long var27 = var26.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var28 = var26.next();
//     org.jfree.data.time.RegularTimePeriod var29 = var26.previous();
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     long var31 = var30.getMiddleMillisecond();
//     int var32 = var26.compareTo((java.lang.Object)var30);
//     org.jfree.data.time.TimeSeries var33 = var22.createCopy((org.jfree.data.time.RegularTimePeriod)var25, (org.jfree.data.time.RegularTimePeriod)var26);
//     var22.setNotify(true);
//     java.util.List var36 = var22.getItems();
//     org.jfree.data.time.TimePeriodFormatException var38 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var22, (java.lang.Object)"");
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     long var41 = var40.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var42 = var40.next();
//     org.jfree.data.time.RegularTimePeriod var43 = var40.previous();
//     org.jfree.data.time.Year var44 = new org.jfree.data.time.Year();
//     long var45 = var44.getMiddleMillisecond();
//     int var46 = var40.compareTo((java.lang.Object)var44);
//     org.jfree.data.time.RegularTimePeriod var47 = var44.next();
//     long var48 = var44.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var49 = var22.getDataItem((org.jfree.data.time.RegularTimePeriod)var44);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var44, (java.lang.Number)1419148800000L, false);
// 
//   }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     int var2 = var0.getMonth();
//     long var3 = var0.getSerialIndex();
//     int var5 = var0.compareTo((java.lang.Object)(short)100);
//     org.jfree.data.time.Year var6 = var0.getYear();
//     java.util.Calendar var7 = null;
//     long var8 = var0.getLastMillisecond(var7);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("ERROR : Relative To String");

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(100, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     long var16 = var7.getLastMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var16);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1420099199999L);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var3 = var1.getTimePeriod(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     java.lang.String var17 = var16.toString();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var16);
//     java.util.Collection var19 = var4.getTimePeriods();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month();
//     long var21 = var20.getFirstMillisecond();
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var24 = null;
//     var23.peg(var24);
//     int var26 = var20.compareTo((java.lang.Object)var24);
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var30);
//     var31.removeAgedItems(true);
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     long var36 = var35.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var37 = var35.next();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.previous();
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     long var40 = var39.getMiddleMillisecond();
//     int var41 = var35.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.TimeSeries var42 = var31.createCopy((org.jfree.data.time.RegularTimePeriod)var34, (org.jfree.data.time.RegularTimePeriod)var35);
//     var31.setNotify(true);
//     java.util.List var45 = var31.getItems();
//     org.jfree.data.time.TimePeriodFormatException var47 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var48 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var31, (java.lang.Object)"");
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var31.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 0.0d);
//     org.jfree.data.time.FixedMillisecond var54 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Calendar var55 = null;
//     long var56 = var54.getFirstMillisecond(var55);
//     boolean var57 = var53.equals((java.lang.Object)var56);
//     java.lang.Object var58 = var53.clone();
//     int var59 = var20.compareTo((java.lang.Object)var53);
//     var4.add(var53, false);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     java.util.Calendar var16 = null;
//     var8.peg(var16);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10, 100, 12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)(short)1);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     long var4 = var3.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var5 = var3.next();
//     org.jfree.data.time.RegularTimePeriod var6 = var3.previous();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     long var8 = var7.getMiddleMillisecond();
//     int var9 = var3.compareTo((java.lang.Object)var7);
//     int var10 = var0.compareTo((java.lang.Object)var3);
//     org.jfree.data.time.RegularTimePeriod var11 = var0.next();
//     long var12 = var0.getSerialIndex();
//     java.util.Calendar var13 = null;
//     long var14 = var0.getFirstMillisecond(var13);
// 
//   }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var23 = var21.next();
//     java.util.Date var24 = var23.getEnd();
//     var4.delete(var23);
//     java.lang.Object var26 = var4.clone();
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var30);
//     var31.removeAgedItems(true);
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     long var36 = var35.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var37 = var35.next();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.previous();
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     long var40 = var39.getMiddleMillisecond();
//     int var41 = var35.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.TimeSeries var42 = var31.createCopy((org.jfree.data.time.RegularTimePeriod)var34, (org.jfree.data.time.RegularTimePeriod)var35);
//     var31.setNotify(true);
//     java.util.List var45 = var31.getItems();
//     org.jfree.data.time.TimePeriodFormatException var47 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var48 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var31, (java.lang.Object)"");
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var31.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 0.0d);
//     int var55 = var49.compareTo((java.lang.Object)(byte)0);
//     org.jfree.data.time.TimeSeriesDataItem var57 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, (java.lang.Number)100);
//     java.util.Calendar var58 = null;
//     long var59 = var49.getFirstMillisecond(var58);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2014, 1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getFirstMillisecond(var1);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.TimeSeries var47 = var44.createCopy(0, 100);
//     var47.setDescription("");
//     java.lang.Class var53 = null;
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var53);
//     var54.removeAgedItems(true);
//     var54.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var62 = null;
//     org.jfree.data.time.TimeSeries var63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var62);
//     var63.removeAgedItems(true);
//     org.jfree.data.time.Year var66 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var67 = new org.jfree.data.time.Year();
//     long var68 = var67.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var69 = var67.next();
//     org.jfree.data.time.RegularTimePeriod var70 = var67.previous();
//     org.jfree.data.time.Year var71 = new org.jfree.data.time.Year();
//     long var72 = var71.getMiddleMillisecond();
//     int var73 = var67.compareTo((java.lang.Object)var71);
//     org.jfree.data.time.TimeSeries var74 = var63.createCopy((org.jfree.data.time.RegularTimePeriod)var66, (org.jfree.data.time.RegularTimePeriod)var67);
//     org.jfree.data.time.Year var75 = new org.jfree.data.time.Year();
//     int var77 = var75.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var78 = var54.createCopy((org.jfree.data.time.RegularTimePeriod)var66, (org.jfree.data.time.RegularTimePeriod)var75);
//     org.jfree.data.time.RegularTimePeriod var79 = var66.next();
//     var47.add(var79, 10.0d);
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Overwritten values from: 1", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var7 = null;
    var4.removePropertyChangeListener(var7);
    boolean var9 = var4.isEmpty();
    var4.setKey((java.lang.Comparable)0.0d);
    var4.setMaximumItemAge(1419148800000L);
    int var14 = var4.getMaximumItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2147483647);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(21, 21);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var23 = var21.next();
//     java.util.Date var24 = var23.getEnd();
//     var4.delete(var23);
//     java.lang.Object var26 = var4.clone();
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var30);
//     var31.removeAgedItems(true);
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     long var36 = var35.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var37 = var35.next();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.previous();
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     long var40 = var39.getMiddleMillisecond();
//     int var41 = var35.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.TimeSeries var42 = var31.createCopy((org.jfree.data.time.RegularTimePeriod)var34, (org.jfree.data.time.RegularTimePeriod)var35);
//     var31.setNotify(true);
//     java.util.List var45 = var31.getItems();
//     org.jfree.data.time.TimePeriodFormatException var47 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var48 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var31, (java.lang.Object)"");
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var31.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 0.0d);
//     int var55 = var49.compareTo((java.lang.Object)(byte)0);
//     org.jfree.data.time.TimeSeriesDataItem var57 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, (java.lang.Number)100);
//     org.jfree.data.time.Year var58 = new org.jfree.data.time.Year();
//     long var59 = var58.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var60 = var58.next();
//     org.jfree.data.time.RegularTimePeriod var61 = var58.previous();
//     org.jfree.data.time.Year var62 = new org.jfree.data.time.Year();
//     long var63 = var62.getMiddleMillisecond();
//     int var64 = var58.compareTo((java.lang.Object)var62);
//     org.jfree.data.time.TimeSeriesDataItem var66 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var62, 100.0d);
//     java.lang.Class var70 = null;
//     org.jfree.data.time.TimeSeries var71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var70);
//     var71.removeAgedItems(true);
//     org.jfree.data.time.Year var74 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var75 = new org.jfree.data.time.Year();
//     long var76 = var75.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var77 = var75.next();
//     org.jfree.data.time.RegularTimePeriod var78 = var75.previous();
//     org.jfree.data.time.Year var79 = new org.jfree.data.time.Year();
//     long var80 = var79.getMiddleMillisecond();
//     int var81 = var75.compareTo((java.lang.Object)var79);
//     org.jfree.data.time.TimeSeries var82 = var71.createCopy((org.jfree.data.time.RegularTimePeriod)var74, (org.jfree.data.time.RegularTimePeriod)var75);
//     var71.setNotify(true);
//     java.util.List var85 = var71.getItems();
//     org.jfree.data.time.TimePeriodFormatException var87 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var88 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var71, (java.lang.Object)"");
//     org.jfree.data.time.Day var89 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var91 = var71.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var89, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var93 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var89, 0.0d);
//     org.jfree.data.time.TimeSeries var95 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)2014);
//     boolean var96 = var89.equals((java.lang.Object)2014);
//     org.jfree.data.time.TimeSeriesDataItem var98 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var89, 10.0d);
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var96 == false);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     java.lang.Comparable var19 = var4.getKey();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     long var21 = var20.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var22 = var20.next();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)2014);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (java.lang.Number)12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.TimeSeries var24 = var4.createCopy(100, 2147483647);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.update(12, (java.lang.Number)1435867199999L);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     long var25 = var22.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var26 = var22.previous();
//     long var27 = var22.getLastMillisecond();
//     java.util.Calendar var28 = null;
//     long var29 = var22.getMiddleMillisecond(var28);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem(var16, (java.lang.Number)1419162646880L);
//     java.util.Date var21 = var16.getStart();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     java.util.TimeZone var23 = null;
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year(var21, var23);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var30);
//     var31.removeAgedItems(true);
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     long var36 = var35.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var37 = var35.next();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.previous();
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     long var40 = var39.getMiddleMillisecond();
//     int var41 = var35.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.TimeSeries var42 = var31.createCopy((org.jfree.data.time.RegularTimePeriod)var34, (org.jfree.data.time.RegularTimePeriod)var35);
//     var31.setNotify(true);
//     java.util.List var45 = var31.getItems();
//     org.jfree.data.time.TimePeriodFormatException var47 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var48 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var31, (java.lang.Object)"");
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var31.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 0.0d);
//     int var54 = var26.compareTo((java.lang.Object)var53);
//     java.lang.Class var58 = null;
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var58);
//     var59.removeAgedItems(true);
//     org.jfree.data.time.Year var62 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var63 = new org.jfree.data.time.Year();
//     long var64 = var63.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var65 = var63.next();
//     org.jfree.data.time.RegularTimePeriod var66 = var63.previous();
//     org.jfree.data.time.Year var67 = new org.jfree.data.time.Year();
//     long var68 = var67.getMiddleMillisecond();
//     int var69 = var63.compareTo((java.lang.Object)var67);
//     org.jfree.data.time.TimeSeries var70 = var59.createCopy((org.jfree.data.time.RegularTimePeriod)var62, (org.jfree.data.time.RegularTimePeriod)var63);
//     var59.setNotify(true);
//     java.util.List var73 = var59.getItems();
//     int var74 = var53.compareTo((java.lang.Object)var59);
//     org.jfree.data.time.FixedMillisecond var76 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var77 = null;
//     var76.peg(var77);
//     org.jfree.data.time.TimeSeriesDataItem var80 = var59.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var76, 0.0d);
//     var59.clear();
//     var59.fireSeriesChanged();
//     org.jfree.data.time.RegularTimePeriod var83 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var59.add(var83, 100.0d);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var80);
// 
//   }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     java.lang.String var9 = var4.getRangeDescription();
//     java.lang.String var10 = var4.getDescription();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var14);
//     var15.removeAgedItems(true);
//     java.beans.PropertyChangeListener var18 = null;
//     var15.removePropertyChangeListener(var18);
//     boolean var20 = var15.isEmpty();
//     var15.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     boolean var25 = var23.equals((java.lang.Object)(short)1);
//     int var26 = var23.getYear();
//     org.jfree.data.time.RegularTimePeriod var27 = var23.previous();
//     org.jfree.data.time.TimeSeriesDataItem var29 = var15.addOrUpdate(var27, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var15.getDataItem((org.jfree.data.time.RegularTimePeriod)var30);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     java.util.Date var35 = var34.getEnd();
//     var15.delete(var34);
//     java.lang.Object var37 = var15.clone();
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var41);
//     var42.removeAgedItems(true);
//     org.jfree.data.time.Year var45 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     long var47 = var46.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var48 = var46.next();
//     org.jfree.data.time.RegularTimePeriod var49 = var46.previous();
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year();
//     long var51 = var50.getMiddleMillisecond();
//     int var52 = var46.compareTo((java.lang.Object)var50);
//     org.jfree.data.time.TimeSeries var53 = var42.createCopy((org.jfree.data.time.RegularTimePeriod)var45, (org.jfree.data.time.RegularTimePeriod)var46);
//     var42.setNotify(true);
//     java.util.List var56 = var42.getItems();
//     org.jfree.data.time.TimePeriodFormatException var58 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var59 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var42, (java.lang.Object)"");
//     org.jfree.data.time.Day var60 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var62 = var42.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var60, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var60, 0.0d);
//     int var66 = var60.compareTo((java.lang.Object)(byte)0);
//     org.jfree.data.time.TimeSeriesDataItem var68 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var60, (java.lang.Number)100);
//     org.jfree.data.time.Year var69 = new org.jfree.data.time.Year();
//     long var70 = var69.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var71 = var69.next();
//     org.jfree.data.time.RegularTimePeriod var72 = var69.previous();
//     org.jfree.data.time.Year var73 = new org.jfree.data.time.Year();
//     long var74 = var73.getMiddleMillisecond();
//     int var75 = var69.compareTo((java.lang.Object)var73);
//     org.jfree.data.time.TimeSeriesDataItem var77 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var73, 100.0d);
//     java.lang.Number var78 = var77.getValue();
//     var4.add(var77);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var6);
//     java.lang.String var8 = var7.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(12, var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3-January-2016"+ "'", var8.equals("3-January-2016"));
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("31-December-2015");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    var4.removeAgedItems(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var9 = var4.createCopy(10, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     java.lang.String var29 = var28.getDescription();
//     int var30 = var28.getItemCount();
//     org.jfree.data.general.SeriesChangeListener var31 = null;
//     var28.removeChangeListener(var31);
//     java.lang.Class var33 = var28.getTimePeriodClass();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     java.lang.String var9 = var4.getRangeDescription();
//     java.lang.String var10 = var4.getDescription();
//     var4.removeAgedItems(10L, false);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Jan");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(0L);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var23, 0.0d, false);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    java.lang.Comparable var5 = var4.getKey();
    var4.setMaximumItemCount(12);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 100L+ "'", var5.equals(100L));

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     java.lang.Class var29 = var28.getTimePeriodClass();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var30 = var28.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     long var47 = var46.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var48 = var46.next();
//     java.util.Date var49 = var48.getEnd();
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.createInstance(var49);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var50);
//     var4.setKey((java.lang.Comparable)var51);
//     java.lang.String var53 = var51.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var53 + "' != '" + "3-January-2016"+ "'", var53.equals("3-January-2016"));
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     java.lang.Class var29 = var28.getTimePeriodClass();
//     java.util.Collection var30 = var28.getTimePeriods();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var32 = var28.getValue((-460));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     long var16 = var8.getSerialIndex();
//     java.util.Calendar var17 = null;
//     long var18 = var8.getLastMillisecond(var17);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var3);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, "1-January-2016", "hi!", var7);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year(var3);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var3);
//     java.util.TimeZone var13 = null;
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(var3, var13);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var3);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, "1-January-2016", "hi!", var7);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year(var3);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var3);
//     java.util.TimeZone var12 = null;
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var3, var12);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var46 = var4.getTimePeriod(100);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var3);
//     java.util.Calendar var7 = null;
//     long var8 = var6.getFirstMillisecond(var7);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     var4.setMaximumItemAge(0L);
//     var4.setMaximumItemCount(10);
//     var4.removeAgedItems(1388563200000L, false);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(1, var6);
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.next();
//     java.util.Date var14 = var13.getEnd();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var15);
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addDays(2014, var16);
//     org.jfree.data.time.SerialDate var18 = var7.getEndOfCurrentMonth(var17);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var21 = var19.next();
//     java.util.Date var22 = var21.getEnd();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day(var23);
//     org.jfree.data.time.SerialDate var25 = var17.getEndOfCurrentMonth(var23);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(12, var17);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1-January-2016"+ "'", var8.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)(short)1);
//     java.lang.String var3 = var0.toString();
//     java.util.Calendar var4 = null;
//     var0.peg(var4);
// 
//   }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     int var2 = var0.getMonth();
//     long var3 = var0.getSerialIndex();
//     int var5 = var0.compareTo((java.lang.Object)(short)100);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var9);
//     var10.removeAgedItems(true);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     long var15 = var14.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var16 = var14.next();
//     org.jfree.data.time.RegularTimePeriod var17 = var14.previous();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     long var19 = var18.getMiddleMillisecond();
//     int var20 = var14.compareTo((java.lang.Object)var18);
//     org.jfree.data.time.TimeSeries var21 = var10.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var14);
//     var10.setNotify(true);
//     boolean var24 = var0.equals((java.lang.Object)var10);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Calendar var26 = null;
//     long var27 = var25.getFirstMillisecond(var26);
//     java.util.Calendar var28 = null;
//     long var29 = var25.getFirstMillisecond(var28);
//     java.util.Calendar var30 = null;
//     long var31 = var25.getLastMillisecond(var30);
//     org.jfree.data.time.RegularTimePeriod var32 = var25.next();
//     var10.add(var32, 1.0d);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + ""+ "'", var0.equals(""));

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var32);
//     var33.removeAgedItems(true);
//     var33.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var41);
//     var42.removeAgedItems(true);
//     org.jfree.data.time.Year var45 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     long var47 = var46.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var48 = var46.next();
//     org.jfree.data.time.RegularTimePeriod var49 = var46.previous();
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year();
//     long var51 = var50.getMiddleMillisecond();
//     int var52 = var46.compareTo((java.lang.Object)var50);
//     org.jfree.data.time.TimeSeries var53 = var42.createCopy((org.jfree.data.time.RegularTimePeriod)var45, (org.jfree.data.time.RegularTimePeriod)var46);
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year();
//     int var56 = var54.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var57 = var33.createCopy((org.jfree.data.time.RegularTimePeriod)var45, (org.jfree.data.time.RegularTimePeriod)var54);
//     java.lang.Object var58 = var57.clone();
//     boolean var59 = var4.equals((java.lang.Object)var57);
//     var57.removeAgedItems(1419162651912L, false);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     int var29 = var4.getMaximumItemCount();
//     java.lang.Object var30 = var4.clone();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var32 = var4.getValue(2147483647);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-460), 2147483647);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, 12, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     var4.removeAgedItems(0L, false);
// 
//   }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     var4.setNotify(true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var19);
//     var20.removeAgedItems(true);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     long var25 = var24.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var26 = var24.next();
//     org.jfree.data.time.RegularTimePeriod var27 = var24.previous();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     long var29 = var28.getMiddleMillisecond();
//     int var30 = var24.compareTo((java.lang.Object)var28);
//     org.jfree.data.time.TimeSeries var31 = var20.createCopy((org.jfree.data.time.RegularTimePeriod)var23, (org.jfree.data.time.RegularTimePeriod)var24);
//     long var32 = var24.getSerialIndex();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)1419162648233L);
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     long var25 = var22.getFirstMillisecond();
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var29);
//     var30.removeAgedItems(true);
//     var30.setKey((java.lang.Comparable)(byte)1);
//     boolean var35 = var22.equals((java.lang.Object)var30);
//     java.lang.Class var39 = null;
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var39);
//     var40.removeAgedItems(true);
//     java.beans.PropertyChangeListener var43 = null;
//     var40.removePropertyChangeListener(var43);
//     java.util.List var45 = var40.getItems();
//     var40.setRangeDescription("");
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var50 = null;
//     long var51 = var49.getMiddleMillisecond(var50);
//     long var52 = var49.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var54 = var40.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 100.0d);
//     boolean var55 = var22.equals((java.lang.Object)var49);
//     java.util.Calendar var56 = null;
//     var49.peg(var56);
//     long var58 = var49.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1419148800000L);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     java.lang.String var29 = var28.getDescription();
//     org.jfree.data.time.TimeSeries var32 = var28.createCopy(0, 0);
//     java.lang.Class var36 = null;
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var36);
//     var37.removeAgedItems(true);
//     java.beans.PropertyChangeListener var40 = null;
//     var37.removePropertyChangeListener(var40);
//     boolean var42 = var37.isEmpty();
//     var37.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day();
//     boolean var47 = var45.equals((java.lang.Object)(short)1);
//     int var48 = var45.getYear();
//     org.jfree.data.time.RegularTimePeriod var49 = var45.previous();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var37.addOrUpdate(var49, (java.lang.Number)100.0f);
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem(var49, (java.lang.Number)1419162646880L);
//     var28.add(var53);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("1-January-2016", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     var4.clear();
//     org.jfree.data.general.SeriesChangeListener var20 = null;
//     var4.removeChangeListener(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2014);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(100, 2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var3);
//     long var6 = var5.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1451635199999L);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var7 = null;
    var4.removePropertyChangeListener(var7);
    boolean var9 = var4.isEmpty();
    var4.setKey((java.lang.Comparable)0.0d);
    var4.setMaximumItemAge(1419148800000L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var15 = var4.getDataItem(21);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.lang.String var3 = var0.toString();
//     long var4 = var0.getFirstMillisecond();
//     java.util.Calendar var5 = null;
//     long var6 = var0.getFirstMillisecond(var5);
// 
//   }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     long var30 = var29.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var31 = var29.next();
//     java.util.Date var32 = var31.getEnd();
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day(var32);
//     org.jfree.data.time.SerialDate var34 = var33.getSerialDate();
//     org.jfree.data.time.TimeSeriesDataItem var36 = var28.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)1419162651912L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var38 = var28.getTimePeriod(2147483647);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
// 
//   }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.TimeSeries var47 = var44.createCopy(0, 100);
//     org.jfree.data.time.Month var48 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var49 = var48.next();
//     var47.add(var49, 10.0d);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     int var2 = var0.getMonth();
//     long var3 = var0.getSerialIndex();
//     int var5 = var0.compareTo((java.lang.Object)(short)100);
//     java.util.Calendar var6 = null;
//     long var7 = var0.getFirstMillisecond(var6);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem(var16, (java.lang.Number)1419162646880L);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var20, var21);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     long var24 = var23.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var25 = var23.next();
//     org.jfree.data.time.RegularTimePeriod var26 = var23.previous();
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     long var28 = var27.getMiddleMillisecond();
//     int var29 = var23.compareTo((java.lang.Object)var27);
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var33);
//     var34.removeAgedItems(true);
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var38 = new org.jfree.data.time.Year();
//     long var39 = var38.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var40 = var38.next();
//     org.jfree.data.time.RegularTimePeriod var41 = var38.previous();
//     org.jfree.data.time.Year var42 = new org.jfree.data.time.Year();
//     long var43 = var42.getMiddleMillisecond();
//     int var44 = var38.compareTo((java.lang.Object)var42);
//     org.jfree.data.time.TimeSeries var45 = var34.createCopy((org.jfree.data.time.RegularTimePeriod)var37, (org.jfree.data.time.RegularTimePeriod)var38);
//     var34.setNotify(true);
//     java.util.List var48 = var34.getItems();
//     org.jfree.data.time.TimePeriodFormatException var50 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var51 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)"");
//     org.jfree.data.time.Day var52 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var54 = var34.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var52, 10.0d);
//     boolean var55 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var23, (java.lang.Object)var52);
//     int var56 = var52.getYear();
//     int var57 = var52.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var52, 10.0d);
//     var22.add((org.jfree.data.time.RegularTimePeriod)var52, (java.lang.Number)1419162651912L);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Wed Dec 31 16:00:00 PST 1969");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var2 = var1.toString();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getLastMillisecond(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var2.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0L);
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     long var1 = var0.getMiddleMillisecond();
//     java.lang.String var2 = var0.toString();
//     long var3 = var0.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419162656603L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "Sun Dec 21 03:50:56 PST 2014"+ "'", var2.equals("Sun Dec 21 03:50:56 PST 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419162656603L);
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     org.jfree.data.time.TimeSeriesDataItem var18 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.add(var18, true);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.TimeSeries var47 = var44.createCopy(0, 100);
//     org.jfree.data.time.FixedMillisecond var48 = new org.jfree.data.time.FixedMillisecond();
//     long var49 = var48.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var44.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var48, 10.0d);
//     java.beans.PropertyChangeListener var52 = null;
//     var44.addPropertyChangeListener(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1419162656843L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem(var16, (java.lang.Number)1419162646880L);
//     java.util.Date var21 = var16.getStart();
//     java.util.TimeZone var22 = null;
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year(var21, var22);
// 
//   }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var4);
//     var5.removeAgedItems(true);
//     var5.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     long var11 = var10.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var12 = var10.next();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var5.addOrUpdate(var12, 1.0d);
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var19);
//     var20.removeAgedItems(true);
//     var20.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var28);
//     var29.removeAgedItems(true);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var35 = var33.next();
//     org.jfree.data.time.RegularTimePeriod var36 = var33.previous();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     long var38 = var37.getMiddleMillisecond();
//     int var39 = var33.compareTo((java.lang.Object)var37);
//     org.jfree.data.time.TimeSeries var40 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var32, (org.jfree.data.time.RegularTimePeriod)var33);
//     org.jfree.data.time.Year var41 = new org.jfree.data.time.Year();
//     int var43 = var41.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var44 = var20.createCopy((org.jfree.data.time.RegularTimePeriod)var32, (org.jfree.data.time.RegularTimePeriod)var41);
//     org.jfree.data.time.TimeSeries var45 = var5.addAndOrUpdate(var20);
//     org.jfree.data.time.Year var47 = new org.jfree.data.time.Year();
//     long var48 = var47.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var49 = var47.next();
//     java.util.Date var50 = var49.getEnd();
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(var50);
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var51);
//     var5.setKey((java.lang.Comparable)var52);
//     var52.setDescription("Sun Dec 21 03:50:49 PST 2014");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, var52);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Following"+ "'", var1.equals("Following"));

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Following");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(1, var6);
//     java.lang.String var8 = var7.toString();
//     java.lang.String var9 = var7.toString();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears((-1), var7);
//     org.jfree.data.time.SerialDate var11 = null;
//     org.jfree.data.time.SerialDate var12 = var10.getEndOfCurrentMonth(var11);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 28);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     java.lang.Object var27 = var26.clone();
//     java.lang.Object var28 = var26.clone();
//     org.jfree.data.time.RegularTimePeriod var29 = var26.getPeriod();
//     java.lang.Number var30 = var26.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + 0.0d+ "'", var30.equals(0.0d));
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Calendar var30 = null;
//     long var31 = var29.getFirstMillisecond(var30);
//     long var32 = var29.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var33 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var34 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var29, var33);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1419162657130L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1419162657130L);
// 
//   }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var4);
//     var5.removeAgedItems(true);
//     var5.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var13);
//     var14.removeAgedItems(true);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     long var19 = var18.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var20 = var18.next();
//     org.jfree.data.time.RegularTimePeriod var21 = var18.previous();
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     long var23 = var22.getMiddleMillisecond();
//     int var24 = var18.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var25 = var14.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var18);
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     int var28 = var26.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var29 = var5.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var26);
//     org.jfree.data.time.RegularTimePeriod var30 = var17.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var31 = new org.jfree.data.time.Month(21, var17);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.TimeSeries var47 = var44.createCopy(0, 100);
//     java.lang.Class var51 = null;
//     org.jfree.data.time.TimeSeries var52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var51);
//     var52.removeAgedItems(true);
//     var52.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var57 = new org.jfree.data.time.Year();
//     long var58 = var57.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var59 = var57.next();
//     long var60 = var59.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var62 = var52.addOrUpdate(var59, 1.0d);
//     java.beans.PropertyChangeListener var63 = null;
//     var52.removePropertyChangeListener(var63);
//     java.util.Collection var65 = var44.getTimePeriodsUniqueToOtherSeries(var52);
//     org.jfree.data.time.RegularTimePeriod var66 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var52.add(var66, (java.lang.Number)(short)0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("31-December-2015");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Last"+ "'", var1.equals("Last"));

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var23 = var21.next();
//     java.util.Date var24 = var23.getEnd();
//     var4.delete(var23);
//     java.lang.Object var26 = var4.clone();
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var30);
//     var31.removeAgedItems(true);
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     long var36 = var35.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var37 = var35.next();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.previous();
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     long var40 = var39.getMiddleMillisecond();
//     int var41 = var35.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.TimeSeries var42 = var31.createCopy((org.jfree.data.time.RegularTimePeriod)var34, (org.jfree.data.time.RegularTimePeriod)var35);
//     var31.setNotify(true);
//     java.util.List var45 = var31.getItems();
//     org.jfree.data.time.TimePeriodFormatException var47 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var48 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var31, (java.lang.Object)"");
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var31.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 0.0d);
//     int var55 = var49.compareTo((java.lang.Object)(byte)0);
//     org.jfree.data.time.TimeSeriesDataItem var57 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, (java.lang.Number)100);
//     org.jfree.data.time.Year var58 = new org.jfree.data.time.Year();
//     long var59 = var58.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var60 = var58.next();
//     org.jfree.data.time.RegularTimePeriod var61 = var58.previous();
//     org.jfree.data.time.Year var62 = new org.jfree.data.time.Year();
//     long var63 = var62.getMiddleMillisecond();
//     int var64 = var58.compareTo((java.lang.Object)var62);
//     org.jfree.data.time.TimeSeriesDataItem var66 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var62, 100.0d);
//     java.lang.Number var67 = var66.getValue();
//     java.lang.Class var71 = null;
//     org.jfree.data.time.TimeSeries var72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var71);
//     var72.removeAgedItems(true);
//     var72.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var80 = null;
//     org.jfree.data.time.TimeSeries var81 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var80);
//     var81.removeAgedItems(true);
//     org.jfree.data.time.Year var84 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var85 = new org.jfree.data.time.Year();
//     long var86 = var85.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var87 = var85.next();
//     org.jfree.data.time.RegularTimePeriod var88 = var85.previous();
//     org.jfree.data.time.Year var89 = new org.jfree.data.time.Year();
//     long var90 = var89.getMiddleMillisecond();
//     int var91 = var85.compareTo((java.lang.Object)var89);
//     org.jfree.data.time.TimeSeries var92 = var81.createCopy((org.jfree.data.time.RegularTimePeriod)var84, (org.jfree.data.time.RegularTimePeriod)var85);
//     org.jfree.data.time.Year var93 = new org.jfree.data.time.Year();
//     int var95 = var93.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var96 = var72.createCopy((org.jfree.data.time.RegularTimePeriod)var84, (org.jfree.data.time.RegularTimePeriod)var93);
//     var72.setMaximumItemAge(0L);
//     boolean var99 = var66.equals((java.lang.Object)var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var67 + "' != '" + 100+ "'", var67.equals(100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var95 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var99 == false);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     long var23 = var22.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var24 = var22.next();
//     org.jfree.data.time.RegularTimePeriod var25 = var22.previous();
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     long var27 = var26.getMiddleMillisecond();
//     int var28 = var22.compareTo((java.lang.Object)var26);
//     org.jfree.data.time.RegularTimePeriod var29 = var26.next();
//     long var30 = var26.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var26);
//     long var32 = var26.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1404331199999L);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2147483647, (-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("31-December-2015");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(4, (-460), 4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
//     org.jfree.data.time.SerialDate var6 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(10, var6);
//     java.lang.String var8 = var6.getDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("December 2014", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("3-January-2016", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     java.util.Calendar var16 = null;
//     long var17 = var7.getFirstMillisecond(var16);
// 
//   }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     long var25 = var22.getFirstMillisecond();
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var29);
//     var30.removeAgedItems(true);
//     var30.setKey((java.lang.Comparable)(byte)1);
//     boolean var35 = var22.equals((java.lang.Object)var30);
//     java.lang.Class var39 = null;
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var39);
//     var40.removeAgedItems(true);
//     java.beans.PropertyChangeListener var43 = null;
//     var40.removePropertyChangeListener(var43);
//     java.util.List var45 = var40.getItems();
//     var40.setRangeDescription("");
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var50 = null;
//     long var51 = var49.getMiddleMillisecond(var50);
//     long var52 = var49.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var54 = var40.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 100.0d);
//     boolean var55 = var22.equals((java.lang.Object)var49);
//     int var56 = var22.getDayOfMonth();
//     java.lang.Class var60 = null;
//     org.jfree.data.time.TimeSeries var61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var60);
//     var61.removeAgedItems(true);
//     var61.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var69 = null;
//     org.jfree.data.time.TimeSeries var70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var69);
//     var70.removeAgedItems(true);
//     org.jfree.data.time.Year var73 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var74 = new org.jfree.data.time.Year();
//     long var75 = var74.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var76 = var74.next();
//     org.jfree.data.time.RegularTimePeriod var77 = var74.previous();
//     org.jfree.data.time.Year var78 = new org.jfree.data.time.Year();
//     long var79 = var78.getMiddleMillisecond();
//     int var80 = var74.compareTo((java.lang.Object)var78);
//     org.jfree.data.time.TimeSeries var81 = var70.createCopy((org.jfree.data.time.RegularTimePeriod)var73, (org.jfree.data.time.RegularTimePeriod)var74);
//     org.jfree.data.time.Year var82 = new org.jfree.data.time.Year();
//     int var84 = var82.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var85 = var61.createCopy((org.jfree.data.time.RegularTimePeriod)var73, (org.jfree.data.time.RegularTimePeriod)var82);
//     org.jfree.data.time.FixedMillisecond var86 = new org.jfree.data.time.FixedMillisecond();
//     var61.setKey((java.lang.Comparable)var86);
//     int var88 = var61.getMaximumItemCount();
//     java.lang.Comparable var89 = var61.getKey();
//     boolean var90 = var22.equals((java.lang.Object)var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == false);
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var27 = var26.getPeriod();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     long var29 = var28.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var30 = var28.next();
//     java.util.Date var31 = var30.getEnd();
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day(var31);
//     int var33 = var26.compareTo((java.lang.Object)var32);
//     java.lang.Class var37 = null;
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var37);
//     var38.removeAgedItems(true);
//     java.beans.PropertyChangeListener var41 = null;
//     var38.removePropertyChangeListener(var41);
//     boolean var43 = var38.isEmpty();
//     var38.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day();
//     boolean var48 = var46.equals((java.lang.Object)(short)1);
//     int var49 = var46.getYear();
//     org.jfree.data.time.RegularTimePeriod var50 = var46.previous();
//     org.jfree.data.time.TimeSeriesDataItem var52 = var38.addOrUpdate(var50, (java.lang.Number)100.0f);
//     org.jfree.data.time.TimeSeriesDataItem var54 = new org.jfree.data.time.TimeSeriesDataItem(var50, (java.lang.Number)1419162646880L);
//     java.util.Date var55 = var50.getStart();
//     org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.createInstance(var55);
//     org.jfree.data.time.Year var57 = new org.jfree.data.time.Year(var55);
//     int var58 = var32.compareTo((java.lang.Object)var55);
//     java.util.TimeZone var59 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var60 = new org.jfree.data.time.Day(var55, var59);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     int var29 = var4.getMaximumItemCount();
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.Class var35 = null;
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var35);
//     var36.removeAgedItems(true);
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     long var41 = var40.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var42 = var40.next();
//     org.jfree.data.time.RegularTimePeriod var43 = var40.previous();
//     org.jfree.data.time.Year var44 = new org.jfree.data.time.Year();
//     long var45 = var44.getMiddleMillisecond();
//     int var46 = var40.compareTo((java.lang.Object)var44);
//     org.jfree.data.time.TimeSeries var47 = var36.createCopy((org.jfree.data.time.RegularTimePeriod)var39, (org.jfree.data.time.RegularTimePeriod)var40);
//     var36.setNotify(true);
//     java.util.List var50 = var36.getItems();
//     org.jfree.data.time.TimePeriodFormatException var52 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var53 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var36, (java.lang.Object)"");
//     org.jfree.data.time.Day var54 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var56 = var36.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var54, 10.0d);
//     long var57 = var54.getFirstMillisecond();
//     java.lang.Class var61 = null;
//     org.jfree.data.time.TimeSeries var62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var61);
//     var62.removeAgedItems(true);
//     var62.setKey((java.lang.Comparable)(byte)1);
//     boolean var67 = var54.equals((java.lang.Object)var62);
//     java.lang.Class var71 = null;
//     org.jfree.data.time.TimeSeries var72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var71);
//     var72.removeAgedItems(true);
//     java.beans.PropertyChangeListener var75 = null;
//     var72.removePropertyChangeListener(var75);
//     java.util.List var77 = var72.getItems();
//     var72.setRangeDescription("");
//     org.jfree.data.time.FixedMillisecond var81 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var82 = null;
//     long var83 = var81.getMiddleMillisecond(var82);
//     long var84 = var81.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var86 = var72.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var81, 100.0d);
//     boolean var87 = var54.equals((java.lang.Object)var81);
//     org.jfree.data.time.TimeSeries var88 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var54);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var4.removeChangeListener(var16);
//     org.jfree.data.general.SeriesChangeListener var18 = null;
//     var4.removeChangeListener(var18);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.update(10, (java.lang.Number)1.0f);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(var5);
//     org.jfree.data.time.RegularTimePeriod var8 = var7.previous();
//     int var9 = var0.compareTo((java.lang.Object)var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("December");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     var4.setMaximumItemAge(1419148800000L);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month();
//     long var15 = var14.getFirstMillisecond();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var18 = null;
//     var17.peg(var18);
//     int var20 = var14.compareTo((java.lang.Object)var18);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     long var30 = var29.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var31 = var29.next();
//     org.jfree.data.time.RegularTimePeriod var32 = var29.previous();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     int var35 = var29.compareTo((java.lang.Object)var33);
//     org.jfree.data.time.TimeSeries var36 = var25.createCopy((org.jfree.data.time.RegularTimePeriod)var28, (org.jfree.data.time.RegularTimePeriod)var29);
//     var25.setNotify(true);
//     java.util.List var39 = var25.getItems();
//     org.jfree.data.time.TimePeriodFormatException var41 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var42 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var25, (java.lang.Object)"");
//     org.jfree.data.time.Day var43 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var45 = var25.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var43, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var43, 0.0d);
//     org.jfree.data.time.FixedMillisecond var48 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Calendar var49 = null;
//     long var50 = var48.getFirstMillisecond(var49);
//     boolean var51 = var47.equals((java.lang.Object)var50);
//     java.lang.Object var52 = var47.clone();
//     int var53 = var14.compareTo((java.lang.Object)var47);
//     var4.add(var47);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
//     org.jfree.data.time.SerialDate var6 = var5.getSerialDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(12, var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     java.util.Date var27 = var22.getEnd();
//     org.jfree.data.time.FixedMillisecond var28 = new org.jfree.data.time.FixedMillisecond(var27);
//     java.util.TimeZone var29 = null;
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year(var27, var29);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var32);
//     var33.removeAgedItems(true);
//     var33.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var41);
//     var42.removeAgedItems(true);
//     org.jfree.data.time.Year var45 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     long var47 = var46.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var48 = var46.next();
//     org.jfree.data.time.RegularTimePeriod var49 = var46.previous();
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year();
//     long var51 = var50.getMiddleMillisecond();
//     int var52 = var46.compareTo((java.lang.Object)var50);
//     org.jfree.data.time.TimeSeries var53 = var42.createCopy((org.jfree.data.time.RegularTimePeriod)var45, (org.jfree.data.time.RegularTimePeriod)var46);
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year();
//     int var56 = var54.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var57 = var33.createCopy((org.jfree.data.time.RegularTimePeriod)var45, (org.jfree.data.time.RegularTimePeriod)var54);
//     java.lang.Object var58 = var57.clone();
//     boolean var59 = var4.equals((java.lang.Object)var57);
//     var57.setDomainDescription("21-December-2014");
//     var57.setMaximumItemAge(1419162649963L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var3);
//     org.jfree.data.time.SerialDate var5 = var4.getSerialDate();
//     java.lang.String var6 = var5.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "31-December-2015"+ "'", var6.equals("31-December-2015"));
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "", "Wed Dec 31 16:00:00 PST 1969", var4);
//     int var6 = var5.getMaximumItemCount();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var8 = var7.getYear();
//     int var9 = var7.getMonth();
//     long var10 = var7.getSerialIndex();
//     int var12 = var7.compareTo((java.lang.Object)(short)100);
//     org.jfree.data.time.Year var13 = var7.getYear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var5.update((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)1419162646880L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     int var2 = var0.getMonth();
//     long var3 = var0.getSerialIndex();
//     int var5 = var0.compareTo((java.lang.Object)(short)100);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var9);
//     var10.removeAgedItems(true);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     long var15 = var14.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var16 = var14.next();
//     org.jfree.data.time.RegularTimePeriod var17 = var14.previous();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     long var19 = var18.getMiddleMillisecond();
//     int var20 = var14.compareTo((java.lang.Object)var18);
//     org.jfree.data.time.TimeSeries var21 = var10.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var14);
//     var10.setNotify(true);
//     boolean var24 = var0.equals((java.lang.Object)var10);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var28);
//     var29.removeAgedItems(true);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var35 = var33.next();
//     org.jfree.data.time.RegularTimePeriod var36 = var33.previous();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     long var38 = var37.getMiddleMillisecond();
//     int var39 = var33.compareTo((java.lang.Object)var37);
//     org.jfree.data.time.TimeSeries var40 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var32, (org.jfree.data.time.RegularTimePeriod)var33);
//     var29.setNotify(true);
//     java.util.List var43 = var29.getItems();
//     boolean var44 = var10.equals((java.lang.Object)var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     var4.setMaximumItemAge(0L);
//     java.lang.Object var47 = var4.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var15.fireSeriesChanged();
//     int var17 = var15.getMaximumItemCount();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     long var19 = var18.getLastMillisecond();
//     var15.add((org.jfree.data.time.RegularTimePeriod)var18, 100.0d, true);
// 
//   }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Wed Dec 31 16:00:00 PST 1969", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("Sun Dec 21 03:50:49 PST 2014");

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2014, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.lang.String var3 = var0.toString();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var7);
//     var8.removeAgedItems(true);
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var14 = var12.next();
//     org.jfree.data.time.RegularTimePeriod var15 = var12.previous();
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     long var17 = var16.getMiddleMillisecond();
//     int var18 = var12.compareTo((java.lang.Object)var16);
//     org.jfree.data.time.TimeSeries var19 = var8.createCopy((org.jfree.data.time.RegularTimePeriod)var11, (org.jfree.data.time.RegularTimePeriod)var12);
//     var8.setNotify(true);
//     java.util.List var22 = var8.getItems();
//     org.jfree.data.time.TimePeriodFormatException var24 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)"");
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var28 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var26, 10.0d);
//     long var29 = var26.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var30 = var26.previous();
//     long var31 = var26.getSerialIndex();
//     int var32 = var0.compareTo((java.lang.Object)var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "December 2014"+ "'", var3.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(31, (-460), 2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("1-January-2016");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.TimeSeries var47 = var44.createCopy(0, 100);
//     org.jfree.data.time.FixedMillisecond var48 = new org.jfree.data.time.FixedMillisecond();
//     long var49 = var48.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var44.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var48, 10.0d);
//     org.jfree.data.time.RegularTimePeriod var52 = var48.next();
//     java.util.Date var53 = var52.getEnd();
//     org.jfree.data.time.FixedMillisecond var54 = new org.jfree.data.time.FixedMillisecond(var53);
//     org.jfree.data.time.FixedMillisecond var55 = new org.jfree.data.time.FixedMillisecond(var53);
//     java.util.TimeZone var56 = null;
//     org.jfree.data.time.Year var57 = new org.jfree.data.time.Year(var53, var56);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var23 = var21.next();
//     java.util.Date var24 = var23.getEnd();
//     var4.delete(var23);
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var27 = var26.getYear();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var30 = var29.next();
//     org.jfree.data.time.Year var31 = var29.getYear();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var35 = var33.next();
//     java.util.Date var36 = var35.getEnd();
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var36);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.addDays(1, var37);
//     java.lang.String var39 = var38.toString();
//     java.lang.String var40 = var38.toString();
//     var38.setDescription("1-January-2016");
//     var38.setDescription("3-January-2016");
//     java.lang.String var45 = var38.getDescription();
//     boolean var46 = var29.equals((java.lang.Object)var38);
//     org.jfree.data.time.TimeSeries var47 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var26, (org.jfree.data.time.RegularTimePeriod)var29);
//     java.util.Calendar var48 = null;
//     long var49 = var26.getLastMillisecond(var48);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.TimeSeries var47 = var44.createCopy(0, 100);
//     java.lang.Class var51 = null;
//     org.jfree.data.time.TimeSeries var52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var51);
//     var52.removeAgedItems(true);
//     var52.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var57 = new org.jfree.data.time.Year();
//     long var58 = var57.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var59 = var57.next();
//     long var60 = var59.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var62 = var52.addOrUpdate(var59, 1.0d);
//     java.beans.PropertyChangeListener var63 = null;
//     var52.removePropertyChangeListener(var63);
//     java.util.Collection var65 = var44.getTimePeriodsUniqueToOtherSeries(var52);
//     long var66 = var52.getMaximumItemAge();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var68 = var52.getDataItem((-460));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 9223372036854775807L);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 21);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var30);
//     var31.removeAgedItems(true);
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     long var36 = var35.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var37 = var35.next();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.previous();
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     long var40 = var39.getMiddleMillisecond();
//     int var41 = var35.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.TimeSeries var42 = var31.createCopy((org.jfree.data.time.RegularTimePeriod)var34, (org.jfree.data.time.RegularTimePeriod)var35);
//     var31.setNotify(true);
//     java.util.List var45 = var31.getItems();
//     org.jfree.data.time.TimePeriodFormatException var47 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var48 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var31, (java.lang.Object)"");
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var31.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 0.0d);
//     int var54 = var26.compareTo((java.lang.Object)var53);
//     org.jfree.data.time.Year var56 = new org.jfree.data.time.Year();
//     long var57 = var56.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var58 = var56.next();
//     java.util.Date var59 = var58.getEnd();
//     org.jfree.data.time.SerialDate var60 = org.jfree.data.time.SerialDate.createInstance(var59);
//     org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.addDays(1, var60);
//     java.lang.String var62 = var61.toString();
//     java.lang.String var63 = var61.toString();
//     var61.setDescription("1-January-2016");
//     var61.setDescription("3-January-2016");
//     boolean var68 = var26.equals((java.lang.Object)"3-January-2016");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var62 + "' != '" + "1-January-2016"+ "'", var62.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "1-January-2016"+ "'", var63.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
// 
//   }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Sun Dec 21 03:50:49 PST 2014", var1);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var3);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, "1-January-2016", "hi!", var7);
//     java.util.TimeZone var9 = null;
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var3, var9);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     int var2 = var0.compareTo((java.lang.Object)10.0f);
//     long var3 = var0.getFirstMillisecond();
//     org.jfree.data.general.SeriesChangeEvent var4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var0);
//     java.lang.String var5 = var4.toString();
//     java.lang.String var6 = var4.toString();
//     java.lang.Object var7 = var4.getSource();
//     java.lang.String var8 = var4.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2014]"+ "'", var5.equals("org.jfree.data.general.SeriesChangeEvent[source=2014]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2014]"+ "'", var6.equals("org.jfree.data.general.SeriesChangeEvent[source=2014]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2014]"+ "'", var8.equals("org.jfree.data.general.SeriesChangeEvent[source=2014]"));
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears(2147483647, var1);
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     org.jfree.data.time.RegularTimePeriod var7 = var4.next();
//     long var8 = var4.getLastMillisecond();
//     java.util.Date var9 = var4.getStart();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     long var29 = var16.getMiddleMillisecond();
//     long var30 = var16.getFirstMillisecond();
//     java.util.Calendar var31 = null;
//     var16.peg(var31);
// 
//   }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     java.lang.String var22 = var4.getDomainDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + ""+ "'", var22.equals(""));
// 
//   }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     java.lang.String var29 = var28.getDescription();
//     int var30 = var28.getItemCount();
//     org.jfree.data.general.SeriesChangeListener var31 = null;
//     var28.removeChangeListener(var31);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var35 = var28.createCopy(1, 0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0);
// 
//   }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)(short)1);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     long var4 = var3.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var5 = var3.next();
//     org.jfree.data.time.RegularTimePeriod var6 = var3.previous();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     long var8 = var7.getMiddleMillisecond();
//     int var9 = var3.compareTo((java.lang.Object)var7);
//     int var10 = var0.compareTo((java.lang.Object)var3);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var14);
//     var15.removeAgedItems(true);
//     var15.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var23);
//     var24.removeAgedItems(true);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     long var29 = var28.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var30 = var28.next();
//     org.jfree.data.time.RegularTimePeriod var31 = var28.previous();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     int var34 = var28.compareTo((java.lang.Object)var32);
//     org.jfree.data.time.TimeSeries var35 = var24.createCopy((org.jfree.data.time.RegularTimePeriod)var27, (org.jfree.data.time.RegularTimePeriod)var28);
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     int var38 = var36.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var39 = var15.createCopy((org.jfree.data.time.RegularTimePeriod)var27, (org.jfree.data.time.RegularTimePeriod)var36);
//     var15.setMaximumItemAge(0L);
//     var15.setMaximumItemCount(10);
//     int var44 = var3.compareTo((java.lang.Object)var15);
//     java.util.Calendar var45 = null;
//     long var46 = var3.getLastMillisecond(var45);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(12, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Dec"+ "'", var2.equals("Dec"));

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(1, var6);
//     var7.setDescription("31-December-2015");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-460), 28, 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.lang.String var3 = var0.toString();
//     org.jfree.data.time.Year var4 = var0.getYear();
//     java.util.Calendar var5 = null;
//     var4.peg(var5);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     long var4 = var3.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var5 = var3.next();
//     java.util.Date var6 = var5.getEnd();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addDays(1, var7);
//     java.lang.String var9 = var8.toString();
//     java.lang.String var10 = var8.toString();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears((-1), var8);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var14 = var12.next();
//     java.util.Date var15 = var14.getEnd();
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day(var15);
//     org.jfree.data.time.SerialDate var17 = var16.getSerialDate();
//     org.jfree.data.time.SerialDate var18 = var11.getEndOfCurrentMonth(var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(100, var17);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "1-January-2016"+ "'", var9.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "1-January-2016"+ "'", var10.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Last");

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addDays(1, var5);
//     java.lang.String var7 = var6.toString();
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     long var11 = var10.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var12 = var10.next();
//     java.util.Date var13 = var12.getEnd();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var14);
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addDays(2014, var15);
//     org.jfree.data.time.SerialDate var17 = var6.getEndOfCurrentMonth(var16);
//     org.jfree.data.time.SerialDate var19 = var17.getPreviousDayOfWeek(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var21 = var17.getNearestDayOfWeek((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "1-January-2016"+ "'", var7.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)(short)1);
//     int var3 = var0.getYear();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getMiddleMillisecond(var4);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(2147483647, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Sun Dec 21 03:50:56 PST 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Overwritten values from: 1");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-1), 4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
//     org.jfree.data.time.SerialDate var6 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(10, var6);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     java.util.Date var12 = var11.getEnd();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var13);
//     java.lang.String var15 = var14.toString();
//     org.jfree.data.time.SerialDate var16 = var7.getEndOfCurrentMonth(var14);
//     var7.setDescription("Sun Dec 21 03:50:56 PST 2014");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "3-January-2016"+ "'", var15.equals("3-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = var4.getNearestDayOfWeek((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     org.jfree.data.time.RegularTimePeriod var29 = var16.next();
//     long var30 = var16.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1388563200000L);
// 
//   }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     int var1 = var0.getYear();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, 0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (java.lang.Number)1419162650308L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Fourth"+ "'", var1.equals("Fourth"));

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var32);
//     var33.removeAgedItems(true);
//     var33.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var41);
//     var42.removeAgedItems(true);
//     org.jfree.data.time.Year var45 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     long var47 = var46.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var48 = var46.next();
//     org.jfree.data.time.RegularTimePeriod var49 = var46.previous();
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year();
//     long var51 = var50.getMiddleMillisecond();
//     int var52 = var46.compareTo((java.lang.Object)var50);
//     org.jfree.data.time.TimeSeries var53 = var42.createCopy((org.jfree.data.time.RegularTimePeriod)var45, (org.jfree.data.time.RegularTimePeriod)var46);
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year();
//     int var56 = var54.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var57 = var33.createCopy((org.jfree.data.time.RegularTimePeriod)var45, (org.jfree.data.time.RegularTimePeriod)var54);
//     java.lang.Object var58 = var57.clone();
//     boolean var59 = var4.equals((java.lang.Object)var57);
//     var57.setDomainDescription("21-December-2014");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var62 = var57.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var27 = var26.getPeriod();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     long var29 = var28.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var30 = var28.next();
//     java.util.Date var31 = var30.getEnd();
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day(var31);
//     int var33 = var26.compareTo((java.lang.Object)var32);
//     int var34 = var32.getDayOfMonth();
//     java.util.Calendar var35 = null;
//     long var36 = var32.getFirstMillisecond(var35);
// 
//   }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var3);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, "1-January-2016", "hi!", var7);
//     long var9 = var8.getMaximumItemAge();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var11 = var8.getDataItem(2147483647);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     long var4 = var3.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var5 = var3.next();
//     java.util.Date var6 = var5.getEnd();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addDays(1, var7);
//     java.lang.String var9 = var8.toString();
//     java.lang.String var10 = var8.toString();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears((-1), var8);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var14 = var12.next();
//     java.util.Date var15 = var14.getEnd();
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day(var15);
//     org.jfree.data.time.SerialDate var17 = var16.getSerialDate();
//     org.jfree.data.time.SerialDate var18 = var11.getEndOfCurrentMonth(var17);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day(var18);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(100, var18);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "1-January-2016"+ "'", var9.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "1-January-2016"+ "'", var10.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("21-December-2014", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var3);
//     org.jfree.data.time.SerialDate var5 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var6 = var4.getSerialDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var8 = var6.getPreviousDayOfWeek(10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-460));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.TimeSeries var24 = var4.createCopy(100, 2147483647);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var26 = var4.getTimePeriod((-460));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (java.lang.Number)1419162658088L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var23 = var21.next();
//     java.util.Date var24 = var23.getEnd();
//     var4.delete(var23);
//     java.lang.Object var26 = var4.clone();
//     var4.removeAgedItems(0L, true);
// 
//   }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(1, var6);
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.next();
//     java.util.Date var14 = var13.getEnd();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var15);
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addDays(2014, var16);
//     org.jfree.data.time.SerialDate var18 = var7.getEndOfCurrentMonth(var17);
//     org.jfree.data.time.SerialDate var20 = var18.getPreviousDayOfWeek(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(28, var20);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1-January-2016"+ "'", var8.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("21-December-2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-1), 0, 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addDays(1, var5);
//     java.lang.String var7 = var6.toString();
//     java.lang.String var8 = var6.toString();
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var8, "SerialDate.weekInMonthToString(): invalid code.", "1-January-2016", var11);
//     var12.removeAgedItems(true);
//     boolean var15 = var12.isEmpty();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var18 = var12.createCopy((-460), 2147483647);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "1-January-2016"+ "'", var7.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1-January-2016"+ "'", var8.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
// 
//   }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var4);
//     var5.removeAgedItems(true);
//     var5.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var13);
//     var14.removeAgedItems(true);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     long var19 = var18.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var20 = var18.next();
//     org.jfree.data.time.RegularTimePeriod var21 = var18.previous();
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     long var23 = var22.getMiddleMillisecond();
//     int var24 = var18.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var25 = var14.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var18);
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     int var28 = var26.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var29 = var5.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var30 = new org.jfree.data.time.Month(28, var17);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
// 
//   }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(1, var6);
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears((-1), var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var11 = var7.getNearestDayOfWeek(10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1-January-2016"+ "'", var8.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     var4.setMaximumItemAge(0L);
//     var4.removeAgedItems(1419162648741L, false);
// 
//   }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     long var25 = var22.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var26 = var22.previous();
//     long var27 = var22.getLastMillisecond();
//     java.util.Calendar var28 = null;
//     var22.peg(var28);
// 
//   }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var4);
//     var5.removeAgedItems(true);
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     org.jfree.data.time.RegularTimePeriod var12 = var9.previous();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     long var14 = var13.getMiddleMillisecond();
//     int var15 = var9.compareTo((java.lang.Object)var13);
//     org.jfree.data.time.TimeSeries var16 = var5.createCopy((org.jfree.data.time.RegularTimePeriod)var8, (org.jfree.data.time.RegularTimePeriod)var9);
//     var5.setNotify(true);
//     java.util.List var19 = var5.getItems();
//     org.jfree.data.time.TimePeriodFormatException var21 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)"");
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 0.0d);
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var31);
//     var32.removeAgedItems(true);
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var38 = var36.next();
//     org.jfree.data.time.RegularTimePeriod var39 = var36.previous();
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     long var41 = var40.getMiddleMillisecond();
//     int var42 = var36.compareTo((java.lang.Object)var40);
//     org.jfree.data.time.TimeSeries var43 = var32.createCopy((org.jfree.data.time.RegularTimePeriod)var35, (org.jfree.data.time.RegularTimePeriod)var36);
//     var32.setNotify(true);
//     java.util.List var46 = var32.getItems();
//     org.jfree.data.time.TimePeriodFormatException var48 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var49 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var32, (java.lang.Object)"");
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var52 = var32.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var50, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var50, 0.0d);
//     int var55 = var27.compareTo((java.lang.Object)var54);
//     org.jfree.data.time.Year var59 = new org.jfree.data.time.Year();
//     long var60 = var59.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var61 = var59.next();
//     java.util.Date var62 = var61.getEnd();
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(var62);
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var63);
//     org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.addDays(2014, var64);
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.addYears(1, var64);
//     int var67 = var27.compareTo((java.lang.Object)var64);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2014, var64);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1);
// 
//   }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "", "Wed Dec 31 16:00:00 PST 1969", var4);
//     java.util.Calendar var6 = null;
//     long var7 = var0.getLastMillisecond(var6);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(1, var6);
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears((-1), var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var11 = var7.getFollowingDayOfWeek(2147483647);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1-January-2016"+ "'", var8.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("Sun Dec 21 03:50:54 PST 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     long var25 = var22.getFirstMillisecond();
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var29);
//     var30.removeAgedItems(true);
//     var30.setKey((java.lang.Comparable)(byte)1);
//     boolean var35 = var22.equals((java.lang.Object)var30);
//     java.util.Date var36 = var22.getStart();
//     java.util.TimeZone var37 = null;
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month(var36, var37);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    java.util.Date var0 = null;
    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var2 = new org.jfree.data.time.Day(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     int var2 = var0.compareTo((java.lang.Object)10.0f);
//     long var3 = var0.getLastMillisecond();
//     java.lang.String var4 = var0.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "2014"+ "'", var4.equals("2014"));
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, 0, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-460), 2147483647, 21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var7 = null;
    var4.removePropertyChangeListener(var7);
    java.util.List var9 = var4.getItems();
    var4.setRangeDescription("");
    org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
    java.util.Calendar var14 = null;
    long var15 = var13.getMiddleMillisecond(var14);
    long var16 = var13.getFirstMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, 100.0d);
    java.lang.String var19 = var4.getRangeDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1419148800000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1419148800000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + ""+ "'", var19.equals(""));

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(31, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     int var2 = var0.getMonth();
//     long var3 = var0.getSerialIndex();
//     int var5 = var0.compareTo((java.lang.Object)(short)100);
//     java.util.Calendar var6 = null;
//     long var7 = var0.getMiddleMillisecond(var6);
// 
//   }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.beans.PropertyChangeListener var15 = null;
//     var4.removePropertyChangeListener(var15);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var20);
//     var21.removeAgedItems(true);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     long var26 = var25.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var27 = var25.next();
//     org.jfree.data.time.RegularTimePeriod var28 = var25.previous();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     long var30 = var29.getMiddleMillisecond();
//     int var31 = var25.compareTo((java.lang.Object)var29);
//     org.jfree.data.time.TimeSeries var32 = var21.createCopy((org.jfree.data.time.RegularTimePeriod)var24, (org.jfree.data.time.RegularTimePeriod)var25);
//     var21.setNotify(true);
//     java.util.List var35 = var21.getItems();
//     org.jfree.data.time.TimePeriodFormatException var37 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var21, (java.lang.Object)"");
//     org.jfree.data.time.Day var39 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var41 = var21.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var39, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, 0.0d);
//     org.jfree.data.time.TimeSeriesDataItem var44 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var39);
//     int var45 = var39.getDayOfMonth();
//     java.util.Calendar var46 = null;
//     long var47 = var39.getMiddleMillisecond(var46);
// 
//   }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var31 = var25.createCopy(2014, 0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var4);
//     var5.removeAgedItems(true);
//     var5.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     long var11 = var10.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var12 = var10.next();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var5.addOrUpdate(var12, 1.0d);
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var19);
//     var20.removeAgedItems(true);
//     var20.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var28);
//     var29.removeAgedItems(true);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var35 = var33.next();
//     org.jfree.data.time.RegularTimePeriod var36 = var33.previous();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     long var38 = var37.getMiddleMillisecond();
//     int var39 = var33.compareTo((java.lang.Object)var37);
//     org.jfree.data.time.TimeSeries var40 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var32, (org.jfree.data.time.RegularTimePeriod)var33);
//     org.jfree.data.time.Year var41 = new org.jfree.data.time.Year();
//     int var43 = var41.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var44 = var20.createCopy((org.jfree.data.time.RegularTimePeriod)var32, (org.jfree.data.time.RegularTimePeriod)var41);
//     org.jfree.data.time.TimeSeries var45 = var5.addAndOrUpdate(var20);
//     org.jfree.data.time.TimeSeries var48 = var45.createCopy(0, 100);
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond();
//     long var50 = var49.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var52 = var45.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 10.0d);
//     org.jfree.data.time.RegularTimePeriod var53 = var49.next();
//     java.util.Date var54 = var53.getEnd();
//     java.util.TimeZone var55 = null;
//     org.jfree.data.time.RegularTimePeriod var56 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var54, var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1419162662668L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var56);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-457));

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var4);
//     var5.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var5.removePropertyChangeListener(var8);
//     boolean var10 = var5.isEmpty();
//     var5.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     boolean var15 = var13.equals((java.lang.Object)(short)1);
//     int var16 = var13.getYear();
//     org.jfree.data.time.RegularTimePeriod var17 = var13.previous();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var5.addOrUpdate(var17, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var5.getDataItem((org.jfree.data.time.RegularTimePeriod)var20);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var25);
//     var26.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var29 = var5.addAndOrUpdate(var26);
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     long var31 = var30.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var32 = var30.next();
//     java.util.Date var33 = var32.getEnd();
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day(var33);
//     org.jfree.data.time.SerialDate var35 = var34.getSerialDate();
//     org.jfree.data.time.TimeSeriesDataItem var37 = var29.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var34, (java.lang.Number)1419162651912L);
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var41);
//     var42.removeAgedItems(true);
//     org.jfree.data.time.Year var45 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     long var47 = var46.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var48 = var46.next();
//     org.jfree.data.time.RegularTimePeriod var49 = var46.previous();
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year();
//     long var51 = var50.getMiddleMillisecond();
//     int var52 = var46.compareTo((java.lang.Object)var50);
//     org.jfree.data.time.TimeSeries var53 = var42.createCopy((org.jfree.data.time.RegularTimePeriod)var45, (org.jfree.data.time.RegularTimePeriod)var46);
//     var42.setNotify(true);
//     java.util.List var56 = var42.getItems();
//     org.jfree.data.time.TimePeriodFormatException var58 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var59 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var42, (java.lang.Object)"");
//     org.jfree.data.time.Day var60 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var62 = var42.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var60, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var60, 0.0d);
//     boolean var65 = var34.equals((java.lang.Object)var60);
//     java.util.Date var66 = var60.getStart();
//     java.util.TimeZone var67 = null;
//     org.jfree.data.time.RegularTimePeriod var68 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var66, var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var68);
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Following", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var6);
//     java.lang.String var8 = var7.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addDays(2147483647, var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3-January-2016"+ "'", var8.equals("3-January-2016"));
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("Sun Dec 21 03:50:56 PST 2014");

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var27 = var26.getPeriod();
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var31);
//     var32.removeAgedItems(true);
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var38 = var36.next();
//     org.jfree.data.time.RegularTimePeriod var39 = var36.previous();
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     long var41 = var40.getMiddleMillisecond();
//     int var42 = var36.compareTo((java.lang.Object)var40);
//     org.jfree.data.time.TimeSeries var43 = var32.createCopy((org.jfree.data.time.RegularTimePeriod)var35, (org.jfree.data.time.RegularTimePeriod)var36);
//     org.jfree.data.general.SeriesChangeListener var44 = null;
//     var32.removeChangeListener(var44);
//     int var46 = var26.compareTo((java.lang.Object)var32);
//     java.lang.Class var47 = var32.getTimePeriodClass();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var47);
// 
//   }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Sun Dec 21 03:50:56 PST 2014", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     long var30 = var29.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var31 = var29.next();
//     java.util.Date var32 = var31.getEnd();
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day(var32);
//     org.jfree.data.time.SerialDate var34 = var33.getSerialDate();
//     org.jfree.data.time.TimeSeriesDataItem var36 = var28.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)1419162651912L);
//     org.jfree.data.time.RegularTimePeriod var37 = var33.previous();
//     java.util.Calendar var38 = null;
//     var33.peg(var38);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Wed Dec 31 16:00:00 PST 1969", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
    java.util.Calendar var2 = null;
    long var3 = var1.getFirstMillisecond(var2);
    long var4 = var1.getLastMillisecond();
    java.util.Calendar var5 = null;
    long var6 = var1.getLastMillisecond(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1419148800000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1419148800000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1419148800000L);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    java.lang.Comparable var0 = null;
    java.lang.Class var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries(var0, "", "Sun Dec 21 03:50:56 PST 2014", var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#');
//     var1.removeAgedItems(1419235199999L, true);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     boolean var7 = var5.equals((java.lang.Object)(short)1);
//     java.lang.String var8 = var5.toString();
//     long var9 = var5.getFirstMillisecond();
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     long var11 = var10.getMiddleMillisecond();
//     long var12 = var10.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeries var13 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var10);
//     long var14 = var5.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "21-December-2014"+ "'", var8.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419191999999L);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("Dec");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     org.jfree.data.time.RegularTimePeriod var7 = var4.next();
//     long var8 = var4.getLastMillisecond();
//     java.lang.String var9 = var4.toString();
//     java.lang.String var10 = var4.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "2014"+ "'", var9.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "2014"+ "'", var10.equals("2014"));
// 
//   }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addDays(1, var5);
//     java.lang.String var7 = var6.toString();
//     java.lang.String var8 = var6.getDescription();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.next();
//     java.util.Date var14 = var13.getEnd();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addDays(1, var15);
//     java.lang.String var17 = var16.toString();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addYears((-1), var16);
//     org.jfree.data.time.SerialDate var19 = var6.getEndOfCurrentMonth(var16);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var23 = var21.next();
//     java.util.Date var24 = var23.getEnd();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var25);
//     java.lang.String var27 = var25.toString();
//     org.jfree.data.time.SerialDate var28 = var16.getEndOfCurrentMonth(var25);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day(var25);
//     java.util.Calendar var30 = null;
//     var29.peg(var30);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, 2014, 2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     java.util.Calendar var29 = null;
//     long var30 = var16.getLastMillisecond(var29);
// 
//   }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var3);
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var3, var5);
// 
//   }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var8 = var5.getNearestDayOfWeek(100);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var10);
//     var11.removeAgedItems(true);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     long var16 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.previous();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     int var21 = var15.compareTo((java.lang.Object)var19);
//     org.jfree.data.time.TimeSeries var22 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var15);
//     var11.setNotify(true);
//     java.util.List var25 = var11.getItems();
//     org.jfree.data.time.TimePeriodFormatException var27 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)"");
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var29, 10.0d);
//     boolean var32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var29);
//     int var33 = var29.getYear();
//     java.util.Date var34 = var29.getEnd();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year(var34);
//     java.util.Calendar var36 = null;
//     long var37 = var35.getFirstMillisecond(var36);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10, 21, 28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     org.jfree.data.time.RegularTimePeriod var29 = var16.previous();
//     long var30 = var16.getFirstMillisecond();
//     java.util.Calendar var31 = null;
//     long var32 = var16.getFirstMillisecond(var31);
// 
//   }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var7, "Last", "ERROR : Relative To String", var18);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var21 = var19.getValue(0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, "1-January-2016", "December 2014", var6);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var11);
//     var12.removeAgedItems(true);
//     var12.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var20);
//     var21.removeAgedItems(true);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     long var26 = var25.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var27 = var25.next();
//     org.jfree.data.time.RegularTimePeriod var28 = var25.previous();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     long var30 = var29.getMiddleMillisecond();
//     int var31 = var25.compareTo((java.lang.Object)var29);
//     org.jfree.data.time.TimeSeries var32 = var21.createCopy((org.jfree.data.time.RegularTimePeriod)var24, (org.jfree.data.time.RegularTimePeriod)var25);
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     int var35 = var33.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var36 = var12.createCopy((org.jfree.data.time.RegularTimePeriod)var24, (org.jfree.data.time.RegularTimePeriod)var33);
//     var12.setMaximumItemAge(0L);
//     var12.setMaximumItemCount(10);
//     org.jfree.data.time.FixedMillisecond var42 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     long var43 = var42.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var42, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var46 = var42.next();
//     org.jfree.data.time.Month var47 = new org.jfree.data.time.Month();
//     long var48 = var47.getLastMillisecond();
//     int var49 = var47.getMonth();
//     org.jfree.data.time.RegularTimePeriod var50 = var47.previous();
//     org.jfree.data.time.TimeSeries var51 = var12.createCopy(var46, (org.jfree.data.time.RegularTimePeriod)var47);
//     org.jfree.data.time.FixedMillisecond var53 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var54 = var7.createCopy(var46, (org.jfree.data.time.RegularTimePeriod)var53);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     var4.setMaximumItemAge(0L);
//     var4.setMaximumItemCount(10);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     long var35 = var34.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var38 = var34.next();
//     org.jfree.data.time.Month var39 = new org.jfree.data.time.Month();
//     long var40 = var39.getLastMillisecond();
//     int var41 = var39.getMonth();
//     org.jfree.data.time.RegularTimePeriod var42 = var39.previous();
//     org.jfree.data.time.TimeSeries var43 = var4.createCopy(var38, (org.jfree.data.time.RegularTimePeriod)var39);
//     java.lang.Class var47 = null;
//     org.jfree.data.time.TimeSeries var48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var47);
//     var48.removeAgedItems(true);
//     org.jfree.data.time.Year var51 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var52 = new org.jfree.data.time.Year();
//     long var53 = var52.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var54 = var52.next();
//     org.jfree.data.time.RegularTimePeriod var55 = var52.previous();
//     org.jfree.data.time.Year var56 = new org.jfree.data.time.Year();
//     long var57 = var56.getMiddleMillisecond();
//     int var58 = var52.compareTo((java.lang.Object)var56);
//     org.jfree.data.time.TimeSeries var59 = var48.createCopy((org.jfree.data.time.RegularTimePeriod)var51, (org.jfree.data.time.RegularTimePeriod)var52);
//     var48.setNotify(true);
//     java.util.List var62 = var48.getItems();
//     org.jfree.data.time.TimePeriodFormatException var64 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var65 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var48, (java.lang.Object)"");
//     org.jfree.data.time.Day var66 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var68 = var48.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var66, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var66, 0.0d);
//     java.util.Date var71 = var66.getEnd();
//     org.jfree.data.time.TimeSeriesDataItem var73 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var66, (java.lang.Number)0);
//     var4.removeAgedItems(10L, false);
// 
//   }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var10);
//     var11.removeAgedItems(true);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     long var16 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.previous();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     int var21 = var15.compareTo((java.lang.Object)var19);
//     org.jfree.data.time.TimeSeries var22 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var15);
//     var11.setNotify(true);
//     java.util.List var25 = var11.getItems();
//     org.jfree.data.time.TimePeriodFormatException var27 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)"");
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var29, 10.0d);
//     boolean var32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var29);
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     long var34 = var33.getFirstMillisecond();
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var37 = null;
//     var36.peg(var37);
//     int var39 = var33.compareTo((java.lang.Object)var37);
//     int var40 = var33.getMonth();
//     java.lang.String var41 = var33.toString();
//     boolean var42 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var29, (java.lang.Object)var33);
//     java.util.Calendar var43 = null;
//     var29.peg(var43);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addYears((-457), var5);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var23 = var21.next();
//     java.util.Date var24 = var23.getEnd();
//     var4.delete(var23);
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var27 = var26.getYear();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var30 = var29.next();
//     org.jfree.data.time.Year var31 = var29.getYear();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var35 = var33.next();
//     java.util.Date var36 = var35.getEnd();
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var36);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.addDays(1, var37);
//     java.lang.String var39 = var38.toString();
//     java.lang.String var40 = var38.toString();
//     var38.setDescription("1-January-2016");
//     var38.setDescription("3-January-2016");
//     java.lang.String var45 = var38.getDescription();
//     boolean var46 = var29.equals((java.lang.Object)var38);
//     org.jfree.data.time.TimeSeries var47 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var26, (org.jfree.data.time.RegularTimePeriod)var29);
//     var47.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String");
//     java.lang.Class var53 = null;
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var53);
//     var54.removeAgedItems(true);
//     java.beans.PropertyChangeListener var57 = null;
//     var54.removePropertyChangeListener(var57);
//     boolean var59 = var54.isEmpty();
//     var54.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var62 = new org.jfree.data.time.Day();
//     boolean var64 = var62.equals((java.lang.Object)(short)1);
//     int var65 = var62.getYear();
//     org.jfree.data.time.RegularTimePeriod var66 = var62.previous();
//     org.jfree.data.time.TimeSeriesDataItem var68 = var54.addOrUpdate(var66, (java.lang.Number)100.0f);
//     org.jfree.data.time.TimeSeriesDataItem var70 = new org.jfree.data.time.TimeSeriesDataItem(var66, (java.lang.Number)1419162646880L);
//     org.jfree.data.time.RegularTimePeriod var71 = var70.getPeriod();
//     var47.add(var70);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.Year var1 = var0.getYear();
    java.lang.Class var4 = null;
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "", "Wed Dec 31 16:00:00 PST 1969", var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var8 = var5.createCopy(4, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.TimeSeries var47 = var44.createCopy(0, 100);
//     org.jfree.data.time.FixedMillisecond var48 = new org.jfree.data.time.FixedMillisecond();
//     long var49 = var48.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var44.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var48, 10.0d);
//     org.jfree.data.time.RegularTimePeriod var52 = var48.next();
//     java.util.Date var53 = var52.getEnd();
//     org.jfree.data.time.FixedMillisecond var54 = new org.jfree.data.time.FixedMillisecond(var53);
//     org.jfree.data.time.FixedMillisecond var55 = new org.jfree.data.time.FixedMillisecond(var53);
//     long var56 = var55.getSerialIndex();
//     long var57 = var55.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1419162664036L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1419162664037L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1419162664037L);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var4);
//     var5.removeAgedItems(true);
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     org.jfree.data.time.RegularTimePeriod var12 = var9.previous();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     long var14 = var13.getMiddleMillisecond();
//     int var15 = var9.compareTo((java.lang.Object)var13);
//     org.jfree.data.time.TimeSeries var16 = var5.createCopy((org.jfree.data.time.RegularTimePeriod)var8, (org.jfree.data.time.RegularTimePeriod)var9);
//     var5.setNotify(true);
//     java.util.List var19 = var5.getItems();
//     org.jfree.data.time.TimePeriodFormatException var21 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)"");
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var26);
//     var27.removeAgedItems(true);
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     long var32 = var31.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var33 = var31.next();
//     org.jfree.data.time.RegularTimePeriod var34 = var31.previous();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     long var36 = var35.getMiddleMillisecond();
//     int var37 = var31.compareTo((java.lang.Object)var35);
//     org.jfree.data.time.TimeSeries var38 = var27.createCopy((org.jfree.data.time.RegularTimePeriod)var30, (org.jfree.data.time.RegularTimePeriod)var31);
//     var27.setNotify(true);
//     java.util.List var41 = var27.getItems();
//     org.jfree.data.time.TimePeriodFormatException var43 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var27, (java.lang.Object)"");
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var47 = var27.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var45, 10.0d);
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     boolean var50 = var48.equals((java.lang.Object)(short)1);
//     org.jfree.data.time.Year var51 = new org.jfree.data.time.Year();
//     long var52 = var51.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var53 = var51.next();
//     org.jfree.data.time.RegularTimePeriod var54 = var51.previous();
//     org.jfree.data.time.Year var55 = new org.jfree.data.time.Year();
//     long var56 = var55.getMiddleMillisecond();
//     int var57 = var51.compareTo((java.lang.Object)var55);
//     int var58 = var48.compareTo((java.lang.Object)var51);
//     java.lang.Class var62 = null;
//     org.jfree.data.time.TimeSeries var63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var62);
//     var63.removeAgedItems(true);
//     var63.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var71 = null;
//     org.jfree.data.time.TimeSeries var72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var71);
//     var72.removeAgedItems(true);
//     org.jfree.data.time.Year var75 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var76 = new org.jfree.data.time.Year();
//     long var77 = var76.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var78 = var76.next();
//     org.jfree.data.time.RegularTimePeriod var79 = var76.previous();
//     org.jfree.data.time.Year var80 = new org.jfree.data.time.Year();
//     long var81 = var80.getMiddleMillisecond();
//     int var82 = var76.compareTo((java.lang.Object)var80);
//     org.jfree.data.time.TimeSeries var83 = var72.createCopy((org.jfree.data.time.RegularTimePeriod)var75, (org.jfree.data.time.RegularTimePeriod)var76);
//     org.jfree.data.time.Year var84 = new org.jfree.data.time.Year();
//     int var86 = var84.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var87 = var63.createCopy((org.jfree.data.time.RegularTimePeriod)var75, (org.jfree.data.time.RegularTimePeriod)var84);
//     var63.setMaximumItemAge(0L);
//     var63.setMaximumItemCount(10);
//     int var92 = var51.compareTo((java.lang.Object)var63);
//     org.jfree.data.time.RegularTimePeriod var93 = var51.next();
//     org.jfree.data.time.TimeSeries var94 = var5.createCopy((org.jfree.data.time.RegularTimePeriod)var45, (org.jfree.data.time.RegularTimePeriod)var51);
//     org.jfree.data.time.SerialDate var95 = var45.getSerialDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var96 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(21, var95);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var95);
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     long var30 = var29.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var31 = var29.next();
//     java.util.Date var32 = var31.getEnd();
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day(var32);
//     org.jfree.data.time.SerialDate var34 = var33.getSerialDate();
//     org.jfree.data.time.TimeSeriesDataItem var36 = var28.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)1419162651912L);
//     var28.setDomainDescription("1-January-2016");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var40 = var28.getValue(21);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(1, var6);
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.next();
//     java.util.Date var14 = var13.getEnd();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var15);
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addDays(2014, var16);
//     org.jfree.data.time.SerialDate var18 = var7.getEndOfCurrentMonth(var17);
//     org.jfree.data.time.SerialDate var20 = var18.getPreviousDayOfWeek(1);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addYears(4, var20);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var23 = var20.getFollowingDayOfWeek(10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1-January-2016"+ "'", var8.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
// 
//   }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.lang.String var3 = var0.toString();
//     long var4 = var0.getFirstMillisecond();
//     java.util.Calendar var5 = null;
//     long var6 = var0.getMiddleMillisecond(var5);
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, "1-January-2016", "December 2014", var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var9 = var7.getTimePeriod(4);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
// 
//   }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem(var16, (java.lang.Number)1419162646880L);
//     java.util.Date var21 = var16.getStart();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year(var21);
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(var21);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var28);
//     var29.removeAgedItems(true);
//     var29.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var37 = null;
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var37);
//     var38.removeAgedItems(true);
//     org.jfree.data.time.Year var41 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var42 = new org.jfree.data.time.Year();
//     long var43 = var42.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var44 = var42.next();
//     org.jfree.data.time.RegularTimePeriod var45 = var42.previous();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     long var47 = var46.getMiddleMillisecond();
//     int var48 = var42.compareTo((java.lang.Object)var46);
//     org.jfree.data.time.TimeSeries var49 = var38.createCopy((org.jfree.data.time.RegularTimePeriod)var41, (org.jfree.data.time.RegularTimePeriod)var42);
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year();
//     int var52 = var50.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var53 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var41, (org.jfree.data.time.RegularTimePeriod)var50);
//     org.jfree.data.time.RegularTimePeriod var54 = var41.previous();
//     long var55 = var41.getFirstMillisecond();
//     boolean var56 = var24.equals((java.lang.Object)var41);
//     java.util.Calendar var57 = null;
//     long var58 = var41.getLastMillisecond(var57);
// 
//   }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-457), var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     java.lang.String var5 = var4.getRangeDescription();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     boolean var8 = var6.equals((java.lang.Object)(short)1);
//     int var9 = var6.getYear();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var9, "hi!", "1-January-2016", var12);
//     java.lang.String var14 = var13.getDomainDescription();
//     java.lang.Object var15 = var13.clone();
//     boolean var16 = var4.equals((java.lang.Object)var13);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)9223372036854775807L);
//     var4.add(var19);
// 
//   }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     java.lang.String var29 = var28.getDescription();
//     org.jfree.data.time.TimeSeries var32 = var28.createCopy(0, 0);
//     java.lang.Class var36 = null;
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var36);
//     var37.removeAgedItems(true);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var41 = new org.jfree.data.time.Year();
//     long var42 = var41.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var43 = var41.next();
//     org.jfree.data.time.RegularTimePeriod var44 = var41.previous();
//     org.jfree.data.time.Year var45 = new org.jfree.data.time.Year();
//     long var46 = var45.getMiddleMillisecond();
//     int var47 = var41.compareTo((java.lang.Object)var45);
//     org.jfree.data.time.TimeSeries var48 = var37.createCopy((org.jfree.data.time.RegularTimePeriod)var40, (org.jfree.data.time.RegularTimePeriod)var41);
//     var37.setNotify(true);
//     java.util.List var51 = var37.getItems();
//     org.jfree.data.time.TimePeriodFormatException var53 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var54 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var37, (java.lang.Object)"");
//     org.jfree.data.time.Day var55 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var57 = var37.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var55, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var55, 0.0d);
//     org.jfree.data.time.TimeSeries var61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)2014);
//     boolean var62 = var55.equals((java.lang.Object)2014);
//     org.jfree.data.time.TimeSeriesDataItem var64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var55, 10.0d);
//     int var65 = var32.getIndex((org.jfree.data.time.RegularTimePeriod)var55);
//     java.util.Calendar var66 = null;
//     long var67 = var55.getFirstMillisecond(var66);
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     java.lang.Comparable var25 = var4.getKey();
//     java.util.List var26 = var4.getItems();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + 100L+ "'", var25.equals(100L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getMiddleMillisecond(var2);
//     java.util.Date var4 = var1.getStart();
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var4, var5);
// 
//   }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     int var2 = var0.compareTo((java.lang.Object)10.0f);
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getFirstMillisecond();
//     long var5 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014L);
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var3);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, "1-January-2016", "hi!", var7);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year(var3);
//     int var11 = var10.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2015);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("ERROR : Relative To String");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     long var25 = var22.getFirstMillisecond();
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var29);
//     var30.removeAgedItems(true);
//     var30.setKey((java.lang.Comparable)(byte)1);
//     boolean var35 = var22.equals((java.lang.Object)var30);
//     java.lang.Class var39 = null;
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var39);
//     var40.removeAgedItems(true);
//     java.beans.PropertyChangeListener var43 = null;
//     var40.removePropertyChangeListener(var43);
//     java.util.List var45 = var40.getItems();
//     var40.setRangeDescription("");
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var50 = null;
//     long var51 = var49.getMiddleMillisecond(var50);
//     long var52 = var49.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var54 = var40.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 100.0d);
//     boolean var55 = var22.equals((java.lang.Object)var49);
//     java.util.Calendar var56 = null;
//     long var57 = var49.getMiddleMillisecond(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1419148800000L);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var10);
//     var11.removeAgedItems(true);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     long var16 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.previous();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     int var21 = var15.compareTo((java.lang.Object)var19);
//     org.jfree.data.time.TimeSeries var22 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var15);
//     var11.setNotify(true);
//     java.util.List var25 = var11.getItems();
//     org.jfree.data.time.TimePeriodFormatException var27 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)"");
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var29, 10.0d);
//     boolean var32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var29);
//     int var33 = var29.getYear();
//     int var34 = var29.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 12);
// 
//   }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var4 = null;
//     var3.peg(var4);
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var10);
//     var11.removeAgedItems(true);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     long var16 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.previous();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     int var21 = var15.compareTo((java.lang.Object)var19);
//     org.jfree.data.time.TimeSeries var22 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var15);
//     var11.setNotify(true);
//     java.util.List var25 = var11.getItems();
//     org.jfree.data.time.TimePeriodFormatException var27 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)"");
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var29, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var29, 0.0d);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var34.getFirstMillisecond(var35);
//     boolean var37 = var33.equals((java.lang.Object)var36);
//     java.lang.Object var38 = var33.clone();
//     int var39 = var0.compareTo((java.lang.Object)var33);
//     org.jfree.data.time.FixedMillisecond var41 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
//     java.util.Calendar var42 = null;
//     long var43 = var41.getMiddleMillisecond(var42);
//     java.util.Calendar var44 = null;
//     long var45 = var41.getMiddleMillisecond(var44);
//     boolean var46 = var33.equals((java.lang.Object)var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1419162665125L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
// 
//   }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)(short)1);
//     int var3 = var0.getYear();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, "hi!", "1-January-2016", var6);
//     java.lang.String var8 = var7.getDomainDescription();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     var13.setNotify(true);
//     java.util.List var27 = var13.getItems();
//     org.jfree.data.time.TimePeriodFormatException var29 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var30 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)"");
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var33 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var31, 10.0d);
//     long var34 = var31.getFirstMillisecond();
//     java.lang.Class var38 = null;
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var38);
//     var39.removeAgedItems(true);
//     var39.setKey((java.lang.Comparable)(byte)1);
//     boolean var44 = var31.equals((java.lang.Object)var39);
//     org.jfree.data.time.RegularTimePeriod var45 = var31.next();
//     var7.add(var45, (java.lang.Number)1419162664036L, true);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(41994L);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     boolean var3 = var0.equals((java.lang.Object)(byte)0);
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     int var6 = var0.getYearValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2014);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-457));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var23 = var21.next();
//     java.util.Date var24 = var23.getEnd();
//     var4.delete(var23);
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var27 = var26.getYear();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var30 = var29.next();
//     org.jfree.data.time.Year var31 = var29.getYear();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var35 = var33.next();
//     java.util.Date var36 = var35.getEnd();
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var36);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.addDays(1, var37);
//     java.lang.String var39 = var38.toString();
//     java.lang.String var40 = var38.toString();
//     var38.setDescription("1-January-2016");
//     var38.setDescription("3-January-2016");
//     java.lang.String var45 = var38.getDescription();
//     boolean var46 = var29.equals((java.lang.Object)var38);
//     org.jfree.data.time.TimeSeries var47 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var26, (org.jfree.data.time.RegularTimePeriod)var29);
//     org.jfree.data.time.RegularTimePeriod var48 = var29.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "December 2014"+ "'", var28.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "1-January-2016"+ "'", var39.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "1-January-2016"+ "'", var40.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var45 + "' != '" + "3-January-2016"+ "'", var45.equals("3-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)(short)1);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     long var4 = var3.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var5 = var3.next();
//     org.jfree.data.time.RegularTimePeriod var6 = var3.previous();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     long var8 = var7.getMiddleMillisecond();
//     int var9 = var3.compareTo((java.lang.Object)var7);
//     int var10 = var0.compareTo((java.lang.Object)var3);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var14);
//     var15.removeAgedItems(true);
//     var15.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var23);
//     var24.removeAgedItems(true);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     long var29 = var28.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var30 = var28.next();
//     org.jfree.data.time.RegularTimePeriod var31 = var28.previous();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     int var34 = var28.compareTo((java.lang.Object)var32);
//     org.jfree.data.time.TimeSeries var35 = var24.createCopy((org.jfree.data.time.RegularTimePeriod)var27, (org.jfree.data.time.RegularTimePeriod)var28);
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     int var38 = var36.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var39 = var15.createCopy((org.jfree.data.time.RegularTimePeriod)var27, (org.jfree.data.time.RegularTimePeriod)var36);
//     var15.setMaximumItemAge(0L);
//     var15.setMaximumItemCount(10);
//     int var44 = var3.compareTo((java.lang.Object)var15);
//     java.lang.Class var48 = null;
//     org.jfree.data.time.TimeSeries var49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var48);
//     var49.removeAgedItems(true);
//     java.beans.PropertyChangeListener var52 = null;
//     var49.removePropertyChangeListener(var52);
//     boolean var54 = var49.isEmpty();
//     var49.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var57 = new org.jfree.data.time.Day();
//     boolean var59 = var57.equals((java.lang.Object)(short)1);
//     int var60 = var57.getYear();
//     org.jfree.data.time.RegularTimePeriod var61 = var57.previous();
//     org.jfree.data.time.TimeSeriesDataItem var63 = var49.addOrUpdate(var61, (java.lang.Number)100.0f);
//     org.jfree.data.time.TimeSeriesDataItem var65 = new org.jfree.data.time.TimeSeriesDataItem(var61, (java.lang.Number)1419162646880L);
//     java.util.Date var66 = var61.getStart();
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.createInstance(var66);
//     org.jfree.data.time.Year var68 = new org.jfree.data.time.Year(var66);
//     org.jfree.data.time.Month var69 = new org.jfree.data.time.Month(var66);
//     org.jfree.data.time.TimeSeriesDataItem var71 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var69, (java.lang.Number)10);
//     int var72 = var69.getYearValue();
//     java.lang.Class var76 = null;
//     org.jfree.data.time.TimeSeries var77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var76);
//     var77.removeAgedItems(true);
//     org.jfree.data.time.Year var80 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var81 = new org.jfree.data.time.Year();
//     long var82 = var81.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var83 = var81.next();
//     org.jfree.data.time.RegularTimePeriod var84 = var81.previous();
//     org.jfree.data.time.Year var85 = new org.jfree.data.time.Year();
//     long var86 = var85.getMiddleMillisecond();
//     int var87 = var81.compareTo((java.lang.Object)var85);
//     org.jfree.data.time.TimeSeries var88 = var77.createCopy((org.jfree.data.time.RegularTimePeriod)var80, (org.jfree.data.time.RegularTimePeriod)var81);
//     int var89 = var69.compareTo((java.lang.Object)var81);
//     var15.add((org.jfree.data.time.RegularTimePeriod)var69, 0.0d, true);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     long var25 = var22.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var26 = var22.previous();
//     long var27 = var22.getSerialIndex();
//     java.util.Calendar var28 = null;
//     var22.peg(var28);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("December");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(1, 2147483647, 12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(100, 2015);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var23 = var21.next();
//     java.util.Date var24 = var23.getEnd();
//     var4.delete(var23);
//     var4.setMaximumItemCount(10);
//     java.beans.PropertyChangeListener var28 = null;
//     var4.addPropertyChangeListener(var28);
//     java.util.Collection var30 = var4.getTimePeriods();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     java.util.Date var35 = var34.getEnd();
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(var35);
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.addDays(1, var36);
//     java.lang.String var38 = var37.toString();
//     var4.setKey((java.lang.Comparable)var38);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var41 = var4.getDataItem(2015);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var38 + "' != '" + "1-January-2016"+ "'", var38.equals("1-January-2016"));
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, 28, 27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     int var2 = var0.compareTo((java.lang.Object)10.0f);
//     java.util.Calendar var3 = null;
//     long var4 = var0.getLastMillisecond(var3);
// 
//   }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.TimeSeries var47 = var44.createCopy(0, 100);
//     java.lang.Class var51 = null;
//     org.jfree.data.time.TimeSeries var52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var51);
//     var52.removeAgedItems(true);
//     java.beans.PropertyChangeListener var55 = null;
//     var52.removePropertyChangeListener(var55);
//     boolean var57 = var52.isEmpty();
//     var52.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var60 = new org.jfree.data.time.Day();
//     boolean var62 = var60.equals((java.lang.Object)(short)1);
//     int var63 = var60.getYear();
//     org.jfree.data.time.RegularTimePeriod var64 = var60.previous();
//     org.jfree.data.time.TimeSeriesDataItem var66 = var52.addOrUpdate(var64, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var67 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var68 = var52.getDataItem((org.jfree.data.time.RegularTimePeriod)var67);
//     java.lang.Class var72 = null;
//     org.jfree.data.time.TimeSeries var73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var72);
//     var73.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var76 = var52.addAndOrUpdate(var73);
//     org.jfree.data.time.Year var77 = new org.jfree.data.time.Year();
//     long var78 = var77.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var79 = var77.next();
//     org.jfree.data.time.RegularTimePeriod var80 = var77.previous();
//     long var81 = var77.getLastMillisecond();
//     var73.delete((org.jfree.data.time.RegularTimePeriod)var77);
//     var44.delete((org.jfree.data.time.RegularTimePeriod)var77);
//     org.jfree.data.time.Month var84 = new org.jfree.data.time.Month();
//     long var85 = var84.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var86 = var84.previous();
//     int var87 = var77.compareTo((java.lang.Object)var84);
//     java.util.Calendar var88 = null;
//     long var89 = var84.getFirstMillisecond(var88);
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var11, 1.0d);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var18);
//     var19.removeAgedItems(true);
//     var19.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var27);
//     var28.removeAgedItems(true);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.next();
//     org.jfree.data.time.RegularTimePeriod var35 = var32.previous();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     int var38 = var32.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.TimeSeries var39 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     int var42 = var40.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var43 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.TimeSeries var44 = var4.addAndOrUpdate(var19);
//     org.jfree.data.time.TimeSeries var47 = var44.createCopy(0, 100);
//     var47.setDescription("");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var47.delete(31, 0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1435867199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
// 
//   }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     var4.setKey((java.lang.Comparable)(byte)1);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var12);
//     var13.removeAgedItems(true);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     int var23 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var24 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)10.0f);
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var25);
//     var4.setMaximumItemAge(0L);
//     var4.setMaximumItemCount(10);
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var35 = var33.next();
//     org.jfree.data.time.TimeSeriesDataItem var37 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)1420099199999L);
//     long var38 = var33.getSerialIndex();
//     java.lang.String var39 = var33.toString();
//     java.util.Calendar var40 = null;
//     long var41 = var33.getLastMillisecond(var40);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 2014);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var10);
//     var11.removeAgedItems(true);
//     java.beans.PropertyChangeListener var14 = null;
//     var11.removePropertyChangeListener(var14);
//     boolean var16 = var11.isEmpty();
//     var11.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     boolean var21 = var19.equals((java.lang.Object)(short)1);
//     int var22 = var19.getYear();
//     org.jfree.data.time.RegularTimePeriod var23 = var19.previous();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var11.addOrUpdate(var23, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var27 = var11.getDataItem((org.jfree.data.time.RegularTimePeriod)var26);
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var31);
//     var32.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var35 = var11.addAndOrUpdate(var32);
//     int var36 = var4.compareTo((java.lang.Object)var35);
//     int var37 = var4.getYear();
//     java.util.Calendar var38 = null;
//     long var39 = var4.getLastMillisecond(var38);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     long var8 = var7.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var9 = var7.next();
//     org.jfree.data.time.RegularTimePeriod var10 = var7.previous();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     long var12 = var11.getMiddleMillisecond();
//     int var13 = var7.compareTo((java.lang.Object)var11);
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)1388563200000L);
//     var4.add(var15);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var30);
//     var31.removeAgedItems(true);
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     long var36 = var35.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var37 = var35.next();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.previous();
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     long var40 = var39.getMiddleMillisecond();
//     int var41 = var35.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.TimeSeries var42 = var31.createCopy((org.jfree.data.time.RegularTimePeriod)var34, (org.jfree.data.time.RegularTimePeriod)var35);
//     var31.setNotify(true);
//     java.util.List var45 = var31.getItems();
//     org.jfree.data.time.TimePeriodFormatException var47 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var48 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var31, (java.lang.Object)"");
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var31.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 0.0d);
//     int var54 = var26.compareTo((java.lang.Object)var53);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var55 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var54);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var15.removeChangeListener(var16);
//     java.beans.PropertyChangeListener var18 = null;
//     var15.addPropertyChangeListener(var18);
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var23);
//     var24.removeAgedItems(true);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     long var29 = var28.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var30 = var28.next();
//     org.jfree.data.time.RegularTimePeriod var31 = var28.previous();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     int var34 = var28.compareTo((java.lang.Object)var32);
//     org.jfree.data.time.TimeSeries var35 = var24.createCopy((org.jfree.data.time.RegularTimePeriod)var27, (org.jfree.data.time.RegularTimePeriod)var28);
//     var24.setNotify(true);
//     java.util.List var38 = var24.getItems();
//     org.jfree.data.time.TimePeriodFormatException var40 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var24, (java.lang.Object)"");
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var44 = var24.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var42, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var42, 0.0d);
//     java.lang.Class var50 = null;
//     org.jfree.data.time.TimeSeries var51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var50);
//     var51.removeAgedItems(true);
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var55 = new org.jfree.data.time.Year();
//     long var56 = var55.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var57 = var55.next();
//     org.jfree.data.time.RegularTimePeriod var58 = var55.previous();
//     org.jfree.data.time.Year var59 = new org.jfree.data.time.Year();
//     long var60 = var59.getMiddleMillisecond();
//     int var61 = var55.compareTo((java.lang.Object)var59);
//     org.jfree.data.time.TimeSeries var62 = var51.createCopy((org.jfree.data.time.RegularTimePeriod)var54, (org.jfree.data.time.RegularTimePeriod)var55);
//     var51.setNotify(true);
//     java.util.List var65 = var51.getItems();
//     org.jfree.data.time.TimePeriodFormatException var67 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var68 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var51, (java.lang.Object)"");
//     org.jfree.data.time.Day var69 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var71 = var51.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var69, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var73 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var69, 0.0d);
//     int var74 = var46.compareTo((java.lang.Object)var73);
//     java.lang.Number var75 = var46.getValue();
//     var15.add(var46);
// 
//   }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var31 = var4.createCopy(21, (-41977));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1419148800000L);
    java.util.Calendar var2 = null;
    long var3 = var1.getMiddleMillisecond(var2);
    long var4 = var1.getFirstMillisecond();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var4);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1419148800000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1419148800000L);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var7 = null;
//     var4.removePropertyChangeListener(var7);
//     boolean var9 = var4.isEmpty();
//     var4.setKey((java.lang.Comparable)0.0d);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var4.addOrUpdate(var16, (java.lang.Number)100.0f);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var24);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var25);
//     java.lang.String var29 = var28.getDescription();
//     org.jfree.data.time.TimeSeries var32 = var28.createCopy(0, 0);
//     java.lang.Comparable var33 = var28.getKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "Overwritten values from: 0.0"+ "'", var33.equals("Overwritten values from: 0.0"));
// 
//   }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var28);
//     var29.removeAgedItems(true);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var35 = var33.next();
//     org.jfree.data.time.RegularTimePeriod var36 = var33.previous();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     long var38 = var37.getMiddleMillisecond();
//     int var39 = var33.compareTo((java.lang.Object)var37);
//     org.jfree.data.time.TimeSeries var40 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var32, (org.jfree.data.time.RegularTimePeriod)var33);
//     var29.setNotify(true);
//     java.util.List var43 = var29.getItems();
//     org.jfree.data.time.TimePeriodFormatException var45 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var29, (java.lang.Object)"");
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var49 = var29.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var47, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, 0.0d);
//     org.jfree.data.time.TimeSeries var53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)2014);
//     boolean var54 = var47.equals((java.lang.Object)2014);
//     org.jfree.data.time.SerialDate var55 = var47.getSerialDate();
//     var4.setKey((java.lang.Comparable)var47);
//     java.util.Calendar var57 = null;
//     long var58 = var47.getFirstMillisecond(var57);
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)(short)1);
//     int var3 = var0.getYear();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, "hi!", "1-January-2016", var6);
//     org.jfree.data.time.RegularTimePeriod var8 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var7.add(var8, (java.lang.Number)1419162662215L);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addDays(1, var5);
//     java.lang.String var7 = var6.toString();
//     java.lang.String var8 = var6.getDescription();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.next();
//     java.util.Date var14 = var13.getEnd();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addDays(1, var15);
//     java.lang.String var17 = var16.toString();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addYears((-1), var16);
//     org.jfree.data.time.SerialDate var19 = var6.getEndOfCurrentMonth(var16);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var23 = var21.next();
//     java.util.Date var24 = var23.getEnd();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var25);
//     java.lang.String var27 = var25.toString();
//     org.jfree.data.time.SerialDate var28 = var16.getEndOfCurrentMonth(var25);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day(var25);
//     int var30 = var29.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "1-January-2016"+ "'", var7.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "1-January-2016"+ "'", var17.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "31-December-2015"+ "'", var27.equals("31-December-2015"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 2015);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     org.jfree.data.time.RegularTimePeriod var4 = var1.previous();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     long var6 = var5.getMiddleMillisecond();
//     int var7 = var1.compareTo((java.lang.Object)var5);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var11);
//     var12.removeAgedItems(true);
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     long var17 = var16.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var18 = var16.next();
//     org.jfree.data.time.RegularTimePeriod var19 = var16.previous();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     long var21 = var20.getMiddleMillisecond();
//     int var22 = var16.compareTo((java.lang.Object)var20);
//     org.jfree.data.time.TimeSeries var23 = var12.createCopy((org.jfree.data.time.RegularTimePeriod)var15, (org.jfree.data.time.RegularTimePeriod)var16);
//     var12.setNotify(true);
//     java.util.List var26 = var12.getItems();
//     org.jfree.data.time.TimePeriodFormatException var28 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var12, (java.lang.Object)"");
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var30, 10.0d);
//     boolean var33 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var30);
//     long var34 = var30.getSerialIndex();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     long var38 = var37.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var39 = var37.next();
//     java.util.Date var40 = var39.getEnd();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(var40);
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.addDays(1, var41);
//     java.lang.String var43 = var42.toString();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     long var47 = var46.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var48 = var46.next();
//     java.util.Date var49 = var48.getEnd();
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.createInstance(var49);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var50);
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.addDays(2014, var51);
//     org.jfree.data.time.SerialDate var53 = var42.getEndOfCurrentMonth(var52);
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.addMonths(1, var42);
//     boolean var55 = var30.equals((java.lang.Object)1);
//     int var56 = var30.getDayOfMonth();
//     org.jfree.data.time.SerialDate var57 = var30.getSerialDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(28, var57);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + "1-January-2016"+ "'", var43.equals("1-January-2016"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Sun Dec 21 03:50:49 PST 2014");

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var8.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeries var15 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var4.setNotify(true);
//     java.util.List var18 = var4.getItems();
//     org.jfree.data.time.TimePeriodFormatException var20 = new org.jfree.data.time.TimePeriodFormatException("");
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
//     java.util.Date var27 = var22.getEnd();
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day(var27);
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

}
