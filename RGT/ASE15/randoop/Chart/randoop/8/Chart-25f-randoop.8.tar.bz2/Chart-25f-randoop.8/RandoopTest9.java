
import junit.framework.*;

public class RandoopTest9 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test1"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
    double var7 = var6.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var9 = var6.getRowRenderingOrder();
    java.awt.Stroke var10 = var6.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var6.getRendererForDataset(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var6);
    boolean var14 = var0.hasListener((java.util.EventListener)var13);
    java.awt.Shape var16 = var0.lookupSeriesShape(10);
    org.jfree.chart.urls.CategoryURLGenerator var19 = var0.getURLGenerator(255, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test2"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var2 = var0.getTickUnit();
    var0.setAutoTickUnitSelection(false);
    double var5 = var0.getUpperMargin();
    java.text.NumberFormat var6 = null;
    var0.setNumberFormatOverride(var6);
    double var8 = var0.getFixedAutoRange();
    org.jfree.chart.axis.MarkerAxisBand var9 = null;
    var0.setMarkerBand(var9);
    var0.setFixedDimension(0.0d);
    var0.setUpperBound(1.9999999999999998d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test3"); }


    java.lang.Comparable var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("SortOrder.ASCENDING");
    org.jfree.data.KeyedObject var3 = new org.jfree.data.KeyedObject(var0, (java.lang.Object)var2);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test4"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var2 = var0.getIndex((java.lang.Comparable)0);
    java.lang.Comparable var4 = var0.getKey((-16777215));
    java.lang.Object var5 = var0.clone();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var6, var7, var8, var9);
    double var11 = var10.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var12 = var10.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var13 = null;
    java.util.List var14 = var10.getCategoriesForAxis(var13);
    double var15 = var10.getAnchorValue();
    var10.clearDomainMarkers();
    var10.mapDatasetToRangeAxis(1, (-253));
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    double var21 = var20.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var22 = var20.getTickUnit();
    org.jfree.data.Range var23 = var10.getDataRange((org.jfree.chart.axis.ValueAxis)var20);
    boolean var24 = var20.isAutoRange();
    org.jfree.chart.axis.NumberTickUnit var26 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    org.jfree.chart.block.LabelBlock var28 = new org.jfree.chart.block.LabelBlock("hi!");
    java.lang.String var29 = var28.getID();
    int var30 = var26.compareTo((java.lang.Object)var28);
    java.lang.String var32 = var26.valueToString(1.0d);
    var20.setTickUnit(var26, false, false);
    java.lang.Object var36 = null;
    var0.addObject((java.lang.Comparable)false, var36);
    java.lang.Comparable var39 = var0.getKey((-1572964));
    java.lang.Object var40 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "1"+ "'", var32.equals("1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test5"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
    var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var10 = var4.getBounds();
    org.jfree.chart.util.RectangleAnchor var11 = null;
    java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
    org.jfree.chart.util.RectangleEdge var13 = null;
    double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
    var0.setMaximumCategoryLabelLines(10);
    float var17 = var0.getMaximumCategoryLabelWidthRatio();
    var0.setTickMarkInsideLength(100.0f);
    java.awt.Paint var20 = var0.getTickMarkPaint();
    java.awt.Paint var22 = var0.getTickLabelPaint((java.lang.Comparable)"TextAnchor.CENTER");
    java.lang.String var24 = var0.getCategoryLabelToolTip((java.lang.Comparable)"TextAnchor.CENTER");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test6"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.setCopyright("org.jfree.data.general.DatasetChangeEvent[source=-1]");
    var0.setInfo("ChartEntity: tooltip = hi!");
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var6 = var5.getInsets();
    org.jfree.chart.util.RectangleInsets var7 = var5.getInsets();
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
    double var13 = var12.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var14 = var12.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var15 = null;
    java.util.List var16 = var12.getCategoriesForAxis(var15);
    double var17 = var12.getAnchorValue();
    var12.clearDomainAxes();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder(var7, var20);
    boolean var22 = var0.equals((java.lang.Object)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test7"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setNegativeArrowVisible(false);
    org.jfree.chart.axis.MarkerAxisBand var3 = var0.getMarkerBand();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var5 = var4.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var4.getLegendItemToolTipGenerator();
    java.awt.Shape var8 = var4.lookupSeriesShape(0);
    var4.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var12 = null;
    var4.setSeriesURLGenerator(0, var12);
    var4.setItemMargin(6.0d);
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.axis.CategoryAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
    double var21 = var20.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var22 = var20.getDrawingSupplier();
    var20.clearAnnotations();
    var4.setPlot(var20);
    java.lang.Object var25 = var20.clone();
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var20);
    org.jfree.chart.axis.CategoryAxis var27 = var20.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var29 = var20.getDomainAxisEdge(100);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var31 = var30.getBasePositiveItemLabelPosition();
    boolean var32 = var30.getAutoPopulateSeriesStroke();
    var30.setBaseCreateEntities(true, true);
    var20.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test8"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     org.jfree.chart.util.RectangleInsets var12 = var10.getMargin();
//     double var13 = var10.getHeight();
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var19 = new org.jfree.chart.entity.TickLabelEntity(var16, "hi!", "hi!");
//     org.jfree.data.Range var20 = null;
//     org.jfree.data.Range var21 = null;
//     org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint(var20, var21);
//     boolean var23 = var19.equals((java.lang.Object)var20);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var19.setArea(var26);
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var28, var29, var30, var31);
//     double var33 = var32.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var34 = var32.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     java.util.List var36 = var32.getCategoriesForAxis(var35);
//     double var37 = var32.getAnchorValue();
//     java.awt.Color var40 = java.awt.Color.getColor("", 1);
//     var32.setOutlinePaint((java.awt.Paint)var40);
//     java.awt.Stroke var42 = var32.getDomainGridlineStroke();
//     java.awt.Color var45 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var46 = var45.getColorSpace();
//     java.awt.image.ColorModel var47 = null;
//     java.awt.Rectangle var48 = null;
//     org.jfree.chart.block.LabelBlock var50 = new org.jfree.chart.block.LabelBlock("hi!");
//     var50.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var56 = var50.getBounds();
//     java.awt.geom.AffineTransform var57 = null;
//     java.awt.RenderingHints var58 = null;
//     java.awt.PaintContext var59 = var45.createContext(var47, var48, var56, var57, var58);
//     var32.setNoDataMessagePaint((java.awt.Paint)var45);
//     org.jfree.chart.title.LegendGraphic var61 = new org.jfree.chart.title.LegendGraphic(var26, (java.awt.Paint)var45);
//     java.awt.Shape var62 = var61.getShape();
//     double var63 = var61.getContentXOffset();
//     boolean var64 = var61.isShapeFilled();
//     org.jfree.chart.util.GradientPaintTransformer var65 = var61.getFillPaintTransformer();
//     org.jfree.chart.util.RectangleAnchor var66 = var61.getShapeAnchor();
//     var10.setLegendItemGraphicLocation(var66);
//     
//     // Checks the contract:  equals-hashcode on var6 and var34
//     assertTrue("Contract failed: equals-hashcode on var6 and var34", var6.equals(var34) ? var6.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var6
//     assertTrue("Contract failed: equals-hashcode on var34 and var6", var34.equals(var6) ? var34.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test9"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var1 = var0.getLeftArrow();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
    double var7 = var6.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var9 = null;
    java.util.List var10 = var6.getCategoriesForAxis(var9);
    double var11 = var6.getAnchorValue();
    org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Paint var13 = var12.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var14 = var12.getPadding();
    var0.setTickLabelInsets(var14);
    boolean var16 = var0.isTickMarksVisible();
    var0.setAutoTickUnitSelection(false, true);
    boolean var20 = var0.isInverted();
    boolean var21 = var0.getAutoRangeStickyZero();
    boolean var22 = var0.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test10"); }


    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var11 = var8.getRowRenderingOrder();
    java.awt.Stroke var12 = var8.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = var8.getRendererForDataset(var13);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var8);
    java.util.List var16 = var15.getSubtitles();
    org.jfree.chart.ChartRenderingInfo var21 = null;
    java.awt.image.BufferedImage var22 = var15.createBufferedImage(1, 10, (-1.0d), 1.0d, var21);
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "", (java.awt.Image)var22, "org.jfree.chart.event.ChartChangeEvent[source=0]", "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", "10");
    var26.setLicenceName("RectangleConstraintType.RANGE");
    java.lang.String var29 = var26.getCopyright();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var31 = var30.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var32 = var30.getLegendItemToolTipGenerator();
    java.awt.Shape var34 = var30.lookupSeriesShape(0);
    var30.setAutoPopulateSeriesFillPaint(true);
    var30.setAutoPopulateSeriesStroke(true);
    java.awt.Paint var40 = var30.getSeriesFillPaint((-16777216));
    var30.setBaseCreateEntities(true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var43 = null;
    var30.setBaseItemLabelGenerator(var43);
    java.awt.Paint var45 = var30.getBaseOutlinePaint();
    boolean var46 = var26.equals((java.lang.Object)var45);
    org.jfree.chart.ui.Library var51 = new org.jfree.chart.ui.Library("org.jfree.chart.event.ChartChangeEvent[source=0]", "Size2D[width=-1.0, height=-1.0]", "RectangleConstraintType.RANGE", "CONTRACT");
    var26.addLibrary(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=0]"+ "'", var29.equals("org.jfree.chart.event.ChartChangeEvent[source=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test11"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
    var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var10 = var4.getBounds();
    org.jfree.chart.util.RectangleAnchor var11 = null;
    java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
    org.jfree.chart.util.RectangleEdge var13 = null;
    double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
    var0.setTickMarkOutsideLength(0.0f);
    org.jfree.chart.util.RectangleInsets var17 = var0.getLabelInsets();
    float var18 = var0.getTickMarkOutsideLength();
    var0.setUpperMargin(100.0d);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
    double var26 = var25.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var27 = var25.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var28 = null;
    java.util.List var29 = var25.getCategoriesForAxis(var28);
    double var30 = var25.getAnchorValue();
    var25.clearDomainAxes();
    org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
    java.awt.RenderingHints var33 = var32.getRenderingHints();
    var32.setBackgroundImageAlpha(0.0f);
    java.lang.Object var36 = var32.getTextAntiAlias();
    var32.removeLegend();
    org.jfree.chart.event.ChartProgressEvent var40 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var32, 0, 100);
    java.awt.Paint var41 = var0.getTickMarkPaint();
    java.awt.Paint var42 = var0.getLabelPaint();
    java.awt.Paint var44 = var0.getTickLabelPaint((java.lang.Comparable)"MAJOR");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test12"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(0.0d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test13"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var1.setAlpha(0.0f);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var11 = null;
    java.util.List var12 = var8.getCategoriesForAxis(var11);
    double var13 = var8.getAnchorValue();
    var8.clearDomainMarkers();
    org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("");
    double var17 = var16.getHeight();
    java.awt.Paint var18 = var16.getPaint();
    var8.setRangeCrosshairPaint(var18);
    int var20 = var8.getDomainAxisCount();
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    java.awt.Color var24 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
    var8.setRangeCrosshairPaint((java.awt.Paint)var24);
    var1.setLabelPaint((java.awt.Paint)var24);
    java.awt.Color var27 = var24.brighter();
    java.awt.Color var28 = var27.brighter();
    java.awt.Color var29 = var28.brighter();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test14"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     java.awt.Paint var15 = var14.getPaint();
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
//     double var21 = var20.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var22 = var20.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     java.util.List var24 = var20.getCategoriesForAxis(var23);
//     double var25 = var20.getAnchorValue();
//     var20.clearDomainAxes();
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var20);
//     org.jfree.chart.title.LegendTitle var29 = var27.getLegend(10);
//     var27.setBorderVisible(true);
//     var14.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var27);
//     
//     // Checks the contract:  equals-hashcode on var5 and var20
//     assertTrue("Contract failed: equals-hashcode on var5 and var20", var5.equals(var20) ? var5.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var5
//     assertTrue("Contract failed: equals-hashcode on var20 and var5", var20.equals(var5) ? var20.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var22
//     assertTrue("Contract failed: equals-hashcode on var7 and var22", var7.equals(var22) ? var7.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var7
//     assertTrue("Contract failed: equals-hashcode on var22 and var7", var22.equals(var7) ? var22.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test15"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
    java.lang.String var1 = var0.getID();
    org.jfree.chart.block.BlockBorder var2 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var3 = var2.getInsets();
    org.jfree.chart.util.UnitType var4 = var3.getUnitType();
    java.awt.Color var7 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var8 = var7.getColorSpace();
    java.awt.image.ColorModel var9 = null;
    java.awt.Rectangle var10 = null;
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("hi!");
    var12.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var18 = var12.getBounds();
    java.awt.geom.AffineTransform var19 = null;
    java.awt.RenderingHints var20 = null;
    java.awt.PaintContext var21 = var7.createContext(var9, var10, var18, var19, var20);
    var3.trim(var18);
    boolean var23 = var0.equals((java.lang.Object)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "NOID"+ "'", var1.equals("NOID"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test16"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
    double var3 = var2.getHeight();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Font var5 = var2.getFont();
    var0.setLabelFont(var5);
    var0.setUpperMargin(100.0d);
    org.jfree.chart.axis.CategoryLabelPositions var10 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0d);
    var0.setCategoryLabelPositions(var10);
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    double var18 = var17.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var19 = var17.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var20 = null;
    java.util.List var21 = var17.getCategoriesForAxis(var20);
    double var22 = var17.getAnchorValue();
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    java.awt.Paint var24 = var23.getBackgroundPaint();
    java.awt.Font var25 = var23.getItemFont();
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("hi!", var25);
    org.jfree.chart.util.RectangleEdge var27 = var26.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var28 = var10.getLabelPosition(var27);
    double var29 = var28.getAngle();
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("hi!");
    var35.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var41 = var35.getBounds();
    org.jfree.chart.util.RectangleAnchor var42 = null;
    java.awt.geom.Point2D var43 = org.jfree.chart.util.RectangleAnchor.coordinates(var41, var42);
    org.jfree.chart.util.RectangleEdge var44 = null;
    double var45 = var31.getCategoryStart((-16777216), (-16777216), var41, var44);
    org.jfree.chart.entity.CategoryLabelEntity var48 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var41, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
    java.lang.String var49 = var48.toString();
    java.awt.Shape var50 = var48.getArea();
    org.jfree.chart.event.ChartChangeEvent var51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var50);
    boolean var52 = var28.equals((java.lang.Object)var50);
    org.jfree.chart.text.TextBlockAnchor var53 = var28.getLabelAnchor();
    float var54 = var28.getWidthRatio();
    double var55 = var28.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="+ "'", var49.equals("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == (-1.0d));

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test17"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.TickUnitSource var2 = var0.getStandardTickUnits();
    var0.setAutoRangeStickyZero(false);
    double var5 = var0.getLowerBound();
    var0.setTickMarksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test18"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    java.awt.Stroke var14 = var4.getDomainGridlineStroke();
    org.jfree.chart.axis.ValueAxis var15 = var4.getRangeAxis();
    var4.setWeight((-16777216));
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var19, var20, var21, var22);
    double var24 = var23.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var25 = var23.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    int var27 = var23.getIndexOf(var26);
    java.util.List var28 = var23.getCategories();
    var23.configureDomainAxes();
    org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var31.setAlpha(0.0f);
    java.awt.Stroke var34 = var31.getOutlineStroke();
    var23.addRangeMarker((org.jfree.chart.plot.Marker)var31);
    org.jfree.chart.text.TextAnchor var36 = var31.getLabelTextAnchor();
    org.jfree.chart.util.Layer var37 = null;
    var4.addRangeMarker((-16777216), (org.jfree.chart.plot.Marker)var31, var37);
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var43 = new org.jfree.chart.block.LabelBlock("hi!");
    var43.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var49 = var43.getBounds();
    org.jfree.chart.util.RectangleAnchor var50 = null;
    java.awt.geom.Point2D var51 = org.jfree.chart.util.RectangleAnchor.coordinates(var49, var50);
    org.jfree.chart.util.RectangleEdge var52 = null;
    double var53 = var39.getCategoryStart((-16777216), (-16777216), var49, var52);
    var39.setTickMarkOutsideLength(0.0f);
    org.jfree.chart.util.RectangleInsets var56 = var39.getLabelInsets();
    var31.setLabelOffset(var56);
    org.jfree.chart.text.TextAnchor var58 = var31.getLabelTextAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test19"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainMarkers();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("");
    double var14 = var13.getHeight();
    java.awt.Paint var15 = var13.getPaint();
    java.awt.Font var16 = var13.getFont();
    var11.setLabelFont(var16);
    var11.setMaximumCategoryLabelLines(15);
    org.jfree.chart.util.RectangleInsets var20 = var11.getLabelInsets();
    java.awt.Font var22 = var11.getTickLabelFont((java.lang.Comparable)"org.jfree.chart.event.ChartChangeEvent[source=0]");
    var4.setNoDataMessageFont(var22);
    var4.configureRangeAxes();
    org.jfree.chart.LegendItemCollection var25 = var4.getLegendItems();
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var4.getDomainMarkers(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test20"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(0, var8);
    java.awt.Paint var11 = var0.getSeriesFillPaint(0);
    boolean var12 = var0.isDrawBarOutline();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = null;
    var0.setSeriesItemLabelGenerator(3, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test21"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getColumnIndex((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=1]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((-1572964));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test22"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Paint var10 = var4.getOutlinePaint();
    java.awt.Paint var11 = var4.getRangeGridlinePaint();
    float var12 = var4.getBackgroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0f);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test23"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.RectangleEdge var6 = var4.getDomainAxisEdge((-1));
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var11 = new org.jfree.chart.block.LabelBlock("hi!");
//     var11.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var17 = var11.getBounds();
//     org.jfree.chart.util.RectangleAnchor var18 = null;
//     java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var17, var18);
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var7.getCategoryStart((-16777216), (-16777216), var17, var20);
//     var7.setMaximumCategoryLabelLines(10);
//     float var24 = var7.getMaximumCategoryLabelWidthRatio();
//     java.util.List var25 = var4.getCategoriesForAxis(var7);
//     org.jfree.chart.axis.CategoryLabelPositions var26 = var7.getCategoryLabelPositions();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var28 = var27.getRowCount();
//     java.awt.Paint var29 = var27.getBasePaint();
//     java.awt.Stroke var31 = var27.getSeriesStroke(1);
//     var27.setItemMargin(0.05d);
//     var27.setAutoPopulateSeriesShape(false);
//     org.jfree.chart.axis.CategoryLabelPositions var37 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     org.jfree.chart.axis.CategoryLabelPosition var39 = var37.getLabelPosition(var38);
//     boolean var41 = var37.equals((java.lang.Object)false);
//     org.jfree.chart.axis.CategoryLabelPositions var43 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
//     org.jfree.data.category.CategoryDataset var44 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
//     org.jfree.chart.util.RectangleEdge var50 = var48.getDomainAxisEdge((-1));
//     java.lang.String var51 = var50.toString();
//     org.jfree.chart.axis.CategoryLabelPosition var52 = var43.getLabelPosition(var50);
//     org.jfree.chart.axis.CategoryLabelPositions var53 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var37, var52);
//     boolean var54 = var27.equals((java.lang.Object)var52);
//     org.jfree.chart.text.TextAnchor var55 = var52.getRotationAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var56 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var26, var52);
//     
//     // Checks the contract:  equals-hashcode on var4 and var48
//     assertTrue("Contract failed: equals-hashcode on var4 and var48", var4.equals(var48) ? var4.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var4
//     assertTrue("Contract failed: equals-hashcode on var48 and var4", var48.equals(var4) ? var48.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test24"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    var0.setItemMargin(0.05d);
    var0.setAutoPopulateSeriesShape(false);
    org.jfree.chart.axis.CategoryLabelPositions var10 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.util.RectangleEdge var11 = null;
    org.jfree.chart.axis.CategoryLabelPosition var12 = var10.getLabelPosition(var11);
    boolean var14 = var10.equals((java.lang.Object)false);
    org.jfree.chart.axis.CategoryLabelPositions var16 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
    org.jfree.chart.util.RectangleEdge var23 = var21.getDomainAxisEdge((-1));
    java.lang.String var24 = var23.toString();
    org.jfree.chart.axis.CategoryLabelPosition var25 = var16.getLabelPosition(var23);
    org.jfree.chart.axis.CategoryLabelPositions var26 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var10, var25);
    boolean var27 = var0.equals((java.lang.Object)var25);
    java.awt.Stroke var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseStroke(var28, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "RectangleEdge.TOP"+ "'", var24.equals("RectangleEdge.TOP"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test25"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.block.LabelBlock var11 = new org.jfree.chart.block.LabelBlock("hi!");
//     var11.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var17 = var11.getBounds();
//     org.jfree.data.general.Dataset var18 = null;
//     org.jfree.data.general.DatasetChangeEvent var19 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var11, var18);
//     var4.datasetChanged(var19);
//     org.jfree.chart.axis.AxisSpace var21 = var4.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.DatasetRenderingOrder var22 = var4.getDatasetRenderingOrder();
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.lang.Object var30 = var29.clone();
//     org.jfree.chart.util.LengthAdjustmentType var31 = var29.getLabelOffsetType();
//     double var32 = var29.getValue();
//     var27.addRangeMarker((org.jfree.chart.plot.Marker)var29);
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var34, var35, var36, var37);
//     double var39 = var38.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var40 = var38.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     int var42 = var38.getIndexOf(var41);
//     org.jfree.chart.LegendItemCollection var43 = null;
//     var38.setFixedLegendItems(var43);
//     org.jfree.chart.event.PlotChangeListener var45 = null;
//     var38.addChangeListener(var45);
//     org.jfree.chart.util.Layer var47 = null;
//     java.util.Collection var48 = var38.getRangeMarkers(var47);
//     org.jfree.data.category.CategoryDataset var49 = null;
//     org.jfree.chart.axis.CategoryAxis var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var49, var50, var51, var52);
//     double var54 = var53.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var55 = var53.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var56 = null;
//     java.util.List var57 = var53.getCategoriesForAxis(var56);
//     double var58 = var53.getAnchorValue();
//     java.awt.Color var61 = java.awt.Color.getColor("", 1);
//     var53.setOutlinePaint((java.awt.Paint)var61);
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     var53.setRangeAxis(0, var64, false);
//     var38.setParent((org.jfree.chart.plot.Plot)var53);
//     var53.setAnchorValue(10.0d);
//     org.jfree.chart.axis.AxisLocation var70 = var53.getRangeAxisLocation();
//     var27.setDomainAxisLocation(var70, true);
//     var4.setDomainAxisLocation(var70, true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var55
//     assertTrue("Contract failed: equals-hashcode on var6 and var55", var6.equals(var55) ? var6.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var6
//     assertTrue("Contract failed: equals-hashcode on var55 and var6", var55.equals(var6) ? var55.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test26"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
    var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var10 = var4.getBounds();
    org.jfree.chart.util.RectangleAnchor var11 = null;
    java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
    org.jfree.chart.util.RectangleEdge var13 = null;
    double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
    var0.setTickMarkOutsideLength(0.0f);
    org.jfree.chart.util.RectangleInsets var17 = var0.getLabelInsets();
    float var18 = var0.getTickMarkOutsideLength();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var20 = var19.getRowCount();
    java.awt.Paint var21 = var19.getBasePaint();
    java.awt.Stroke var23 = var19.getSeriesStroke(1);
    var19.setItemMargin(0.05d);
    var19.setAutoPopulateSeriesShape(false);
    var19.setIncludeBaseInRange(true);
    java.awt.Stroke var30 = var19.getBaseOutlineStroke();
    var0.setTickMarkStroke(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test27"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var2 = var1.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var1.getLegendItemToolTipGenerator();
    java.awt.Shape var5 = var1.lookupSeriesShape(0);
    var1.setAutoPopulateSeriesFillPaint(true);
    var1.setAutoPopulateSeriesStroke(true);
    java.awt.Paint var12 = var1.getItemFillPaint(100, 100);
    java.awt.Paint var15 = var1.getItemOutlinePaint((-8323073), (-1));
    java.awt.Stroke var17 = var1.getSeriesStroke(0);
    java.awt.Paint var20 = var1.getItemOutlinePaint(255, 15);
    org.jfree.chart.plot.ValueMarker var22 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var22.setAlpha(0.0f);
    org.jfree.chart.util.RectangleInsets var25 = var22.getLabelOffset();
    org.jfree.data.category.CategoryDataset var26 = null;
    org.jfree.chart.axis.CategoryAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
    double var31 = var30.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var32 = var30.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var33 = null;
    java.util.List var34 = var30.getCategoriesForAxis(var33);
    double var35 = var30.getAnchorValue();
    var30.clearDomainAxes();
    org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var30);
    org.jfree.chart.title.LegendTitle var39 = var37.getLegend(10);
    java.awt.Stroke var40 = var37.getBorderStroke();
    var22.setOutlineStroke(var40);
    org.jfree.chart.plot.ValueMarker var42 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var20, var40);
    java.lang.String var43 = var42.getLabel();
    org.jfree.chart.util.RectangleInsets var48 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var50 = var48.extendHeight(4.0d);
    var42.setLabelOffset(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 2.0d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test28"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var1 = var0.getColumnCount();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 10.0d);
    boolean var4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
    double var12 = var11.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var13 = var11.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var14 = null;
    java.util.List var15 = var11.getCategoriesForAxis(var14);
    double var16 = var11.getAnchorValue();
    var11.clearDomainAxes();
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
    java.awt.Paint var19 = var18.getBackgroundPaint();
    org.jfree.chart.plot.CategoryPlot var20 = var18.getCategoryPlot();
    var20.configureDomainAxes();
    int var22 = var20.getWeight();
    var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var20);
    boolean var24 = var20.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.0d+ "'", var5.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test29"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    java.awt.Stroke var14 = var4.getDomainGridlineStroke();
    var4.setAnchorValue((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test30"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setNegativeArrowVisible(false);
    org.jfree.chart.axis.MarkerAxisBand var3 = var0.getMarkerBand();
    var0.configure();
    org.jfree.chart.axis.TickUnitSource var5 = null;
    var0.setStandardTickUnits(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test31"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     int var9 = var4.getDomainAxisIndex(var8);
//     int var10 = var4.getWeight();
//     org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var12 = org.jfree.chart.axis.AxisLocation.getOpposite(var11);
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     double var18 = var17.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var19 = var17.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     java.util.List var21 = var17.getCategoriesForAxis(var20);
//     double var22 = var17.getAnchorValue();
//     org.jfree.chart.plot.PlotOrientation var23 = var17.getOrientation();
//     boolean var25 = var23.equals((java.lang.Object)100.0d);
//     java.lang.String var26 = var23.toString();
//     java.lang.String var27 = var23.toString();
//     org.jfree.chart.util.RectangleEdge var28 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var12, var23);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var19
//     assertTrue("Contract failed: equals-hashcode on var6 and var19", var6.equals(var19) ? var6.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var6
//     assertTrue("Contract failed: equals-hashcode on var19 and var6", var19.equals(var6) ? var19.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test32"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     java.awt.Paint var15 = var14.getPaint();
//     var14.setNotify(false);
//     var14.setWidth((-1.0d));
//     java.lang.Object var20 = var14.clone();
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
//     double var26 = var25.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var27 = var25.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     java.util.List var29 = var25.getCategoriesForAxis(var28);
//     double var30 = var25.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25);
//     org.jfree.chart.util.HorizontalAlignment var32 = var31.getHorizontalAlignment();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var34 = var33.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var35 = var33.getLegendItemToolTipGenerator();
//     java.awt.Shape var37 = var33.lookupSeriesShape(0);
//     var33.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.urls.CategoryURLGenerator var41 = null;
//     var33.setSeriesURLGenerator(0, var41);
//     var33.setItemMargin(6.0d);
//     boolean var45 = var32.equals((java.lang.Object)var33);
//     org.jfree.chart.block.LineBorder var46 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var47 = var46.getPaint();
//     org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var52 = new org.jfree.chart.block.LabelBlock("hi!");
//     var52.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var58 = var52.getBounds();
//     org.jfree.chart.util.RectangleAnchor var59 = null;
//     java.awt.geom.Point2D var60 = org.jfree.chart.util.RectangleAnchor.coordinates(var58, var59);
//     org.jfree.chart.util.RectangleEdge var61 = null;
//     double var62 = var48.getCategoryStart((-16777216), (-16777216), var58, var61);
//     var48.setMaximumCategoryLabelLines(10);
//     float var65 = var48.getMaximumCategoryLabelWidthRatio();
//     var48.setFixedDimension(1.0d);
//     boolean var68 = var48.isTickLabelsVisible();
//     boolean var69 = var46.equals((java.lang.Object)var48);
//     org.jfree.chart.axis.CategoryLabelPositions var70 = var48.getCategoryLabelPositions();
//     boolean var71 = var32.equals((java.lang.Object)var70);
//     var14.setHorizontalAlignment(var32);
//     
//     // Checks the contract:  equals-hashcode on var5 and var25
//     assertTrue("Contract failed: equals-hashcode on var5 and var25", var5.equals(var25) ? var5.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var5
//     assertTrue("Contract failed: equals-hashcode on var25 and var5", var25.equals(var5) ? var25.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var27
//     assertTrue("Contract failed: equals-hashcode on var7 and var27", var7.equals(var27) ? var7.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var7
//     assertTrue("Contract failed: equals-hashcode on var27 and var7", var27.equals(var7) ? var27.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test33"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
    double var3 = var2.getHeight();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Font var5 = var2.getFont();
    var0.setLabelFont(var5);
    var0.setMaximumCategoryLabelLines(15);
    float var9 = var0.getTickMarkOutsideLength();
    java.awt.Font var10 = var0.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test34"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
//     var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var10 = var4.getBounds();
//     org.jfree.chart.util.RectangleAnchor var11 = null;
//     java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
//     var0.setMaximumCategoryLabelLines(10);
//     float var17 = var0.getMaximumCategoryLabelWidthRatio();
//     var0.setTickMarkInsideLength(100.0f);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var22, var23, var24, var25);
//     double var27 = var26.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var28 = var26.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     java.util.List var30 = var26.getCategoriesForAxis(var29);
//     var26.setDomainGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     org.jfree.chart.block.LabelBlock var38 = new org.jfree.chart.block.LabelBlock("hi!");
//     var38.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var44 = var38.getBounds();
//     org.jfree.chart.util.RectangleAnchor var45 = null;
//     java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
//     var26.zoomDomainAxes(100.0d, 10.0d, var36, var46);
//     java.awt.geom.Rectangle2D var48 = var36.getDataArea();
//     org.jfree.data.category.CategoryDataset var49 = null;
//     org.jfree.chart.axis.CategoryAxis var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var49, var50, var51, var52);
//     double var54 = var53.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var55 = var53.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var56 = null;
//     java.util.List var57 = var53.getCategoriesForAxis(var56);
//     double var58 = var53.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var53);
//     java.awt.Paint var60 = var59.getBackgroundPaint();
//     double var61 = var59.getWidth();
//     java.lang.Object var62 = var59.clone();
//     org.jfree.chart.util.RectangleAnchor var63 = var59.getLegendItemGraphicLocation();
//     org.jfree.chart.util.RectangleEdge var64 = var59.getLegendItemGraphicEdge();
//     double var65 = var0.getCategoryStart(10, 0, var48, var64);
//     
//     // Checks the contract:  equals-hashcode on var4 and var38
//     assertTrue("Contract failed: equals-hashcode on var4 and var38", var4.equals(var38) ? var4.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var4
//     assertTrue("Contract failed: equals-hashcode on var38 and var4", var38.equals(var4) ? var38.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var53
//     assertTrue("Contract failed: equals-hashcode on var26 and var53", var26.equals(var53) ? var26.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var26
//     assertTrue("Contract failed: equals-hashcode on var53 and var26", var53.equals(var26) ? var53.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var55
//     assertTrue("Contract failed: equals-hashcode on var28 and var55", var28.equals(var55) ? var28.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var28
//     assertTrue("Contract failed: equals-hashcode on var55 and var28", var55.equals(var28) ? var55.hashCode() == var28.hashCode() : true);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test35"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    double var6 = var5.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var8 = null;
    java.util.List var9 = var5.getCategoriesForAxis(var8);
    double var10 = var5.getAnchorValue();
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    java.awt.Paint var12 = var11.getBackgroundPaint();
    java.awt.Font var13 = var11.getItemFont();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
    java.awt.Paint var15 = var14.getPaint();
    var14.setNotify(false);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
    double var23 = var22.getAnchorValue();
    java.awt.Color var26 = java.awt.Color.getColor("", 1);
    var22.setDomainGridlinePaint((java.awt.Paint)var26);
    var14.setPaint((java.awt.Paint)var26);
    org.jfree.chart.event.TitleChangeEvent var29 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var14);
    org.jfree.chart.title.Title var30 = var29.getTitle();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test36"); }
// 
// 
//     org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
//     org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
//     org.jfree.chart.util.RectangleEdge var10 = var8.getDomainAxisEdge((-1));
//     java.lang.String var11 = var10.toString();
//     org.jfree.chart.axis.CategoryLabelPosition var12 = var3.getLabelPosition(var10);
//     var0.moveCursor(0.0d, var10);
//     var0.setCursor(0.2d);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     double var22 = var21.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var23 = var21.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     java.util.List var25 = var21.getCategoriesForAxis(var24);
//     double var26 = var21.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21);
//     java.awt.Paint var28 = var27.getBackgroundPaint();
//     org.jfree.chart.util.RectangleInsets var29 = var27.getMargin();
//     java.awt.Color var32 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var33 = var32.getColorSpace();
//     java.awt.image.ColorModel var34 = null;
//     java.awt.Rectangle var35 = null;
//     org.jfree.chart.block.LabelBlock var37 = new org.jfree.chart.block.LabelBlock("hi!");
//     var37.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var43 = var37.getBounds();
//     java.awt.geom.AffineTransform var44 = null;
//     java.awt.RenderingHints var45 = null;
//     java.awt.PaintContext var46 = var32.createContext(var34, var35, var43, var44, var45);
//     var27.setItemPaint((java.awt.Paint)var32);
//     org.jfree.chart.util.RectangleEdge var48 = var27.getLegendItemGraphicEdge();
//     var0.moveCursor(1.0d, var48);
//     
//     // Checks the contract:  equals-hashcode on var8 and var21
//     assertTrue("Contract failed: equals-hashcode on var8 and var21", var8.equals(var21) ? var8.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var8
//     assertTrue("Contract failed: equals-hashcode on var21 and var8", var21.equals(var8) ? var21.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test37"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("[size=1]");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test38"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var1 = null;
    org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)1L);
    org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("");
    double var6 = var5.getHeight();
    java.lang.Object var7 = var5.clone();
    java.lang.Object var8 = null;
    var0.add((org.jfree.chart.block.Block)var5, var8);
    org.jfree.chart.axis.CategoryLabelPositions var11 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.util.RectangleEdge var12 = null;
    org.jfree.chart.axis.CategoryLabelPosition var13 = var11.getLabelPosition(var12);
    boolean var14 = var0.equals((java.lang.Object)var11);
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.axis.CategoryAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
    double var21 = var20.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var22 = var20.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var23 = null;
    java.util.List var24 = var20.getCategoriesForAxis(var23);
    double var25 = var20.getAnchorValue();
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
    java.awt.Paint var27 = var26.getBackgroundPaint();
    java.awt.Font var28 = var26.getItemFont();
    org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("hi!", var28);
    java.awt.Graphics2D var30 = null;
    java.awt.Color var33 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var34 = var33.getColorSpace();
    java.awt.image.ColorModel var35 = null;
    java.awt.Rectangle var36 = null;
    org.jfree.chart.block.LabelBlock var38 = new org.jfree.chart.block.LabelBlock("hi!");
    var38.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var44 = var38.getBounds();
    java.awt.geom.AffineTransform var45 = null;
    java.awt.RenderingHints var46 = null;
    java.awt.PaintContext var47 = var33.createContext(var35, var36, var44, var45, var46);
    var29.draw(var30, var44);
    org.jfree.chart.block.BlockFrame var49 = var29.getFrame();
    org.jfree.chart.util.VerticalAlignment var50 = var29.getVerticalAlignment();
    org.jfree.chart.util.VerticalAlignment var51 = var29.getVerticalAlignment();
    var29.setURLText("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    org.jfree.data.Range var55 = null;
    org.jfree.data.Range var57 = org.jfree.data.Range.expandToInclude(var55, 100.0d);
    org.jfree.data.Range var58 = null;
    org.jfree.data.Range var59 = null;
    org.jfree.chart.block.RectangleConstraint var60 = new org.jfree.chart.block.RectangleConstraint(var58, var59);
    org.jfree.data.Range var61 = null;
    org.jfree.data.Range var63 = org.jfree.data.Range.expandToInclude(var61, 100.0d);
    org.jfree.chart.block.RectangleConstraint var65 = new org.jfree.chart.block.RectangleConstraint(var63, 10.0d);
    org.jfree.data.Range var66 = null;
    org.jfree.chart.block.RectangleConstraint var67 = new org.jfree.chart.block.RectangleConstraint(var63, var66);
    double var68 = var63.getLowerBound();
    org.jfree.chart.block.RectangleConstraint var69 = var60.toRangeHeight(var63);
    org.jfree.chart.block.RectangleConstraint var70 = new org.jfree.chart.block.RectangleConstraint(var57, var63);
    org.jfree.data.Range var71 = null;
    org.jfree.data.Range var72 = null;
    org.jfree.chart.block.RectangleConstraint var73 = new org.jfree.chart.block.RectangleConstraint(var71, var72);
    org.jfree.data.Range var74 = null;
    org.jfree.data.Range var76 = org.jfree.data.Range.expandToInclude(var74, 100.0d);
    org.jfree.chart.block.RectangleConstraint var77 = var73.toRangeHeight(var76);
    org.jfree.chart.block.LengthConstraintType var78 = var73.getWidthConstraintType();
    org.jfree.data.Range var80 = null;
    org.jfree.data.Range var82 = org.jfree.data.Range.expandToInclude(var80, 100.0d);
    org.jfree.chart.block.RectangleConstraint var84 = new org.jfree.chart.block.RectangleConstraint(var82, 10.0d);
    double var85 = var82.getLowerBound();
    org.jfree.data.Range var86 = null;
    org.jfree.data.Range var87 = null;
    org.jfree.chart.block.RectangleConstraint var88 = new org.jfree.chart.block.RectangleConstraint(var86, var87);
    org.jfree.chart.block.LengthConstraintType var89 = var88.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var90 = new org.jfree.chart.block.RectangleConstraint(4.0d, var63, var78, 1.0d, var82, var89);
    java.lang.String var91 = var78.toString();
    java.lang.String var92 = var78.toString();
    var0.add((org.jfree.chart.block.Block)var29, (java.lang.Object)var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var91 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var91.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var92 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var92.equals("RectangleConstraintType.RANGE"));

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test39"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     java.awt.Paint var15 = var14.getPaint();
//     var14.setNotify(false);
//     var14.setWidth((-1.0d));
//     java.lang.Object var20 = var14.clone();
//     java.lang.String var21 = var14.getText();
//     java.awt.Graphics2D var22 = null;
//     org.jfree.data.Range var23 = null;
//     org.jfree.data.Range var24 = null;
//     org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(var23, var24);
//     org.jfree.data.Range var26 = null;
//     org.jfree.data.Range var27 = null;
//     org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(var26, var27);
//     org.jfree.data.Range var29 = null;
//     org.jfree.data.Range var31 = org.jfree.data.Range.expandToInclude(var29, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint(var31, 10.0d);
//     org.jfree.data.Range var34 = null;
//     org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(var31, var34);
//     double var36 = var31.getLowerBound();
//     org.jfree.chart.block.RectangleConstraint var37 = var28.toRangeHeight(var31);
//     org.jfree.data.Range var40 = org.jfree.data.Range.expand(var31, 100.0d, 8.0d);
//     org.jfree.chart.block.RectangleConstraint var41 = var25.toRangeHeight(var40);
//     org.jfree.chart.util.Size2D var42 = var14.arrange(var22, var25);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test40"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
    double var10 = var9.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var11 = var9.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var12 = null;
    java.util.List var13 = var9.getCategoriesForAxis(var12);
    double var14 = var9.getAnchorValue();
    var9.clearDomainAxes();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var9);
    org.jfree.chart.title.LegendTitle var18 = var16.getLegend(10);
    java.awt.Stroke var19 = var16.getBorderStroke();
    var0.setBaseStroke(var19);
    boolean var23 = var0.isItemLabelVisible(0, (-165));
    boolean var24 = var0.getAutoPopulateSeriesStroke();
    java.lang.Boolean var26 = var0.getSeriesCreateEntities((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test41"); }


    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "hi!", "hi!");
    org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var6);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var6, var13);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var16 = var15.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var15.getLegendItemToolTipGenerator();
    java.awt.Shape var19 = var15.lookupSeriesShape(0);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    double var25 = var24.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var26 = var24.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var27 = null;
    java.util.List var28 = var24.getCategoriesForAxis(var27);
    double var29 = var24.getAnchorValue();
    var24.clearDomainAxes();
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
    org.jfree.chart.title.LegendTitle var33 = var31.getLegend(10);
    java.awt.Stroke var34 = var31.getBorderStroke();
    var15.setBaseStroke(var34);
    boolean var38 = var15.isItemLabelVisible(0, (-165));
    java.awt.Stroke var41 = var15.getItemOutlineStroke(15, (-16777215));
    java.awt.Paint var42 = null;
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=0]", "RectangleConstraintType.RANGE", "[size=1]", "VerticalAlignment.CENTER", var6, var41, var42);
    java.lang.String var44 = var43.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=0]"+ "'", var44.equals("org.jfree.chart.event.ChartChangeEvent[source=0]"));

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test42"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
    double var3 = var2.getHeight();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Font var5 = var2.getFont();
    var0.setLabelFont(var5);
    java.lang.String var8 = var0.getCategoryLabelToolTip((java.lang.Comparable)(byte)10);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var11 = var10.getLeftArrow();
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
    double var17 = var16.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var18 = var16.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var19 = null;
    java.util.List var20 = var16.getCategoriesForAxis(var19);
    double var21 = var16.getAnchorValue();
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    java.awt.Paint var23 = var22.getBackgroundPaint();
    java.awt.Font var24 = var22.getItemFont();
    var10.setTickLabelFont(var24);
    var0.setTickLabelFont((java.lang.Comparable)"1", var24);
    double var27 = var0.getLowerMargin();
    java.awt.Paint var29 = var0.getTickLabelPaint((java.lang.Comparable)2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test43"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(0, var8);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = var0.getBaseToolTipGenerator();
    org.jfree.chart.util.RectangleInsets var15 = new org.jfree.chart.util.RectangleInsets(10.05d, 100.0d, 98.0d, Double.NaN);
    boolean var16 = var0.equals((java.lang.Object)Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test44"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
    double var3 = var2.getHeight();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Font var5 = var2.getFont();
    var0.setLabelFont(var5);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
    double var12 = var11.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var13 = var11.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    int var15 = var11.getIndexOf(var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var11.setFixedLegendItems(var16);
    org.jfree.chart.event.PlotChangeListener var18 = null;
    var11.addChangeListener(var18);
    var0.setPlot((org.jfree.chart.plot.Plot)var11);
    int var21 = var0.getMaximumCategoryLabelLines();
    var0.setMaximumCategoryLabelLines(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test45"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
//     org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("hi!");
//     var16.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var22 = var16.getBounds();
//     org.jfree.chart.util.RectangleAnchor var23 = null;
//     java.awt.geom.Point2D var24 = org.jfree.chart.util.RectangleAnchor.coordinates(var22, var23);
//     var4.zoomDomainAxes(100.0d, 10.0d, var14, var24);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
//     double var31 = var30.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var32 = var30.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     java.util.List var34 = var30.getCategoriesForAxis(var33);
//     var30.setDomainGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var39 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var40 = new org.jfree.chart.plot.PlotRenderingInfo(var39);
//     org.jfree.chart.block.LabelBlock var42 = new org.jfree.chart.block.LabelBlock("hi!");
//     var42.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var48 = var42.getBounds();
//     org.jfree.chart.util.RectangleAnchor var49 = null;
//     java.awt.geom.Point2D var50 = org.jfree.chart.util.RectangleAnchor.coordinates(var48, var49);
//     var30.zoomDomainAxes(100.0d, 10.0d, var40, var50);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var52 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var40);
//     java.lang.Object var53 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var40);
//     org.jfree.chart.ChartRenderingInfo var54 = var40.getOwner();
//     java.awt.geom.Rectangle2D var55 = null;
//     var40.setDataArea(var55);
//     java.lang.Object var57 = null;
//     boolean var58 = var40.equals(var57);
//     var14.addSubplotInfo(var40);
//     
//     // Checks the contract:  equals-hashcode on var4 and var30
//     assertTrue("Contract failed: equals-hashcode on var4 and var30", var4.equals(var30) ? var4.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var4
//     assertTrue("Contract failed: equals-hashcode on var30 and var4", var30.equals(var4) ? var30.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var32
//     assertTrue("Contract failed: equals-hashcode on var6 and var32", var6.equals(var32) ? var6.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var6
//     assertTrue("Contract failed: equals-hashcode on var32 and var6", var32.equals(var6) ? var32.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var42
//     assertTrue("Contract failed: equals-hashcode on var16 and var42", var16.equals(var42) ? var16.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var16
//     assertTrue("Contract failed: equals-hashcode on var42 and var16", var42.equals(var16) ? var42.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test46"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    var4.clearAnnotations();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var6, var7, var8, var9);
    double var11 = var10.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var12 = var10.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var13 = null;
    java.util.List var14 = var10.getCategoriesForAxis(var13);
    double var15 = var10.getAnchorValue();
    var10.clearDomainMarkers();
    org.jfree.chart.block.LabelBlock var18 = new org.jfree.chart.block.LabelBlock("");
    double var19 = var18.getHeight();
    java.awt.Paint var20 = var18.getPaint();
    var10.setRangeCrosshairPaint(var20);
    int var22 = var10.getDomainAxisCount();
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
    java.awt.Color var26 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
    var10.setRangeCrosshairPaint((java.awt.Paint)var26);
    int var28 = var26.getRed();
    var4.setDomainGridlinePaint((java.awt.Paint)var26);
    org.jfree.data.general.DatasetGroup var30 = var4.getDatasetGroup();
    java.awt.Image var31 = var4.getBackgroundImage();
    java.util.List var32 = var4.getAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test47"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var2 = var0.getTickUnit();
    var0.zoomRange(0.0d, 0.0d);
    org.jfree.chart.axis.TickUnitSource var6 = var0.getStandardTickUnits();
    double var7 = var0.getLabelAngle();
    java.awt.Shape var8 = var0.getUpArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test48"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.MarkerAxisBand var1 = null;
//     var0.setMarkerBand(var1);
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("hi!");
//     var7.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var13 = var7.getBounds();
//     org.jfree.chart.util.RectangleAnchor var14 = null;
//     java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var13, var14);
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var3.getCategoryStart((-16777216), (-16777216), var13, var16);
//     var3.setMaximumCategoryLabelLines(10);
//     float var20 = var3.getMaximumCategoryLabelWidthRatio();
//     java.lang.String var21 = var3.getLabel();
//     java.awt.Font var22 = var3.getLabelFont();
//     var0.setLabelFont(var22);
//     var0.setAutoRangeStickyZero(false);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
//     double var31 = var30.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var32 = var30.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     java.util.List var34 = var30.getCategoriesForAxis(var33);
//     var30.setDomainGridlinesVisible(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var38 = var37.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var39 = var37.getLegendItemToolTipGenerator();
//     java.awt.Shape var41 = var37.lookupSeriesShape(0);
//     int var42 = var30.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
//     var37.setAutoPopulateSeriesFillPaint(true);
//     java.awt.Shape var46 = var37.lookupSeriesShape(100);
//     java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var52 = new org.jfree.chart.entity.TickLabelEntity(var49, "hi!", "hi!");
//     org.jfree.data.Range var53 = null;
//     org.jfree.data.Range var54 = null;
//     org.jfree.chart.block.RectangleConstraint var55 = new org.jfree.chart.block.RectangleConstraint(var53, var54);
//     boolean var56 = var52.equals((java.lang.Object)var53);
//     java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var52.setArea(var59);
//     boolean var61 = org.jfree.chart.util.ShapeUtilities.equal(var46, var59);
//     var0.setDownArrow(var46);
//     org.jfree.data.category.CategoryDataset var63 = null;
//     org.jfree.chart.axis.CategoryAxis var64 = null;
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var66 = null;
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot(var63, var64, var65, var66);
//     double var68 = var67.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var69 = var67.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var70 = null;
//     java.util.List var71 = var67.getCategoriesForAxis(var70);
//     double var72 = var67.getAnchorValue();
//     var67.clearDomainAxes();
//     org.jfree.chart.JFreeChart var74 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var67);
//     java.awt.RenderingHints var75 = var74.getRenderingHints();
//     java.awt.Stroke var76 = var74.getBorderStroke();
//     int var77 = var74.getBackgroundImageAlignment();
//     org.jfree.chart.title.Title var78 = null;
//     var74.removeSubtitle(var78);
//     org.jfree.chart.plot.CategoryPlot var80 = var74.getCategoryPlot();
//     org.jfree.chart.title.LegendTitle var81 = var74.getLegend();
//     java.awt.Stroke var82 = var74.getBorderStroke();
//     var0.setAxisLineStroke(var82);
//     
//     // Checks the contract:  equals-hashcode on var30 and var67
//     assertTrue("Contract failed: equals-hashcode on var30 and var67", var30.equals(var67) ? var30.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var80
//     assertTrue("Contract failed: equals-hashcode on var30 and var80", var30.equals(var80) ? var30.hashCode() == var80.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var30
//     assertTrue("Contract failed: equals-hashcode on var67 and var30", var67.equals(var30) ? var67.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var80 and var30
//     assertTrue("Contract failed: equals-hashcode on var80 and var30", var80.equals(var30) ? var80.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var69
//     assertTrue("Contract failed: equals-hashcode on var32 and var69", var32.equals(var69) ? var32.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var32
//     assertTrue("Contract failed: equals-hashcode on var69 and var32", var69.equals(var32) ? var69.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test49"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     int var8 = var4.getIndexOf(var7);
//     java.util.List var9 = var4.getCategories();
//     var4.configureDomainAxes();
//     org.jfree.chart.util.Layer var11 = null;
//     java.util.Collection var12 = var4.getRangeMarkers(var11);
//     java.awt.Paint var13 = var4.getDomainGridlinePaint();
//     org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker((-1.0d));
//     org.jfree.chart.util.LengthAdjustmentType var16 = var15.getLabelOffsetType();
//     java.awt.Stroke var17 = var15.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
//     double var23 = var22.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var24 = var22.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     java.util.List var26 = var22.getCategoriesForAxis(var25);
//     double var27 = var22.getAnchorValue();
//     org.jfree.chart.plot.PlotOrientation var28 = var22.getOrientation();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var30 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var29};
//     var22.setRenderers(var30);
//     org.jfree.chart.util.RectangleInsets var32 = var22.getInsets();
//     double var34 = var32.extendHeight(2.05d);
//     double var36 = var32.calculateLeftInset(0.0d);
//     double var37 = var32.getLeft();
//     org.jfree.chart.block.LineBorder var38 = new org.jfree.chart.block.LineBorder(var13, var17, var32);
//     
//     // Checks the contract:  equals-hashcode on var4 and var22
//     assertTrue("Contract failed: equals-hashcode on var4 and var22", var4.equals(var22) ? var4.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var4
//     assertTrue("Contract failed: equals-hashcode on var22 and var4", var22.equals(var4) ? var22.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test50"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var1 = var0.getColumnCount();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 10.0d);
    boolean var4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
    java.util.List var5 = var0.getColumnKeys();
    java.lang.Object var6 = var0.clone();
    java.lang.Number var7 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
    org.jfree.chart.util.RectangleEdge var14 = var12.getDomainAxisEdge((-1));
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.0d+ "'", var7.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test51"); }


    java.awt.Font var1 = null;
    org.jfree.chart.axis.CategoryLabelPositions var2 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var4 = var3.getRowCount();
    java.awt.Paint var5 = var3.getBasePaint();
    java.awt.Stroke var7 = var3.getSeriesStroke(1);
    var3.setItemMargin(0.05d);
    var3.setAutoPopulateSeriesShape(false);
    org.jfree.chart.axis.CategoryLabelPositions var13 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.util.RectangleEdge var14 = null;
    org.jfree.chart.axis.CategoryLabelPosition var15 = var13.getLabelPosition(var14);
    boolean var17 = var13.equals((java.lang.Object)false);
    org.jfree.chart.axis.CategoryLabelPositions var19 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    org.jfree.chart.util.RectangleEdge var26 = var24.getDomainAxisEdge((-1));
    java.lang.String var27 = var26.toString();
    org.jfree.chart.axis.CategoryLabelPosition var28 = var19.getLabelPosition(var26);
    org.jfree.chart.axis.CategoryLabelPositions var29 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var13, var28);
    boolean var30 = var3.equals((java.lang.Object)var28);
    org.jfree.chart.axis.CategoryLabelPositions var31 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var2, var28);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var33 = var32.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var34 = var32.getLegendItemToolTipGenerator();
    java.awt.Shape var36 = var32.lookupSeriesShape(0);
    int var37 = var32.getRowCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var39 = var32.getSeriesToolTipGenerator(1);
    var32.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Paint var43 = var32.lookupSeriesFillPaint(0);
    var32.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var46 = var32.getLegendItemLabelGenerator();
    boolean var47 = var31.equals((java.lang.Object)var32);
    boolean var48 = var32.isDrawBarOutline();
    java.awt.Paint var49 = var32.getBasePaint();
    java.awt.Graphics2D var52 = null;
    org.jfree.chart.text.G2TextMeasurer var53 = new org.jfree.chart.text.G2TextMeasurer(var52);
    org.jfree.chart.text.TextBlock var54 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var49, 0.0f, (-83), (org.jfree.chart.text.TextMeasurer)var53);
    org.jfree.chart.text.TextBlock var55 = new org.jfree.chart.text.TextBlock();
    java.util.List var56 = var55.getLines();
    java.awt.Graphics2D var57 = null;
    org.jfree.chart.util.Size2D var58 = var55.calculateDimensions(var57);
    java.lang.Object var59 = null;
    boolean var60 = var55.equals(var59);
    org.jfree.chart.text.TextLine var62 = new org.jfree.chart.text.TextLine("hi!");
    org.jfree.chart.text.TextFragment var64 = new org.jfree.chart.text.TextFragment("");
    var62.addFragment(var64);
    var55.addLine(var62);
    var54.addLine(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "RectangleEdge.TOP"+ "'", var27.equals("RectangleEdge.TOP"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test52"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    int var5 = var0.getRowCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = var0.getSeriesToolTipGenerator(1);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Paint var11 = var0.lookupSeriesFillPaint(0);
    var0.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemLabelGenerator();
    var0.setAutoPopulateSeriesOutlineStroke(false);
    java.awt.Paint var18 = var0.lookupSeriesOutlinePaint((-1));
    java.lang.Object var19 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test53"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
    var2.setHeight((-1.0d));
    double var5 = var2.getWidth();
    java.lang.String var6 = var2.toString();
    java.lang.String var7 = var2.toString();
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 100.0d);
    boolean var11 = var2.equals((java.lang.Object)var10);
    double var12 = var2.getWidth();
    java.lang.String var13 = var2.toString();
    var2.setHeight(98.0d);
    var2.setHeight(4.00000001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Size2D[width=-1.0, height=-1.0]"+ "'", var6.equals("Size2D[width=-1.0, height=-1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Size2D[width=-1.0, height=-1.0]"+ "'", var7.equals("Size2D[width=-1.0, height=-1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Size2D[width=-1.0, height=-1.0]"+ "'", var13.equals("Size2D[width=-1.0, height=-1.0]"));

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test54"); }
// 
// 
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "hi!", "hi!");
//     org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var6);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var6, var13);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var16 = var15.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var15.getLegendItemToolTipGenerator();
//     java.awt.Shape var19 = var15.lookupSeriesShape(0);
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
//     double var25 = var24.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var26 = var24.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     java.util.List var28 = var24.getCategoriesForAxis(var27);
//     double var29 = var24.getAnchorValue();
//     var24.clearDomainAxes();
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
//     org.jfree.chart.title.LegendTitle var33 = var31.getLegend(10);
//     java.awt.Stroke var34 = var31.getBorderStroke();
//     var15.setBaseStroke(var34);
//     boolean var38 = var15.isItemLabelVisible(0, (-165));
//     java.awt.Stroke var41 = var15.getItemOutlineStroke(15, (-16777215));
//     java.awt.Paint var42 = null;
//     org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=0]", "RectangleConstraintType.RANGE", "[size=1]", "VerticalAlignment.CENTER", var6, var41, var42);
//     java.lang.Comparable var44 = var43.getSeriesKey();
//     java.awt.Shape var45 = var43.getLine();
//     org.jfree.chart.entity.ChartEntity var46 = new org.jfree.chart.entity.ChartEntity(var45);
//     
//     // Checks the contract:  equals-hashcode on var10 and var46
//     assertTrue("Contract failed: equals-hashcode on var10 and var46", var10.equals(var46) ? var10.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var10
//     assertTrue("Contract failed: equals-hashcode on var46 and var10", var46.equals(var10) ? var46.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test55"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getHeightConstraintType();
    org.jfree.data.Range var4 = var2.getWidthRange();
    org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var8 = var2.toRangeWidth(var7);
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 100.0d);
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(var11, 10.0d);
    org.jfree.data.Range var15 = org.jfree.data.Range.shift(var11, 0.05d);
    org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(var7, var11);
    org.jfree.data.Range var18 = org.jfree.data.Range.expandToInclude(var11, 8.0d);
    org.jfree.chart.axis.AxisSpace var19 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var20 = var19.clone();
    org.jfree.chart.axis.AxisSpace var21 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var22 = var21.clone();
    var19.ensureAtLeast(var21);
    boolean var24 = var11.equals((java.lang.Object)var21);
    double var25 = var11.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 100.0d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test56"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
    var4.setDomainGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test57"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var11 = null;
    java.util.List var12 = var8.getCategoriesForAxis(var11);
    double var13 = var8.getAnchorValue();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    java.awt.Paint var15 = var14.getBackgroundPaint();
    java.awt.Font var16 = var14.getItemFont();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("hi!", var16);
    org.jfree.chart.util.RectangleEdge var18 = var17.getPosition();
    boolean var19 = var0.equals((java.lang.Object)var17);
    java.lang.Object var20 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test58"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    var0.setItemMargin(0.05d);
    int var7 = var0.getPassCount();
    double var8 = var0.getUpperClip();
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var0.getBaseItemLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test59"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    java.awt.Stroke var14 = var4.getDomainGridlineStroke();
    java.awt.Color var17 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var18 = var17.getColorSpace();
    java.awt.image.ColorModel var19 = null;
    java.awt.Rectangle var20 = null;
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
    var22.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var28 = var22.getBounds();
    java.awt.geom.AffineTransform var29 = null;
    java.awt.RenderingHints var30 = null;
    java.awt.PaintContext var31 = var17.createContext(var19, var20, var28, var29, var30);
    var4.setNoDataMessagePaint((java.awt.Paint)var17);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var34 = var33.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var35 = var33.getLegendItemToolTipGenerator();
    java.awt.Shape var37 = var33.lookupSeriesShape(0);
    var33.setAutoPopulateSeriesFillPaint(true);
    var33.setAutoPopulateSeriesStroke(true);
    java.awt.Paint var44 = var33.getItemFillPaint(100, 100);
    var4.setOutlinePaint(var44);
    org.jfree.chart.util.RectangleInsets var50 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var51 = var50.getLeft();
    double var52 = var50.getLeft();
    double var54 = var50.calculateRightInset(0.0d);
    var4.setInsets(var50, true);
    double var58 = var50.trimWidth(12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 14.0d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test60"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    float var14 = var4.getForegroundAlpha();
    org.jfree.chart.axis.ValueAxis var16 = var4.getRangeAxis(0);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
    var22.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var28 = var22.getBounds();
    org.jfree.chart.util.RectangleAnchor var29 = null;
    java.awt.geom.Point2D var30 = org.jfree.chart.util.RectangleAnchor.coordinates(var28, var29);
    org.jfree.chart.util.RectangleEdge var31 = null;
    double var32 = var18.getCategoryStart((-16777216), (-16777216), var28, var31);
    var18.setTickMarkOutsideLength(0.0f);
    org.jfree.chart.util.RectangleInsets var35 = var18.getLabelInsets();
    var4.setDomainAxis(15, var18);
    var4.setOutlineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test61"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var1 = var0.getColumnCount();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 10.0d);
    java.lang.Number var6 = var0.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 6.0d);
    org.jfree.data.Range var11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
    int var12 = var0.getColumnCount();
    java.util.List var13 = var0.getColumnKeys();
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Object var15 = null;
    boolean var16 = var14.equals(var15);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var18 = var17.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var19 = var17.getLegendItemToolTipGenerator();
    java.awt.Shape var21 = var17.lookupSeriesShape(0);
    int var22 = var17.getRowCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var24 = var17.getSeriesToolTipGenerator(1);
    var17.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var29 = var17.getNegativeItemLabelPosition(0, (-16777216));
    var14.setBaseNegativeItemLabelPosition(var29);
    boolean var31 = var0.equals((java.lang.Object)var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test62"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    double var1 = var0.getTranslateX();
    double var2 = var0.getTranslateX();
    var0.setTranslateY(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test63"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     org.jfree.chart.util.GradientPaintTransformType var1 = var0.getType();
//     org.jfree.chart.util.StandardGradientPaintTransformer var2 = new org.jfree.chart.util.StandardGradientPaintTransformer(var1);
//     java.awt.GradientPaint var3 = null;
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
//     double var9 = var8.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     java.util.List var12 = var8.getCategoriesForAxis(var11);
//     var8.setDomainGridlinesVisible(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var16 = var15.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var15.getLegendItemToolTipGenerator();
//     java.awt.Shape var19 = var15.lookupSeriesShape(0);
//     int var20 = var8.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     var15.setAutoPopulateSeriesFillPaint(true);
//     java.awt.Shape var24 = var15.lookupSeriesShape(100);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var30 = new org.jfree.chart.entity.TickLabelEntity(var27, "hi!", "hi!");
//     org.jfree.data.Range var31 = null;
//     org.jfree.data.Range var32 = null;
//     org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint(var31, var32);
//     boolean var34 = var30.equals((java.lang.Object)var31);
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var30.setArea(var37);
//     boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var24, var37);
//     java.awt.GradientPaint var40 = var2.transform(var3, var37);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test64"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var11 = var10.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var12 = var10.getMargin();
    java.awt.Color var15 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var16 = var15.getColorSpace();
    java.awt.image.ColorModel var17 = null;
    java.awt.Rectangle var18 = null;
    org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("hi!");
    var20.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var26 = var20.getBounds();
    java.awt.geom.AffineTransform var27 = null;
    java.awt.RenderingHints var28 = null;
    java.awt.PaintContext var29 = var15.createContext(var17, var18, var26, var27, var28);
    var10.setItemPaint((java.awt.Paint)var15);
    org.jfree.chart.util.RectangleEdge var31 = var10.getLegendItemGraphicEdge();
    org.jfree.chart.block.BlockBorder var32 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var33 = var32.getInsets();
    org.jfree.chart.util.UnitType var34 = var33.getUnitType();
    org.jfree.chart.util.RectangleInsets var39 = new org.jfree.chart.util.RectangleInsets(var34, 2.0d, 100.0d, 0.05d, 0.05d);
    var10.setItemLabelPadding(var39);
    org.jfree.chart.util.RectangleEdge var41 = var10.getLegendItemGraphicEdge();
    org.jfree.chart.block.BlockContainer var42 = var10.getItemContainer();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test65"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    double var1 = var0.getRight();
    double var2 = var0.getLeft();
    double var3 = var0.getLeft();
    org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
    double var5 = var4.getRight();
    var4.setBottom(2.05d);
    var0.ensureAtLeast(var4);
    org.jfree.chart.axis.AxisSpace var9 = new org.jfree.chart.axis.AxisSpace();
    double var10 = var9.getRight();
    var9.setBottom(2.05d);
    double var13 = var9.getRight();
    var4.ensureAtLeast(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test66"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test67"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var2 = var0.getTickUnit();
    var0.setAutoTickUnitSelection(false);
    double var5 = var0.getUpperMargin();
    java.text.NumberFormat var6 = null;
    var0.setNumberFormatOverride(var6);
    double var8 = var0.getFixedAutoRange();
    java.lang.String var9 = var0.getLabelURL();
    var0.setLowerBound((-2.0d));
    double var12 = var0.getUpperBound();
    double var13 = var0.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-2.0d));

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test68"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
//     java.awt.Stroke var9 = var5.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = var5.getRendererForDataset(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var5);
//     java.util.List var13 = var12.getSubtitles();
//     var12.setNotify(false);
//     var12.clearSubtitles();
//     org.jfree.chart.plot.CategoryPlot var17 = var12.getCategoryPlot();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var19 = var18.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var20 = var18.getLegendItemToolTipGenerator();
//     java.awt.Shape var22 = var18.lookupSeriesShape(0);
//     var18.setAutoPopulateSeriesFillPaint(true);
//     boolean var26 = var18.isSeriesItemLabelsVisible(0);
//     java.awt.Paint var28 = var18.lookupSeriesFillPaint(1);
//     org.jfree.chart.LegendItemCollection var29 = var18.getLegendItems();
//     java.util.Iterator var30 = var29.iterator();
//     var17.setFixedLegendItems(var29);
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var37 = new org.jfree.chart.block.LabelBlock("hi!");
//     var37.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var43 = var37.getBounds();
//     org.jfree.chart.util.RectangleAnchor var44 = null;
//     java.awt.geom.Point2D var45 = org.jfree.chart.util.RectangleAnchor.coordinates(var43, var44);
//     org.jfree.chart.util.RectangleEdge var46 = null;
//     double var47 = var33.getCategoryStart((-16777216), (-16777216), var43, var46);
//     var33.setTickMarkOutsideLength(0.0f);
//     org.jfree.chart.util.RectangleInsets var50 = var33.getLabelInsets();
//     float var51 = var33.getTickMarkOutsideLength();
//     var33.setUpperMargin(100.0d);
//     org.jfree.data.category.CategoryDataset var54 = null;
//     org.jfree.chart.axis.CategoryAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var54, var55, var56, var57);
//     double var59 = var58.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var60 = var58.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var61 = null;
//     java.util.List var62 = var58.getCategoriesForAxis(var61);
//     double var63 = var58.getAnchorValue();
//     var58.clearDomainAxes();
//     org.jfree.chart.JFreeChart var65 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var58);
//     java.awt.RenderingHints var66 = var65.getRenderingHints();
//     var65.setBackgroundImageAlpha(0.0f);
//     java.lang.Object var69 = var65.getTextAntiAlias();
//     var65.removeLegend();
//     org.jfree.chart.event.ChartProgressEvent var73 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var33, var65, 0, 100);
//     double var74 = var33.getUpperMargin();
//     java.awt.Stroke var75 = var33.getTickMarkStroke();
//     var17.setDomainAxis(4, var33, true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var5
//     assertTrue("Contract failed: equals-hashcode on var58 and var5", var58.equals(var5) ? var58.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var17
//     assertTrue("Contract failed: equals-hashcode on var58 and var17", var58.equals(var17) ? var58.hashCode() == var17.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var58 and var5.", var58.equals(var5) == var5.equals(var58));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var58 and var17.", var58.equals(var17) == var17.equals(var58));
//     
//     // Checks the contract:  equals-hashcode on var7 and var60
//     assertTrue("Contract failed: equals-hashcode on var7 and var60", var7.equals(var60) ? var7.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var7
//     assertTrue("Contract failed: equals-hashcode on var60 and var7", var60.equals(var7) ? var60.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test69"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var2 = var0.getTickUnit();
    var0.setAutoTickUnitSelection(false);
    var0.setLabelAngle(10.0d);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    double var8 = var7.getLowerMargin();
    org.jfree.chart.axis.TickUnitSource var9 = var7.getStandardTickUnits();
    var0.setStandardTickUnits(var9);
    boolean var11 = var0.isNegativeArrowVisible();
    boolean var12 = var0.isTickLabelsVisible();
    boolean var13 = var0.getAutoRangeIncludesZero();
    var0.setFixedAutoRange(0.0d);
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.axis.CategoryAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
    double var21 = var20.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var22 = var20.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var23 = null;
    java.util.List var24 = var20.getCategoriesForAxis(var23);
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var20);
    boolean var26 = var0.isPositiveArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test70"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var2 = var0.getTickUnit();
    var0.setAutoTickUnitSelection(false);
    var0.setLabelAngle(10.0d);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    double var8 = var7.getLowerMargin();
    org.jfree.chart.axis.TickUnitSource var9 = var7.getStandardTickUnits();
    var0.setStandardTickUnits(var9);
    var0.resizeRange(4.0d);
    java.awt.Font var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelFont(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test71"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     double var7 = var6.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     java.util.List var10 = var6.getCategoriesForAxis(var9);
//     double var11 = var6.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Paint var13 = var12.getBackgroundPaint();
//     java.awt.Font var14 = var12.getItemFont();
//     org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("hi!");
//     var16.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var22 = var16.getBounds();
//     java.awt.Paint var23 = var16.getPaint();
//     org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("SortOrder.ASCENDING", var14, var23);
//     org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("10", var14);
//     var25.setToolTipText("PlotOrientation.VERTICAL");
//     java.lang.String var28 = var25.getToolTipText();
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.block.LabelBlock var31 = new org.jfree.chart.block.LabelBlock("hi!");
//     var31.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var37 = var31.getBounds();
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var39, var40, var41, var42);
//     double var44 = var43.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var45 = var43.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var46 = null;
//     java.util.List var47 = var43.getCategoriesForAxis(var46);
//     double var48 = var43.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
//     java.awt.Paint var50 = var49.getBackgroundPaint();
//     java.awt.Font var51 = var49.getItemFont();
//     org.jfree.chart.title.TextTitle var52 = new org.jfree.chart.title.TextTitle("hi!", var51);
//     java.awt.Graphics2D var53 = null;
//     java.awt.geom.Rectangle2D var54 = null;
//     var52.draw(var53, var54);
//     java.awt.Paint var56 = var52.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var57 = var52.getBounds();
//     boolean var58 = org.jfree.chart.util.ShapeUtilities.intersects(var37, var57);
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var64 = new org.jfree.chart.entity.TickLabelEntity(var61, "hi!", "hi!");
//     org.jfree.data.Range var65 = null;
//     org.jfree.data.Range var66 = null;
//     org.jfree.chart.block.RectangleConstraint var67 = new org.jfree.chart.block.RectangleConstraint(var65, var66);
//     boolean var68 = var64.equals((java.lang.Object)var65);
//     java.awt.Shape var71 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var64.setArea(var71);
//     java.lang.Object var73 = var64.clone();
//     java.lang.Object var74 = var25.draw(var29, var37, (java.lang.Object)var64);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test72"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=0]");
    float var2 = var1.getTickMarkInsideLength();
    boolean var3 = var1.isPositiveArrowVisible();
    double var4 = var1.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test73"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(98.0d, 7.0d, 12.0d, 100.0d);
    java.lang.String var5 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleInsets[t=98.0,l=7.0,b=12.0,r=100.0]"+ "'", var5.equals("RectangleInsets[t=98.0,l=7.0,b=12.0,r=100.0]"));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test74"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.LegendItemCollection var7 = null;
    var4.setFixedLegendItems(var7);
    boolean var9 = var4.isSubplot();
    var4.configureDomainAxes();
    int var11 = var4.getWeight();
    java.awt.Image var12 = var4.getBackgroundImage();
    java.awt.Paint var13 = var4.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var14 = var4.getInsets();
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var4.getRangeMarkers(var15);
    var4.setRangeCrosshairValue(4.00000001d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test75"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
    var0.setLegendItemToolTipGenerator(var5);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var8 = var7.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var7.getLegendItemToolTipGenerator();
    java.awt.Shape var11 = var7.lookupSeriesShape(0);
    org.jfree.chart.labels.ItemLabelPosition var12 = new org.jfree.chart.labels.ItemLabelPosition();
    var7.setPositiveItemLabelPositionFallback(var12);
    org.jfree.chart.text.TextAnchor var14 = var12.getTextAnchor();
    var0.setNegativeItemLabelPositionFallback(var12);
    boolean var18 = var0.isItemLabelVisible(15, (-8323073));
    double var19 = var0.getMaximumBarWidth();
    java.awt.Paint var20 = var0.getBaseItemLabelPaint();
    var0.setBase(8.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var25 = var24.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var26 = var24.getLegendItemToolTipGenerator();
    java.awt.Shape var28 = var24.lookupSeriesShape(0);
    int var29 = var24.getRowCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = var24.getSeriesToolTipGenerator(1);
    var24.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var36 = var24.getNegativeItemLabelPosition(0, (-16777216));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var38 = var37.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var39 = var37.getLegendItemToolTipGenerator();
    java.awt.Shape var41 = var37.lookupSeriesShape(0);
    org.jfree.chart.labels.ItemLabelPosition var42 = new org.jfree.chart.labels.ItemLabelPosition();
    var37.setPositiveItemLabelPositionFallback(var42);
    org.jfree.chart.text.TextAnchor var44 = var42.getTextAnchor();
    var24.setPositiveItemLabelPositionFallback(var42);
    org.jfree.chart.text.TextAnchor var46 = var42.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesNegativeItemLabelPosition((-165), var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test76"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    boolean var5 = var0.getBaseCreateEntities();
    java.awt.Paint var6 = var0.getErrorIndicatorPaint();
    boolean var7 = var0.getBaseItemLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test77"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    var4.setDomainGridlinesVisible(false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var12 = var11.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var11.getLegendItemToolTipGenerator();
    java.awt.Shape var15 = var11.lookupSeriesShape(0);
    int var16 = var4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    var11.setAutoPopulateSeriesFillPaint(true);
    java.awt.Shape var20 = var11.lookupSeriesShape(100);
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = null;
    var11.setBaseToolTipGenerator(var21);
    boolean var23 = var11.getAutoPopulateSeriesOutlineStroke();
    org.jfree.chart.labels.ItemLabelPosition var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setSeriesPositiveItemLabelPosition((-3670018), var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test78"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
    double var3 = var2.getHeight();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Font var5 = var2.getFont();
    var0.setLabelFont(var5);
    var0.setMaximumCategoryLabelLines(15);
    org.jfree.chart.util.RectangleInsets var9 = var0.getLabelInsets();
    org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("hi!");
    var14.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var20 = var14.getBounds();
    org.jfree.chart.util.RectangleAnchor var21 = null;
    java.awt.geom.Point2D var22 = org.jfree.chart.util.RectangleAnchor.coordinates(var20, var21);
    var11.setShape(0, (java.awt.Shape)var20);
    org.jfree.chart.entity.CategoryLabelEntity var26 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"VerticalAlignment.CENTER", (java.awt.Shape)var20, "Range[0.0,0.0]", "HorizontalAlignment.CENTER");
    java.awt.geom.Rectangle2D var29 = var9.createInsetRectangle(var20, false, false);
    org.jfree.chart.entity.ChartEntity var32 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var29, "Range[0.0,0.0]", "hi! version VerticalAlignment.CENTER.\norg.jfree.chart.event.ChartChangeEvent[source=0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\n10");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test79"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     java.awt.RenderingHints var12 = var11.getRenderingHints();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     java.awt.Color var26 = java.awt.Color.getColor("", 1);
//     var18.setOutlinePaint((java.awt.Paint)var26);
//     float var28 = var18.getForegroundAlpha();
//     org.jfree.chart.axis.ValueAxis var30 = var18.getRangeAxis(0);
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("hi!");
//     var36.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var42 = var36.getBounds();
//     org.jfree.chart.util.RectangleAnchor var43 = null;
//     java.awt.geom.Point2D var44 = org.jfree.chart.util.RectangleAnchor.coordinates(var42, var43);
//     org.jfree.chart.util.RectangleEdge var45 = null;
//     double var46 = var32.getCategoryStart((-16777216), (-16777216), var42, var45);
//     var32.setTickMarkOutsideLength(0.0f);
//     org.jfree.chart.util.RectangleInsets var49 = var32.getLabelInsets();
//     var18.setDomainAxis(15, var32);
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     java.awt.geom.Rectangle2D var52 = var51.getBounds();
//     org.jfree.chart.ChartRenderingInfo var53 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var54 = new org.jfree.chart.plot.PlotRenderingInfo(var53);
//     int var55 = var54.getSubplotCount();
//     org.jfree.chart.renderer.RendererState var56 = new org.jfree.chart.renderer.RendererState(var54);
//     org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("hi!");
//     var58.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var64 = var58.getBounds();
//     org.jfree.chart.util.RectangleAnchor var65 = null;
//     java.awt.geom.Point2D var66 = org.jfree.chart.util.RectangleAnchor.coordinates(var64, var65);
//     int var67 = var54.getSubplotIndex(var66);
//     org.jfree.chart.ChartRenderingInfo var68 = null;
//     var11.draw(var13, var52, var66, var68);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test80"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(0, var8);
    var0.setItemMargin(6.0d);
    java.awt.Shape var13 = var0.lookupSeriesShape(100);
    java.awt.Paint var16 = var0.getItemLabelPaint(100, 10);
    var0.setBaseCreateEntities(false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var20 = var19.getRowCount();
    org.jfree.chart.labels.ItemLabelPosition var21 = var19.getBaseNegativeItemLabelPosition();
    var0.setNegativeItemLabelPositionFallback(var21);
    boolean var23 = var0.getIncludeBaseInRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test81"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    double var2 = var1.getHeight();
    java.lang.Object var3 = var1.clone();
    var1.setToolTipText("AxisLocation.TOP_OR_LEFT");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test82"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
    double var7 = var6.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var9 = null;
    java.util.List var10 = var6.getCategoriesForAxis(var9);
    double var11 = var6.getAnchorValue();
    var6.clearDomainMarkers();
    java.awt.Paint var13 = var6.getRangeGridlinePaint();
    var0.setSeriesOutlinePaint(1, var13, false);
    var0.setMinimumBarLength(0.05d);
    var0.setSeriesCreateEntities(3, (java.lang.Boolean)true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var22 = null;
    var0.setBaseItemLabelGenerator(var22, true);
    org.jfree.chart.labels.ItemLabelPosition var26 = var0.getSeriesPositiveItemLabelPosition((-3670018));
    org.jfree.data.category.CategoryDataset var28 = null;
    org.jfree.chart.axis.CategoryAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var28, var29, var30, var31);
    double var33 = var32.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var34 = var32.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var35 = null;
    java.util.List var36 = var32.getCategoriesForAxis(var35);
    var32.setDomainGridlinesVisible(false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var40 = var39.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var41 = var39.getLegendItemToolTipGenerator();
    java.awt.Shape var43 = var39.lookupSeriesShape(0);
    int var44 = var32.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
    var39.setAutoPopulateSeriesFillPaint(true);
    java.awt.Shape var48 = var39.lookupSeriesShape(100);
    java.awt.Stroke var51 = var39.getItemOutlineStroke(100, (-253));
    boolean var52 = var39.isDrawBarOutline();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var53 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var54 = var53.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var55 = var53.getLegendItemToolTipGenerator();
    java.awt.Shape var57 = var53.lookupSeriesShape(0);
    int var58 = var53.getRowCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var60 = var53.getSeriesToolTipGenerator(1);
    var53.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var65 = var53.getNegativeItemLabelPosition(0, (-16777216));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var66 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var67 = var66.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var68 = var66.getLegendItemToolTipGenerator();
    java.awt.Shape var70 = var66.lookupSeriesShape(0);
    org.jfree.chart.labels.ItemLabelPosition var71 = new org.jfree.chart.labels.ItemLabelPosition();
    var66.setPositiveItemLabelPositionFallback(var71);
    org.jfree.chart.text.TextAnchor var73 = var71.getTextAnchor();
    var53.setPositiveItemLabelPositionFallback(var71);
    org.jfree.chart.text.TextAnchor var75 = var71.getRotationAnchor();
    var39.setBasePositiveItemLabelPosition(var71);
    java.awt.Color var80 = java.awt.Color.getColor("", 1);
    var39.setSeriesItemLabelPaint(255, (java.awt.Paint)var80, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-127), (java.awt.Paint)var80, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test83"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var1 = var0.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
//     java.awt.Shape var4 = var0.lookupSeriesShape(0);
//     var0.setAutoPopulateSeriesFillPaint(true);
//     var0.setMinimumBarLength(0.05d);
//     java.awt.Paint var10 = var0.getSeriesFillPaint(255);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var12 = var11.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var11.getLegendItemToolTipGenerator();
//     java.awt.Shape var15 = var11.lookupSeriesShape(0);
//     int var16 = var11.getRowCount();
//     org.jfree.chart.labels.CategoryToolTipGenerator var18 = var11.getSeriesToolTipGenerator(1);
//     java.awt.Paint var21 = var11.getItemOutlinePaint((-16777216), (-165));
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var23 = var22.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var24 = var22.getLegendItemToolTipGenerator();
//     java.awt.Shape var26 = var22.lookupSeriesShape(0);
//     var22.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.urls.CategoryURLGenerator var30 = null;
//     var22.setSeriesURLGenerator(0, var30);
//     org.jfree.chart.labels.CategoryToolTipGenerator var32 = var22.getBaseToolTipGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var34 = var22.getSeriesNegativeItemLabelPosition(0);
//     var11.setBaseNegativeItemLabelPosition(var34);
//     var0.setPositiveItemLabelPositionFallback(var34);
//     org.jfree.data.category.CategoryDataset var37 = null;
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
//     double var42 = var41.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var43 = var41.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var44 = null;
//     java.util.List var45 = var41.getCategoriesForAxis(var44);
//     var41.setDomainGridlinesVisible(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var48 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var49 = var48.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var50 = var48.getLegendItemToolTipGenerator();
//     java.awt.Shape var52 = var48.lookupSeriesShape(0);
//     int var53 = var41.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var48);
//     var48.setAutoPopulateSeriesFillPaint(true);
//     java.awt.Shape var57 = var48.lookupSeriesShape(100);
//     java.awt.Stroke var60 = var48.getItemOutlineStroke(100, (-253));
//     boolean var61 = var48.isDrawBarOutline();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var62 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var63 = var62.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var64 = var62.getLegendItemToolTipGenerator();
//     java.awt.Shape var66 = var62.lookupSeriesShape(0);
//     int var67 = var62.getRowCount();
//     org.jfree.chart.labels.CategoryToolTipGenerator var69 = var62.getSeriesToolTipGenerator(1);
//     var62.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var74 = var62.getNegativeItemLabelPosition(0, (-16777216));
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var75 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var76 = var75.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var77 = var75.getLegendItemToolTipGenerator();
//     java.awt.Shape var79 = var75.lookupSeriesShape(0);
//     org.jfree.chart.labels.ItemLabelPosition var80 = new org.jfree.chart.labels.ItemLabelPosition();
//     var75.setPositiveItemLabelPositionFallback(var80);
//     org.jfree.chart.text.TextAnchor var82 = var80.getTextAnchor();
//     var62.setPositiveItemLabelPositionFallback(var80);
//     org.jfree.chart.text.TextAnchor var84 = var80.getRotationAnchor();
//     var48.setBasePositiveItemLabelPosition(var80);
//     java.awt.Color var89 = java.awt.Color.getColor("", 1);
//     var48.setSeriesItemLabelPaint(255, (java.awt.Paint)var89, true);
//     java.awt.Color var92 = var89.darker();
//     var0.setBaseFillPaint((java.awt.Paint)var92);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var48.", var11.equals(var48) == var48.equals(var11));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var48.", var22.equals(var48) == var48.equals(var22));
//     
//     // Checks the contract:  equals-hashcode on var34 and var74
//     assertTrue("Contract failed: equals-hashcode on var34 and var74", var34.equals(var74) ? var34.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var34
//     assertTrue("Contract failed: equals-hashcode on var74 and var34", var74.equals(var34) ? var74.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test84"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    var0.setAutoPopulateSeriesFillPaint(false);
    boolean var8 = var0.isSeriesVisibleInLegend(1);
    java.lang.Object var9 = var0.clone();
    boolean var10 = var0.getIncludeBaseInRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test85"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Set var2 = var0.keySet();
    java.lang.Object var4 = var0.handleGetObject("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=");
    java.util.Set var5 = var0.keySet();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test86"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.util.List var1 = var0.getLines();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
    double var7 = var6.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var9 = null;
    java.util.List var10 = var6.getCategoriesForAxis(var9);
    double var11 = var6.getAnchorValue();
    org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getHorizontalAlignment();
    java.lang.String var14 = var13.toString();
    var0.setLineAlignment(var13);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    var16.setNegativeArrowVisible(false);
    var16.setInverted(true);
    boolean var21 = var16.isVisible();
    java.lang.String var22 = var16.getLabelToolTip();
    org.jfree.chart.event.AxisChangeListener var23 = null;
    var16.addChangeListener(var23);
    org.jfree.chart.plot.Plot var25 = var16.getPlot();
    java.awt.Paint var26 = var16.getTickMarkPaint();
    boolean var27 = var13.equals((java.lang.Object)var16);
    float var28 = var16.getTickMarkOutsideLength();
    boolean var29 = var16.isPositiveArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var14.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test87"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var1 = null;
    org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)1L);
    java.lang.String var4 = var3.getToolTipText();
    java.awt.Graphics2D var5 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var8 = null;
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(var7, var8);
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 100.0d);
    org.jfree.chart.block.RectangleConstraint var13 = var9.toRangeHeight(var12);
    double var14 = var12.getLength();
    org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var12);
    org.jfree.chart.util.Size2D var16 = var3.arrange(var5, var15);
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("hi!");
    var3.add((org.jfree.chart.block.Block)var18);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
    double var26 = var25.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var27 = var25.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var28 = null;
    java.util.List var29 = var25.getCategoriesForAxis(var28);
    double var30 = var25.getAnchorValue();
    org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25);
    java.awt.Paint var32 = var31.getBackgroundPaint();
    java.awt.Font var33 = var31.getItemFont();
    org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle("hi!", var33);
    java.awt.Graphics2D var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    var34.draw(var35, var36);
    java.awt.Paint var38 = var34.getBackgroundPaint();
    java.awt.geom.Rectangle2D var39 = var34.getBounds();
    org.jfree.chart.util.VerticalAlignment var40 = var34.getVerticalAlignment();
    var18.setVerticalAlignment(var40);
    var18.setText("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=");
    java.lang.String var44 = var18.getText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="+ "'", var44.equals("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="));

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test88"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.lang.Object var2 = var1.clone();
//     org.jfree.chart.util.LengthAdjustmentType var3 = var1.getLabelOffsetType();
//     org.jfree.chart.util.RectangleInsets var4 = var1.getLabelOffset();
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.lang.Object var7 = var6.clone();
//     org.jfree.chart.util.LengthAdjustmentType var8 = var6.getLabelOffsetType();
//     java.lang.String var9 = var8.toString();
//     java.lang.String var10 = var8.toString();
//     var1.setLabelOffsetType(var8);
//     
//     // Checks the contract:  equals-hashcode on var1 and var6
//     assertTrue("Contract failed: equals-hashcode on var1 and var6", var1.equals(var6) ? var1.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var1
//     assertTrue("Contract failed: equals-hashcode on var6 and var1", var6.equals(var1) ? var6.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var7
//     assertTrue("Contract failed: equals-hashcode on var2 and var7", var2.equals(var7) ? var2.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var2
//     assertTrue("Contract failed: equals-hashcode on var7 and var2", var7.equals(var2) ? var7.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test89"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 100.0d);
    org.jfree.chart.block.RectangleConstraint var6 = var2.toRangeHeight(var5);
    org.jfree.chart.block.RectangleConstraint var7 = var6.toUnconstrainedWidth();
    org.jfree.data.Range var8 = var6.getHeightRange();
    org.jfree.chart.block.LengthConstraintType var9 = var6.getHeightConstraintType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test90"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    var0.setAutoPopulateSeriesFillPaint(false);
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var0.setBaseURLGenerator(var7);
    java.awt.Stroke var9 = var0.getErrorIndicatorStroke();
    java.awt.Stroke var11 = var0.getSeriesOutlineStroke((-1572964));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test91"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var14.draw(var15, var16);
//     org.jfree.chart.util.VerticalAlignment var18 = var14.getVerticalAlignment();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
//     double var25 = var24.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var26 = var24.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     java.util.List var28 = var24.getCategoriesForAxis(var27);
//     double var29 = var24.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
//     org.jfree.chart.util.HorizontalAlignment var31 = var30.getHorizontalAlignment();
//     org.jfree.chart.block.FlowArrangement var32 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var33 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var35 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var32, var33, (java.lang.Comparable)1L);
//     var35.setURLText("PlotOrientation.VERTICAL");
//     boolean var38 = var35.isEmpty();
//     var30.setWrapper((org.jfree.chart.block.BlockContainer)var35);
//     java.awt.Graphics2D var40 = null;
//     org.jfree.data.Range var42 = null;
//     org.jfree.data.Range var43 = null;
//     org.jfree.chart.block.RectangleConstraint var44 = new org.jfree.chart.block.RectangleConstraint(var42, var43);
//     org.jfree.data.Range var45 = null;
//     org.jfree.data.Range var47 = org.jfree.data.Range.expandToInclude(var45, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var48 = var44.toRangeHeight(var47);
//     double var49 = var47.getLength();
//     org.jfree.chart.block.RectangleConstraint var50 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var47);
//     org.jfree.data.Range var53 = new org.jfree.data.Range(1.0d, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var54 = var50.toRangeWidth(var53);
//     org.jfree.data.Range var55 = null;
//     org.jfree.data.Range var57 = org.jfree.data.Range.expandToInclude(var55, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var59 = new org.jfree.chart.block.RectangleConstraint(var57, 10.0d);
//     org.jfree.chart.block.RectangleConstraint var60 = var59.toUnconstrainedHeight();
//     org.jfree.data.Range var61 = null;
//     org.jfree.data.Range var63 = org.jfree.data.Range.expandToInclude(var61, 100.0d);
//     org.jfree.data.Range var64 = null;
//     org.jfree.data.Range var65 = null;
//     org.jfree.chart.block.RectangleConstraint var66 = new org.jfree.chart.block.RectangleConstraint(var64, var65);
//     org.jfree.data.Range var67 = null;
//     org.jfree.data.Range var69 = org.jfree.data.Range.expandToInclude(var67, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var71 = new org.jfree.chart.block.RectangleConstraint(var69, 10.0d);
//     org.jfree.data.Range var72 = null;
//     org.jfree.chart.block.RectangleConstraint var73 = new org.jfree.chart.block.RectangleConstraint(var69, var72);
//     double var74 = var69.getLowerBound();
//     org.jfree.chart.block.RectangleConstraint var75 = var66.toRangeHeight(var69);
//     org.jfree.chart.block.RectangleConstraint var76 = new org.jfree.chart.block.RectangleConstraint(var63, var69);
//     org.jfree.data.Range var79 = org.jfree.data.Range.expand(var63, 100.0d, 0.0d);
//     double var80 = var63.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var81 = var60.toRangeHeight(var63);
//     org.jfree.chart.block.RectangleConstraint var82 = new org.jfree.chart.block.RectangleConstraint(var53, var63);
//     org.jfree.chart.util.Size2D var83 = var30.arrange(var40, var82);
//     org.jfree.chart.util.Size2D var84 = var14.arrange(var19, var82);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test92"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    double var6 = var5.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var7 = var5.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    int var9 = var5.getIndexOf(var8);
    java.util.List var10 = var5.getCategories();
    org.jfree.chart.axis.AxisLocation var11 = var5.getDomainAxisLocation();
    org.jfree.chart.plot.DatasetRenderingOrder var12 = var5.getDatasetRenderingOrder();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var5);
    var5.setWeight((-3670018));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test93"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.2d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var1, var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    org.jfree.chart.util.RectangleEdge var10 = var8.getDomainAxisEdge((-1));
    org.jfree.chart.plot.Plot var11 = var8.getRootPlot();
    boolean var12 = var1.equals((java.lang.Object)var8);
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.lang.Object var20 = var19.clone();
    org.jfree.chart.util.LengthAdjustmentType var21 = var19.getLabelOffsetType();
    double var22 = var19.getValue();
    var17.addRangeMarker((org.jfree.chart.plot.Marker)var19);
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    double var29 = var28.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var30 = var28.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    int var32 = var28.getIndexOf(var31);
    org.jfree.chart.LegendItemCollection var33 = null;
    var28.setFixedLegendItems(var33);
    org.jfree.chart.event.PlotChangeListener var35 = null;
    var28.addChangeListener(var35);
    org.jfree.chart.util.Layer var37 = null;
    java.util.Collection var38 = var28.getRangeMarkers(var37);
    org.jfree.data.category.CategoryDataset var39 = null;
    org.jfree.chart.axis.CategoryAxis var40 = null;
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
    org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var39, var40, var41, var42);
    double var44 = var43.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var45 = var43.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var46 = null;
    java.util.List var47 = var43.getCategoriesForAxis(var46);
    double var48 = var43.getAnchorValue();
    java.awt.Color var51 = java.awt.Color.getColor("", 1);
    var43.setOutlinePaint((java.awt.Paint)var51);
    org.jfree.chart.axis.ValueAxis var54 = null;
    var43.setRangeAxis(0, var54, false);
    var28.setParent((org.jfree.chart.plot.Plot)var43);
    var43.setAnchorValue(10.0d);
    org.jfree.chart.axis.AxisLocation var60 = var43.getRangeAxisLocation();
    var17.setDomainAxisLocation(var60, true);
    var8.setDomainAxisLocation(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test94"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
    double var7 = var6.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var9 = var6.getRowRenderingOrder();
    java.awt.Stroke var10 = var6.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var6.getRendererForDataset(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var6);
    boolean var14 = var0.hasListener((java.util.EventListener)var13);
    org.jfree.chart.title.Title var15 = null;
    var13.removeSubtitle(var15);
    org.jfree.chart.event.ChartProgressListener var17 = null;
    var13.addProgressListener(var17);
    java.awt.Stroke var19 = var13.getBorderStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test95"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.2d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var1, var2);
    org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.util.RectangleEdge var6 = null;
    org.jfree.chart.axis.CategoryLabelPosition var7 = var5.getLabelPosition(var6);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("");
    double var11 = var10.getHeight();
    java.awt.Paint var12 = var10.getPaint();
    java.awt.Font var13 = var10.getFont();
    var8.setLabelFont(var13);
    var8.setUpperMargin(100.0d);
    org.jfree.chart.axis.CategoryLabelPositions var18 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0d);
    var8.setCategoryLabelPositions(var18);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
    double var26 = var25.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var27 = var25.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var28 = null;
    java.util.List var29 = var25.getCategoriesForAxis(var28);
    double var30 = var25.getAnchorValue();
    org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25);
    java.awt.Paint var32 = var31.getBackgroundPaint();
    java.awt.Font var33 = var31.getItemFont();
    org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle("hi!", var33);
    org.jfree.chart.util.RectangleEdge var35 = var34.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var36 = var18.getLabelPosition(var35);
    double var37 = var36.getAngle();
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var43 = new org.jfree.chart.block.LabelBlock("hi!");
    var43.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var49 = var43.getBounds();
    org.jfree.chart.util.RectangleAnchor var50 = null;
    java.awt.geom.Point2D var51 = org.jfree.chart.util.RectangleAnchor.coordinates(var49, var50);
    org.jfree.chart.util.RectangleEdge var52 = null;
    double var53 = var39.getCategoryStart((-16777216), (-16777216), var49, var52);
    org.jfree.chart.entity.CategoryLabelEntity var56 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var49, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
    java.lang.String var57 = var56.toString();
    java.awt.Shape var58 = var56.getArea();
    org.jfree.chart.event.ChartChangeEvent var59 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var58);
    boolean var60 = var36.equals((java.lang.Object)var58);
    org.jfree.chart.axis.CategoryLabelPositions var61 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var5, var36);
    org.jfree.chart.axis.CategoryLabelPositions var62 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var3, var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="+ "'", var57.equals("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test96"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.HorizontalAlignment var11 = var10.getHorizontalAlignment();
    org.jfree.chart.util.RectangleInsets var12 = var10.getMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test97"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.Object var1 = var0.clone();
    var0.setLabelToolTip("[size=1]");
    java.lang.Object var4 = var0.clone();
    java.awt.Font var6 = var0.getTickLabelFont((java.lang.Comparable)"PlotOrientation.VERTICAL");
    double var7 = var0.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test98"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
//     double var8 = var7.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var10 = var7.getRowRenderingOrder();
//     java.awt.Stroke var11 = var7.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = var7.getRendererForDataset(var12);
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var7);
//     boolean var15 = var1.hasListener((java.util.EventListener)var14);
//     java.awt.Paint var18 = var1.getItemOutlinePaint((-253), (-8323073));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var19 = var1.getLegendItemLabelGenerator();
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker((-1.0d));
//     java.awt.Font var22 = var21.getLabelFont();
//     var1.setBaseItemLabelFont(var22, true);
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var25, var26, var27, var28);
//     double var30 = var29.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var31 = var29.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     java.util.List var33 = var29.getCategoriesForAxis(var32);
//     double var34 = var29.getAnchorValue();
//     java.awt.Color var37 = java.awt.Color.getColor("", 1);
//     var29.setOutlinePaint((java.awt.Paint)var37);
//     java.awt.Stroke var39 = var29.getDomainGridlineStroke();
//     java.awt.Color var42 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var43 = var42.getColorSpace();
//     java.awt.image.ColorModel var44 = null;
//     java.awt.Rectangle var45 = null;
//     org.jfree.chart.block.LabelBlock var47 = new org.jfree.chart.block.LabelBlock("hi!");
//     var47.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var53 = var47.getBounds();
//     java.awt.geom.AffineTransform var54 = null;
//     java.awt.RenderingHints var55 = null;
//     java.awt.PaintContext var56 = var42.createContext(var44, var45, var53, var54, var55);
//     var29.setNoDataMessagePaint((java.awt.Paint)var42);
//     var29.setNoDataMessage("");
//     org.jfree.chart.event.AxisChangeEvent var60 = null;
//     var29.axisChanged(var60);
//     org.jfree.chart.axis.AxisLocation var63 = var29.getDomainAxisLocation((-165));
//     java.awt.Paint var64 = var29.getRangeCrosshairPaint();
//     org.jfree.chart.text.TextFragment var65 = new org.jfree.chart.text.TextFragment("", var22, var64);
//     
//     // Checks the contract:  equals-hashcode on var9 and var31
//     assertTrue("Contract failed: equals-hashcode on var9 and var31", var9.equals(var31) ? var9.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var9
//     assertTrue("Contract failed: equals-hashcode on var31 and var9", var31.equals(var9) ? var31.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test99"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    int var8 = var4.getIndexOf(var7);
    org.jfree.chart.LegendItemCollection var9 = null;
    var4.setFixedLegendItems(var9);
    org.jfree.chart.event.PlotChangeListener var11 = null;
    var4.addChangeListener(var11);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var21 = null;
    java.util.List var22 = var18.getCategoriesForAxis(var21);
    double var23 = var18.getAnchorValue();
    org.jfree.chart.plot.PlotOrientation var24 = var18.getOrientation();
    var18.setRangeCrosshairLockedOnData(true);
    var18.setBackgroundImageAlignment((-8323073));
    org.jfree.chart.event.PlotChangeEvent var29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var18);
    org.jfree.chart.axis.AxisLocation var30 = var18.getDomainAxisLocation();
    var4.setRangeAxisLocation(10, var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test100"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    double var3 = var1.calculateRightInset(8.0d);
    double var5 = var1.calculateTopInset(9.05d);
    double var6 = var1.getLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test101"); }


    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var11 = var8.getRowRenderingOrder();
    java.awt.Stroke var12 = var8.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = var8.getRendererForDataset(var13);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var8);
    java.util.List var16 = var15.getSubtitles();
    org.jfree.chart.ChartRenderingInfo var21 = null;
    java.awt.image.BufferedImage var22 = var15.createBufferedImage(1, 10, (-1.0d), 1.0d, var21);
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("ChartEntity: tooltip = hi!", "PlotOrientation.VERTICAL", "org.jfree.chart.event.ChartChangeEvent[source=0]", (java.awt.Image)var22, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "org.jfree.chart.event.ChartChangeEvent[source=0]", "");
    java.lang.String var27 = var26.getName();
    var26.setInfo("SortOrder.ASCENDING");
    java.lang.String var30 = var26.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "ChartEntity: tooltip = hi!"+ "'", var27.equals("ChartEntity: tooltip = hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "PlotOrientation.VERTICAL"+ "'", var30.equals("PlotOrientation.VERTICAL"));

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test102"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    var4.clearAnnotations();
    java.awt.Image var8 = null;
    var4.setBackgroundImage(var8);
    org.jfree.chart.plot.DatasetRenderingOrder var10 = var4.getDatasetRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test103"); }


    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "hi!", "hi!");
    org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var6);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var6, var13);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var16 = var15.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var15.getLegendItemToolTipGenerator();
    java.awt.Shape var19 = var15.lookupSeriesShape(0);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    double var25 = var24.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var26 = var24.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var27 = null;
    java.util.List var28 = var24.getCategoriesForAxis(var27);
    double var29 = var24.getAnchorValue();
    var24.clearDomainAxes();
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
    org.jfree.chart.title.LegendTitle var33 = var31.getLegend(10);
    java.awt.Stroke var34 = var31.getBorderStroke();
    var15.setBaseStroke(var34);
    boolean var38 = var15.isItemLabelVisible(0, (-165));
    java.awt.Stroke var41 = var15.getItemOutlineStroke(15, (-16777215));
    java.awt.Paint var42 = null;
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=0]", "RectangleConstraintType.RANGE", "[size=1]", "VerticalAlignment.CENTER", var6, var41, var42);
    java.lang.Comparable var44 = var43.getSeriesKey();
    java.awt.Stroke var45 = var43.getOutlineStroke();
    boolean var46 = var43.isShapeVisible();
    var43.setDatasetIndex(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test104"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
//     var1.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.lang.String var7 = var1.getID();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.data.Range var9 = null;
//     org.jfree.data.Range var10 = null;
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(var9, var10);
//     org.jfree.data.Range var12 = null;
//     org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var15 = var11.toRangeHeight(var14);
//     org.jfree.chart.block.RectangleConstraint var17 = var15.toFixedWidth(8.0d);
//     org.jfree.chart.util.Size2D var18 = var1.arrange(var8, var17);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test105"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    var0.setItemMargin(0.05d);
    int var7 = var0.getPassCount();
    java.awt.Paint var9 = var0.getSeriesPaint((-253));
    org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var12.setAlpha(0.0f);
    java.awt.Stroke var15 = var12.getOutlineStroke();
    java.awt.Stroke var16 = var12.getStroke();
    var0.setSeriesStroke(0, var16);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var19 = var18.getRowCount();
    java.awt.Paint var20 = var18.getBasePaint();
    java.awt.Stroke var22 = var18.getSeriesStroke(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var23 = null;
    var18.setLegendItemToolTipGenerator(var23);
    java.awt.Color var27 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var28 = var27.getColorSpace();
    java.awt.image.ColorModel var29 = null;
    java.awt.Rectangle var30 = null;
    org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("hi!");
    var32.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var38 = var32.getBounds();
    java.awt.geom.AffineTransform var39 = null;
    java.awt.RenderingHints var40 = null;
    java.awt.PaintContext var41 = var27.createContext(var29, var30, var38, var39, var40);
    boolean var42 = var18.equals((java.lang.Object)var27);
    org.jfree.chart.labels.ItemLabelPosition var44 = var18.getSeriesPositiveItemLabelPosition((-8323073));
    java.awt.Stroke var45 = var18.getBaseOutlineStroke();
    java.awt.Paint var47 = var18.lookupSeriesFillPaint((-8323073));
    var0.setErrorIndicatorPaint(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test106"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    java.awt.RenderingHints var12 = var11.getRenderingHints();
    var11.setBackgroundImageAlpha(0.0f);
    java.awt.image.BufferedImage var17 = var11.createBufferedImage(4, 255);
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("hi!");
    var23.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var29 = var23.getBounds();
    org.jfree.chart.util.RectangleAnchor var30 = null;
    java.awt.geom.Point2D var31 = org.jfree.chart.util.RectangleAnchor.coordinates(var29, var30);
    org.jfree.chart.util.RectangleEdge var32 = null;
    double var33 = var19.getCategoryStart((-16777216), (-16777216), var29, var32);
    org.jfree.chart.entity.CategoryLabelEntity var36 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var29, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
    java.lang.String var37 = var36.toString();
    java.awt.Shape var38 = var36.getArea();
    org.jfree.chart.event.ChartChangeEvent var39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var38);
    boolean var40 = var11.equals((java.lang.Object)var39);
    org.jfree.chart.event.ChartChangeEventType var41 = var39.getType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="+ "'", var37.equals("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test107"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
    double var3 = var2.getHeight();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Font var5 = var2.getFont();
    var0.setLabelFont(var5);
    java.lang.String var8 = var0.getCategoryLabelToolTip((java.lang.Comparable)(byte)10);
    var0.setFixedDimension(6.0d);
    java.awt.Font var11 = var0.getTickLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test108"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var12 = var11.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var11.getLegendItemToolTipGenerator();
//     java.awt.Shape var15 = var11.lookupSeriesShape(0);
//     int var16 = var4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
//     var11.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.util.StandardGradientPaintTransformer var19 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var11.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var19);
//     org.jfree.chart.util.GradientPaintTransformType var21 = var19.getType();
//     java.lang.String var22 = var21.toString();
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     double var28 = var27.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var29 = var27.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     java.util.List var31 = var27.getCategoriesForAxis(var30);
//     double var32 = var27.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
//     org.jfree.chart.util.HorizontalAlignment var34 = var33.getHorizontalAlignment();
//     org.jfree.chart.block.FlowArrangement var35 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var36 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var38 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var35, var36, (java.lang.Comparable)1L);
//     var38.setURLText("PlotOrientation.VERTICAL");
//     boolean var41 = var38.isEmpty();
//     var33.setWrapper((org.jfree.chart.block.BlockContainer)var38);
//     java.awt.Graphics2D var43 = null;
//     org.jfree.data.Range var45 = null;
//     org.jfree.data.Range var46 = null;
//     org.jfree.chart.block.RectangleConstraint var47 = new org.jfree.chart.block.RectangleConstraint(var45, var46);
//     org.jfree.data.Range var48 = null;
//     org.jfree.data.Range var50 = org.jfree.data.Range.expandToInclude(var48, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var51 = var47.toRangeHeight(var50);
//     double var52 = var50.getLength();
//     org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var50);
//     org.jfree.data.Range var56 = new org.jfree.data.Range(1.0d, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var57 = var53.toRangeWidth(var56);
//     org.jfree.data.Range var58 = null;
//     org.jfree.data.Range var60 = org.jfree.data.Range.expandToInclude(var58, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var62 = new org.jfree.chart.block.RectangleConstraint(var60, 10.0d);
//     org.jfree.chart.block.RectangleConstraint var63 = var62.toUnconstrainedHeight();
//     org.jfree.data.Range var64 = null;
//     org.jfree.data.Range var66 = org.jfree.data.Range.expandToInclude(var64, 100.0d);
//     org.jfree.data.Range var67 = null;
//     org.jfree.data.Range var68 = null;
//     org.jfree.chart.block.RectangleConstraint var69 = new org.jfree.chart.block.RectangleConstraint(var67, var68);
//     org.jfree.data.Range var70 = null;
//     org.jfree.data.Range var72 = org.jfree.data.Range.expandToInclude(var70, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var74 = new org.jfree.chart.block.RectangleConstraint(var72, 10.0d);
//     org.jfree.data.Range var75 = null;
//     org.jfree.chart.block.RectangleConstraint var76 = new org.jfree.chart.block.RectangleConstraint(var72, var75);
//     double var77 = var72.getLowerBound();
//     org.jfree.chart.block.RectangleConstraint var78 = var69.toRangeHeight(var72);
//     org.jfree.chart.block.RectangleConstraint var79 = new org.jfree.chart.block.RectangleConstraint(var66, var72);
//     org.jfree.data.Range var82 = org.jfree.data.Range.expand(var66, 100.0d, 0.0d);
//     double var83 = var66.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var84 = var63.toRangeHeight(var66);
//     org.jfree.chart.block.RectangleConstraint var85 = new org.jfree.chart.block.RectangleConstraint(var56, var66);
//     org.jfree.chart.util.Size2D var86 = var33.arrange(var43, var85);
//     boolean var87 = var21.equals((java.lang.Object)var43);
//     
//     // Checks the contract:  equals-hashcode on var4 and var27
//     assertTrue("Contract failed: equals-hashcode on var4 and var27", var4.equals(var27) ? var4.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var4
//     assertTrue("Contract failed: equals-hashcode on var27 and var4", var27.equals(var4) ? var27.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var29
//     assertTrue("Contract failed: equals-hashcode on var6 and var29", var6.equals(var29) ? var6.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var6
//     assertTrue("Contract failed: equals-hashcode on var29 and var6", var29.equals(var6) ? var29.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test109"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    int var3 = var0.getColumnIndex((java.lang.Comparable)"CategoryLabelEntity: category=UnitType.ABSOLUTE, tooltip=Range[-1.0,-1.0], url=3");
    java.lang.Number var4 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0d+ "'", var4.equals(0.0d));

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test110"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("\uFFFD", var1, 18.05d, (-1.0f), 2.0f);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test111"); }


    java.lang.Comparable var0 = null;
    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.text.TextAnchor var5 = var4.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var7 = new org.jfree.chart.axis.CategoryTick(var0, var1, var2, var5, (-1.0d));
    java.lang.Object var8 = var7.clone();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("hi!");
    var13.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var19 = var13.getBounds();
    org.jfree.chart.util.RectangleAnchor var20 = null;
    java.awt.geom.Point2D var21 = org.jfree.chart.util.RectangleAnchor.coordinates(var19, var20);
    org.jfree.chart.util.RectangleEdge var22 = null;
    double var23 = var9.getCategoryStart((-16777216), (-16777216), var19, var22);
    var9.setTickMarkOutsideLength(0.0f);
    org.jfree.chart.util.RectangleInsets var26 = var9.getLabelInsets();
    float var27 = var9.getTickMarkOutsideLength();
    var9.setCategoryLabelPositionOffset(0);
    boolean var30 = var7.equals((java.lang.Object)var9);
    org.jfree.chart.text.TextBlockAnchor var31 = var7.getLabelAnchor();
    java.lang.Object var32 = null;
    boolean var33 = var7.equals(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test112"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.awt.Color var5 = java.awt.Color.getHSBColor((-1.0f), 0.5f, 0.0f);
    var0.setPaint((java.awt.Paint)var5);
    int var7 = var5.getGreen();
    org.jfree.chart.util.StandardGradientPaintTransformer var8 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var9 = var8.getType();
    org.jfree.chart.text.TextBlock var10 = new org.jfree.chart.text.TextBlock();
    java.util.List var11 = var10.getLines();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.util.Size2D var13 = var10.calculateDimensions(var12);
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var16 = null;
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(var15, var16);
    org.jfree.data.Range var18 = null;
    org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var18, 100.0d);
    org.jfree.chart.block.RectangleConstraint var21 = var17.toRangeHeight(var20);
    double var22 = var20.getLength();
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var20);
    double var25 = var20.constrain(10.0d);
    boolean var26 = var10.equals((java.lang.Object)10.0d);
    java.awt.Graphics2D var27 = null;
    org.jfree.chart.text.TextBlockAnchor var30 = null;
    java.awt.Shape var34 = var10.calculateBounds(var27, 100.0f, 0.0f, var30, 1.0f, 0.0f, 2.0d);
    boolean var35 = var8.equals((java.lang.Object)1.0f);
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var40 = new org.jfree.chart.block.LabelBlock("hi!");
    var40.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var46 = var40.getBounds();
    org.jfree.chart.util.RectangleAnchor var47 = null;
    java.awt.geom.Point2D var48 = org.jfree.chart.util.RectangleAnchor.coordinates(var46, var47);
    org.jfree.chart.util.RectangleEdge var49 = null;
    double var50 = var36.getCategoryStart((-16777216), (-16777216), var46, var49);
    var36.setMaximumCategoryLabelLines(10);
    float var53 = var36.getMaximumCategoryLabelWidthRatio();
    java.lang.String var54 = var36.getLabel();
    org.jfree.chart.axis.NumberTickUnit var56 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("hi!");
    java.lang.String var59 = var58.getID();
    int var60 = var56.compareTo((java.lang.Object)var58);
    int var61 = var56.getMinorTickCount();
    java.lang.String var62 = var56.toString();
    var36.removeCategoryLabelToolTip((java.lang.Comparable)var56);
    java.awt.Color var67 = java.awt.Color.getHSBColor(100.0f, 100.0f, 0.0f);
    var36.setTickMarkPaint((java.awt.Paint)var67);
    boolean var69 = var8.equals((java.lang.Object)var67);
    org.jfree.chart.block.LabelBlock var73 = new org.jfree.chart.block.LabelBlock("");
    double var74 = var73.getHeight();
    java.awt.Paint var75 = var73.getPaint();
    java.awt.Font var76 = var73.getFont();
    org.jfree.chart.title.TextTitle var77 = new org.jfree.chart.title.TextTitle("hi!", var76);
    java.awt.Color var80 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
    org.jfree.chart.block.LabelBlock var81 = new org.jfree.chart.block.LabelBlock("", var76, (java.awt.Paint)var80);
    float[] var82 = null;
    float[] var83 = var80.getComponents(var82);
    java.awt.color.ColorSpace var84 = var80.getColorSpace();
    float[] var85 = null;
    float[] var86 = var67.getComponents(var84, var85);
    float[] var87 = var5.getColorComponents(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + "[size=1]"+ "'", var62.equals("[size=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test113"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    var4.setDomainGridlinesVisible(false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var12 = var11.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var11.getLegendItemToolTipGenerator();
    java.awt.Shape var15 = var11.lookupSeriesShape(0);
    int var16 = var4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    var11.setAutoPopulateSeriesFillPaint(true);
    java.awt.Shape var20 = var11.lookupSeriesShape(100);
    java.awt.Stroke var23 = var11.getItemOutlineStroke(100, (-253));
    boolean var24 = var11.isDrawBarOutline();
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var11.getBaseItemLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test114"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    org.jfree.chart.util.RectangleInsets var2 = var0.getInsets();
    java.awt.Paint var3 = var0.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test115"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    int var2 = var1.getSubplotCount();
    org.jfree.chart.renderer.RendererState var3 = new org.jfree.chart.renderer.RendererState(var1);
    org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("hi!");
    var5.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var11 = var5.getBounds();
    org.jfree.chart.util.RectangleAnchor var12 = null;
    java.awt.geom.Point2D var13 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var12);
    int var14 = var1.getSubplotIndex(var13);
    org.jfree.chart.ChartRenderingInfo var15 = var1.getOwner();
    org.jfree.chart.renderer.category.CategoryItemRendererState var16 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var1);
    org.jfree.chart.entity.EntityCollection var17 = var16.getEntityCollection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test116"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    var4.clearAnnotations();
    java.awt.Image var8 = null;
    var4.setBackgroundImage(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var4.getRenderer();
    int var11 = var4.getWeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test117"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getColumnIndex((java.lang.Comparable)"100");
    java.util.List var3 = var0.getColumnKeys();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var4.addChangeListener(var6);
    boolean var8 = var0.equals((java.lang.Object)var4);
    org.jfree.chart.axis.NumberTickUnit var10 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    double var16 = var15.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var18 = null;
    java.util.List var19 = var15.getCategoriesForAxis(var18);
    org.jfree.chart.axis.AxisSpace var20 = var15.getFixedDomainAxisSpace();
    var15.setOutlineVisible(false);
    boolean var23 = var15.isSubplot();
    org.jfree.data.KeyedObject var24 = new org.jfree.data.KeyedObject((java.lang.Comparable)var10, (java.lang.Object)var15);
    int var25 = var0.getRowIndex((java.lang.Comparable)var10);
    int var26 = var0.getColumnCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test118"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.LegendItemCollection var7 = null;
    var4.setFixedLegendItems(var7);
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var9, var10, var11, var12);
    double var14 = var13.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var15 = var13.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    int var17 = var13.getIndexOf(var16);
    java.util.List var18 = var13.getCategories();
    var13.configureDomainAxes();
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var21.setAlpha(0.0f);
    java.awt.Stroke var24 = var21.getOutlineStroke();
    var13.addRangeMarker((org.jfree.chart.plot.Marker)var21);
    var4.setParent((org.jfree.chart.plot.Plot)var13);
    var13.clearDomainMarkers((-589829));
    org.jfree.chart.plot.Plot var29 = var13.getRootPlot();
    float var30 = var29.getForegroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0f);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test119"); }


    java.lang.Comparable var0 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var2 = var1.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var1.getLegendItemToolTipGenerator();
    java.awt.Shape var5 = var1.lookupSeriesShape(0);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var6, var7, var8, var9);
    double var11 = var10.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var12 = var10.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var13 = null;
    java.util.List var14 = var10.getCategoriesForAxis(var13);
    double var15 = var10.getAnchorValue();
    var10.clearDomainAxes();
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    org.jfree.chart.title.LegendTitle var19 = var17.getLegend(10);
    java.awt.Stroke var20 = var17.getBorderStroke();
    var1.setBaseStroke(var20);
    var1.setMaximumBarWidth(8.0d);
    var1.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.plot.DrawingSupplier var26 = var1.getDrawingSupplier();
    org.jfree.data.KeyedObject var27 = new org.jfree.data.KeyedObject(var0, (java.lang.Object)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test120"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var4 = var3.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var3.getLegendItemToolTipGenerator();
    java.awt.Shape var7 = var3.lookupSeriesShape(0);
    var3.setAutoPopulateSeriesFillPaint(true);
    var3.setBaseSeriesVisible(false, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var14 = var13.getRowCount();
    java.awt.Paint var15 = var13.getBasePaint();
    java.awt.Stroke var17 = var13.getSeriesStroke(1);
    var13.setItemMargin(0.05d);
    int var20 = var13.getPassCount();
    java.awt.Paint var22 = var13.getSeriesPaint((-253));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var24 = var23.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var25 = var23.getLegendItemToolTipGenerator();
    java.awt.Shape var27 = var23.lookupSeriesShape(0);
    org.jfree.data.category.CategoryDataset var28 = null;
    org.jfree.chart.axis.CategoryAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var28, var29, var30, var31);
    double var33 = var32.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var34 = var32.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var35 = null;
    java.util.List var36 = var32.getCategoriesForAxis(var35);
    double var37 = var32.getAnchorValue();
    var32.clearDomainAxes();
    org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var32);
    org.jfree.chart.title.LegendTitle var41 = var39.getLegend(10);
    java.awt.Stroke var42 = var39.getBorderStroke();
    var23.setBaseStroke(var42);
    boolean var46 = var23.isItemLabelVisible(0, (-165));
    var23.setBaseItemLabelsVisible(false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var49 = var23.getLegendItemLabelGenerator();
    var13.setLegendItemToolTipGenerator(var49);
    var3.setLegendItemLabelGenerator(var49);
    var0.setLegendItemToolTipGenerator(var49);
    boolean var53 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategoryToolTipGenerator var54 = null;
    var0.setBaseToolTipGenerator(var54, false);
    var0.setItemMargin(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test121"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var1 = null;
    org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)1L);
    java.util.List var4 = var3.getBlocks();
    org.jfree.chart.block.Arrangement var5 = var3.getArrangement();
    org.jfree.chart.util.RectangleInsets var6 = var3.getPadding();
    java.lang.Object var7 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test122"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setAutoRangeStickyZero(false);
    boolean var3 = var0.isPositiveArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test123"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("PlotOrientation.VERTICAL version VerticalAlignment.CENTER.\norg.jfree.chart.event.ChartChangeEvent[source=0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY PlotOrientation.VERTICAL:None\nPlotOrientation.VERTICAL LICENCE TERMS:\n10", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "TextAnchor.CENTER", "SortOrder.ASCENDING", "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test124"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape((-16777215));
    org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = hi!");
    boolean var5 = var0.equals((java.lang.Object)var4);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var13 = new org.jfree.chart.entity.TickLabelEntity(var10, "hi!", "hi!");
    org.jfree.chart.entity.ChartEntity var14 = new org.jfree.chart.entity.ChartEntity(var10);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var10, var17);
    org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker((-1.0d));
    org.jfree.chart.util.LengthAdjustmentType var21 = var20.getLabelOffsetType();
    java.awt.Paint var22 = var20.getOutlinePaint();
    org.jfree.chart.title.LegendGraphic var23 = new org.jfree.chart.title.LegendGraphic(var17, var22);
    org.jfree.data.Range var24 = null;
    org.jfree.data.Range var25 = null;
    org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(var24, var25);
    org.jfree.data.Range var27 = null;
    org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, 100.0d);
    org.jfree.chart.block.RectangleConstraint var30 = var26.toRangeHeight(var29);
    org.jfree.chart.block.RectangleConstraint var31 = var30.toUnconstrainedWidth();
    org.jfree.data.Range var32 = var30.getHeightRange();
    boolean var33 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var17, (java.lang.Object)var32);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-3670018), var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test125"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.plot.PlotOrientation var10 = var4.getOrientation();
    var4.setRangeCrosshairValue(0.0d, false);
    org.jfree.chart.axis.CategoryAxis var15 = var4.getDomainAxis((-16777216));
    org.jfree.chart.event.MarkerChangeEvent var16 = null;
    var4.markerChanged(var16);
    java.lang.String var18 = var4.getNoDataMessage();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test126"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 100.0d);
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var2, 10.0d);
    org.jfree.data.Range var6 = org.jfree.data.Range.shift(var2, 0.05d);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
    double var12 = var11.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var13 = var11.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    int var15 = var11.getIndexOf(var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var11.setFixedLegendItems(var16);
    org.jfree.chart.event.PlotChangeListener var18 = null;
    var11.addChangeListener(var18);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var21 = var20.getRowCount();
    java.awt.Paint var22 = var20.getBasePaint();
    java.awt.Stroke var24 = var20.getSeriesStroke(1);
    var20.setAutoPopulateSeriesFillPaint(false);
    org.jfree.chart.urls.CategoryURLGenerator var27 = null;
    var20.setBaseURLGenerator(var27);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var29 = var20.getLegendItemToolTipGenerator();
    boolean var30 = var20.getAutoPopulateSeriesOutlinePaint();
    java.lang.Object var31 = null;
    boolean var32 = var20.equals(var31);
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var33 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var20};
    var11.setRenderers(var33);
    boolean var35 = var2.equals((java.lang.Object)var11);
    org.jfree.chart.block.LabelBlock var38 = new org.jfree.chart.block.LabelBlock("");
    double var39 = var38.getHeight();
    java.awt.Paint var40 = var38.getPaint();
    java.awt.Font var41 = var38.getFont();
    org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle("hi!", var41);
    var11.setNoDataMessageFont(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test127"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var11 = var10.getBackgroundPaint();
    org.jfree.chart.util.VerticalAlignment var12 = var10.getVerticalAlignment();
    java.awt.Graphics2D var13 = null;
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var15 = null;
    org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(var14, var15);
    org.jfree.data.Range var17 = null;
    org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 100.0d);
    org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var19, 10.0d);
    org.jfree.data.Range var22 = null;
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint(var19, var22);
    double var24 = var19.getLowerBound();
    org.jfree.chart.block.RectangleConstraint var25 = var16.toRangeHeight(var19);
    org.jfree.chart.util.Size2D var26 = var10.arrange(var13, var16);
    org.jfree.chart.util.RectangleInsets var27 = var10.getItemLabelPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test128"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.lang.Object var7 = var6.clone();
//     org.jfree.chart.util.LengthAdjustmentType var8 = var6.getLabelOffsetType();
//     double var9 = var6.getValue();
//     var4.addRangeMarker((org.jfree.chart.plot.Marker)var6);
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
//     double var16 = var15.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var17 = var15.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     int var19 = var15.getIndexOf(var18);
//     org.jfree.chart.LegendItemCollection var20 = null;
//     var15.setFixedLegendItems(var20);
//     org.jfree.chart.event.PlotChangeListener var22 = null;
//     var15.addChangeListener(var22);
//     org.jfree.chart.util.Layer var24 = null;
//     java.util.Collection var25 = var15.getRangeMarkers(var24);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
//     double var31 = var30.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var32 = var30.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     java.util.List var34 = var30.getCategoriesForAxis(var33);
//     double var35 = var30.getAnchorValue();
//     java.awt.Color var38 = java.awt.Color.getColor("", 1);
//     var30.setOutlinePaint((java.awt.Paint)var38);
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     var30.setRangeAxis(0, var41, false);
//     var15.setParent((org.jfree.chart.plot.Plot)var30);
//     var30.setAnchorValue(10.0d);
//     org.jfree.chart.axis.AxisLocation var47 = var30.getRangeAxisLocation();
//     var4.setDomainAxisLocation(var47, true);
//     org.jfree.chart.axis.AxisSpace var50 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.data.category.CategoryDataset var53 = null;
//     org.jfree.chart.axis.CategoryAxis var54 = null;
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var56 = null;
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot(var53, var54, var55, var56);
//     double var58 = var57.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var59 = var57.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var60 = null;
//     java.util.List var61 = var57.getCategoriesForAxis(var60);
//     double var62 = var57.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var57);
//     java.awt.Paint var64 = var63.getBackgroundPaint();
//     java.awt.Font var65 = var63.getItemFont();
//     org.jfree.chart.title.TextTitle var66 = new org.jfree.chart.title.TextTitle("hi!", var65);
//     org.jfree.chart.util.RectangleEdge var67 = var66.getPosition();
//     var50.add(100.0d, var67);
//     var50.setLeft(12.0d);
//     var4.setFixedRangeAxisSpace(var50);
//     
//     // Checks the contract:  equals-hashcode on var15 and var57
//     assertTrue("Contract failed: equals-hashcode on var15 and var57", var15.equals(var57) ? var15.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var15
//     assertTrue("Contract failed: equals-hashcode on var57 and var15", var57.equals(var15) ? var57.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var59
//     assertTrue("Contract failed: equals-hashcode on var32 and var59", var32.equals(var59) ? var32.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var32
//     assertTrue("Contract failed: equals-hashcode on var59 and var32", var59.equals(var32) ? var59.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test129"); }


    java.lang.Comparable var1 = null;
    org.jfree.chart.text.TextBlock var2 = null;
    org.jfree.chart.text.TextBlockAnchor var3 = null;
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.text.TextAnchor var6 = var5.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var8 = new org.jfree.chart.axis.CategoryTick(var1, var2, var3, var6, (-1.0d));
    org.jfree.chart.text.TextAnchor var9 = var8.getTextAnchor();
    org.jfree.data.KeyedObject var10 = new org.jfree.data.KeyedObject((java.lang.Comparable)true, (java.lang.Object)var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    double var16 = var15.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var17 = var15.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    int var19 = var15.getIndexOf(var18);
    java.util.List var20 = var15.getCategories();
    org.jfree.chart.axis.AxisLocation var21 = var15.getDomainAxisLocation();
    org.jfree.chart.plot.DatasetRenderingOrder var22 = var15.getDatasetRenderingOrder();
    boolean var23 = var10.equals((java.lang.Object)var22);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var29 = new org.jfree.chart.entity.TickLabelEntity(var26, "hi!", "hi!");
    org.jfree.data.Range var30 = null;
    org.jfree.data.Range var31 = null;
    org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(var30, var31);
    boolean var33 = var29.equals((java.lang.Object)var30);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var29.setArea(var36);
    org.jfree.data.category.CategoryDataset var38 = null;
    org.jfree.chart.axis.CategoryAxis var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var38, var39, var40, var41);
    double var43 = var42.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var44 = var42.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var45 = null;
    java.util.List var46 = var42.getCategoriesForAxis(var45);
    double var47 = var42.getAnchorValue();
    java.awt.Color var50 = java.awt.Color.getColor("", 1);
    var42.setOutlinePaint((java.awt.Paint)var50);
    java.awt.Stroke var52 = var42.getDomainGridlineStroke();
    java.awt.Color var55 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var56 = var55.getColorSpace();
    java.awt.image.ColorModel var57 = null;
    java.awt.Rectangle var58 = null;
    org.jfree.chart.block.LabelBlock var60 = new org.jfree.chart.block.LabelBlock("hi!");
    var60.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var66 = var60.getBounds();
    java.awt.geom.AffineTransform var67 = null;
    java.awt.RenderingHints var68 = null;
    java.awt.PaintContext var69 = var55.createContext(var57, var58, var66, var67, var68);
    var42.setNoDataMessagePaint((java.awt.Paint)var55);
    org.jfree.chart.title.LegendGraphic var71 = new org.jfree.chart.title.LegendGraphic(var36, (java.awt.Paint)var55);
    java.awt.Shape var72 = var71.getShape();
    double var73 = var71.getContentXOffset();
    java.awt.Graphics2D var74 = null;
    org.jfree.chart.util.Size2D var75 = var71.arrange(var74);
    org.jfree.chart.util.RectangleAnchor var76 = var71.getShapeAnchor();
    boolean var77 = var10.equals((java.lang.Object)var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test130"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var2 = var0.getTickUnit();
    var0.setAutoTickUnitSelection(false);
    double var5 = var0.getUpperMargin();
    java.text.NumberFormat var6 = null;
    var0.setNumberFormatOverride(var6);
    org.jfree.chart.util.RectangleInsets var12 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var14 = var12.extendHeight(4.0d);
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("SortOrder.ASCENDING");
    var16.setNotify(false);
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.block.LineBorder var22 = new org.jfree.chart.block.LineBorder();
    java.awt.Graphics2D var23 = null;
    org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("hi!");
    var25.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var31 = var25.getBounds();
    org.jfree.data.category.CategoryDataset var33 = null;
    org.jfree.chart.axis.CategoryAxis var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var33, var34, var35, var36);
    double var38 = var37.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var39 = var37.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var40 = null;
    java.util.List var41 = var37.getCategoriesForAxis(var40);
    double var42 = var37.getAnchorValue();
    org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37);
    java.awt.Paint var44 = var43.getBackgroundPaint();
    java.awt.Font var45 = var43.getItemFont();
    org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle("hi!", var45);
    java.awt.Graphics2D var47 = null;
    java.awt.geom.Rectangle2D var48 = null;
    var46.draw(var47, var48);
    java.awt.Paint var50 = var46.getBackgroundPaint();
    java.awt.geom.Rectangle2D var51 = var46.getBounds();
    boolean var52 = org.jfree.chart.util.ShapeUtilities.intersects(var31, var51);
    var22.draw(var23, var31);
    java.awt.geom.Point2D var54 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(2.0d, 2.0d, var31);
    var16.draw(var19, var31);
    var12.trim(var31);
    var0.setTickLabelInsets(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test131"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis();
    org.jfree.chart.axis.AxisLocation var8 = var4.getDomainAxisLocation(0);
    org.jfree.chart.axis.ValueAxis var10 = var4.getRangeAxisForDataset(15);
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("hi!");
    var12.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var18 = var12.getBounds();
    org.jfree.data.general.Dataset var19 = null;
    org.jfree.data.general.DatasetChangeEvent var20 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var12, var19);
    var4.datasetChanged(var20);
    org.jfree.chart.plot.Plot var22 = var4.getParent();
    org.jfree.chart.annotations.CategoryAnnotation var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addAnnotation(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test132"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.FlowArrangement var1 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var2 = null;
    org.jfree.chart.title.LegendItemBlockContainer var4 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var1, var2, (java.lang.Comparable)1L);
    java.lang.Object var5 = var4.clone();
    var4.setToolTipText("Size2D[width=-1.0, height=-1.0]");
    org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("");
    double var11 = var10.getHeight();
    java.awt.Paint var12 = var10.getPaint();
    java.awt.Font var13 = var10.getFont();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
    var0.add((org.jfree.chart.block.Block)var4, (java.lang.Object)"hi!");
    boolean var17 = var0.equals((java.lang.Object)"RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    org.jfree.chart.block.BlockContainer var18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
    org.jfree.chart.block.BlockFrame var19 = var18.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test133"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainMarkers();
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("");
    double var13 = var12.getHeight();
    java.awt.Paint var14 = var12.getPaint();
    var4.setRangeCrosshairPaint(var14);
    int var16 = var4.getDomainAxisCount();
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    var4.setDomainGridlinesVisible(true);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var21 = var20.getColumnCount();
    org.jfree.data.Range var23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var20, 10.0d);
    boolean var24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var20);
    org.jfree.data.general.DatasetChangeEvent var25 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var4, (org.jfree.data.general.Dataset)var20);
    org.jfree.chart.LegendItemCollection var26 = var4.getFixedLegendItems();
    org.jfree.chart.axis.AxisLocation var27 = var4.getRangeAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test134"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
//     boolean var9 = var5.equals((java.lang.Object)var6);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var5.setArea(var12);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var17 = var16.getColumnCount();
//     org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var16, 10.0d);
//     java.lang.Number var22 = var16.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
//     org.jfree.data.Range var23 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var16);
//     double var25 = var16.getRangeLowerBound(true);
//     boolean var26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var16);
//     java.lang.Number var27 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var16);
//     org.jfree.chart.axis.NumberTickUnit var30 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     boolean var33 = var30.equals((java.lang.Object)var31);
//     int var34 = var30.getMinorTickCount();
//     org.jfree.chart.entity.CategoryItemEntity var35 = new org.jfree.chart.entity.CategoryItemEntity(var12, "ChartEntity: tooltip = hi!", "RectangleEdge.TOP", (org.jfree.data.category.CategoryDataset)var16, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)var34);
//     java.lang.Comparable var36 = var35.getColumnKey();
//     var35.setColumnKey((java.lang.Comparable)"[size=1]");
//     var35.setRowKey((java.lang.Comparable)"RectangleEdge.TOP");
//     org.jfree.chart.text.TextLine var43 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var44 = var43.getFirstTextFragment();
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.axis.CategoryAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var47, var48, var49, var50);
//     double var52 = var51.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var53 = var51.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var54 = null;
//     java.util.List var55 = var51.getCategoriesForAxis(var54);
//     double var56 = var51.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var51);
//     java.awt.Paint var58 = var57.getBackgroundPaint();
//     java.awt.Font var59 = var57.getItemFont();
//     org.jfree.chart.title.TextTitle var60 = new org.jfree.chart.title.TextTitle("hi!", var59);
//     org.jfree.chart.text.TextFragment var61 = new org.jfree.chart.text.TextFragment("", var59);
//     var43.removeFragment(var61);
//     org.jfree.chart.axis.CategoryAxis var63 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var67 = new org.jfree.chart.block.LabelBlock("hi!");
//     var67.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var73 = var67.getBounds();
//     org.jfree.chart.util.RectangleAnchor var74 = null;
//     java.awt.geom.Point2D var75 = org.jfree.chart.util.RectangleAnchor.coordinates(var73, var74);
//     org.jfree.chart.util.RectangleEdge var76 = null;
//     double var77 = var63.getCategoryStart((-16777216), (-16777216), var73, var76);
//     var63.setTickMarkOutsideLength(0.0f);
//     java.lang.String var80 = var63.getLabel();
//     java.awt.Font var81 = var63.getLabelFont();
//     boolean var82 = var61.equals((java.lang.Object)var81);
//     org.jfree.chart.text.TextFragment var83 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", var81);
//     boolean var84 = var35.equals((java.lang.Object)var81);
//     java.lang.Comparable var85 = var35.getColumnKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + 0.0d+ "'", var27.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + 0+ "'", var36.equals(0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var85 + "' != '" + "[size=1]"+ "'", var85.equals("[size=1]"));
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test135"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    float var14 = var4.getForegroundAlpha();
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    var4.setRenderer(var15, false);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    double var19 = var18.getLowerMargin();
    org.jfree.data.Range var20 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var18);
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("hi!");
    var26.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var32 = var26.getBounds();
    org.jfree.chart.util.RectangleAnchor var33 = null;
    java.awt.geom.Point2D var34 = org.jfree.chart.util.RectangleAnchor.coordinates(var32, var33);
    org.jfree.chart.util.RectangleEdge var35 = null;
    double var36 = var22.getCategoryStart((-16777216), (-16777216), var32, var35);
    org.jfree.chart.entity.CategoryLabelEntity var39 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var32, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
    org.jfree.chart.entity.AxisLabelEntity var42 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var18, (java.awt.Shape)var32, "org.jfree.chart.event.ChartChangeEvent[source=0]", "org.jfree.data.general.DatasetChangeEvent[source=-1]");
    var18.setLowerMargin(10.0d);
    var18.setFixedAutoRange(0.05d);
    boolean var47 = var18.getAutoRangeIncludesZero();
    java.awt.Shape var48 = var18.getUpArrow();
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis();
    var49.setAutoRangeIncludesZero(true);
    var49.setPositiveArrowVisible(true);
    org.jfree.chart.block.LineBorder var54 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var55 = var54.getInsets();
    double var57 = var55.calculateBottomOutset(0.0d);
    double var59 = var55.extendHeight(0.0d);
    var49.setTickLabelInsets(var55);
    java.awt.Shape var61 = var49.getUpArrow();
    var18.setDownArrow(var61);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.setRangeAboutValue(0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test136"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
    boolean var9 = var5.equals((java.lang.Object)var6);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var5.setArea(var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var21 = null;
    java.util.List var22 = var18.getCategoriesForAxis(var21);
    double var23 = var18.getAnchorValue();
    java.awt.Color var26 = java.awt.Color.getColor("", 1);
    var18.setOutlinePaint((java.awt.Paint)var26);
    java.awt.Stroke var28 = var18.getDomainGridlineStroke();
    java.awt.Color var31 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var32 = var31.getColorSpace();
    java.awt.image.ColorModel var33 = null;
    java.awt.Rectangle var34 = null;
    org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("hi!");
    var36.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var42 = var36.getBounds();
    java.awt.geom.AffineTransform var43 = null;
    java.awt.RenderingHints var44 = null;
    java.awt.PaintContext var45 = var31.createContext(var33, var34, var42, var43, var44);
    var18.setNoDataMessagePaint((java.awt.Paint)var31);
    org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic(var12, (java.awt.Paint)var31);
    java.awt.Shape var48 = var47.getShape();
    double var49 = var47.getContentXOffset();
    org.jfree.chart.util.RectangleAnchor var50 = var47.getShapeLocation();
    boolean var51 = var47.isShapeOutlineVisible();
    java.awt.Shape var52 = var47.getShape();
    var47.setShapeOutlineVisible(true);
    java.awt.Shape var55 = var47.getShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test137"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setAutoRangeIncludesZero(true);
    var0.setPositiveArrowVisible(true);
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var6 = null;
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, var6);
    org.jfree.chart.block.LengthConstraintType var8 = var7.getHeightConstraintType();
    org.jfree.data.Range var9 = var7.getWidthRange();
    org.jfree.data.Range var12 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var13 = var7.toRangeWidth(var12);
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 100.0d);
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(var16, 10.0d);
    org.jfree.data.Range var20 = org.jfree.data.Range.shift(var16, 0.05d);
    org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var12, var16);
    var0.setRangeWithMargins(var16);
    boolean var23 = var0.isVisible();
    boolean var24 = var0.isInverted();
    var0.configure();
    var0.setLowerBound(1.9999999999999998d);
    java.text.NumberFormat var28 = var0.getNumberFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test138"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
    java.lang.String var2 = var1.getID();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    double var8 = var7.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var10 = null;
    java.util.List var11 = var7.getCategoriesForAxis(var10);
    var7.setDomainGridlinesVisible(false);
    org.jfree.chart.ChartRenderingInfo var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("hi!");
    var19.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var25 = var19.getBounds();
    org.jfree.chart.util.RectangleAnchor var26 = null;
    java.awt.geom.Point2D var27 = org.jfree.chart.util.RectangleAnchor.coordinates(var25, var26);
    var7.zoomDomainAxes(100.0d, 10.0d, var17, var27);
    org.jfree.chart.renderer.category.CategoryItemRendererState var29 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var17);
    boolean var30 = var1.equals((java.lang.Object)var17);
    org.jfree.chart.renderer.category.CategoryItemRendererState var31 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var17);
    java.awt.geom.Rectangle2D var32 = var17.getDataArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test139"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    var0.setAutoPopulateSeriesStroke(true);
    java.awt.Paint var11 = var0.getItemFillPaint(100, 100);
    java.awt.Paint var14 = var0.getItemOutlinePaint((-8323073), (-1));
    java.lang.Boolean var16 = var0.getSeriesVisible(15);
    java.awt.Paint var18 = var0.getSeriesOutlinePaint((-16777215));
    org.jfree.chart.plot.CategoryPlot var19 = var0.getPlot();
    var0.setIncludeBaseInRange(false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var23 = var22.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var24 = var22.getLegendItemToolTipGenerator();
    java.awt.Shape var26 = var22.lookupSeriesShape(0);
    int var27 = var22.getRowCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var29 = var22.getSeriesToolTipGenerator(1);
    java.awt.Paint var32 = var22.getItemOutlinePaint((-16777216), (-165));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var34 = var33.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var35 = var33.getLegendItemToolTipGenerator();
    java.awt.Shape var37 = var33.lookupSeriesShape(0);
    var33.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var41 = null;
    var33.setSeriesURLGenerator(0, var41);
    org.jfree.chart.labels.CategoryToolTipGenerator var43 = var33.getBaseToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var45 = var33.getSeriesNegativeItemLabelPosition(0);
    var22.setBaseNegativeItemLabelPosition(var45);
    var0.setBasePositiveItemLabelPosition(var45);
    boolean var48 = var0.getAutoPopulateSeriesOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test140"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
//     boolean var9 = var5.equals((java.lang.Object)var6);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var5.setArea(var12);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var17 = var16.getColumnCount();
//     org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var16, 10.0d);
//     java.lang.Number var22 = var16.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
//     org.jfree.data.Range var23 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var16);
//     double var25 = var16.getRangeLowerBound(true);
//     boolean var26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var16);
//     java.lang.Number var27 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var16);
//     org.jfree.chart.axis.NumberTickUnit var30 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     boolean var33 = var30.equals((java.lang.Object)var31);
//     int var34 = var30.getMinorTickCount();
//     org.jfree.chart.entity.CategoryItemEntity var35 = new org.jfree.chart.entity.CategoryItemEntity(var12, "ChartEntity: tooltip = hi!", "RectangleEdge.TOP", (org.jfree.data.category.CategoryDataset)var16, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)var34);
//     java.lang.Comparable var36 = var35.getColumnKey();
//     java.lang.String var37 = var35.toString();
//     java.awt.Color var40 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var41 = var40.getColorSpace();
//     java.awt.image.ColorModel var42 = null;
//     java.awt.Rectangle var43 = null;
//     org.jfree.chart.block.LabelBlock var45 = new org.jfree.chart.block.LabelBlock("hi!");
//     var45.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var51 = var45.getBounds();
//     java.awt.geom.AffineTransform var52 = null;
//     java.awt.RenderingHints var53 = null;
//     java.awt.PaintContext var54 = var40.createContext(var42, var43, var51, var52, var53);
//     org.jfree.data.category.CategoryDataset var55 = null;
//     org.jfree.chart.axis.CategoryAxis var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var55, var56, var57, var58);
//     double var60 = var59.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var61 = var59.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var62 = null;
//     java.util.List var63 = var59.getCategoriesForAxis(var62);
//     double var64 = var59.getAnchorValue();
//     java.awt.Color var67 = java.awt.Color.getColor("", 1);
//     var59.setOutlinePaint((java.awt.Paint)var67);
//     org.jfree.chart.title.LegendGraphic var69 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var51, (java.awt.Paint)var67);
//     var35.setArea((java.awt.Shape)var51);
//     var35.setColumnKey((java.lang.Comparable)"100");
//     java.lang.Comparable var73 = var35.getRowKey();
//     java.lang.String var74 = var35.getURLText();
//     org.jfree.chart.axis.NumberTickUnit var76 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     org.jfree.chart.block.LabelBlock var78 = new org.jfree.chart.block.LabelBlock("hi!");
//     java.lang.String var79 = var78.getID();
//     int var80 = var76.compareTo((java.lang.Object)var78);
//     int var81 = var76.getMinorTickCount();
//     java.lang.String var83 = var76.valueToString(0.0d);
//     var35.setColumnKey((java.lang.Comparable)var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + 0.0d+ "'", var27.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + 0+ "'", var36.equals(0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var73 + "' != '" + (-1.0d)+ "'", var73.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var74 + "' != '" + "RectangleEdge.TOP"+ "'", var74.equals("RectangleEdge.TOP"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var83 + "' != '" + "0"+ "'", var83.equals("0"));
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test141"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var4.rendererChanged(var9);
    org.jfree.chart.axis.CategoryAxis var11 = null;
    int var12 = var4.getDomainAxisIndex(var11);
    org.jfree.chart.util.SortOrder var13 = var4.getRowRenderingOrder();
    org.jfree.chart.plot.DrawingSupplier var14 = null;
    var4.setDrawingSupplier(var14);
    var4.setBackgroundAlpha(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test142"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("1", "PlotOrientation.VERTICAL", "hi!", "RectangleAnchor.CENTER");
    var4.setInfo("org.jfree.data.general.DatasetChangeEvent[source=-1]");

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test143"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var1.setAlpha(0.0f);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var11 = null;
    java.util.List var12 = var8.getCategoriesForAxis(var11);
    double var13 = var8.getAnchorValue();
    var8.clearDomainMarkers();
    org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("");
    double var17 = var16.getHeight();
    java.awt.Paint var18 = var16.getPaint();
    var8.setRangeCrosshairPaint(var18);
    int var20 = var8.getDomainAxisCount();
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    java.awt.Color var24 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
    var8.setRangeCrosshairPaint((java.awt.Paint)var24);
    var1.setLabelPaint((java.awt.Paint)var24);
    org.jfree.data.category.CategoryDataset var27 = null;
    org.jfree.chart.axis.CategoryAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var27, var28, var29, var30);
    double var32 = var31.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var33 = var31.getDomainAxis();
    org.jfree.chart.axis.AxisLocation var35 = var31.getDomainAxisLocation(0);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var31);
    var31.clearDomainMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test144"); }


    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("");
    double var5 = var4.getHeight();
    java.awt.Paint var6 = var4.getPaint();
    java.awt.Font var7 = var4.getFont();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("hi!", var7);
    java.awt.Color var11 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("", var7, (java.awt.Paint)var11);
    java.awt.Color var13 = java.awt.Color.getColor("Range[-1.0,-1.0]", var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test145"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var11 = null;
    java.util.List var12 = var8.getCategoriesForAxis(var11);
    double var13 = var8.getAnchorValue();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    java.awt.Paint var15 = var14.getBackgroundPaint();
    java.awt.Font var16 = var14.getItemFont();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("hi!", var16);
    org.jfree.chart.util.RectangleEdge var18 = var17.getPosition();
    boolean var19 = var0.equals((java.lang.Object)var17);
    int var20 = var0.size();
    java.lang.Object var21 = var0.clone();
    java.awt.Stroke var23 = var0.getStroke(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test146"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var1 = var0.getRowCount();
//     java.awt.Paint var2 = var0.getBasePaint();
//     java.awt.Stroke var4 = var0.getSeriesStroke(1);
//     var0.setAutoPopulateSeriesFillPaint(false);
//     org.jfree.chart.urls.CategoryURLGenerator var7 = null;
//     var0.setBaseURLGenerator(var7);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var0.getLegendItemToolTipGenerator();
//     boolean var10 = var0.getAutoPopulateSeriesOutlinePaint();
//     java.lang.Object var11 = null;
//     boolean var12 = var0.equals(var11);
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     double var18 = var17.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var19 = var17.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     java.util.List var21 = var17.getCategoriesForAxis(var20);
//     double var22 = var17.getAnchorValue();
//     java.awt.Color var25 = java.awt.Color.getColor("", 1);
//     var17.setOutlinePaint((java.awt.Paint)var25);
//     float var27 = var17.getForegroundAlpha();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     var17.setRenderer(var28, false);
//     var0.setPlot(var17);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var32 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var33 = var32.getColumnCount();
//     org.jfree.data.Range var35 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var32, 10.0d);
//     java.lang.Number var38 = var32.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
//     org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var32);
//     org.jfree.data.Range var41 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var32, 6.0d);
//     double var43 = var32.getRangeUpperBound(true);
//     var17.setDataset((org.jfree.data.category.CategoryDataset)var32);
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.axis.CategoryAxis var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var45, var46, var47, var48);
//     double var50 = var49.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var51 = var49.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var52 = null;
//     java.util.List var53 = var49.getCategoriesForAxis(var52);
//     double var54 = var49.getAnchorValue();
//     var49.clearDomainMarkers();
//     org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("");
//     double var59 = var58.getHeight();
//     java.awt.Paint var60 = var58.getPaint();
//     java.awt.Font var61 = var58.getFont();
//     var56.setLabelFont(var61);
//     var56.setMaximumCategoryLabelLines(15);
//     org.jfree.chart.util.RectangleInsets var65 = var56.getLabelInsets();
//     java.awt.Font var67 = var56.getTickLabelFont((java.lang.Comparable)"org.jfree.chart.event.ChartChangeEvent[source=0]");
//     var49.setNoDataMessageFont(var67);
//     var49.configureRangeAxes();
//     boolean var70 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var32, (java.lang.Object)var49);
//     
//     // Checks the contract:  equals-hashcode on var19 and var51
//     assertTrue("Contract failed: equals-hashcode on var19 and var51", var19.equals(var51) ? var19.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var19
//     assertTrue("Contract failed: equals-hashcode on var51 and var19", var51.equals(var19) ? var51.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test147"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var11 = null;
    java.util.List var12 = var8.getCategoriesForAxis(var11);
    double var13 = var8.getAnchorValue();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    java.awt.Paint var15 = var14.getBackgroundPaint();
    java.awt.Font var16 = var14.getItemFont();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("hi!", var16);
    org.jfree.chart.util.RectangleEdge var18 = var17.getPosition();
    boolean var19 = var0.equals((java.lang.Object)var17);
    int var20 = var0.size();
    org.jfree.chart.ui.BasicProjectInfo var21 = new org.jfree.chart.ui.BasicProjectInfo();
    var21.setVersion("org.jfree.chart.event.ChartChangeEvent[source=0]");
    org.jfree.chart.ui.Library var28 = new org.jfree.chart.ui.Library("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", "RectangleAnchor.CENTER", "Size2D[width=-1.0, height=-1.0]");
    var21.addOptionalLibrary(var28);
    org.jfree.chart.ui.Library[] var30 = var21.getOptionalLibraries();
    boolean var31 = var0.equals((java.lang.Object)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test148"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
    var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var10 = var4.getBounds();
    org.jfree.chart.util.RectangleAnchor var11 = null;
    java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
    org.jfree.chart.util.RectangleEdge var13 = null;
    double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
    var0.setMaximumCategoryLabelLines(10);
    var0.setTickLabelsVisible(false);
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var19, var20, var21, var22);
    double var24 = var23.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var25 = var23.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var26 = null;
    java.util.List var27 = var23.getCategoriesForAxis(var26);
    double var28 = var23.getAnchorValue();
    var23.clearDomainAxes();
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    java.awt.Image var31 = null;
    var23.setBackgroundImage(var31);
    boolean var33 = var0.hasListener((java.util.EventListener)var23);
    java.awt.Paint var34 = var0.getLabelPaint();
    int var35 = var0.getMaximumCategoryLabelLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 10);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test149"); }


    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "hi!", "hi!");
    org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var6);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var6, var13);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var16 = var15.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var15.getLegendItemToolTipGenerator();
    java.awt.Shape var19 = var15.lookupSeriesShape(0);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    double var25 = var24.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var26 = var24.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var27 = null;
    java.util.List var28 = var24.getCategoriesForAxis(var27);
    double var29 = var24.getAnchorValue();
    var24.clearDomainAxes();
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
    org.jfree.chart.title.LegendTitle var33 = var31.getLegend(10);
    java.awt.Stroke var34 = var31.getBorderStroke();
    var15.setBaseStroke(var34);
    boolean var38 = var15.isItemLabelVisible(0, (-165));
    java.awt.Stroke var41 = var15.getItemOutlineStroke(15, (-16777215));
    java.awt.Paint var42 = null;
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=0]", "RectangleConstraintType.RANGE", "[size=1]", "VerticalAlignment.CENTER", var6, var41, var42);
    java.lang.Comparable var44 = var43.getSeriesKey();
    java.awt.Shape var45 = var43.getShape();
    org.jfree.chart.entity.ChartEntity var47 = new org.jfree.chart.entity.ChartEntity(var45, "1");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test150"); }
// 
// 
//     org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     org.jfree.chart.block.LabelBlock var3 = new org.jfree.chart.block.LabelBlock("hi!");
//     java.lang.String var4 = var3.getID();
//     int var5 = var1.compareTo((java.lang.Object)var3);
//     java.lang.String var7 = var1.valueToString(9.05d);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var13 = new org.jfree.chart.entity.TickLabelEntity(var10, "hi!", "hi!");
//     org.jfree.data.Range var14 = null;
//     org.jfree.data.Range var15 = null;
//     org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(var14, var15);
//     boolean var17 = var13.equals((java.lang.Object)var14);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var13.setArea(var20);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var25 = var24.getColumnCount();
//     org.jfree.data.Range var27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var24, 10.0d);
//     java.lang.Number var30 = var24.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
//     org.jfree.data.Range var31 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var24);
//     double var33 = var24.getRangeLowerBound(true);
//     boolean var34 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var24);
//     java.lang.Number var35 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var24);
//     org.jfree.chart.axis.NumberTickUnit var38 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var39 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var40 = new org.jfree.chart.plot.PlotRenderingInfo(var39);
//     boolean var41 = var38.equals((java.lang.Object)var39);
//     int var42 = var38.getMinorTickCount();
//     org.jfree.chart.entity.CategoryItemEntity var43 = new org.jfree.chart.entity.CategoryItemEntity(var20, "ChartEntity: tooltip = hi!", "RectangleEdge.TOP", (org.jfree.data.category.CategoryDataset)var24, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)var42);
//     java.lang.Comparable var44 = var43.getColumnKey();
//     org.jfree.data.category.CategoryDataset var45 = var43.getDataset();
//     org.jfree.data.general.PieDataset var47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var45, (java.lang.Comparable)"1");
//     org.jfree.data.category.CategoryDataset var48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var7, (org.jfree.data.KeyedValues)var47);
//     
//     // Checks the contract:  equals-hashcode on var48 and var45
//     assertTrue("Contract failed: equals-hashcode on var48 and var45", var48.equals(var45) ? var48.hashCode() == var45.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var48 and var45.", var48.equals(var45) == var45.equals(var48));
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test151"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(4.0d);
    java.lang.Object var2 = null;
    boolean var3 = var1.equals(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test152"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainMarkers();
    var4.mapDatasetToRangeAxis(1, (-253));
    org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.lang.Object var15 = var14.clone();
    var4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var14);
    org.jfree.chart.axis.CategoryAnchor var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainGridlinePosition(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test153"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "VerticalAlignment.CENTER", "0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0");

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test154"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.LegendItemCollection var7 = null;
    var4.setFixedLegendItems(var7);
    boolean var9 = var4.isSubplot();
    var4.configureDomainAxes();
    int var11 = var4.getWeight();
    var4.setBackgroundImageAlpha(0.0f);
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
    double var20 = var19.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var21 = var19.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    int var23 = var19.getIndexOf(var22);
    java.util.List var24 = var19.getCategories();
    var19.configureDomainAxes();
    org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var27.setAlpha(0.0f);
    java.awt.Stroke var30 = var27.getOutlineStroke();
    var19.addRangeMarker((org.jfree.chart.plot.Marker)var27);
    org.jfree.chart.util.Layer var32 = null;
    var4.addRangeMarker(10, (org.jfree.chart.plot.Marker)var27, var32);
    org.jfree.chart.util.RectangleEdge var35 = var4.getRangeAxisEdge((-8323073));
    org.jfree.chart.axis.NumberTickUnit var37 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    org.jfree.chart.block.LabelBlock var39 = new org.jfree.chart.block.LabelBlock("hi!");
    java.lang.String var40 = var39.getID();
    int var41 = var37.compareTo((java.lang.Object)var39);
    java.lang.String var43 = var37.valueToString(9.05d);
    boolean var45 = var37.equals((java.lang.Object)15);
    java.lang.String var46 = var37.toString();
    boolean var47 = var35.equals((java.lang.Object)var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "9.05"+ "'", var43.equals("9.05"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "[size=1]"+ "'", var46.equals("[size=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test155"); }


    org.jfree.chart.plot.DefaultDrawingSupplier var0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Stroke var1 = var0.getNextOutlineStroke();
    java.awt.Stroke var2 = var0.getNextOutlineStroke();
    java.awt.Stroke var3 = var0.getNextOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test156"); }
// 
// 
//     org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
//     int var1 = var0.size();
//     int var2 = var0.size();
//     org.jfree.chart.axis.TickUnit var3 = null;
//     var0.add(var3);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test157"); }


    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "hi!", "hi!");
    org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var6);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var6, var13);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var16 = var15.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var15.getLegendItemToolTipGenerator();
    java.awt.Shape var19 = var15.lookupSeriesShape(0);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    double var25 = var24.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var26 = var24.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var27 = null;
    java.util.List var28 = var24.getCategoriesForAxis(var27);
    double var29 = var24.getAnchorValue();
    var24.clearDomainAxes();
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
    org.jfree.chart.title.LegendTitle var33 = var31.getLegend(10);
    java.awt.Stroke var34 = var31.getBorderStroke();
    var15.setBaseStroke(var34);
    boolean var38 = var15.isItemLabelVisible(0, (-165));
    java.awt.Stroke var41 = var15.getItemOutlineStroke(15, (-16777215));
    java.awt.Paint var42 = null;
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=0]", "RectangleConstraintType.RANGE", "[size=1]", "VerticalAlignment.CENTER", var6, var41, var42);
    java.lang.Comparable var44 = var43.getSeriesKey();
    int var45 = var43.getSeriesIndex();
    int var46 = var43.getDatasetIndex();
    java.awt.Paint var47 = var43.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test158"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("1");

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test159"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
    boolean var9 = var5.equals((java.lang.Object)var6);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var5.setArea(var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var21 = null;
    java.util.List var22 = var18.getCategoriesForAxis(var21);
    double var23 = var18.getAnchorValue();
    java.awt.Color var26 = java.awt.Color.getColor("", 1);
    var18.setOutlinePaint((java.awt.Paint)var26);
    java.awt.Stroke var28 = var18.getDomainGridlineStroke();
    java.awt.Color var31 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var32 = var31.getColorSpace();
    java.awt.image.ColorModel var33 = null;
    java.awt.Rectangle var34 = null;
    org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("hi!");
    var36.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var42 = var36.getBounds();
    java.awt.geom.AffineTransform var43 = null;
    java.awt.RenderingHints var44 = null;
    java.awt.PaintContext var45 = var31.createContext(var33, var34, var42, var43, var44);
    var18.setNoDataMessagePaint((java.awt.Paint)var31);
    org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic(var12, (java.awt.Paint)var31);
    java.awt.Shape var48 = var47.getShape();
    var47.setShapeOutlineVisible(true);
    var47.setShapeFilled(true);
    var47.setHeight(2.0d);
    double var55 = var47.getWidth();
    java.awt.Paint var56 = var47.getFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test160"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(0, var8);
    var0.setItemMargin(6.0d);
    java.awt.Shape var13 = var0.lookupSeriesShape(100);
    java.awt.Paint var16 = var0.getItemLabelPaint(100, 10);
    java.awt.Stroke var17 = var0.getBaseStroke();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var20 = var19.getRowCount();
    java.awt.Paint var21 = var19.getBasePaint();
    java.awt.Stroke var23 = var19.getSeriesStroke(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var24 = null;
    var19.setLegendItemToolTipGenerator(var24);
    java.awt.Color var28 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var29 = var28.getColorSpace();
    java.awt.image.ColorModel var30 = null;
    java.awt.Rectangle var31 = null;
    org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("hi!");
    var33.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var39 = var33.getBounds();
    java.awt.geom.AffineTransform var40 = null;
    java.awt.RenderingHints var41 = null;
    java.awt.PaintContext var42 = var28.createContext(var30, var31, var39, var40, var41);
    boolean var43 = var19.equals((java.lang.Object)var28);
    var0.setSeriesItemLabelPaint(0, (java.awt.Paint)var28, false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var47 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var48 = var47.getBasePositiveItemLabelPosition();
    double var49 = var48.getAngle();
    var0.setSeriesPositiveItemLabelPosition(3, var48, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test161"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape((-16777215));
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Shape var4 = var3.getLeftArrow();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
//     double var10 = var9.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var11 = var9.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     java.util.List var13 = var9.getCategoriesForAxis(var12);
//     double var14 = var9.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     java.awt.Paint var16 = var15.getBackgroundPaint();
//     org.jfree.chart.util.RectangleInsets var17 = var15.getPadding();
//     var3.setTickLabelInsets(var17);
//     boolean var19 = var3.isTickMarksVisible();
//     var3.setAutoTickUnitSelection(false, true);
//     boolean var23 = var3.isInverted();
//     boolean var24 = var0.equals((java.lang.Object)var23);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var26 = var25.getRowCount();
//     java.awt.Paint var27 = var25.getBasePaint();
//     java.awt.Stroke var29 = var25.getSeriesStroke(1);
//     var25.setAutoPopulateSeriesFillPaint(false);
//     boolean var33 = var25.isSeriesVisibleInLegend(1);
//     int var34 = var25.getPassCount();
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var35, var36, var37, var38);
//     double var40 = var39.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var41 = var39.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     java.util.List var43 = var39.getCategoriesForAxis(var42);
//     double var44 = var39.getAnchorValue();
//     var39.clearDomainAxes();
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var39);
//     java.awt.RenderingHints var47 = var46.getRenderingHints();
//     java.awt.Stroke var48 = var46.getBorderStroke();
//     int var49 = var46.getBackgroundImageAlignment();
//     org.jfree.chart.title.Title var50 = null;
//     var46.removeSubtitle(var50);
//     org.jfree.chart.plot.CategoryPlot var52 = var46.getCategoryPlot();
//     boolean var53 = var25.hasListener((java.util.EventListener)var52);
//     boolean var54 = var0.equals((java.lang.Object)var25);
//     
//     // Checks the contract:  equals-hashcode on var9 and var39
//     assertTrue("Contract failed: equals-hashcode on var9 and var39", var9.equals(var39) ? var9.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var52
//     assertTrue("Contract failed: equals-hashcode on var9 and var52", var9.equals(var52) ? var9.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var9
//     assertTrue("Contract failed: equals-hashcode on var39 and var9", var39.equals(var9) ? var39.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var9
//     assertTrue("Contract failed: equals-hashcode on var52 and var9", var52.equals(var9) ? var52.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var41
//     assertTrue("Contract failed: equals-hashcode on var11 and var41", var11.equals(var41) ? var11.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var11
//     assertTrue("Contract failed: equals-hashcode on var41 and var11", var41.equals(var11) ? var41.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test162"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var11 = var10.getBackgroundPaint();
    double var12 = var10.getWidth();
    java.lang.Object var13 = var10.clone();
    java.awt.Graphics2D var14 = null;
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var16 = null;
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(var15, var16);
    org.jfree.data.Range var18 = null;
    org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var18, 100.0d);
    org.jfree.chart.block.RectangleConstraint var21 = var17.toRangeHeight(var20);
    org.jfree.chart.util.Size2D var22 = var10.arrange(var14, var17);
    org.jfree.chart.util.HorizontalAlignment var23 = var10.getHorizontalAlignment();
    org.jfree.chart.util.RectangleInsets var24 = var10.getLegendItemGraphicPadding();
    java.lang.String var25 = var24.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"+ "'", var25.equals("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"));

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test163"); }


    java.awt.Color var2 = java.awt.Color.getColor("ChartEntity: tooltip = hi!", (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test164"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    java.awt.Paint var12 = var11.getBackgroundPaint();
    org.jfree.chart.plot.CategoryPlot var13 = var11.getCategoryPlot();
    var11.clearSubtitles();
    float var15 = var11.getBackgroundImageAlpha();
    org.jfree.chart.event.ChartProgressListener var16 = null;
    var11.addProgressListener(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test165"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    var0.setAutoPopulateSeriesStroke(true);
    java.awt.Paint var10 = var0.getSeriesFillPaint((-16777216));
    double var11 = var0.getItemMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test166"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setAutoTickUnitSelection(false, true);
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var6 = null;
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, var6);
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 100.0d);
    org.jfree.chart.block.RectangleConstraint var11 = var7.toRangeHeight(var10);
    double var12 = var10.getLength();
    org.jfree.data.Range var13 = null;
    org.jfree.data.Range var14 = null;
    org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint(var13, var14);
    org.jfree.chart.block.LengthConstraintType var16 = var15.getHeightConstraintType();
    org.jfree.data.Range var17 = var15.getWidthRange();
    java.lang.String var18 = var15.toString();
    org.jfree.chart.block.LengthConstraintType var19 = var15.getHeightConstraintType();
    org.jfree.data.Range var21 = null;
    org.jfree.data.Range var22 = null;
    org.jfree.data.Range var23 = null;
    org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(var22, var23);
    org.jfree.chart.block.RectangleConstraint var25 = var24.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var27 = var24.toFixedWidth(1.0d);
    org.jfree.chart.block.RectangleConstraint var29 = var24.toFixedHeight((-1.0d));
    org.jfree.chart.block.LengthConstraintType var30 = var24.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint((-2.0d), var10, var19, 8.0d, var21, var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var21, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"+ "'", var18.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test167"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     int var2 = var0.getIndex((java.lang.Comparable)0);
//     java.lang.Comparable var4 = var0.getKey((-16777215));
//     java.util.List var5 = var0.getKeys();
//     java.lang.Object var6 = var0.clone();
//     java.util.List var7 = var0.getKeys();
//     org.jfree.chart.axis.NumberTickUnit var9 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     org.jfree.chart.block.LabelBlock var11 = new org.jfree.chart.block.LabelBlock("hi!");
//     java.lang.String var12 = var11.getID();
//     int var13 = var9.compareTo((java.lang.Object)var11);
//     java.lang.String var15 = var9.valueToString(9.05d);
//     boolean var17 = var9.equals((java.lang.Object)15);
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
//     double var23 = var22.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var24 = var22.getDrawingSupplier();
//     org.jfree.chart.LegendItemCollection var25 = null;
//     var22.setFixedLegendItems(var25);
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var27, var28, var29, var30);
//     double var32 = var31.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var33 = var31.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     int var35 = var31.getIndexOf(var34);
//     java.util.List var36 = var31.getCategories();
//     var31.configureDomainAxes();
//     org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     var39.setAlpha(0.0f);
//     java.awt.Stroke var42 = var39.getOutlineStroke();
//     var31.addRangeMarker((org.jfree.chart.plot.Marker)var39);
//     var22.setParent((org.jfree.chart.plot.Plot)var31);
//     var31.clearDomainMarkers((-589829));
//     org.jfree.chart.plot.Plot var47 = var31.getRootPlot();
//     var0.setObject((java.lang.Comparable)var9, (java.lang.Object)var31);
//     org.jfree.data.category.CategoryDataset var49 = null;
//     org.jfree.chart.axis.CategoryAxis var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var49, var50, var51, var52);
//     double var54 = var53.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var55 = var53.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var56 = null;
//     int var57 = var53.getIndexOf(var56);
//     java.util.List var58 = var53.getCategories();
//     var53.configureDomainAxes();
//     org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     var61.setAlpha(0.0f);
//     java.awt.Stroke var64 = var61.getOutlineStroke();
//     var53.addRangeMarker((org.jfree.chart.plot.Marker)var61);
//     org.jfree.chart.axis.CategoryAxis var67 = var53.getDomainAxis((-16777216));
//     org.jfree.data.category.CategoryDataset var68 = null;
//     org.jfree.chart.axis.CategoryAxis var69 = null;
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var71 = null;
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot(var68, var69, var70, var71);
//     var72.clearAnnotations();
//     org.jfree.data.category.CategoryDataset var74 = null;
//     org.jfree.chart.axis.CategoryAxis var75 = null;
//     org.jfree.chart.axis.ValueAxis var76 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var77 = null;
//     org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot(var74, var75, var76, var77);
//     double var79 = var78.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var80 = var78.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var81 = null;
//     java.util.List var82 = var78.getCategoriesForAxis(var81);
//     var78.setDomainGridlinesVisible(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var85 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var86 = var85.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var87 = var85.getLegendItemToolTipGenerator();
//     java.awt.Shape var89 = var85.lookupSeriesShape(0);
//     int var90 = var78.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var85);
//     var85.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var93 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var85};
//     var72.setRenderers(var93);
//     var53.setRenderers(var93);
//     var31.setRenderers(var93);
//     
//     // Checks the contract:  equals-hashcode on var22 and var78
//     assertTrue("Contract failed: equals-hashcode on var22 and var78", var22.equals(var78) ? var22.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var53
//     assertTrue("Contract failed: equals-hashcode on var31 and var53", var31.equals(var53) ? var31.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var31
//     assertTrue("Contract failed: equals-hashcode on var53 and var31", var53.equals(var31) ? var53.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var22
//     assertTrue("Contract failed: equals-hashcode on var78 and var22", var78.equals(var22) ? var78.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var80
//     assertTrue("Contract failed: equals-hashcode on var24 and var80", var24.equals(var80) ? var24.hashCode() == var80.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var80 and var24
//     assertTrue("Contract failed: equals-hashcode on var80 and var24", var80.equals(var24) ? var80.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var61
//     assertTrue("Contract failed: equals-hashcode on var39 and var61", var39.equals(var61) ? var39.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var39
//     assertTrue("Contract failed: equals-hashcode on var61 and var39", var61.equals(var39) ? var61.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test168"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainMarkers();
//     boolean var11 = var4.isOutlineVisible();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var13 = var12.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var12.getLegendItemToolTipGenerator();
//     java.awt.Shape var16 = var12.lookupSeriesShape(0);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     double var22 = var21.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var23 = var21.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     java.util.List var25 = var21.getCategoriesForAxis(var24);
//     double var26 = var21.getAnchorValue();
//     var21.clearDomainAxes();
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var21);
//     org.jfree.chart.title.LegendTitle var30 = var28.getLegend(10);
//     java.awt.Stroke var31 = var28.getBorderStroke();
//     var12.setBaseStroke(var31);
//     boolean var35 = var12.isItemLabelVisible(0, (-165));
//     var12.setBaseItemLabelsVisible(false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var38 = var12.getLegendItemLabelGenerator();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var40 = var39.getRowCount();
//     java.awt.Paint var41 = var39.getBasePaint();
//     java.awt.Stroke var43 = var39.getSeriesStroke(1);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var44 = null;
//     var39.setLegendItemToolTipGenerator(var44);
//     java.awt.Color var48 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var49 = var48.getColorSpace();
//     java.awt.image.ColorModel var50 = null;
//     java.awt.Rectangle var51 = null;
//     org.jfree.chart.block.LabelBlock var53 = new org.jfree.chart.block.LabelBlock("hi!");
//     var53.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var59 = var53.getBounds();
//     java.awt.geom.AffineTransform var60 = null;
//     java.awt.RenderingHints var61 = null;
//     java.awt.PaintContext var62 = var48.createContext(var50, var51, var59, var60, var61);
//     boolean var63 = var39.equals((java.lang.Object)var48);
//     org.jfree.chart.urls.CategoryURLGenerator var65 = var39.getSeriesURLGenerator((-16777215));
//     java.awt.Paint var67 = var39.getSeriesItemLabelPaint((-253));
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var68 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var69 = var68.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var70 = var68.getLegendItemToolTipGenerator();
//     java.awt.Shape var72 = var68.lookupSeriesShape(0);
//     var68.setAutoPopulateSeriesFillPaint(true);
//     boolean var76 = var68.isSeriesItemLabelsVisible(0);
//     org.jfree.chart.labels.ItemLabelPosition var77 = var68.getBasePositiveItemLabelPosition();
//     var39.setBasePositiveItemLabelPosition(var77, true);
//     var12.setBaseNegativeItemLabelPosition(var77);
//     var4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var23
//     assertTrue("Contract failed: equals-hashcode on var6 and var23", var6.equals(var23) ? var6.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var6
//     assertTrue("Contract failed: equals-hashcode on var23 and var6", var23.equals(var6) ? var23.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test169"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    java.awt.RenderingHints var12 = var11.getRenderingHints();
    java.awt.Paint var13 = null;
    var11.setBackgroundPaint(var13);
    boolean var15 = var11.getAntiAlias();
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
    double var23 = var22.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var24 = var22.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var25 = null;
    java.util.List var26 = var22.getCategoriesForAxis(var25);
    double var27 = var22.getAnchorValue();
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
    java.awt.Paint var29 = var28.getBackgroundPaint();
    java.awt.Font var30 = var28.getItemFont();
    org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("hi!", var30);
    java.awt.Graphics2D var32 = null;
    java.awt.geom.Rectangle2D var33 = null;
    var31.draw(var32, var33);
    java.awt.Paint var35 = var31.getBackgroundPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addSubtitle((-8323073), (org.jfree.chart.title.Title)var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test170"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(2.05d, 6.0d, 1.0d, 10.05d);
    double var6 = var4.calculateTopInset(98.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.05d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test171"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getColumnIndex((java.lang.Comparable)"100");
    java.util.List var3 = var0.getColumnKeys();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var4.addChangeListener(var6);
    boolean var8 = var0.equals((java.lang.Object)var4);
    java.util.List var9 = var0.getRowKeys();
    int var11 = var0.getRowIndex((java.lang.Comparable)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test172"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("0,0,1,1", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test173"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(0, var8);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = var0.getBaseToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getBasePositiveItemLabelPosition();
    java.awt.Paint var15 = var0.getSeriesOutlinePaint((-1572964));
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
    double var22 = var21.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var23 = var21.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var24 = var21.getRowRenderingOrder();
    java.awt.Stroke var25 = var21.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = var21.getRendererForDataset(var26);
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var21);
    org.jfree.chart.axis.AxisSpace var29 = var21.getFixedRangeAxisSpace();
    org.jfree.chart.event.AxisChangeEvent var30 = null;
    var21.axisChanged(var30);
    var21.setDrawSharedDomainAxis(true);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test174"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.lang.Boolean var2 = var0.getBoolean(100);
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    double var4 = var3.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var5 = var3.getTickUnit();
    var3.setAutoTickUnitSelection(false);
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
    double var13 = var12.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var14 = var12.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var15 = null;
    java.util.List var16 = var12.getCategoriesForAxis(var15);
    double var17 = var12.getAnchorValue();
    java.awt.Color var20 = java.awt.Color.getColor("", 1);
    var12.setOutlinePaint((java.awt.Paint)var20);
    java.awt.Stroke var22 = var12.getDomainGridlineStroke();
    org.jfree.chart.axis.ValueAxis var23 = var12.getRangeAxis();
    var12.setWeight((-16777216));
    var3.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var12);
    java.awt.Paint var27 = var3.getAxisLinePaint();
    boolean var28 = var0.equals((java.lang.Object)var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test175"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     java.awt.RenderingHints var12 = var11.getRenderingHints();
//     var11.setBackgroundImageAlpha(0.0f);
//     java.lang.Object var15 = var11.getTextAntiAlias();
//     var11.removeLegend();
//     var11.setTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     var11.draw(var19, var20, var21);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test176"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainMarkers();
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("");
    double var13 = var12.getHeight();
    java.awt.Paint var14 = var12.getPaint();
    var4.setRangeCrosshairPaint(var14);
    int var16 = var4.getDomainAxisCount();
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.block.LineBorder var18 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var19 = var18.getInsets();
    var17.setPadding(var19);
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var22 = null;
    org.jfree.chart.title.LegendItemBlockContainer var24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var21, var22, (java.lang.Comparable)1L);
    java.lang.Object var25 = var24.clone();
    var17.setWrapper((org.jfree.chart.block.BlockContainer)var24);
    java.lang.Comparable var27 = var24.getSeriesKey();
    var24.setURLText("Size2D[width=0.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + 1L+ "'", var27.equals(1L));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test177"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var2 = var0.getTickUnit();
    var0.setAutoTickUnitSelection(false);
    double var5 = var0.getUpperMargin();
    java.text.NumberFormat var6 = null;
    var0.setNumberFormatOverride(var6);
    double var8 = var0.getFixedAutoRange();
    var0.setLabel("DatasetRenderingOrder.REVERSE");
    var0.zoomRange(0.0d, 98.0d);
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 100.0d);
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(var16, 10.0d);
    org.jfree.data.Range var21 = org.jfree.data.Range.shift(var16, 10.05d, false);
    var0.setRange(var21);
    var0.setAutoTickUnitSelection(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test178"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
    var0.setLegendItemToolTipGenerator(var5);
    java.awt.Color var9 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var10 = var9.getColorSpace();
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("hi!");
    var14.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var20 = var14.getBounds();
    java.awt.geom.AffineTransform var21 = null;
    java.awt.RenderingHints var22 = null;
    java.awt.PaintContext var23 = var9.createContext(var11, var12, var20, var21, var22);
    boolean var24 = var0.equals((java.lang.Object)var9);
    org.jfree.chart.urls.CategoryURLGenerator var26 = var0.getSeriesURLGenerator((-16777215));
    java.awt.Paint var28 = var0.getSeriesItemLabelPaint((-253));
    java.awt.Stroke var30 = var0.getSeriesStroke(10);
    var0.setAutoPopulateSeriesFillPaint(true);
    java.awt.Paint var34 = null;
    var0.setSeriesPaint(0, var34);
    org.jfree.chart.labels.CategoryToolTipGenerator var37 = null;
    var0.setSeriesToolTipGenerator(4, var37);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var48 = new org.jfree.chart.entity.TickLabelEntity(var45, "hi!", "hi!");
    org.jfree.chart.entity.ChartEntity var49 = new org.jfree.chart.entity.ChartEntity(var45);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    boolean var53 = org.jfree.chart.util.ShapeUtilities.equal(var45, var52);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var54 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var55 = var54.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var56 = var54.getLegendItemToolTipGenerator();
    java.awt.Shape var58 = var54.lookupSeriesShape(0);
    org.jfree.data.category.CategoryDataset var59 = null;
    org.jfree.chart.axis.CategoryAxis var60 = null;
    org.jfree.chart.axis.ValueAxis var61 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var62 = null;
    org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot(var59, var60, var61, var62);
    double var64 = var63.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var65 = var63.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var66 = null;
    java.util.List var67 = var63.getCategoriesForAxis(var66);
    double var68 = var63.getAnchorValue();
    var63.clearDomainAxes();
    org.jfree.chart.JFreeChart var70 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var63);
    org.jfree.chart.title.LegendTitle var72 = var70.getLegend(10);
    java.awt.Stroke var73 = var70.getBorderStroke();
    var54.setBaseStroke(var73);
    boolean var77 = var54.isItemLabelVisible(0, (-165));
    java.awt.Stroke var80 = var54.getItemOutlineStroke(15, (-16777215));
    java.awt.Paint var81 = null;
    org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=0]", "RectangleConstraintType.RANGE", "[size=1]", "VerticalAlignment.CENTER", var45, var80, var81);
    java.lang.Comparable var83 = var82.getSeriesKey();
    java.awt.Stroke var84 = var82.getOutlineStroke();
    java.awt.Paint var85 = var82.getLinePaint();
    boolean var86 = var82.isShapeOutlineVisible();
    org.jfree.chart.util.GradientPaintTransformer var87 = var82.getFillPaintTransformer();
    var0.setGradientPaintTransformer(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test179"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainMarkers();
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("");
//     double var14 = var13.getHeight();
//     java.awt.Paint var15 = var13.getPaint();
//     java.awt.Font var16 = var13.getFont();
//     var11.setLabelFont(var16);
//     var11.setMaximumCategoryLabelLines(15);
//     org.jfree.chart.util.RectangleInsets var20 = var11.getLabelInsets();
//     java.awt.Font var22 = var11.getTickLabelFont((java.lang.Comparable)"org.jfree.chart.event.ChartChangeEvent[source=0]");
//     var4.setNoDataMessageFont(var22);
//     double var24 = var4.getAnchorValue();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var27 = var26.getColumnCount();
//     org.jfree.data.Range var29 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var26, 10.0d);
//     boolean var30 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var26);
//     double var32 = var26.getRangeUpperBound(true);
//     java.lang.Number var35 = var26.getValue((java.lang.Comparable)100.0f, (java.lang.Comparable)"org.jfree.chart.event.ChartChangeEvent[source=0]");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setDataset((-16777216), (org.jfree.data.category.CategoryDataset)var26);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test180"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    double var6 = var5.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var8 = null;
    java.util.List var9 = var5.getCategoriesForAxis(var8);
    var5.setDomainGridlinesVisible(false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var13 = var12.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var12.getLegendItemToolTipGenerator();
    java.awt.Shape var16 = var12.lookupSeriesShape(0);
    int var17 = var5.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    var12.setAutoPopulateSeriesFillPaint(true);
    java.awt.Shape var21 = var12.lookupSeriesShape(100);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var21, var24);
    org.jfree.chart.entity.ChartEntity var26 = new org.jfree.chart.entity.ChartEntity(var24);
    var0.setRightArrow(var24);
    java.lang.String var28 = var0.getLabel();
    double var29 = var0.getFixedDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test181"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
    double var10 = var9.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var11 = var9.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var12 = null;
    java.util.List var13 = var9.getCategoriesForAxis(var12);
    double var14 = var9.getAnchorValue();
    var9.clearDomainAxes();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var9);
    org.jfree.chart.title.LegendTitle var18 = var16.getLegend(10);
    java.awt.Stroke var19 = var16.getBorderStroke();
    var0.setBaseStroke(var19);
    boolean var23 = var0.isItemLabelVisible(0, (-165));
    var0.setSeriesVisible(15, (java.lang.Boolean)true, true);
    org.jfree.chart.labels.ItemLabelPosition var28 = null;
    var0.setPositiveItemLabelPositionFallback(var28);
    java.awt.Font var31 = var0.getSeriesItemLabelFont(10);
    org.jfree.chart.labels.ItemLabelPosition var32 = var0.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.ItemLabelPosition var33 = var0.getBaseNegativeItemLabelPosition();
    java.lang.Object var34 = var0.clone();
    var0.setBaseItemLabelsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test182"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
    double var3 = var2.getHeight();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Font var5 = var2.getFont();
    var0.setLabelFont(var5);
    var0.setTickMarkInsideLength(1.0f);
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
    double var15 = var14.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var16 = var14.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var17 = var14.getRowRenderingOrder();
    java.awt.Stroke var18 = var14.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = var14.getRendererForDataset(var19);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var14);
    org.jfree.chart.axis.AxisSpace var22 = var14.getFixedRangeAxisSpace();
    var0.setPlot((org.jfree.chart.plot.Plot)var14);
    org.jfree.chart.event.PlotChangeEvent var24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var14);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var26 = var25.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var27 = var25.getLegendItemToolTipGenerator();
    java.awt.Shape var29 = var25.lookupSeriesShape(0);
    int var30 = var25.getRowCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = var25.getSeriesToolTipGenerator(1);
    var25.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Paint var36 = var25.lookupSeriesFillPaint(0);
    var25.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var39 = var25.getLegendItemLabelGenerator();
    var25.setAutoPopulateSeriesOutlineStroke(false);
    var14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var25, false);
    java.awt.Stroke var44 = var14.getDomainGridlineStroke();
    org.jfree.chart.axis.AxisLocation var46 = var14.getRangeAxisLocation((-16777216));
    org.jfree.chart.axis.AxisLocation var47 = var46.getOpposite();
    org.jfree.chart.axis.AxisLocation var48 = var47.getOpposite();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test183"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(0, var8);
    org.jfree.chart.event.RendererChangeEvent var10 = null;
    var0.notifyListeners(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-16777215), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test184"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
    double var13 = var12.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var14 = var12.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    int var16 = var12.getIndexOf(var15);
    java.util.List var17 = var12.getCategories();
    var12.configureDomainAxes();
    org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var20.setAlpha(0.0f);
    java.awt.Stroke var23 = var20.getOutlineStroke();
    var12.addRangeMarker((org.jfree.chart.plot.Marker)var20);
    org.jfree.chart.util.Layer var25 = null;
    var4.addRangeMarker((org.jfree.chart.plot.Marker)var20, var25);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    var27.setBackgroundImageAlignment((-16777215));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test185"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var3 = var2.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var4 = var2.getLegendItemToolTipGenerator();
    java.awt.Shape var6 = var2.lookupSeriesShape(0);
    var2.setAutoPopulateSeriesFillPaint(true);
    boolean var10 = var2.isSeriesItemLabelsVisible(0);
    org.jfree.chart.labels.ItemLabelPosition var11 = var2.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var12 = var11.getRotationAnchor();
    org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.text.TextAnchor var15 = var14.getLabelTextAnchor();
    java.awt.Color var18 = java.awt.Color.getColor("", 1);
    boolean var19 = var15.equals((java.lang.Object)"");
    org.jfree.chart.axis.NumberTick var21 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(byte)0, "org.jfree.chart.event.ChartChangeEvent[source=0]", var12, var15, 0.0d);
    double var22 = var21.getValue();
    double var23 = var21.getValue();
    org.jfree.chart.axis.TickType var24 = var21.getTickType();
    org.jfree.data.Range var25 = null;
    org.jfree.data.Range var27 = org.jfree.data.Range.expandToInclude(var25, 100.0d);
    org.jfree.data.Range var28 = null;
    org.jfree.data.Range var29 = null;
    org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint(var28, var29);
    org.jfree.data.Range var31 = null;
    org.jfree.data.Range var33 = org.jfree.data.Range.expandToInclude(var31, 100.0d);
    org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(var33, 10.0d);
    org.jfree.data.Range var36 = null;
    org.jfree.chart.block.RectangleConstraint var37 = new org.jfree.chart.block.RectangleConstraint(var33, var36);
    double var38 = var33.getLowerBound();
    org.jfree.chart.block.RectangleConstraint var39 = var30.toRangeHeight(var33);
    org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint(var27, var33);
    boolean var41 = var24.equals((java.lang.Object)var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test186"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    float var14 = var4.getForegroundAlpha();
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    var4.setRenderer(var15, false);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    double var19 = var18.getLowerMargin();
    org.jfree.data.Range var20 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var18);
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("hi!");
    var26.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var32 = var26.getBounds();
    org.jfree.chart.util.RectangleAnchor var33 = null;
    java.awt.geom.Point2D var34 = org.jfree.chart.util.RectangleAnchor.coordinates(var32, var33);
    org.jfree.chart.util.RectangleEdge var35 = null;
    double var36 = var22.getCategoryStart((-16777216), (-16777216), var32, var35);
    org.jfree.chart.entity.CategoryLabelEntity var39 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var32, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
    org.jfree.chart.entity.AxisLabelEntity var42 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var18, (java.awt.Shape)var32, "org.jfree.chart.event.ChartChangeEvent[source=0]", "org.jfree.data.general.DatasetChangeEvent[source=-1]");
    boolean var43 = var18.isAutoTickUnitSelection();
    org.jfree.chart.axis.TickUnitSource var44 = var18.getStandardTickUnits();
    org.jfree.chart.axis.TickUnitSource var45 = var18.getStandardTickUnits();
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    org.jfree.chart.entity.ChartEntity var50 = new org.jfree.chart.entity.ChartEntity(var48, "hi!");
    org.jfree.chart.block.LabelBlock var52 = new org.jfree.chart.block.LabelBlock("");
    double var53 = var52.getHeight();
    java.awt.Paint var54 = var52.getPaint();
    org.jfree.chart.title.LegendGraphic var55 = new org.jfree.chart.title.LegendGraphic(var48, var54);
    var55.setShapeFilled(true);
    java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
    var55.setLine(var60);
    var18.setDownArrow(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test187"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var1.setAlpha(0.0f);
    java.awt.Stroke var4 = var1.getOutlineStroke();
    java.awt.Stroke var5 = var1.getStroke();
    org.jfree.chart.event.MarkerChangeEvent var6 = null;
    var1.notifyListeners(var6);
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
    double var13 = var12.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var14 = var12.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var15 = null;
    java.util.List var16 = var12.getCategoriesForAxis(var15);
    double var17 = var12.getAnchorValue();
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12);
    java.awt.Paint var19 = var18.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var20 = var18.getPadding();
    org.jfree.chart.util.RectangleAnchor var21 = var18.getLegendItemGraphicLocation();
    var1.setLabelAnchor(var21);
    org.jfree.chart.event.MarkerChangeEvent var23 = null;
    var1.notifyListeners(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test188"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var3 = var2.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var4 = var2.getLegendItemToolTipGenerator();
    java.awt.Shape var6 = var2.lookupSeriesShape(0);
    var2.setAutoPopulateSeriesFillPaint(true);
    boolean var10 = var2.isSeriesItemLabelsVisible(0);
    org.jfree.chart.labels.ItemLabelPosition var11 = var2.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var12 = var11.getRotationAnchor();
    org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.text.TextAnchor var15 = var14.getLabelTextAnchor();
    java.awt.Color var18 = java.awt.Color.getColor("", 1);
    boolean var19 = var15.equals((java.lang.Object)"");
    org.jfree.chart.axis.NumberTick var21 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(byte)0, "org.jfree.chart.event.ChartChangeEvent[source=0]", var12, var15, 0.0d);
    double var22 = var21.getValue();
    java.lang.Object var23 = var21.clone();
    double var24 = var21.getValue();
    org.jfree.chart.text.TextAnchor var25 = var21.getRotationAnchor();
    org.jfree.chart.axis.TickType var26 = var21.getTickType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test189"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    int var8 = var4.getIndexOf(var7);
    org.jfree.chart.LegendItemCollection var9 = null;
    var4.setFixedLegendItems(var9);
    org.jfree.chart.event.PlotChangeListener var11 = null;
    var4.addChangeListener(var11);
    org.jfree.chart.axis.ValueAxis var13 = null;
    int var14 = var4.getRangeAxisIndex(var13);
    org.jfree.chart.axis.CategoryAxis var16 = var4.getDomainAxis((-16777216));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var18 = var17.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var19 = var17.getLegendItemToolTipGenerator();
    java.awt.Shape var21 = var17.lookupSeriesShape(0);
    var17.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var25 = null;
    var17.setSeriesURLGenerator(0, var25);
    org.jfree.chart.labels.CategoryToolTipGenerator var27 = var17.getBaseToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var29 = var17.getSeriesNegativeItemLabelPosition(0);
    var17.setBaseItemLabelsVisible(false, false);
    org.jfree.chart.LegendItemCollection var33 = var17.getLegendItems();
    var4.setFixedLegendItems(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test190"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    boolean var1 = var0.getGenerateEntities();
    boolean var2 = var0.getGenerateEntities();
    double var3 = var0.getTranslateX();
    var0.setTranslateX(12.0d);
    boolean var6 = var0.getGenerateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test191"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    var4.setDomainGridlinesVisible(false);
    org.jfree.chart.ChartRenderingInfo var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
    org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("hi!");
    var16.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var22 = var16.getBounds();
    org.jfree.chart.util.RectangleAnchor var23 = null;
    java.awt.geom.Point2D var24 = org.jfree.chart.util.RectangleAnchor.coordinates(var22, var23);
    var4.zoomDomainAxes(100.0d, 10.0d, var14, var24);
    org.jfree.chart.renderer.category.CategoryItemRendererState var26 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var14);
    int var27 = var14.getSubplotCount();
    org.jfree.chart.axis.AxisState var28 = new org.jfree.chart.axis.AxisState();
    var28.cursorLeft(2.0d);
    var28.setCursor(10.0d);
    double var33 = var28.getMax();
    var28.setCursor(100.0d);
    boolean var36 = var14.equals((java.lang.Object)100.0d);
    org.jfree.chart.renderer.category.CategoryItemRendererState var37 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test192"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var3 = var2.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var4 = var2.getLegendItemToolTipGenerator();
    java.awt.Shape var6 = var2.lookupSeriesShape(0);
    var2.setAutoPopulateSeriesFillPaint(true);
    boolean var10 = var2.isSeriesItemLabelsVisible(0);
    org.jfree.chart.labels.ItemLabelPosition var11 = var2.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var12 = var11.getRotationAnchor();
    org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.text.TextAnchor var15 = var14.getLabelTextAnchor();
    java.awt.Color var18 = java.awt.Color.getColor("", 1);
    boolean var19 = var15.equals((java.lang.Object)"");
    org.jfree.chart.axis.NumberTick var21 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(byte)0, "org.jfree.chart.event.ChartChangeEvent[source=0]", var12, var15, 0.0d);
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.axis.CategoryAxis var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var22, var23, var24, var25);
    double var27 = var26.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var28 = var26.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    int var30 = var26.getIndexOf(var29);
    java.util.List var31 = var26.getCategories();
    org.jfree.chart.axis.AxisLocation var32 = var26.getDomainAxisLocation();
    org.jfree.chart.plot.DatasetRenderingOrder var33 = var26.getDatasetRenderingOrder();
    org.jfree.chart.block.FlowArrangement var34 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var35 = null;
    org.jfree.chart.title.LegendItemBlockContainer var37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var34, var35, (java.lang.Comparable)1L);
    boolean var38 = var37.isEmpty();
    boolean var39 = var33.equals((java.lang.Object)var37);
    boolean var40 = var21.equals((java.lang.Object)var37);
    java.lang.Object var41 = var37.clone();
    boolean var42 = var37.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test193"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = null;
    org.jfree.chart.block.RectangleConstraint var3 = new org.jfree.chart.block.RectangleConstraint(var1, var2);
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var4, 100.0d);
    org.jfree.chart.block.RectangleConstraint var7 = var3.toRangeHeight(var6);
    double var8 = var6.getLength();
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var10 = null;
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(var9, var10);
    org.jfree.chart.block.LengthConstraintType var12 = var11.getHeightConstraintType();
    org.jfree.data.Range var13 = var11.getWidthRange();
    java.lang.String var14 = var11.toString();
    org.jfree.chart.block.LengthConstraintType var15 = var11.getHeightConstraintType();
    org.jfree.data.Range var17 = null;
    org.jfree.data.Range var18 = null;
    org.jfree.data.Range var19 = null;
    org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(var18, var19);
    org.jfree.chart.block.RectangleConstraint var21 = var20.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var23 = var20.toFixedWidth(1.0d);
    org.jfree.chart.block.RectangleConstraint var25 = var20.toFixedHeight((-1.0d));
    org.jfree.chart.block.LengthConstraintType var26 = var20.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint((-2.0d), var6, var15, 8.0d, var17, var26);
    org.jfree.data.category.CategoryDataset var28 = null;
    org.jfree.chart.axis.CategoryAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var28, var29, var30, var31);
    double var33 = var32.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var34 = var32.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var35 = null;
    java.util.List var36 = var32.getCategoriesForAxis(var35);
    double var37 = var32.getAnchorValue();
    var32.clearDomainMarkers();
    var32.mapDatasetToRangeAxis(1, (-253));
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis();
    double var43 = var42.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var44 = var42.getTickUnit();
    org.jfree.data.Range var45 = var32.getDataRange((org.jfree.chart.axis.ValueAxis)var42);
    boolean var46 = var42.isAutoRange();
    org.jfree.chart.axis.NumberTickUnit var48 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    org.jfree.chart.block.LabelBlock var50 = new org.jfree.chart.block.LabelBlock("hi!");
    java.lang.String var51 = var50.getID();
    int var52 = var48.compareTo((java.lang.Object)var50);
    java.lang.String var54 = var48.valueToString(1.0d);
    var42.setTickUnit(var48, false, false);
    java.awt.Stroke var58 = var42.getAxisLineStroke();
    org.jfree.data.RangeType var59 = var42.getRangeType();
    boolean var60 = var26.equals((java.lang.Object)var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"+ "'", var14.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + "1"+ "'", var54.equals("1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test194"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    double var6 = var5.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var8 = null;
    java.util.List var9 = var5.getCategoriesForAxis(var8);
    double var10 = var5.getAnchorValue();
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    java.awt.Paint var12 = var11.getBackgroundPaint();
    java.awt.Font var13 = var11.getItemFont();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
    org.jfree.chart.util.RectangleEdge var15 = var14.getPosition();
    java.awt.Font var16 = var14.getFont();
    org.jfree.chart.util.HorizontalAlignment var17 = var14.getTextAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test195"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.title.LegendTitle var13 = var11.getLegend(10);
    java.awt.Stroke var14 = var11.getBorderStroke();
    java.util.List var15 = var11.getSubtitles();
    boolean var16 = var11.isBorderVisible();
    var11.setBackgroundImageAlpha(1.0f);
    var11.setAntiAlias(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test196"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    org.jfree.chart.labels.ItemLabelPosition var5 = new org.jfree.chart.labels.ItemLabelPosition();
    var0.setPositiveItemLabelPositionFallback(var5);
    org.jfree.chart.block.LabelBlock var9 = new org.jfree.chart.block.LabelBlock("");
    double var10 = var9.getHeight();
    java.awt.Paint var11 = var9.getPaint();
    java.awt.Font var12 = var9.getFont();
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("hi!", var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var21 = null;
    java.util.List var22 = var18.getCategoriesForAxis(var21);
    double var23 = var18.getAnchorValue();
    var18.clearDomainAxes();
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var18);
    java.awt.RenderingHints var26 = var25.getRenderingHints();
    java.awt.Stroke var27 = var25.getBorderStroke();
    var25.setBorderVisible(false);
    org.jfree.chart.util.RectangleInsets var30 = var25.getPadding();
    boolean var31 = var13.equals((java.lang.Object)var25);
    var25.setAntiAlias(true);
    org.jfree.chart.event.ChartProgressEvent var36 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var25, 0, (-1));
    org.jfree.chart.JFreeChart var37 = var36.getChart();
    var36.setPercent(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test197"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var3 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var2, var3);
    org.jfree.chart.block.RectangleConstraint var5 = var4.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var7 = var4.toFixedWidth(1.0d);
    org.jfree.chart.block.RectangleConstraint var9 = var4.toFixedHeight((-1.0d));
    org.jfree.chart.block.LengthConstraintType var10 = var9.getHeightConstraintType();
    org.jfree.data.Range var12 = null;
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 100.0d);
    org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(var14, 10.0d);
    org.jfree.data.Range var17 = null;
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(var14, var17);
    double var19 = var14.getLowerBound();
    org.jfree.data.Range var20 = null;
    org.jfree.data.Range var21 = null;
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint(var20, var21);
    org.jfree.data.Range var23 = null;
    org.jfree.data.Range var25 = org.jfree.data.Range.expandToInclude(var23, 100.0d);
    org.jfree.chart.block.RectangleConstraint var26 = var22.toRangeHeight(var25);
    org.jfree.chart.block.LengthConstraintType var27 = var22.getWidthConstraintType();
    boolean var29 = var27.equals((java.lang.Object)(-16777216));
    org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint(5.0d, var1, var10, 0.0d, var14, var27);
    org.jfree.data.Range var31 = var30.getHeightRange();
    java.lang.String var32 = var30.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=5.0, height=0.0]"+ "'", var32.equals("RectangleConstraint[LengthConstraintType.FIXED: width=5.0, height=0.0]"));

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test198"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     java.awt.Stroke var14 = var4.getDomainGridlineStroke();
//     java.awt.Color var17 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var18 = var17.getColorSpace();
//     java.awt.image.ColorModel var19 = null;
//     java.awt.Rectangle var20 = null;
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
//     var22.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var28 = var22.getBounds();
//     java.awt.geom.AffineTransform var29 = null;
//     java.awt.RenderingHints var30 = null;
//     java.awt.PaintContext var31 = var17.createContext(var19, var20, var28, var29, var30);
//     var4.setNoDataMessagePaint((java.awt.Paint)var17);
//     var4.setNoDataMessage("");
//     org.jfree.chart.event.AxisChangeEvent var35 = null;
//     var4.axisChanged(var35);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var37 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var38 = var37.getColumnCount();
//     org.jfree.data.Range var40 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var37, 10.0d);
//     java.lang.Number var43 = var37.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
//     org.jfree.data.Range var44 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var37);
//     org.jfree.data.Range var46 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var37, 6.0d);
//     double var48 = var37.getRangeUpperBound(true);
//     var37.validateObject();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = var4.getRendererForDataset((org.jfree.data.category.CategoryDataset)var37);
//     double var52 = var37.getRangeUpperBound(true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == Double.NaN);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test199"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getColumnIndex((java.lang.Comparable)"100");
    java.util.List var3 = var0.getColumnKeys();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var4.addChangeListener(var6);
    boolean var8 = var0.equals((java.lang.Object)var4);
    org.jfree.chart.axis.NumberTickUnit var10 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    double var16 = var15.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var18 = null;
    java.util.List var19 = var15.getCategoriesForAxis(var18);
    org.jfree.chart.axis.AxisSpace var20 = var15.getFixedDomainAxisSpace();
    var15.setOutlineVisible(false);
    boolean var23 = var15.isSubplot();
    org.jfree.data.KeyedObject var24 = new org.jfree.data.KeyedObject((java.lang.Comparable)var10, (java.lang.Object)var15);
    int var25 = var0.getRowIndex((java.lang.Comparable)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((-6553600));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1));

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test200"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    int var8 = var4.getIndexOf(var7);
    org.jfree.chart.LegendItemCollection var9 = null;
    var4.setFixedLegendItems(var9);
    org.jfree.chart.event.PlotChangeListener var11 = null;
    var4.addChangeListener(var11);
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var4.getRangeMarkers(var13);
    var4.clearRangeMarkers();
    var4.setRangeCrosshairValue(1.05d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test201"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     java.awt.Stroke var8 = var4.getOutlineStroke();
//     var4.clearRangeAxes();
//     org.jfree.chart.axis.AxisSpace var10 = new org.jfree.chart.axis.AxisSpace();
//     double var11 = var10.getRight();
//     var4.setFixedDomainAxisSpace(var10);
//     float var13 = var4.getBackgroundImageAlpha();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var16 = var15.getRowCount();
//     java.awt.Paint var17 = var15.getBasePaint();
//     java.awt.Stroke var19 = var15.getSeriesStroke(1);
//     boolean var20 = var15.getBaseCreateEntities();
//     java.awt.Paint var21 = var15.getErrorIndicatorPaint();
//     org.jfree.chart.labels.ItemLabelPosition var23 = null;
//     var15.setSeriesNegativeItemLabelPosition(4, var23);
//     var4.setRenderer(4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15, true);
//     org.jfree.chart.ChartRenderingInfo var29 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var30 = new org.jfree.chart.plot.PlotRenderingInfo(var29);
//     int var31 = var30.getSubplotCount();
//     org.jfree.chart.renderer.RendererState var32 = new org.jfree.chart.renderer.RendererState(var30);
//     org.jfree.chart.entity.EntityCollection var33 = var32.getEntityCollection();
//     org.jfree.chart.plot.PlotRenderingInfo var34 = var32.getInfo();
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     var34.addSubplotInfo(var36);
//     org.jfree.chart.ChartRenderingInfo var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var38);
//     java.awt.geom.Rectangle2D var40 = null;
//     var39.setDataArea(var40);
//     org.jfree.chart.renderer.RendererState var42 = new org.jfree.chart.renderer.RendererState(var39);
//     java.lang.Object var43 = var39.clone();
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("SortOrder.ASCENDING");
//     org.jfree.data.category.CategoryDataset var46 = null;
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var46, var47, var48, var49);
//     double var51 = var50.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var52 = var50.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     java.util.List var54 = var50.getCategoriesForAxis(var53);
//     double var55 = var50.getAnchorValue();
//     var50.clearDomainAxes();
//     org.jfree.chart.util.RectangleInsets var57 = var50.getInsets();
//     var45.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var50);
//     org.jfree.chart.ChartRenderingInfo var60 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var61 = new org.jfree.chart.plot.PlotRenderingInfo(var60);
//     org.jfree.chart.block.LabelBlock var63 = new org.jfree.chart.block.LabelBlock("hi!");
//     var63.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var69 = var63.getBounds();
//     org.jfree.chart.util.RectangleAnchor var70 = null;
//     java.awt.geom.Point2D var71 = org.jfree.chart.util.RectangleAnchor.coordinates(var69, var70);
//     var50.zoomRangeAxes((-1.0d), var61, var71);
//     int var73 = var39.getSubplotIndex(var71);
//     var4.zoomRangeAxes(100.0d, 100.0d, var34, var71);
//     
//     // Checks the contract:  equals-hashcode on var6 and var52
//     assertTrue("Contract failed: equals-hashcode on var6 and var52", var6.equals(var52) ? var6.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var6
//     assertTrue("Contract failed: equals-hashcode on var52 and var6", var52.equals(var6) ? var52.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var61
//     assertTrue("Contract failed: equals-hashcode on var36 and var61", var36.equals(var61) ? var36.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var36
//     assertTrue("Contract failed: equals-hashcode on var61 and var36", var61.equals(var36) ? var61.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test202"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var1.setAlpha(0.0f);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var11 = null;
    java.util.List var12 = var8.getCategoriesForAxis(var11);
    double var13 = var8.getAnchorValue();
    var8.clearDomainMarkers();
    org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("");
    double var17 = var16.getHeight();
    java.awt.Paint var18 = var16.getPaint();
    var8.setRangeCrosshairPaint(var18);
    int var20 = var8.getDomainAxisCount();
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    java.awt.Color var24 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
    var8.setRangeCrosshairPaint((java.awt.Paint)var24);
    var1.setLabelPaint((java.awt.Paint)var24);
    org.jfree.chart.text.TextAnchor var27 = var1.getLabelTextAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test203"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setIncludeBaseInRange(true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test204"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getBasePositiveItemLabelPosition();
    boolean var2 = var0.getAutoPopulateSeriesStroke();
    java.awt.Paint var5 = var0.getItemPaint((-253), (-589829));
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var8.setAlpha(0.0f);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var12 = var11.getInsets();
    org.jfree.chart.util.RectangleInsets var13 = var11.getInsets();
    org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("hi!");
    var15.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var21 = var15.getBounds();
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
    double var28 = var27.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var29 = var27.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var30 = null;
    java.util.List var31 = var27.getCategoriesForAxis(var30);
    double var32 = var27.getAnchorValue();
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
    java.awt.Paint var34 = var33.getBackgroundPaint();
    java.awt.Font var35 = var33.getItemFont();
    org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("hi!", var35);
    java.awt.Graphics2D var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    var36.draw(var37, var38);
    java.awt.Paint var40 = var36.getBackgroundPaint();
    java.awt.geom.Rectangle2D var41 = var36.getBounds();
    boolean var42 = org.jfree.chart.util.ShapeUtilities.intersects(var21, var41);
    java.awt.geom.Rectangle2D var43 = var13.createOutsetRectangle(var41);
    var8.setLabelOffset(var13);
    var6.setItemLabelPadding(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test205"); }


    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var11 = null;
    java.util.List var12 = var8.getCategoriesForAxis(var11);
    double var13 = var8.getAnchorValue();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    java.awt.Paint var15 = var14.getBackgroundPaint();
    java.awt.Font var16 = var14.getItemFont();
    org.jfree.chart.block.LabelBlock var18 = new org.jfree.chart.block.LabelBlock("hi!");
    var18.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var24 = var18.getBounds();
    java.awt.Paint var25 = var18.getPaint();
    org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("SortOrder.ASCENDING", var16, var25);
    org.jfree.chart.block.LabelBlock var27 = new org.jfree.chart.block.LabelBlock("10", var16);
    org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("VerticalAlignment.CENTER", var16);
    org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("RectangleAnchor.CENTER", var16);
    var29.setWidth(12.0d);
    java.lang.Object var32 = var29.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test206"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("org.jfree.data.general.DatasetChangeEvent[source=-1]");
//     org.jfree.chart.text.TextFragment var2 = var1.getFirstTextFragment();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var1.calculateDimensions(var3);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test207"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    var0.setItemMargin(0.05d);
    int var7 = var0.getPassCount();
    java.awt.Paint var9 = var0.getSeriesPaint((-253));
    org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var12.setAlpha(0.0f);
    java.awt.Stroke var15 = var12.getOutlineStroke();
    java.awt.Stroke var16 = var12.getStroke();
    var0.setSeriesStroke(0, var16);
    boolean var18 = var0.getAutoPopulateSeriesStroke();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    var0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test208"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     java.awt.geom.Point2D var17 = null;
//     var4.zoomRangeAxes((-1.0d), 1.0d, var16, var17);
//     org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("hi!");
//     var20.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var26 = var20.getBounds();
//     java.awt.Paint var27 = var20.getPaint();
//     var4.setRangeGridlinePaint(var27);
//     org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.Object var30 = var29.clone();
//     var29.setFixedDimension(10.0d);
//     double var33 = var29.getUpperMargin();
//     org.jfree.chart.event.AxisChangeEvent var34 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var29);
//     var4.axisChanged(var34);
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.axis.CategoryAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var36, var37, var38, var39);
//     double var41 = var40.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var42 = var40.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var43 = null;
//     java.util.List var44 = var40.getCategoriesForAxis(var43);
//     double var45 = var40.getAnchorValue();
//     var40.clearDomainAxes();
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
//     var40.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var48, true);
//     double var51 = var48.getUpperBound();
//     var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var48);
//     
//     // Checks the contract:  equals-hashcode on var6 and var42
//     assertTrue("Contract failed: equals-hashcode on var6 and var42", var6.equals(var42) ? var6.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var6
//     assertTrue("Contract failed: equals-hashcode on var42 and var6", var42.equals(var6) ? var42.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test209"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    var4.setDomainGridlinesVisible(false);
    var4.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.CategoryAxis var14 = var4.getDomainAxis();
    org.jfree.chart.LegendItemCollection var15 = var4.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test210"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    var11.setBackgroundImageAlignment(0);
    boolean var14 = var11.isBorderVisible();
    org.jfree.chart.title.TextTitle var15 = null;
    var11.setTitle(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test211"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    java.awt.Stroke var14 = var4.getDomainGridlineStroke();
    org.jfree.chart.axis.AxisLocation var16 = var4.getDomainAxisLocation(1);
    org.jfree.chart.plot.Plot var17 = var4.getParent();
    var4.setAnchorValue(6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test212"); }
// 
// 
//     org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
//     java.util.List var1 = var0.getLines();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var0.calculateDimensions(var2);
//     org.jfree.data.category.CategoryDataset var8 = null;
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
//     double var13 = var12.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var14 = var12.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var15 = var12.getRowRenderingOrder();
//     java.awt.Stroke var16 = var12.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = var12.getRendererForDataset(var17);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var12);
//     java.util.List var20 = var19.getSubtitles();
//     org.jfree.chart.ChartRenderingInfo var25 = null;
//     java.awt.image.BufferedImage var26 = var19.createBufferedImage(1, 10, (-1.0d), 1.0d, var25);
//     org.jfree.chart.ui.ProjectInfo var30 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "", (java.awt.Image)var26, "org.jfree.chart.event.ChartChangeEvent[source=0]", "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", "10");
//     var30.setName("");
//     org.jfree.chart.ui.Library[] var33 = var30.getLibraries();
//     java.lang.String var34 = var30.getVersion();
//     java.lang.String var35 = var30.toString();
//     boolean var36 = var0.equals((java.lang.Object)var35);
//     org.jfree.chart.text.TextLine var37 = var0.getLastLine();
//     org.jfree.chart.text.TextLine var38 = var0.getLastLine();
//     org.jfree.chart.text.TextLine var40 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("");
//     var40.addFragment(var42);
//     var0.addLine(var40);
//     org.jfree.chart.text.TextLine var46 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var47 = var46.getFirstTextFragment();
//     org.jfree.data.category.CategoryDataset var50 = null;
//     org.jfree.chart.axis.CategoryAxis var51 = null;
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var50, var51, var52, var53);
//     double var55 = var54.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var56 = var54.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var57 = null;
//     java.util.List var58 = var54.getCategoriesForAxis(var57);
//     double var59 = var54.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var54);
//     java.awt.Paint var61 = var60.getBackgroundPaint();
//     java.awt.Font var62 = var60.getItemFont();
//     org.jfree.chart.title.TextTitle var63 = new org.jfree.chart.title.TextTitle("hi!", var62);
//     org.jfree.chart.text.TextFragment var64 = new org.jfree.chart.text.TextFragment("", var62);
//     var46.removeFragment(var64);
//     var40.addFragment(var64);
//     
//     // Checks the contract:  equals-hashcode on var12 and var54
//     assertTrue("Contract failed: equals-hashcode on var12 and var54", var12.equals(var54) ? var12.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var12
//     assertTrue("Contract failed: equals-hashcode on var54 and var12", var54.equals(var12) ? var54.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var56
//     assertTrue("Contract failed: equals-hashcode on var14 and var56", var14.equals(var56) ? var14.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var14
//     assertTrue("Contract failed: equals-hashcode on var56 and var14", var56.equals(var14) ? var56.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test213"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    org.jfree.chart.labels.ItemLabelPosition var5 = new org.jfree.chart.labels.ItemLabelPosition();
    var0.setPositiveItemLabelPositionFallback(var5);
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
    var0.setSeriesToolTipGenerator(0, var8, false);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    double var16 = var15.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var18 = null;
    java.util.List var19 = var15.getCategoriesForAxis(var18);
    double var20 = var15.getAnchorValue();
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
    java.awt.Paint var22 = var21.getBackgroundPaint();
    java.awt.Font var23 = var21.getItemFont();
    var0.setBaseItemLabelFont(var23, false);
    org.jfree.chart.labels.ItemLabelPosition var26 = var0.getPositiveItemLabelPositionFallback();
    org.jfree.data.Range var27 = null;
    org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, 100.0d);
    org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint(var29, 10.0d);
    org.jfree.chart.block.RectangleConstraint var32 = var31.toUnconstrainedHeight();
    boolean var33 = var0.equals((java.lang.Object)var31);
    org.jfree.chart.util.Size2D var36 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
    var36.setHeight((-1.0d));
    var36.setWidth((-1.0d));
    org.jfree.chart.util.Size2D var41 = var31.calculateConstrainedSize(var36);
    double var42 = var41.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 10.0d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test214"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    int var12 = var4.getBackgroundImageAlignment();
    var4.setAnchorValue(0.05d);
    int var15 = var4.getDatasetCount();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var17 = var16.getRowCount();
    java.awt.Paint var18 = var16.getBasePaint();
    java.awt.Stroke var20 = var16.getSeriesStroke(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var21 = null;
    var16.setLegendItemToolTipGenerator(var21);
    java.awt.Color var25 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var26 = var25.getColorSpace();
    java.awt.image.ColorModel var27 = null;
    java.awt.Rectangle var28 = null;
    org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("hi!");
    var30.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var36 = var30.getBounds();
    java.awt.geom.AffineTransform var37 = null;
    java.awt.RenderingHints var38 = null;
    java.awt.PaintContext var39 = var25.createContext(var27, var28, var36, var37, var38);
    boolean var40 = var16.equals((java.lang.Object)var25);
    org.jfree.chart.urls.CategoryURLGenerator var42 = var16.getSeriesURLGenerator((-16777215));
    org.jfree.chart.LegendItemCollection var43 = var16.getLegendItems();
    var4.setFixedLegendItems(var43);
    var4.clearRangeMarkers((-253));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test215"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
    var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var10 = var4.getBounds();
    org.jfree.chart.util.RectangleAnchor var11 = null;
    java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
    org.jfree.chart.util.RectangleEdge var13 = null;
    double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
    var0.setTickMarkOutsideLength(0.0f);
    org.jfree.chart.util.RectangleInsets var17 = var0.getLabelInsets();
    float var18 = var0.getTickMarkOutsideLength();
    var0.setUpperMargin(100.0d);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
    double var26 = var25.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var27 = var25.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var28 = null;
    java.util.List var29 = var25.getCategoriesForAxis(var28);
    double var30 = var25.getAnchorValue();
    var25.clearDomainAxes();
    org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
    java.awt.RenderingHints var33 = var32.getRenderingHints();
    var32.setBackgroundImageAlpha(0.0f);
    java.lang.Object var36 = var32.getTextAntiAlias();
    var32.removeLegend();
    org.jfree.chart.event.ChartProgressEvent var40 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var32, 0, 100);
    org.jfree.chart.JFreeChart var41 = var40.getChart();
    var40.setPercent((-16777215));
    int var44 = var40.getPercent();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-16777215));

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test216"); }


    java.lang.Comparable var2 = null;
    org.jfree.chart.text.TextBlock var3 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.text.TextAnchor var7 = var6.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var9 = new org.jfree.chart.axis.CategoryTick(var2, var3, var4, var7, (-1.0d));
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("hi!");
    var15.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var21 = var15.getBounds();
    org.jfree.chart.util.RectangleAnchor var22 = null;
    java.awt.geom.Point2D var23 = org.jfree.chart.util.RectangleAnchor.coordinates(var21, var22);
    org.jfree.chart.util.RectangleEdge var24 = null;
    double var25 = var11.getCategoryStart((-16777216), (-16777216), var21, var24);
    var11.setTickMarkOutsideLength(0.0f);
    org.jfree.chart.util.RectangleInsets var28 = var11.getLabelInsets();
    float var29 = var11.getTickMarkOutsideLength();
    var11.setCategoryLabelPositionOffset(0);
    boolean var32 = var9.equals((java.lang.Object)var11);
    org.jfree.chart.text.TextAnchor var33 = var9.getTextAnchor();
    java.lang.String var34 = var33.toString();
    java.lang.String var35 = var33.toString();
    org.jfree.chart.text.TextBlock var37 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.text.TextBlockAnchor var38 = null;
    org.jfree.data.category.CategoryDataset var39 = null;
    org.jfree.chart.axis.CategoryAxis var40 = null;
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
    org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var39, var40, var41, var42);
    double var44 = var43.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var45 = var43.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var46 = null;
    int var47 = var43.getIndexOf(var46);
    java.util.List var48 = var43.getCategories();
    var43.configureDomainAxes();
    org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var51.setAlpha(0.0f);
    java.awt.Stroke var54 = var51.getOutlineStroke();
    var43.addRangeMarker((org.jfree.chart.plot.Marker)var51);
    org.jfree.chart.text.TextAnchor var56 = var51.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var58 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)10.0f, var37, var38, var56, 6.0d);
    org.jfree.chart.axis.NumberTick var60 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(-1.0d), "ItemLabelAnchor.OUTSIDE12", var33, var56, 9.05d);
    org.jfree.chart.axis.TickType var61 = var60.getTickType();
    java.lang.String var62 = var60.getText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "TextAnchor.CENTER"+ "'", var34.equals("TextAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "TextAnchor.CENTER"+ "'", var35.equals("TextAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + "ItemLabelAnchor.OUTSIDE12"+ "'", var62.equals("ItemLabelAnchor.OUTSIDE12"));

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test217"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var2 = var0.getIndex((java.lang.Comparable)0);
    java.util.List var3 = var0.getKeys();
    java.lang.Object var5 = var0.getObject((java.lang.Comparable)10.05d);
    org.jfree.chart.axis.NumberTickUnit var7 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var9 = var8.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var10 = var8.getLegendItemToolTipGenerator();
    java.awt.Shape var12 = var8.lookupSeriesShape(0);
    int var13 = var8.getRowCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var15 = var8.getSeriesToolTipGenerator(1);
    var8.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var20 = var8.getNegativeItemLabelPosition(0, (-16777216));
    var0.addObject((java.lang.Comparable)var7, (java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test218"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var1 = var0.getColumnCount();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 10.0d);
    boolean var4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    java.lang.Comparable var6 = null;
    int var7 = var0.getRowIndex(var6);
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
    double var13 = var12.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var14 = var12.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var15 = null;
    java.util.List var16 = var12.getCategoriesForAxis(var15);
    double var17 = var12.getAnchorValue();
    var12.clearDomainAxes();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
    org.jfree.chart.title.LegendTitle var21 = var19.getLegend(10);
    var19.setBackgroundImageAlignment(100);
    org.jfree.chart.event.ChartProgressListener var24 = null;
    var19.addProgressListener(var24);
    org.jfree.chart.event.ChartChangeEventType var26 = null;
    org.jfree.chart.event.ChartChangeEvent var27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7, var19, var26);
    java.awt.Paint var28 = var19.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.0d+ "'", var5.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test219"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var1 = var0.getRangeAxis();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var3 = var2.getColumnCount();
//     org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var2, 10.0d);
//     java.lang.Number var8 = var2.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
//     org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var2);
//     double var11 = var2.getRangeLowerBound(true);
//     var0.setDataset((org.jfree.data.category.CategoryDataset)var2);
//     java.awt.Stroke var13 = var0.getRangeCrosshairStroke();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test220"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var1 = null;
    org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)1L);
    var3.clear();
    java.lang.String var5 = var3.getURLText();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var7 = var6.getColumnCount();
    org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var6, 10.0d);
    java.lang.Number var12 = var6.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
    org.jfree.data.Range var13 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var6);
    org.jfree.data.Range var15 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var6, 6.0d);
    boolean var16 = var3.equals((java.lang.Object)6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test221"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
    double var3 = var2.getHeight();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Font var5 = var2.getFont();
    var0.setLabelFont(var5);
    java.lang.String var8 = var0.getCategoryLabelToolTip((java.lang.Comparable)(byte)10);
    java.lang.String var10 = var0.getCategoryLabelToolTip((java.lang.Comparable)(short)0);
    boolean var11 = var0.isAxisLineVisible();
    var0.clearCategoryLabelToolTips();
    java.lang.String var14 = var0.getCategoryLabelToolTip((java.lang.Comparable)"0");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test222"); }


    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "hi!", "hi!");
    org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var6);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var6, var13);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var16 = var15.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var15.getLegendItemToolTipGenerator();
    java.awt.Shape var19 = var15.lookupSeriesShape(0);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    double var25 = var24.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var26 = var24.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var27 = null;
    java.util.List var28 = var24.getCategoriesForAxis(var27);
    double var29 = var24.getAnchorValue();
    var24.clearDomainAxes();
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
    org.jfree.chart.title.LegendTitle var33 = var31.getLegend(10);
    java.awt.Stroke var34 = var31.getBorderStroke();
    var15.setBaseStroke(var34);
    boolean var38 = var15.isItemLabelVisible(0, (-165));
    java.awt.Stroke var41 = var15.getItemOutlineStroke(15, (-16777215));
    java.awt.Paint var42 = null;
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=0]", "RectangleConstraintType.RANGE", "[size=1]", "VerticalAlignment.CENTER", var6, var41, var42);
    java.lang.Comparable var44 = var43.getSeriesKey();
    java.awt.Stroke var45 = var43.getOutlineStroke();
    var43.setDatasetIndex((-165));
    java.awt.Paint var48 = var43.getFillPaint();
    boolean var49 = var43.isShapeFilled();
    java.lang.String var50 = var43.getLabel();
    java.lang.String var51 = var43.getToolTipText();
    boolean var52 = var43.isShapeOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=0]"+ "'", var50.equals("org.jfree.chart.event.ChartChangeEvent[source=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "[size=1]"+ "'", var51.equals("[size=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test223"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var11 = null;
    java.util.List var12 = var8.getCategoriesForAxis(var11);
    double var13 = var8.getAnchorValue();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    java.awt.Paint var15 = var14.getBackgroundPaint();
    java.awt.Font var16 = var14.getItemFont();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("hi!", var16);
    org.jfree.chart.util.RectangleEdge var18 = var17.getPosition();
    boolean var19 = var0.equals((java.lang.Object)var17);
    int var20 = var0.size();
    java.lang.Object var21 = var0.clone();
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
    double var28 = var27.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var29 = var27.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var30 = null;
    java.util.List var31 = var27.getCategoriesForAxis(var30);
    double var32 = var27.getAnchorValue();
    java.awt.Color var35 = java.awt.Color.getColor("", 1);
    var27.setOutlinePaint((java.awt.Paint)var35);
    java.awt.Stroke var37 = var27.getDomainGridlineStroke();
    org.jfree.chart.axis.AxisLocation var39 = var27.getDomainAxisLocation(1);
    java.awt.Stroke var40 = var27.getOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setStroke((-16777216), var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test224"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
    boolean var9 = var5.equals((java.lang.Object)var6);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var5.setArea(var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var21 = null;
    java.util.List var22 = var18.getCategoriesForAxis(var21);
    double var23 = var18.getAnchorValue();
    java.awt.Color var26 = java.awt.Color.getColor("", 1);
    var18.setOutlinePaint((java.awt.Paint)var26);
    java.awt.Stroke var28 = var18.getDomainGridlineStroke();
    java.awt.Color var31 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var32 = var31.getColorSpace();
    java.awt.image.ColorModel var33 = null;
    java.awt.Rectangle var34 = null;
    org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("hi!");
    var36.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var42 = var36.getBounds();
    java.awt.geom.AffineTransform var43 = null;
    java.awt.RenderingHints var44 = null;
    java.awt.PaintContext var45 = var31.createContext(var33, var34, var42, var43, var44);
    var18.setNoDataMessagePaint((java.awt.Paint)var31);
    org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic(var12, (java.awt.Paint)var31);
    java.awt.Shape var48 = var47.getShape();
    var47.setShapeOutlineVisible(true);
    org.jfree.chart.util.GradientPaintTransformer var51 = var47.getFillPaintTransformer();
    java.awt.Stroke var52 = var47.getOutlineStroke();
    java.awt.Shape var53 = var47.getLine();
    org.jfree.chart.util.RectangleAnchor var54 = var47.getShapeAnchor();
    org.jfree.chart.block.BlockBorder var55 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var56 = var55.getInsets();
    org.jfree.chart.axis.AxisCollection var57 = new org.jfree.chart.axis.AxisCollection();
    org.jfree.chart.event.ChartChangeEvent var58 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var57);
    boolean var59 = var55.equals((java.lang.Object)var58);
    org.jfree.chart.util.RectangleInsets var60 = var55.getInsets();
    boolean var61 = var47.equals((java.lang.Object)var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test225"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
    boolean var9 = var5.equals((java.lang.Object)var6);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var5.setArea(var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var21 = null;
    java.util.List var22 = var18.getCategoriesForAxis(var21);
    double var23 = var18.getAnchorValue();
    java.awt.Color var26 = java.awt.Color.getColor("", 1);
    var18.setOutlinePaint((java.awt.Paint)var26);
    java.awt.Stroke var28 = var18.getDomainGridlineStroke();
    java.awt.Color var31 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var32 = var31.getColorSpace();
    java.awt.image.ColorModel var33 = null;
    java.awt.Rectangle var34 = null;
    org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("hi!");
    var36.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var42 = var36.getBounds();
    java.awt.geom.AffineTransform var43 = null;
    java.awt.RenderingHints var44 = null;
    java.awt.PaintContext var45 = var31.createContext(var33, var34, var42, var43, var44);
    var18.setNoDataMessagePaint((java.awt.Paint)var31);
    org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic(var12, (java.awt.Paint)var31);
    java.awt.Shape var48 = var47.getShape();
    var47.setShapeOutlineVisible(true);
    org.jfree.chart.util.GradientPaintTransformer var51 = var47.getFillPaintTransformer();
    java.awt.Stroke var52 = var47.getOutlineStroke();
    java.awt.Shape var53 = null;
    var47.setLine(var53);
    var47.setMargin(0.0d, 0.2d, 8.0d, 1.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test226"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var2 = var0.getIndex((java.lang.Comparable)0);
    java.lang.Comparable var4 = var0.getKey((-16777215));
    java.util.List var5 = var0.getKeys();
    java.lang.Object var6 = var0.clone();
    java.util.List var7 = var0.getKeys();
    int var8 = var0.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test227"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    java.awt.Stroke var14 = var4.getDomainGridlineStroke();
    java.awt.Color var17 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var18 = var17.getColorSpace();
    java.awt.image.ColorModel var19 = null;
    java.awt.Rectangle var20 = null;
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
    var22.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var28 = var22.getBounds();
    java.awt.geom.AffineTransform var29 = null;
    java.awt.RenderingHints var30 = null;
    java.awt.PaintContext var31 = var17.createContext(var19, var20, var28, var29, var30);
    var4.setNoDataMessagePaint((java.awt.Paint)var17);
    var4.setNoDataMessage("");
    float var35 = var4.getBackgroundImageAlpha();
    int var36 = var4.getRangeAxisCount();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var37 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var38 = var37.getColumnCount();
    java.lang.Number var41 = var37.getMeanValue((java.lang.Comparable)"[size=1]", (java.lang.Comparable)100);
    org.jfree.chart.renderer.category.CategoryItemRenderer var42 = var4.getRendererForDataset((org.jfree.data.category.CategoryDataset)var37);
    org.jfree.chart.axis.CategoryAxis var44 = var4.getDomainAxisForDataset((-253));
    org.jfree.data.category.CategoryDataset var46 = null;
    org.jfree.chart.axis.CategoryAxis var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var46, var47, var48, var49);
    double var51 = var50.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var52 = var50.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    int var54 = var50.getIndexOf(var53);
    java.util.List var55 = var50.getCategories();
    org.jfree.chart.axis.AxisLocation var56 = var50.getDomainAxisLocation();
    var4.setRangeAxisLocation(0, var56);
    var4.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test228"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var1 = var0.getAxesAtTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test229"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
//     boolean var9 = var5.equals((java.lang.Object)var6);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var5.setArea(var12);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var17 = var16.getColumnCount();
//     org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var16, 10.0d);
//     java.lang.Number var22 = var16.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
//     org.jfree.data.Range var23 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var16);
//     double var25 = var16.getRangeLowerBound(true);
//     boolean var26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var16);
//     java.lang.Number var27 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var16);
//     org.jfree.chart.axis.NumberTickUnit var30 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     boolean var33 = var30.equals((java.lang.Object)var31);
//     int var34 = var30.getMinorTickCount();
//     org.jfree.chart.entity.CategoryItemEntity var35 = new org.jfree.chart.entity.CategoryItemEntity(var12, "ChartEntity: tooltip = hi!", "RectangleEdge.TOP", (org.jfree.data.category.CategoryDataset)var16, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)var34);
//     java.lang.Comparable var36 = var35.getColumnKey();
//     java.lang.String var37 = var35.toString();
//     var35.setColumnKey((java.lang.Comparable)"RectangleEdge.TOP");
//     java.lang.String var40 = var35.toString();
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var46 = new org.jfree.chart.entity.TickLabelEntity(var43, "hi!", "hi!");
//     org.jfree.data.Range var47 = null;
//     org.jfree.data.Range var48 = null;
//     org.jfree.chart.block.RectangleConstraint var49 = new org.jfree.chart.block.RectangleConstraint(var47, var48);
//     boolean var50 = var46.equals((java.lang.Object)var47);
//     java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var46.setArea(var53);
//     org.jfree.data.category.CategoryDataset var55 = null;
//     org.jfree.chart.axis.CategoryAxis var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var55, var56, var57, var58);
//     double var60 = var59.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var61 = var59.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var62 = null;
//     java.util.List var63 = var59.getCategoriesForAxis(var62);
//     double var64 = var59.getAnchorValue();
//     java.awt.Color var67 = java.awt.Color.getColor("", 1);
//     var59.setOutlinePaint((java.awt.Paint)var67);
//     java.awt.Stroke var69 = var59.getDomainGridlineStroke();
//     java.awt.Color var72 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var73 = var72.getColorSpace();
//     java.awt.image.ColorModel var74 = null;
//     java.awt.Rectangle var75 = null;
//     org.jfree.chart.block.LabelBlock var77 = new org.jfree.chart.block.LabelBlock("hi!");
//     var77.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var83 = var77.getBounds();
//     java.awt.geom.AffineTransform var84 = null;
//     java.awt.RenderingHints var85 = null;
//     java.awt.PaintContext var86 = var72.createContext(var74, var75, var83, var84, var85);
//     var59.setNoDataMessagePaint((java.awt.Paint)var72);
//     org.jfree.chart.title.LegendGraphic var88 = new org.jfree.chart.title.LegendGraphic(var53, (java.awt.Paint)var72);
//     java.awt.Shape var89 = var88.getShape();
//     double var90 = var88.getContentXOffset();
//     boolean var91 = var88.isShapeFilled();
//     org.jfree.chart.util.GradientPaintTransformer var92 = var88.getFillPaintTransformer();
//     boolean var93 = var35.equals((java.lang.Object)var88);
//     java.lang.String var94 = var35.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + 0.0d+ "'", var27.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + 0+ "'", var36.equals(0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == false);
// 
//   }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test230"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.chart.event.MarkerChangeEvent var11 = null;
//     var4.markerChanged(var11);
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
//     var13.setNegativeArrowVisible(false);
//     org.jfree.chart.axis.MarkerAxisBand var16 = var13.getMarkerBand();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var18 = var17.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var19 = var17.getLegendItemToolTipGenerator();
//     java.awt.Shape var21 = var17.lookupSeriesShape(0);
//     var17.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.urls.CategoryURLGenerator var25 = null;
//     var17.setSeriesURLGenerator(0, var25);
//     var17.setItemMargin(6.0d);
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var29, var30, var31, var32);
//     double var34 = var33.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var35 = var33.getDrawingSupplier();
//     var33.clearAnnotations();
//     var17.setPlot(var33);
//     java.lang.Object var38 = var33.clone();
//     var13.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var33);
//     java.awt.Stroke var40 = var13.getTickMarkStroke();
//     var13.setRangeAboutValue(10.05d, 0.2d);
//     int var44 = var4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var13);
//     
//     // Checks the contract:  equals-hashcode on var4 and var33
//     assertTrue("Contract failed: equals-hashcode on var4 and var33", var4.equals(var33) ? var4.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var4
//     assertTrue("Contract failed: equals-hashcode on var33 and var4", var33.equals(var4) ? var33.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var35
//     assertTrue("Contract failed: equals-hashcode on var6 and var35", var6.equals(var35) ? var6.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var6
//     assertTrue("Contract failed: equals-hashcode on var35 and var6", var35.equals(var6) ? var35.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test231"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(0, var8);
    var0.setItemMargin(6.0d);
    java.awt.Shape var13 = var0.lookupSeriesShape(100);
    java.awt.Paint var16 = var0.getItemLabelPaint(100, 10);
    org.jfree.chart.urls.CategoryURLGenerator var18 = null;
    var0.setSeriesURLGenerator(15, var18);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var21 = var20.getRowCount();
    java.awt.Paint var22 = var20.getBasePaint();
    java.awt.Stroke var24 = var20.getSeriesStroke(1);
    var20.setItemMargin(0.05d);
    var20.setAutoPopulateSeriesShape(false);
    org.jfree.chart.axis.CategoryLabelPositions var30 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.util.RectangleEdge var31 = null;
    org.jfree.chart.axis.CategoryLabelPosition var32 = var30.getLabelPosition(var31);
    boolean var34 = var30.equals((java.lang.Object)false);
    org.jfree.chart.axis.CategoryLabelPositions var36 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
    org.jfree.data.category.CategoryDataset var37 = null;
    org.jfree.chart.axis.CategoryAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
    org.jfree.chart.util.RectangleEdge var43 = var41.getDomainAxisEdge((-1));
    java.lang.String var44 = var43.toString();
    org.jfree.chart.axis.CategoryLabelPosition var45 = var36.getLabelPosition(var43);
    org.jfree.chart.axis.CategoryLabelPositions var46 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var30, var45);
    boolean var47 = var20.equals((java.lang.Object)var45);
    org.jfree.chart.block.LabelBlock var52 = new org.jfree.chart.block.LabelBlock("");
    double var53 = var52.getHeight();
    java.awt.Paint var54 = var52.getPaint();
    java.awt.Font var55 = var52.getFont();
    org.jfree.chart.title.TextTitle var56 = new org.jfree.chart.title.TextTitle("hi!", var55);
    org.jfree.data.category.CategoryDataset var57 = null;
    org.jfree.chart.axis.CategoryAxis var58 = null;
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var57, var58, var59, var60);
    double var62 = var61.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var63 = var61.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var64 = null;
    java.util.List var65 = var61.getCategoriesForAxis(var64);
    double var66 = var61.getAnchorValue();
    java.awt.Color var69 = java.awt.Color.getColor("", 1);
    var61.setOutlinePaint((java.awt.Paint)var69);
    org.jfree.chart.block.LabelBlock var71 = new org.jfree.chart.block.LabelBlock("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", var55, (java.awt.Paint)var69);
    var20.setSeriesItemLabelFont(0, var55, false);
    org.jfree.chart.labels.ItemLabelPosition var75 = var20.getSeriesNegativeItemLabelPosition((-589829));
    double var76 = var75.getAngle();
    var0.setBaseNegativeItemLabelPosition(var75);
    org.jfree.chart.labels.CategoryToolTipGenerator var78 = null;
    var0.setBaseToolTipGenerator(var78, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "RectangleEdge.TOP"+ "'", var44.equals("RectangleEdge.TOP"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test232"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    float var14 = var4.getForegroundAlpha();
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    var4.setRenderer(var15, false);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    double var19 = var18.getLowerMargin();
    org.jfree.data.Range var20 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var18);
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("hi!");
    var26.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var32 = var26.getBounds();
    org.jfree.chart.util.RectangleAnchor var33 = null;
    java.awt.geom.Point2D var34 = org.jfree.chart.util.RectangleAnchor.coordinates(var32, var33);
    org.jfree.chart.util.RectangleEdge var35 = null;
    double var36 = var22.getCategoryStart((-16777216), (-16777216), var32, var35);
    org.jfree.chart.entity.CategoryLabelEntity var39 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var32, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
    org.jfree.chart.entity.AxisLabelEntity var42 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var18, (java.awt.Shape)var32, "org.jfree.chart.event.ChartChangeEvent[source=0]", "org.jfree.data.general.DatasetChangeEvent[source=-1]");
    boolean var43 = var18.isAutoTickUnitSelection();
    org.jfree.chart.axis.TickUnitSource var44 = var18.getStandardTickUnits();
    org.jfree.chart.axis.TickUnitSource var45 = null;
    var18.setStandardTickUnits(var45);
    double var47 = var18.getLowerBound();
    var18.setUpperBound(1.05d);
    java.awt.Shape var50 = var18.getRightArrow();
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var50, 1.0d, (-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test233"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 100.0d);
    org.jfree.chart.block.RectangleConstraint var6 = var2.toRangeHeight(var5);
    org.jfree.chart.block.RectangleConstraint var7 = var6.toUnconstrainedWidth();
    org.jfree.data.Range var8 = var6.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var9 = var6.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var11 = var9.toFixedHeight(6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test234"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     double var18 = var17.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var19 = var17.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     java.util.List var21 = var17.getCategoriesForAxis(var20);
//     double var22 = var17.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     java.awt.Paint var24 = var23.getBackgroundPaint();
//     java.awt.Font var25 = var23.getItemFont();
//     org.jfree.chart.util.VerticalAlignment var26 = var23.getVerticalAlignment();
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     int var29 = var28.getSubplotCount();
//     org.jfree.chart.renderer.RendererState var30 = new org.jfree.chart.renderer.RendererState(var28);
//     boolean var31 = var26.equals((java.lang.Object)var28);
//     org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var35 = var34.getBackgroundPaint();
//     java.awt.Color var39 = java.awt.Color.getHSBColor((-1.0f), 0.5f, 0.0f);
//     var34.setPaint((java.awt.Paint)var39);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("SortOrder.ASCENDING");
//     var43.setNotify(false);
//     java.awt.Graphics2D var46 = null;
//     org.jfree.chart.block.LineBorder var49 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.block.LabelBlock var52 = new org.jfree.chart.block.LabelBlock("hi!");
//     var52.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var58 = var52.getBounds();
//     org.jfree.data.category.CategoryDataset var60 = null;
//     org.jfree.chart.axis.CategoryAxis var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var63 = null;
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var60, var61, var62, var63);
//     double var65 = var64.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var66 = var64.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var67 = null;
//     java.util.List var68 = var64.getCategoriesForAxis(var67);
//     double var69 = var64.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var70 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var64);
//     java.awt.Paint var71 = var70.getBackgroundPaint();
//     java.awt.Font var72 = var70.getItemFont();
//     org.jfree.chart.title.TextTitle var73 = new org.jfree.chart.title.TextTitle("hi!", var72);
//     java.awt.Graphics2D var74 = null;
//     java.awt.geom.Rectangle2D var75 = null;
//     var73.draw(var74, var75);
//     java.awt.Paint var77 = var73.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var78 = var73.getBounds();
//     boolean var79 = org.jfree.chart.util.ShapeUtilities.intersects(var58, var78);
//     var49.draw(var50, var58);
//     java.awt.geom.Point2D var81 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(2.0d, 2.0d, var58);
//     var43.draw(var46, var58);
//     var34.draw(var41, var58);
//     java.awt.geom.Point2D var84 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.2d, 0.0d, var58);
//     var4.zoomDomainAxes((-1.0d), 14.0d, var28, var84);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var64
//     assertTrue("Contract failed: equals-hashcode on var4 and var64", var4.equals(var64) ? var4.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var64
//     assertTrue("Contract failed: equals-hashcode on var17 and var64", var17.equals(var64) ? var17.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var4
//     assertTrue("Contract failed: equals-hashcode on var64 and var4", var64.equals(var4) ? var64.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var17
//     assertTrue("Contract failed: equals-hashcode on var64 and var17", var64.equals(var17) ? var64.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var19
//     assertTrue("Contract failed: equals-hashcode on var6 and var19", var6.equals(var19) ? var6.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var66
//     assertTrue("Contract failed: equals-hashcode on var6 and var66", var6.equals(var66) ? var6.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var6
//     assertTrue("Contract failed: equals-hashcode on var19 and var6", var19.equals(var6) ? var19.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var66
//     assertTrue("Contract failed: equals-hashcode on var19 and var66", var19.equals(var66) ? var19.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var6
//     assertTrue("Contract failed: equals-hashcode on var66 and var6", var66.equals(var6) ? var66.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var19
//     assertTrue("Contract failed: equals-hashcode on var66 and var19", var66.equals(var19) ? var66.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test235"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     java.awt.Paint var15 = var14.getPaint();
//     var14.setNotify(false);
//     var14.setWidth((-1.0d));
//     java.lang.Object var20 = var14.clone();
//     var14.setURLText("LegendItemEntity: seriesKey=null, dataset=null");
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var28 = new org.jfree.chart.entity.TickLabelEntity(var25, "hi!", "hi!");
//     org.jfree.data.Range var29 = null;
//     org.jfree.data.Range var30 = null;
//     org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint(var29, var30);
//     boolean var32 = var28.equals((java.lang.Object)var29);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var28.setArea(var35);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var39 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var40 = var39.getColumnCount();
//     org.jfree.data.Range var42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var39, 10.0d);
//     java.lang.Number var45 = var39.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
//     org.jfree.data.Range var46 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var39);
//     double var48 = var39.getRangeLowerBound(true);
//     boolean var49 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var39);
//     java.lang.Number var50 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var39);
//     org.jfree.chart.axis.NumberTickUnit var53 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var54 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var55 = new org.jfree.chart.plot.PlotRenderingInfo(var54);
//     boolean var56 = var53.equals((java.lang.Object)var54);
//     int var57 = var53.getMinorTickCount();
//     org.jfree.chart.entity.CategoryItemEntity var58 = new org.jfree.chart.entity.CategoryItemEntity(var35, "ChartEntity: tooltip = hi!", "RectangleEdge.TOP", (org.jfree.data.category.CategoryDataset)var39, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)var57);
//     java.lang.Comparable var59 = var58.getColumnKey();
//     boolean var60 = var14.equals((java.lang.Object)var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + 0.0d+ "'", var50.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var59 + "' != '" + 0+ "'", var59.equals(0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test236"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setAutoRangeIncludesZero(true);
    var0.setPositiveArrowVisible(true);
    var0.setTickLabelsVisible(false);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
    double var12 = var11.getAnchorValue();
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var11.getRangeMarkers(var13);
    org.jfree.chart.axis.CategoryAnchor var15 = var11.getDomainGridlinePosition();
    var11.setRangeCrosshairValue(6.0d, true);
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    boolean var20 = var11.isSubplot();
    java.awt.Paint var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setRangeCrosshairPaint(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test237"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
    boolean var9 = var5.equals((java.lang.Object)var6);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var5.setArea(var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var21 = null;
    java.util.List var22 = var18.getCategoriesForAxis(var21);
    double var23 = var18.getAnchorValue();
    java.awt.Color var26 = java.awt.Color.getColor("", 1);
    var18.setOutlinePaint((java.awt.Paint)var26);
    java.awt.Stroke var28 = var18.getDomainGridlineStroke();
    java.awt.Color var31 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var32 = var31.getColorSpace();
    java.awt.image.ColorModel var33 = null;
    java.awt.Rectangle var34 = null;
    org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("hi!");
    var36.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var42 = var36.getBounds();
    java.awt.geom.AffineTransform var43 = null;
    java.awt.RenderingHints var44 = null;
    java.awt.PaintContext var45 = var31.createContext(var33, var34, var42, var43, var44);
    var18.setNoDataMessagePaint((java.awt.Paint)var31);
    org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic(var12, (java.awt.Paint)var31);
    java.awt.Shape var48 = var47.getShape();
    double var49 = var47.getContentXOffset();
    org.jfree.chart.util.RectangleAnchor var50 = var47.getShapeLocation();
    boolean var51 = var47.isShapeOutlineVisible();
    java.awt.Shape var52 = var47.getShape();
    java.awt.Shape var53 = var47.getShape();
    var47.setShapeFilled(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test238"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.Object var1 = var0.clone();
    var0.setFixedDimension(10.0d);
    double var4 = var0.getUpperMargin();
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("hi!");
    var10.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var16 = var10.getBounds();
    org.jfree.chart.util.RectangleAnchor var17 = null;
    java.awt.geom.Point2D var18 = org.jfree.chart.util.RectangleAnchor.coordinates(var16, var17);
    var7.setShape(0, (java.awt.Shape)var16);
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var21 = var20.getInsets();
    org.jfree.chart.util.UnitType var22 = var21.getUnitType();
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
    double var28 = var27.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var29 = var27.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var30 = null;
    java.util.List var31 = var27.getCategoriesForAxis(var30);
    double var32 = var27.getAnchorValue();
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
    boolean var34 = var22.equals((java.lang.Object)var27);
    org.jfree.chart.util.RectangleEdge var36 = var27.getDomainAxisEdge(10);
    java.lang.String var37 = var36.toString();
    double var38 = var0.getCategoryMiddle((-589829), 1, var16, var36);
    float var39 = var0.getTickMarkInsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "RectangleEdge.TOP"+ "'", var37.equals("RectangleEdge.TOP"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0f);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test239"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    double var6 = var5.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var8 = null;
    java.util.List var9 = var5.getCategoriesForAxis(var8);
    org.jfree.chart.event.RendererChangeEvent var10 = null;
    var5.rendererChanged(var10);
    org.jfree.chart.axis.CategoryAxis var12 = null;
    int var13 = var5.getDomainAxisIndex(var12);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", (org.jfree.chart.plot.Plot)var5);
    float var15 = var5.getBackgroundImageAlpha();
    int var16 = var5.getRangeAxisCount();
    var5.configureRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test240"); }


    org.jfree.chart.plot.DefaultDrawingSupplier var0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Stroke var1 = var0.getNextOutlineStroke();
    java.awt.Paint var2 = var0.getNextFillPaint();
    java.awt.Paint var3 = var0.getNextOutlinePaint();
    java.lang.Object var4 = var0.clone();
    java.awt.Paint var5 = var0.getNextPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test241"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.TickUnitSource var2 = var0.getStandardTickUnits();
    var0.setAutoRangeStickyZero(false);
    double var5 = var0.getLowerBound();
    java.awt.Paint var6 = var0.getLabelPaint();
    java.lang.Object var7 = var0.clone();
    var0.setFixedAutoRange((-2.0d));
    java.awt.Stroke var10 = var0.getTickMarkStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test242"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.util.List var1 = var0.getLines();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.util.Size2D var3 = var0.calculateDimensions(var2);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.text.TextBlock var8 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.text.TextBlockAnchor var9 = null;
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
    double var15 = var14.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var16 = var14.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    int var18 = var14.getIndexOf(var17);
    java.util.List var19 = var14.getCategories();
    var14.configureDomainAxes();
    org.jfree.chart.plot.ValueMarker var22 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var22.setAlpha(0.0f);
    java.awt.Stroke var25 = var22.getOutlineStroke();
    var14.addRangeMarker((org.jfree.chart.plot.Marker)var22);
    org.jfree.chart.text.TextAnchor var27 = var22.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var29 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)10.0f, var8, var9, var27, 6.0d);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("");
    double var36 = var35.getHeight();
    java.awt.Paint var37 = var35.getPaint();
    java.awt.Font var38 = var35.getFont();
    var33.setLabelFont(var38);
    var33.setUpperMargin(100.0d);
    org.jfree.chart.axis.CategoryLabelPositions var43 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0d);
    var33.setCategoryLabelPositions(var43);
    org.jfree.data.category.CategoryDataset var46 = null;
    org.jfree.chart.axis.CategoryAxis var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var46, var47, var48, var49);
    double var51 = var50.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var52 = var50.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var53 = null;
    java.util.List var54 = var50.getCategoriesForAxis(var53);
    double var55 = var50.getAnchorValue();
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50);
    java.awt.Paint var57 = var56.getBackgroundPaint();
    java.awt.Font var58 = var56.getItemFont();
    org.jfree.chart.title.TextTitle var59 = new org.jfree.chart.title.TextTitle("hi!", var58);
    org.jfree.chart.util.RectangleEdge var60 = var59.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var61 = var43.getLabelPosition(var60);
    double var62 = var61.getAngle();
    org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var68 = new org.jfree.chart.block.LabelBlock("hi!");
    var68.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var74 = var68.getBounds();
    org.jfree.chart.util.RectangleAnchor var75 = null;
    java.awt.geom.Point2D var76 = org.jfree.chart.util.RectangleAnchor.coordinates(var74, var75);
    org.jfree.chart.util.RectangleEdge var77 = null;
    double var78 = var64.getCategoryStart((-16777216), (-16777216), var74, var77);
    org.jfree.chart.entity.CategoryLabelEntity var81 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var74, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
    java.lang.String var82 = var81.toString();
    java.awt.Shape var83 = var81.getArea();
    org.jfree.chart.event.ChartChangeEvent var84 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var83);
    boolean var85 = var61.equals((java.lang.Object)var83);
    org.jfree.chart.text.TextBlockAnchor var86 = var61.getLabelAnchor();
    var8.draw(var30, 10.0f, 0.0f, var86);
    var0.draw(var4, 0.0f, (-1.0f), var86);
    java.lang.String var89 = var86.toString();
    java.lang.String var90 = var86.toString();
    java.lang.String var91 = var86.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var82 + "' != '" + "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="+ "'", var82.equals("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var89 + "' != '" + "TextBlockAnchor.BOTTOM_LEFT"+ "'", var89.equals("TextBlockAnchor.BOTTOM_LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var90 + "' != '" + "TextBlockAnchor.BOTTOM_LEFT"+ "'", var90.equals("TextBlockAnchor.BOTTOM_LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var91 + "' != '" + "TextBlockAnchor.BOTTOM_LEFT"+ "'", var91.equals("TextBlockAnchor.BOTTOM_LEFT"));

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test243"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.title.LegendTitle var13 = var11.getLegend(10);
    org.jfree.chart.util.RectangleInsets var14 = var11.getPadding();
    org.jfree.chart.event.ChartProgressListener var15 = null;
    var11.removeProgressListener(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test244"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     var2.setBaseSeriesVisibleInLegend(true, false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var7 = var6.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var8 = var6.getLegendItemToolTipGenerator();
//     java.awt.Shape var10 = var6.lookupSeriesShape(0);
//     org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition();
//     var6.setPositiveItemLabelPositionFallback(var11);
//     org.jfree.chart.labels.CategoryToolTipGenerator var14 = null;
//     var6.setSeriesToolTipGenerator(0, var14, false);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     double var22 = var21.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var23 = var21.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     java.util.List var25 = var21.getCategoriesForAxis(var24);
//     double var26 = var21.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21);
//     java.awt.Paint var28 = var27.getBackgroundPaint();
//     java.awt.Font var29 = var27.getItemFont();
//     var6.setBaseItemLabelFont(var29, false);
//     org.jfree.chart.labels.ItemLabelPosition var32 = var6.getPositiveItemLabelPositionFallback();
//     var2.setPositiveItemLabelPositionFallback(var32);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var36 = var2.getItemLabelGenerator((-253), (-165));
//     boolean var37 = var0.equals((java.lang.Object)var2);
//     java.lang.Object var38 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var38
//     assertTrue("Contract failed: equals-hashcode on var1 and var38", var1.equals(var38) ? var1.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var1
//     assertTrue("Contract failed: equals-hashcode on var38 and var1", var38.equals(var1) ? var38.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test245"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    double var6 = var5.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var9 = null;
    int var10 = var5.getDomainAxisIndex(var9);
    org.jfree.chart.axis.AxisSpace var11 = null;
    var5.setFixedRangeAxisSpace(var11);
    org.jfree.chart.event.AxisChangeEvent var13 = null;
    var5.axisChanged(var13);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("Range[0.0,0.0]", (org.jfree.chart.plot.Plot)var5);
    int var16 = var15.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 15);

  }

//  public void test246() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest9.test246"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleConstraintType.RANGE", var1);
//
//  }
//
  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test247"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    org.jfree.chart.util.UnitType var2 = var1.getUnitType();
    java.awt.Color var5 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var6 = var5.getColorSpace();
    java.awt.image.ColorModel var7 = null;
    java.awt.Rectangle var8 = null;
    org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("hi!");
    var10.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var16 = var10.getBounds();
    java.awt.geom.AffineTransform var17 = null;
    java.awt.RenderingHints var18 = null;
    java.awt.PaintContext var19 = var5.createContext(var7, var8, var16, var17, var18);
    var1.trim(var16);
    double var22 = var1.calculateTopOutset(4.0d);
    double var24 = var1.calculateTopOutset(18.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test248"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainMarkers();
    var4.mapDatasetToRangeAxis(1, (-253));
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    double var15 = var14.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var16 = var14.getTickUnit();
    org.jfree.data.Range var17 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var14);
    boolean var18 = var14.isAutoRange();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
    java.lang.String var23 = var22.getID();
    int var24 = var20.compareTo((java.lang.Object)var22);
    java.lang.String var26 = var20.valueToString(1.0d);
    var14.setTickUnit(var20, false, false);
    org.jfree.chart.axis.TickUnitSource var30 = var14.getStandardTickUnits();
    java.awt.Shape var31 = var14.getLeftArrow();
    var14.setAutoRangeMinimumSize(0.2d);
    org.jfree.chart.plot.Plot var34 = var14.getPlot();
    java.awt.Paint var35 = var14.getTickMarkPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "1"+ "'", var26.equals("1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test249"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(0, var8);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = var0.getBaseToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.urls.CategoryURLGenerator var13 = null;
    var0.setBaseURLGenerator(var13);
    double var15 = var0.getUpperClip();
    java.awt.Stroke var17 = var0.getSeriesStroke((-127));
    java.awt.Stroke var19 = var0.lookupSeriesOutlineStroke((-16777216));
    java.awt.Stroke var21 = var0.getSeriesStroke(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test250"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 100.0d);
    org.jfree.chart.block.RectangleConstraint var6 = var2.toRangeHeight(var5);
    org.jfree.chart.block.LengthConstraintType var7 = var2.getWidthConstraintType();
    java.lang.String var8 = var7.toString();
    java.lang.String var9 = var7.toString();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
    double var15 = var14.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var16 = var14.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var17 = null;
    java.util.List var18 = var14.getCategoriesForAxis(var17);
    double var19 = var14.getAnchorValue();
    var14.clearDomainMarkers();
    java.awt.Paint var21 = var14.getRangeGridlinePaint();
    org.jfree.chart.axis.AxisSpace var22 = new org.jfree.chart.axis.AxisSpace();
    var14.setFixedDomainAxisSpace(var22);
    var14.clearRangeAxes();
    boolean var25 = var7.equals((java.lang.Object)var14);
    var14.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var8.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var9.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test251"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    java.awt.Stroke var14 = var4.getDomainGridlineStroke();
    java.awt.Color var17 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var18 = var17.getColorSpace();
    java.awt.image.ColorModel var19 = null;
    java.awt.Rectangle var20 = null;
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
    var22.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var28 = var22.getBounds();
    java.awt.geom.AffineTransform var29 = null;
    java.awt.RenderingHints var30 = null;
    java.awt.PaintContext var31 = var17.createContext(var19, var20, var28, var29, var30);
    var4.setNoDataMessagePaint((java.awt.Paint)var17);
    var4.setNoDataMessage("");
    int var35 = var4.getDomainAxisCount();
    org.jfree.chart.util.RectangleInsets var36 = var4.getAxisOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test252"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var3 = var2.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var4 = var2.getLegendItemToolTipGenerator();
    java.awt.Shape var6 = var2.lookupSeriesShape(0);
    org.jfree.chart.labels.ItemLabelPosition var7 = new org.jfree.chart.labels.ItemLabelPosition();
    var2.setPositiveItemLabelPositionFallback(var7);
    org.jfree.chart.text.TextAnchor var9 = var7.getTextAnchor();
    java.lang.String var10 = var9.toString();
    org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var12.setAlpha(0.0f);
    org.jfree.chart.util.LengthAdjustmentType var15 = var12.getLabelOffsetType();
    org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.text.TextAnchor var18 = var17.getLabelTextAnchor();
    var12.setLabelTextAnchor(var18);
    org.jfree.chart.axis.NumberTick var21 = new org.jfree.chart.axis.NumberTick((java.lang.Number)0.5d, "TextAnchor.CENTER", var9, var18, 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "TextAnchor.BOTTOM_CENTER"+ "'", var10.equals("TextAnchor.BOTTOM_CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test253"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    double var6 = var5.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var8 = null;
    java.util.List var9 = var5.getCategoriesForAxis(var8);
    double var10 = var5.getAnchorValue();
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    java.awt.Paint var12 = var11.getBackgroundPaint();
    java.awt.Font var13 = var11.getItemFont();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
    java.lang.Object var15 = var14.clone();
    java.awt.Paint var16 = var14.getBackgroundPaint();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var18 = var17.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var19 = var17.getLegendItemToolTipGenerator();
    java.awt.Shape var21 = var17.lookupSeriesShape(0);
    var17.setAutoPopulateSeriesFillPaint(true);
    var17.setAutoPopulateSeriesStroke(true);
    var17.setBaseItemLabelsVisible(false, false);
    java.lang.Boolean var30 = var17.getSeriesCreateEntities((-253));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var32 = var31.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var33 = var31.getLegendItemToolTipGenerator();
    java.awt.Shape var35 = var31.lookupSeriesShape(0);
    var31.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var39 = null;
    var31.setSeriesURLGenerator(0, var39);
    var31.setItemMargin(6.0d);
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
    double var45 = var44.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var46 = var44.getTickUnit();
    var44.zoomRange(0.0d, 0.0d);
    var44.setInverted(true);
    java.awt.Stroke var52 = var44.getAxisLineStroke();
    var31.setSeriesOutlineStroke(0, var52);
    var17.setBaseOutlineStroke(var52, false);
    boolean var56 = var14.equals((java.lang.Object)var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test254"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    double var6 = var5.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var8 = null;
    java.util.List var9 = var5.getCategoriesForAxis(var8);
    double var10 = var5.getAnchorValue();
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    java.awt.Paint var12 = var11.getBackgroundPaint();
    java.awt.Font var13 = var11.getItemFont();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
    java.awt.Graphics2D var15 = null;
    java.awt.Color var18 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var19 = var18.getColorSpace();
    java.awt.image.ColorModel var20 = null;
    java.awt.Rectangle var21 = null;
    org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("hi!");
    var23.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var29 = var23.getBounds();
    java.awt.geom.AffineTransform var30 = null;
    java.awt.RenderingHints var31 = null;
    java.awt.PaintContext var32 = var18.createContext(var20, var21, var29, var30, var31);
    var14.draw(var15, var29);
    org.jfree.chart.block.BlockFrame var34 = var14.getFrame();
    java.lang.String var35 = var14.getText();
    var14.setURLText("");
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var43 = new org.jfree.chart.entity.TickLabelEntity(var40, "hi!", "hi!");
    org.jfree.chart.entity.ChartEntity var44 = new org.jfree.chart.entity.ChartEntity(var40);
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    boolean var48 = org.jfree.chart.util.ShapeUtilities.equal(var40, var47);
    org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker((-1.0d));
    org.jfree.chart.util.LengthAdjustmentType var51 = var50.getLabelOffsetType();
    java.awt.Paint var52 = var50.getOutlinePaint();
    org.jfree.chart.title.LegendGraphic var53 = new org.jfree.chart.title.LegendGraphic(var47, var52);
    var14.setPaint(var52);
    java.lang.Object var55 = var14.clone();
    java.awt.Color var58 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
    var14.setBackgroundPaint((java.awt.Paint)var58);
    java.lang.String var60 = var14.getText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "hi!"+ "'", var35.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + "hi!"+ "'", var60.equals("hi!"));

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test255"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    var0.setAutoPopulateSeriesFillPaint(false);
    boolean var8 = var0.isSeriesVisibleInLegend(1);
    int var9 = var0.getPassCount();
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var15 = new org.jfree.chart.entity.TickLabelEntity(var12, "hi!", "hi!");
    org.jfree.data.Range var16 = null;
    org.jfree.data.Range var17 = null;
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(var16, var17);
    boolean var19 = var15.equals((java.lang.Object)var16);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var15.setArea(var22);
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    double var29 = var28.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var30 = var28.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var31 = null;
    java.util.List var32 = var28.getCategoriesForAxis(var31);
    double var33 = var28.getAnchorValue();
    java.awt.Color var36 = java.awt.Color.getColor("", 1);
    var28.setOutlinePaint((java.awt.Paint)var36);
    java.awt.Stroke var38 = var28.getDomainGridlineStroke();
    java.awt.Color var41 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var42 = var41.getColorSpace();
    java.awt.image.ColorModel var43 = null;
    java.awt.Rectangle var44 = null;
    org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("hi!");
    var46.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var52 = var46.getBounds();
    java.awt.geom.AffineTransform var53 = null;
    java.awt.RenderingHints var54 = null;
    java.awt.PaintContext var55 = var41.createContext(var43, var44, var52, var53, var54);
    var28.setNoDataMessagePaint((java.awt.Paint)var41);
    org.jfree.chart.title.LegendGraphic var57 = new org.jfree.chart.title.LegendGraphic(var22, (java.awt.Paint)var41);
    org.jfree.chart.util.RectangleAnchor var58 = var57.getShapeAnchor();
    org.jfree.chart.util.RectangleAnchor var59 = var57.getShapeLocation();
    java.awt.Paint var60 = var57.getFillPaint();
    var0.setBaseOutlinePaint(var60);
    org.jfree.data.category.CategoryDataset var62 = null;
    org.jfree.chart.axis.CategoryAxis var63 = null;
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var62, var63, var64, var65);
    double var67 = var66.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var68 = var66.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var69 = null;
    int var70 = var66.getIndexOf(var69);
    boolean var71 = var0.hasListener((java.util.EventListener)var66);
    var66.mapDatasetToRangeAxis(100, (-253));
    org.jfree.chart.axis.CategoryAxis var76 = var66.getDomainAxisForDataset(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test256"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.util.RectangleInsets var11 = var4.getInsets();
//     org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var13 = var12.clone();
//     var12.setLeft(4.0d);
//     org.jfree.chart.block.LineBorder var16 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("hi!");
//     var19.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var25 = var19.getBounds();
//     org.jfree.chart.util.RectangleAnchor var26 = null;
//     java.awt.geom.Point2D var27 = org.jfree.chart.util.RectangleAnchor.coordinates(var25, var26);
//     var16.draw(var17, var25);
//     org.jfree.chart.util.RectangleEdge var29 = null;
//     java.awt.geom.Rectangle2D var30 = var12.reserved(var25, var29);
//     var4.setFixedDomainAxisSpace(var12);
//     org.jfree.data.category.CategoryDataset var33 = null;
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var33, var34, var35, var36);
//     double var38 = var37.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var39 = var37.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     java.util.List var41 = var37.getCategoriesForAxis(var40);
//     double var42 = var37.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37);
//     java.awt.Paint var44 = var43.getBackgroundPaint();
//     double var45 = var43.getWidth();
//     org.jfree.chart.util.RectangleInsets var46 = var43.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleEdge var47 = var43.getLegendItemGraphicEdge();
//     boolean var48 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var47);
//     var12.ensureAtLeast(7.0d, var47);
//     
//     // Checks the contract:  equals-hashcode on var6 and var39
//     assertTrue("Contract failed: equals-hashcode on var6 and var39", var6.equals(var39) ? var6.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var6
//     assertTrue("Contract failed: equals-hashcode on var39 and var6", var39.equals(var6) ? var39.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test257"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "hi!");
    org.jfree.chart.block.LabelBlock var6 = new org.jfree.chart.block.LabelBlock("");
    double var7 = var6.getHeight();
    java.awt.Paint var8 = var6.getPaint();
    org.jfree.chart.title.LegendGraphic var9 = new org.jfree.chart.title.LegendGraphic(var2, var8);
    java.awt.Stroke var10 = var9.getLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test258"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("SortOrder.ASCENDING", "Range[100.0,100.0]", "VerticalAlignment.CENTER", "PlotOrientation.VERTICAL", "RectangleConstraintType.RANGE");
    org.jfree.chart.ui.Library[] var6 = var5.getLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test259"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.HorizontalAlignment var11 = var10.getHorizontalAlignment();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var13 = var12.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var12.getLegendItemToolTipGenerator();
    java.awt.Shape var16 = var12.lookupSeriesShape(0);
    var12.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var20 = null;
    var12.setSeriesURLGenerator(0, var20);
    var12.setItemMargin(6.0d);
    boolean var24 = var11.equals((java.lang.Object)var12);
    java.awt.Paint var26 = var12.lookupSeriesPaint(15);
    org.jfree.chart.labels.CategoryToolTipGenerator var27 = null;
    var12.setBaseToolTipGenerator(var27);
    java.awt.Paint var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setBaseOutlinePaint(var29, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test260"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     org.jfree.chart.plot.CategoryPlot var13 = var11.getCategoryPlot();
//     var13.configureDomainAxes();
//     int var15 = var13.getWeight();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     var16.setNegativeArrowVisible(false);
//     org.jfree.chart.axis.MarkerAxisBand var19 = var16.getMarkerBand();
//     org.jfree.data.Range var20 = var13.getDataRange((org.jfree.chart.axis.ValueAxis)var16);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     var21.setNegativeArrowVisible(false);
//     var21.setInverted(true);
//     boolean var26 = var21.isAxisLineVisible();
//     boolean var27 = var21.isTickMarksVisible();
//     var21.resizeRange((-2.0d));
//     org.jfree.data.RangeType var30 = var21.getRangeType();
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
//     double var36 = var35.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var37 = var35.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     java.util.List var39 = var35.getCategoriesForAxis(var38);
//     double var40 = var35.getAnchorValue();
//     var35.clearDomainMarkers();
//     var35.mapDatasetToRangeAxis(1, (-253));
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
//     double var46 = var45.getLowerMargin();
//     org.jfree.chart.axis.NumberTickUnit var47 = var45.getTickUnit();
//     org.jfree.data.Range var48 = var35.getDataRange((org.jfree.chart.axis.ValueAxis)var45);
//     boolean var49 = var45.isAutoRange();
//     var45.setRangeAboutValue(2.0d, Double.NaN);
//     double var53 = var45.getLowerMargin();
//     boolean var54 = var30.equals((java.lang.Object)var45);
//     java.lang.String var55 = var30.toString();
//     var16.setRangeType(var30);
//     
//     // Checks the contract:  equals-hashcode on var4 and var35
//     assertTrue("Contract failed: equals-hashcode on var4 and var35", var4.equals(var35) ? var4.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var35
//     assertTrue("Contract failed: equals-hashcode on var13 and var35", var13.equals(var35) ? var13.hashCode() == var35.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var35.", var4.equals(var35) == var35.equals(var4));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var35.", var13.equals(var35) == var35.equals(var13));
//     
//     // Checks the contract:  equals-hashcode on var6 and var37
//     assertTrue("Contract failed: equals-hashcode on var6 and var37", var6.equals(var37) ? var6.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var6
//     assertTrue("Contract failed: equals-hashcode on var37 and var6", var37.equals(var6) ? var37.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test261"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
//     double var5 = var4.getLeft();
//     double var6 = var4.getLeft();
//     double var8 = var4.calculateRightInset(0.0d);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("");
//     double var13 = var12.getHeight();
//     java.awt.Paint var14 = var12.getPaint();
//     java.awt.Font var15 = var12.getFont();
//     var10.setLabelFont(var15);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("org.jfree.data.general.DatasetChangeEvent[source=-1]", var15);
//     java.awt.Paint var18 = var17.getPaint();
//     org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder(var4, var18);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("");
//     double var23 = var22.getHeight();
//     java.awt.Paint var24 = var22.getPaint();
//     java.awt.Font var25 = var22.getFont();
//     var20.setLabelFont(var25);
//     float var27 = var20.getMaximumCategoryLabelWidthRatio();
//     org.jfree.chart.event.AxisChangeEvent var28 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var20);
//     boolean var29 = var19.equals((java.lang.Object)var20);
//     
//     // Checks the contract:  equals-hashcode on var12 and var22
//     assertTrue("Contract failed: equals-hashcode on var12 and var22", var12.equals(var22) ? var12.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var12
//     assertTrue("Contract failed: equals-hashcode on var22 and var12", var22.equals(var12) ? var22.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test262"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(0, var8);
    org.jfree.chart.event.RendererChangeEvent var10 = null;
    var0.notifyListeners(var10);
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getSeriesNegativeItemLabelPosition(10);
    double var14 = var0.getItemLabelAnchorOffset();
    org.jfree.chart.annotations.CategoryAnnotation var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test263"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextBlockAnchor var1 = var0.getLabelAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test264"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.MarkerAxisBand var1 = null;
//     var0.setMarkerBand(var1);
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("hi!");
//     var7.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var13 = var7.getBounds();
//     org.jfree.chart.util.RectangleAnchor var14 = null;
//     java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var13, var14);
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var3.getCategoryStart((-16777216), (-16777216), var13, var16);
//     var3.setMaximumCategoryLabelLines(10);
//     float var20 = var3.getMaximumCategoryLabelWidthRatio();
//     java.lang.String var21 = var3.getLabel();
//     java.awt.Font var22 = var3.getLabelFont();
//     var0.setLabelFont(var22);
//     boolean var24 = var0.getAutoRangeIncludesZero();
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var34 = new org.jfree.chart.entity.TickLabelEntity(var31, "hi!", "hi!");
//     org.jfree.chart.entity.ChartEntity var35 = new org.jfree.chart.entity.ChartEntity(var31);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var31, var38);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var41 = var40.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var42 = var40.getLegendItemToolTipGenerator();
//     java.awt.Shape var44 = var40.lookupSeriesShape(0);
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.axis.CategoryAxis var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var45, var46, var47, var48);
//     double var50 = var49.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var51 = var49.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var52 = null;
//     java.util.List var53 = var49.getCategoriesForAxis(var52);
//     double var54 = var49.getAnchorValue();
//     var49.clearDomainAxes();
//     org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var49);
//     org.jfree.chart.title.LegendTitle var58 = var56.getLegend(10);
//     java.awt.Stroke var59 = var56.getBorderStroke();
//     var40.setBaseStroke(var59);
//     boolean var63 = var40.isItemLabelVisible(0, (-165));
//     java.awt.Stroke var66 = var40.getItemOutlineStroke(15, (-16777215));
//     java.awt.Paint var67 = null;
//     org.jfree.chart.LegendItem var68 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=0]", "RectangleConstraintType.RANGE", "[size=1]", "VerticalAlignment.CENTER", var31, var66, var67);
//     java.awt.Stroke var69 = var68.getLineStroke();
//     java.awt.Shape var70 = var68.getShape();
//     var0.setLeftArrow(var70);
//     var0.setVerticalTickLabels(true);
//     org.jfree.data.category.CategoryDataset var74 = null;
//     org.jfree.chart.axis.CategoryAxis var75 = null;
//     org.jfree.chart.axis.ValueAxis var76 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var77 = null;
//     org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot(var74, var75, var76, var77);
//     double var79 = var78.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var80 = var78.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var81 = var78.getRowRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var82 = null;
//     int var83 = var78.getDomainAxisIndex(var82);
//     org.jfree.chart.axis.AxisSpace var84 = null;
//     var78.setFixedRangeAxisSpace(var84);
//     org.jfree.chart.event.AxisChangeEvent var86 = null;
//     var78.axisChanged(var86);
//     boolean var88 = var78.isRangeCrosshairLockedOnData();
//     var78.setAnchorValue(1.0d, false);
//     int var92 = var78.getRangeAxisCount();
//     boolean var93 = var0.hasListener((java.util.EventListener)var78);
//     
//     // Checks the contract:  equals-hashcode on var51 and var80
//     assertTrue("Contract failed: equals-hashcode on var51 and var80", var51.equals(var80) ? var51.hashCode() == var80.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var80 and var51
//     assertTrue("Contract failed: equals-hashcode on var80 and var51", var80.equals(var51) ? var80.hashCode() == var51.hashCode() : true);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test265"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var0.setBaseSeriesVisibleInLegend(true, false);
    var0.setBaseItemLabelsVisible(true);
    boolean var6 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.ItemLabelPosition var9 = var0.getNegativeItemLabelPosition((-1), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test266"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    int var2 = var0.getWeight();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var5 = var4.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var4.getLegendItemToolTipGenerator();
    java.awt.Shape var8 = var4.lookupSeriesShape(0);
    org.jfree.chart.labels.ItemLabelPosition var9 = new org.jfree.chart.labels.ItemLabelPosition();
    var4.setPositiveItemLabelPositionFallback(var9);
    org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("");
    double var14 = var13.getHeight();
    java.awt.Paint var15 = var13.getPaint();
    java.awt.Font var16 = var13.getFont();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("hi!", var16);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
    double var23 = var22.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var24 = var22.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var25 = null;
    java.util.List var26 = var22.getCategoriesForAxis(var25);
    double var27 = var22.getAnchorValue();
    var22.clearDomainAxes();
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
    java.awt.RenderingHints var30 = var29.getRenderingHints();
    java.awt.Stroke var31 = var29.getBorderStroke();
    var29.setBorderVisible(false);
    org.jfree.chart.util.RectangleInsets var34 = var29.getPadding();
    boolean var35 = var17.equals((java.lang.Object)var29);
    var29.setAntiAlias(true);
    org.jfree.chart.event.ChartProgressEvent var40 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var29, 0, (-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-6553600), (org.jfree.chart.renderer.category.CategoryItemRenderer)var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test267"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Point2D var17 = null;
    var4.zoomRangeAxes((-1.0d), 1.0d, var16, var17);
    var4.clearDomainMarkers(10);
    org.jfree.chart.event.PlotChangeListener var21 = null;
    var4.addChangeListener(var21);
    org.jfree.chart.axis.AxisLocation var24 = var4.getRangeAxisLocation((-253));
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var25 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var26 = var25.getColumnCount();
    org.jfree.data.Range var28 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var25, 10.0d);
    java.lang.Number var31 = var25.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
    java.lang.Number var34 = var25.getStdDevValue((java.lang.Comparable)(short)100, (java.lang.Comparable)'#');
    org.jfree.data.general.DatasetChangeEvent var35 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(-253), (org.jfree.data.general.Dataset)var25);
    org.jfree.data.Range var37 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var25, false);
    int var38 = var25.getRowCount();
    java.lang.Number var39 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var25);
    int var41 = var25.getRowIndex((java.lang.Comparable)"Range[0.0,0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + 0.0d+ "'", var39.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-1));

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test268"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    boolean var5 = var0.getBaseCreateEntities();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var7 = var6.getGroup();
    boolean var8 = var0.equals((java.lang.Object)var7);
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("hi!");
    var14.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var20 = var14.getBounds();
    org.jfree.chart.util.RectangleAnchor var21 = null;
    java.awt.geom.Point2D var22 = org.jfree.chart.util.RectangleAnchor.coordinates(var20, var21);
    org.jfree.chart.util.RectangleEdge var23 = null;
    double var24 = var10.getCategoryStart((-16777216), (-16777216), var20, var23);
    org.jfree.chart.entity.CategoryLabelEntity var27 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var20, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
    java.lang.String var28 = var27.toString();
    boolean var29 = var7.equals((java.lang.Object)var28);
    org.jfree.chart.util.RectangleInsets var34 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var35 = var34.getLeft();
    double var37 = var34.calculateLeftInset(0.0d);
    boolean var38 = var7.equals((java.lang.Object)var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="+ "'", var28.equals("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test269"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var4 = var3.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var3.getLegendItemToolTipGenerator();
    java.awt.Shape var7 = var3.lookupSeriesShape(0);
    int var8 = var3.getRowCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = var3.getSeriesToolTipGenerator(1);
    var3.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var15 = var3.getNegativeItemLabelPosition(0, (-16777216));
    var0.setBaseNegativeItemLabelPosition(var15);
    var0.setAutoPopulateSeriesPaint(false);
    var0.setAutoPopulateSeriesOutlineStroke(false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var22 = var21.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var23 = var21.getLegendItemToolTipGenerator();
    java.awt.Shape var25 = var21.lookupSeriesShape(0);
    int var26 = var21.getRowCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var28 = var21.getSeriesToolTipGenerator(1);
    var21.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Paint var32 = var21.lookupSeriesFillPaint(0);
    var21.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var35 = var21.getLegendItemLabelGenerator();
    var0.setLegendItemURLGenerator(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test270"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var1.setAlpha(0.0f);
    java.awt.Paint var4 = var1.getOutlinePaint();
    java.awt.Paint var5 = var1.getPaint();
    org.jfree.chart.util.RectangleAnchor var6 = var1.getLabelAnchor();
    org.jfree.chart.text.TextBlock var7 = new org.jfree.chart.text.TextBlock();
    java.util.List var8 = var7.getLines();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.util.Size2D var10 = var7.calculateDimensions(var9);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.text.TextBlock var15 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
    double var22 = var21.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var23 = var21.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    int var25 = var21.getIndexOf(var24);
    java.util.List var26 = var21.getCategories();
    var21.configureDomainAxes();
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var29.setAlpha(0.0f);
    java.awt.Stroke var32 = var29.getOutlineStroke();
    var21.addRangeMarker((org.jfree.chart.plot.Marker)var29);
    org.jfree.chart.text.TextAnchor var34 = var29.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var36 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)10.0f, var15, var16, var34, 6.0d);
    java.awt.Graphics2D var37 = null;
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var42 = new org.jfree.chart.block.LabelBlock("");
    double var43 = var42.getHeight();
    java.awt.Paint var44 = var42.getPaint();
    java.awt.Font var45 = var42.getFont();
    var40.setLabelFont(var45);
    var40.setUpperMargin(100.0d);
    org.jfree.chart.axis.CategoryLabelPositions var50 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0d);
    var40.setCategoryLabelPositions(var50);
    org.jfree.data.category.CategoryDataset var53 = null;
    org.jfree.chart.axis.CategoryAxis var54 = null;
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var56 = null;
    org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot(var53, var54, var55, var56);
    double var58 = var57.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var59 = var57.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var60 = null;
    java.util.List var61 = var57.getCategoriesForAxis(var60);
    double var62 = var57.getAnchorValue();
    org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var57);
    java.awt.Paint var64 = var63.getBackgroundPaint();
    java.awt.Font var65 = var63.getItemFont();
    org.jfree.chart.title.TextTitle var66 = new org.jfree.chart.title.TextTitle("hi!", var65);
    org.jfree.chart.util.RectangleEdge var67 = var66.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var68 = var50.getLabelPosition(var67);
    double var69 = var68.getAngle();
    org.jfree.chart.axis.CategoryAxis var71 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var75 = new org.jfree.chart.block.LabelBlock("hi!");
    var75.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var81 = var75.getBounds();
    org.jfree.chart.util.RectangleAnchor var82 = null;
    java.awt.geom.Point2D var83 = org.jfree.chart.util.RectangleAnchor.coordinates(var81, var82);
    org.jfree.chart.util.RectangleEdge var84 = null;
    double var85 = var71.getCategoryStart((-16777216), (-16777216), var81, var84);
    org.jfree.chart.entity.CategoryLabelEntity var88 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var81, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
    java.lang.String var89 = var88.toString();
    java.awt.Shape var90 = var88.getArea();
    org.jfree.chart.event.ChartChangeEvent var91 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var90);
    boolean var92 = var68.equals((java.lang.Object)var90);
    org.jfree.chart.text.TextBlockAnchor var93 = var68.getLabelAnchor();
    var15.draw(var37, 10.0f, 0.0f, var93);
    var7.draw(var11, 0.0f, (-1.0f), var93);
    java.lang.String var96 = var93.toString();
    org.jfree.chart.axis.CategoryLabelWidthType var97 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var99 = new org.jfree.chart.axis.CategoryLabelPosition(var6, var93, var97, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var89 + "' != '" + "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="+ "'", var89.equals("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var96 + "' != '" + "TextBlockAnchor.BOTTOM_LEFT"+ "'", var96.equals("TextBlockAnchor.BOTTOM_LEFT"));

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test271"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var11 = var10.getBackgroundPaint();
    java.awt.Font var12 = var10.getItemFont();
    double var13 = var10.getContentXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test272"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainMarkers();
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("");
    double var13 = var12.getHeight();
    java.awt.Paint var14 = var12.getPaint();
    var4.setRangeCrosshairPaint(var14);
    int var16 = var4.getDomainAxisCount();
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.block.LineBorder var18 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var19 = var18.getInsets();
    var17.setPadding(var19);
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var22 = null;
    org.jfree.chart.title.LegendItemBlockContainer var24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var21, var22, (java.lang.Comparable)1L);
    java.lang.Object var25 = var24.clone();
    var17.setWrapper((org.jfree.chart.block.BlockContainer)var24);
    java.awt.Font var27 = var17.getItemFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test273"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(2.05d);
    org.jfree.chart.block.LabelBlock var3 = new org.jfree.chart.block.LabelBlock("hi!");
    var3.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var9 = var3.getBounds();
    boolean var10 = var1.equals((java.lang.Object)var3);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    double var16 = var15.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var18 = null;
    java.util.List var19 = var15.getCategoriesForAxis(var18);
    double var20 = var15.getAnchorValue();
    java.awt.Color var23 = java.awt.Color.getColor("", 1);
    var15.setOutlinePaint((java.awt.Paint)var23);
    java.awt.Paint var25 = var15.getRangeCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var26 = null;
    var15.axisChanged(var26);
    boolean var28 = var3.equals((java.lang.Object)var26);
    java.awt.geom.Rectangle2D var29 = var3.getBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test274"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("LegendItemEntity: seriesKey=#, dataset=null", "RangeType.FULL", "Size2D[width=-1.0, height=0.0]", "Range[0.0,0.0]");

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test275"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getColumnIndex((java.lang.Comparable)"100");
    java.util.List var3 = var0.getColumnKeys();
    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getPlotArea();
    org.jfree.chart.ChartRenderingInfo var7 = var5.getOwner();
    org.jfree.chart.renderer.category.CategoryItemRendererState var8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var5);
    org.jfree.chart.plot.PlotRenderingInfo var9 = var8.getInfo();
    var0.addObject((java.lang.Object)var9, (java.lang.Comparable)100.0d, (java.lang.Comparable)(short)100);
    org.jfree.chart.plot.DefaultDrawingSupplier var13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Stroke var14 = var13.getNextOutlineStroke();
    java.awt.Paint var15 = var13.getNextFillPaint();
    java.awt.Paint var16 = var13.getNextOutlinePaint();
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
    double var22 = var21.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var23 = var21.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var24 = null;
    java.util.List var25 = var21.getCategoriesForAxis(var24);
    double var26 = var21.getAnchorValue();
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21);
    org.jfree.chart.util.HorizontalAlignment var28 = var27.getHorizontalAlignment();
    org.jfree.chart.axis.AxisCollection var29 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var30 = var29.getAxesAtRight();
    boolean var31 = var28.equals((java.lang.Object)var29);
    java.util.List var32 = var29.getAxesAtRight();
    java.util.List var33 = var29.getAxesAtBottom();
    boolean var34 = var13.equals((java.lang.Object)var29);
    java.awt.Stroke var35 = var13.getNextOutlineStroke();
    java.awt.Shape var36 = var13.getNextShape();
    boolean var37 = var0.equals((java.lang.Object)var36);
    int var38 = var0.getRowCount();
    java.lang.Object var39 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test276"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var14.draw(var15, var16);
//     org.jfree.chart.util.VerticalAlignment var18 = var14.getVerticalAlignment();
//     org.jfree.data.category.CategoryDataset var19 = null;
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var19, var20, var21, var22);
//     double var24 = var23.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var25 = var23.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     java.util.List var27 = var23.getCategoriesForAxis(var26);
//     double var28 = var23.getAnchorValue();
//     var23.clearDomainAxes();
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
//     java.awt.RenderingHints var31 = var30.getRenderingHints();
//     var30.setBackgroundImageAlpha(0.0f);
//     java.lang.Object var34 = var30.getTextAntiAlias();
//     org.jfree.chart.title.LegendTitle var35 = var30.getLegend();
//     java.awt.Paint var36 = var35.getBackgroundPaint();
//     var14.setBackgroundPaint(var36);
//     
//     // Checks the contract:  equals-hashcode on var5 and var23
//     assertTrue("Contract failed: equals-hashcode on var5 and var23", var5.equals(var23) ? var5.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var5
//     assertTrue("Contract failed: equals-hashcode on var23 and var5", var23.equals(var5) ? var23.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var25
//     assertTrue("Contract failed: equals-hashcode on var7 and var25", var7.equals(var25) ? var7.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var7
//     assertTrue("Contract failed: equals-hashcode on var25 and var7", var25.equals(var7) ? var25.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test277"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Point2D var17 = null;
    var4.zoomRangeAxes((-1.0d), 1.0d, var16, var17);
    var4.clearDomainMarkers(10);
    org.jfree.chart.event.PlotChangeListener var21 = null;
    var4.addChangeListener(var21);
    org.jfree.chart.axis.AxisLocation var24 = var4.getRangeAxisLocation((-253));
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var25 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var26 = var25.getColumnCount();
    org.jfree.data.Range var28 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var25, 10.0d);
    java.lang.Number var31 = var25.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
    java.lang.Number var34 = var25.getStdDevValue((java.lang.Comparable)(short)100, (java.lang.Comparable)'#');
    org.jfree.data.general.DatasetChangeEvent var35 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(-253), (org.jfree.data.general.Dataset)var25);
    org.jfree.data.Range var37 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var25, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var40 = var25.getStdDevValue((-253), 15);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test278"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    float var14 = var4.getForegroundAlpha();
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    var4.setRenderer(var15, false);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    double var19 = var18.getLowerMargin();
    org.jfree.data.Range var20 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var18);
    java.lang.String var21 = var18.getLabelURL();
    var18.setInverted(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test279"); }
// 
// 
//     org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("SortOrder.ASCENDING");
//     org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("");
//     java.lang.String var5 = var4.getText();
//     var2.addFragment(var4);
//     var0.addLine(var2);
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var11 = new org.jfree.chart.block.LabelBlock("");
//     double var12 = var11.getHeight();
//     java.awt.Paint var13 = var11.getPaint();
//     java.awt.Font var14 = var11.getFont();
//     var9.setLabelFont(var14);
//     java.lang.String var17 = var9.getCategoryLabelToolTip((java.lang.Comparable)(byte)10);
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Shape var20 = var19.getLeftArrow();
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
//     double var26 = var25.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var27 = var25.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     java.util.List var29 = var25.getCategoriesForAxis(var28);
//     double var30 = var25.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25);
//     java.awt.Paint var32 = var31.getBackgroundPaint();
//     java.awt.Font var33 = var31.getItemFont();
//     var19.setTickLabelFont(var33);
//     var9.setTickLabelFont((java.lang.Comparable)"1", var33);
//     org.jfree.chart.text.TextFragment var36 = new org.jfree.chart.text.TextFragment("HorizontalAlignment.CENTER", var33);
//     var2.removeFragment(var36);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.text.TextAnchor var39 = null;
//     float var40 = var36.calculateBaselineOffset(var38, var39);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test280"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var7 = null;
    var0.setLegendItemToolTipGenerator(var7);
    boolean var11 = var0.isItemLabelVisible(255, (-6553600));
    org.jfree.chart.urls.CategoryURLGenerator var12 = null;
    var0.setBaseURLGenerator(var12);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = var0.getToolTipGenerator(100, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test281"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    int var5 = var0.getRowCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = var0.getSeriesToolTipGenerator(1);
    java.awt.Paint var10 = var0.getItemOutlinePaint((-16777216), (-165));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var12 = var11.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var11.getLegendItemToolTipGenerator();
    java.awt.Shape var15 = var11.lookupSeriesShape(0);
    var11.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var11.setSeriesURLGenerator(0, var19);
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = var11.getBaseToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var23 = var11.getSeriesNegativeItemLabelPosition(0);
    var0.setBaseNegativeItemLabelPosition(var23);
    var0.setMaximumBarWidth(0.05d);
    org.jfree.chart.labels.ItemLabelPosition var27 = var0.getPositiveItemLabelPositionFallback();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test282"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(9.05d);
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    double var3 = var2.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var4 = var2.getTickUnit();
    var2.zoomRange(0.0d, 0.0d);
    java.text.NumberFormat var8 = null;
    var2.setNumberFormatOverride(var8);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    double var16 = var15.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var18 = null;
    java.util.List var19 = var15.getCategoriesForAxis(var18);
    double var20 = var15.getAnchorValue();
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
    java.awt.Paint var22 = var21.getBackgroundPaint();
    java.awt.Font var23 = var21.getItemFont();
    org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("hi!");
    var25.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var31 = var25.getBounds();
    java.awt.Paint var32 = var25.getPaint();
    org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("SortOrder.ASCENDING", var23, var32);
    var2.setTickLabelPaint(var32);
    java.awt.Paint var35 = var2.getTickLabelPaint();
    var1.setPaint(var35);
    org.jfree.chart.util.LengthAdjustmentType var37 = var1.getLabelOffsetType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test283"); }


    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var11 = var8.getRowRenderingOrder();
    java.awt.Stroke var12 = var8.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = var8.getRendererForDataset(var13);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var8);
    java.util.List var16 = var15.getSubtitles();
    org.jfree.chart.ChartRenderingInfo var21 = null;
    java.awt.image.BufferedImage var22 = var15.createBufferedImage(1, 10, (-1.0d), 1.0d, var21);
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("SortOrder.ASCENDING", "Range[100.0,100.0]", "org.jfree.data.general.DatasetChangeEvent[source=-1]", (java.awt.Image)var22, "[size=1]", "ChartEntity: tooltip = hi!", "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=");
    java.lang.String var27 = var26.getName();
    java.lang.String var28 = var26.getCopyright();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "SortOrder.ASCENDING"+ "'", var27.equals("SortOrder.ASCENDING"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "[size=1]"+ "'", var28.equals("[size=1]"));

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test284"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test285"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(0, var8);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = var0.getBaseToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.urls.CategoryURLGenerator var13 = null;
    var0.setBaseURLGenerator(var13);
    double var15 = var0.getUpperClip();
    java.awt.Stroke var17 = var0.getSeriesStroke((-127));
    java.awt.Stroke var19 = var0.lookupSeriesOutlineStroke((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var20 = var0.getLegendItemURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test286"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    double var6 = var5.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var8 = null;
    java.util.List var9 = var5.getCategoriesForAxis(var8);
    double var10 = var5.getAnchorValue();
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    java.awt.Paint var12 = var11.getBackgroundPaint();
    java.awt.Font var13 = var11.getItemFont();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
    java.awt.Paint var15 = var14.getPaint();
    var14.setWidth(10.05d);
    var14.setToolTipText("RectangleEdge.TOP");
    java.lang.String var20 = var14.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "RectangleEdge.TOP"+ "'", var20.equals("RectangleEdge.TOP"));

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test287"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    var0.setVersion("org.jfree.chart.event.ChartChangeEvent[source=0]");
    java.lang.String var3 = var0.getCopyright();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test288"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    java.awt.Stroke var14 = var4.getDomainGridlineStroke();
    java.awt.Color var17 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var18 = var17.getColorSpace();
    java.awt.image.ColorModel var19 = null;
    java.awt.Rectangle var20 = null;
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
    var22.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var28 = var22.getBounds();
    java.awt.geom.AffineTransform var29 = null;
    java.awt.RenderingHints var30 = null;
    java.awt.PaintContext var31 = var17.createContext(var19, var20, var28, var29, var30);
    var4.setNoDataMessagePaint((java.awt.Paint)var17);
    var4.setNoDataMessage("");
    float var35 = var4.getBackgroundImageAlpha();
    int var36 = var4.getRangeAxisCount();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var37 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var38 = var37.getColumnCount();
    java.lang.Number var41 = var37.getMeanValue((java.lang.Comparable)"[size=1]", (java.lang.Comparable)100);
    org.jfree.chart.renderer.category.CategoryItemRenderer var42 = var4.getRendererForDataset((org.jfree.data.category.CategoryDataset)var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var44 = var37.getColumnKey(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test289"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    double var1 = var0.getTop();
    var0.setBottom(4.0d);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var9 = new org.jfree.chart.block.LabelBlock("hi!");
    var9.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var15 = var9.getBounds();
    org.jfree.chart.util.RectangleAnchor var16 = null;
    java.awt.geom.Point2D var17 = org.jfree.chart.util.RectangleAnchor.coordinates(var15, var16);
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var5.getCategoryStart((-16777216), (-16777216), var15, var18);
    org.jfree.chart.entity.CategoryLabelEntity var22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var15, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
    double var28 = var27.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var29 = var27.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var30 = null;
    java.util.List var31 = var27.getCategoriesForAxis(var30);
    double var32 = var27.getAnchorValue();
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
    java.awt.Paint var34 = var33.getBackgroundPaint();
    double var35 = var33.getWidth();
    java.lang.Object var36 = var33.clone();
    org.jfree.chart.util.RectangleAnchor var37 = var33.getLegendItemGraphicLocation();
    java.awt.geom.Point2D var38 = org.jfree.chart.util.RectangleAnchor.coordinates(var15, var37);
    org.jfree.chart.entity.TickLabelEntity var41 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var15, "CategoryLabelWidthType.RANGE", "hi!");
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var15);
    java.awt.geom.Rectangle2D var43 = null;
    java.awt.geom.Rectangle2D var44 = var0.expand(var15, var43);
    double var45 = var0.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test290"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-127));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test291"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.LegendItemEntity var2 = new org.jfree.chart.entity.LegendItemEntity(var1);
    java.lang.String var3 = var2.toString();
    org.jfree.data.general.Dataset var4 = var2.getDataset();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
    double var10 = var9.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var11 = var9.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var12 = null;
    java.util.List var13 = var9.getCategoriesForAxis(var12);
    double var14 = var9.getAnchorValue();
    java.awt.Color var17 = java.awt.Color.getColor("", 1);
    var9.setOutlinePaint((java.awt.Paint)var17);
    java.awt.Stroke var19 = var9.getDomainGridlineStroke();
    org.jfree.chart.axis.AxisLocation var21 = var9.getDomainAxisLocation(1);
    var9.setOutlineVisible(true);
    boolean var24 = var2.equals((java.lang.Object)var9);
    java.lang.String var25 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var3.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var25.equals("LegendItemEntity: seriesKey=null, dataset=null"));

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test292"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)0, var1, var2);
    org.jfree.chart.event.ChartChangeEventType var4 = var3.getType();
    java.lang.Object var5 = var3.getSource();
    org.jfree.chart.event.ChartChangeEventType var6 = null;
    var3.setType(var6);
    org.jfree.chart.event.ChartChangeEventType var8 = var3.getType();
    org.jfree.chart.event.ChartChangeEventType var9 = null;
    var3.setType(var9);
    org.jfree.chart.event.ChartChangeEventType var11 = var3.getType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test293"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(0, var8);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = var0.getBaseToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getBasePositiveItemLabelPosition();
    java.awt.Paint var15 = var0.getSeriesOutlinePaint((-1572964));
    org.jfree.chart.plot.CategoryPlot var16 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test294"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    double var8 = var7.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var10 = null;
    java.util.List var11 = var7.getCategoriesForAxis(var10);
    double var12 = var7.getAnchorValue();
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
    java.awt.Paint var14 = var13.getBackgroundPaint();
    java.awt.Font var15 = var13.getItemFont();
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("hi!", var15);
    org.jfree.chart.util.RectangleEdge var17 = var16.getPosition();
    var0.add(100.0d, var17);
    var0.setTop(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test295"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     var1.setAlpha(0.0f);
//     org.jfree.chart.util.LengthAdjustmentType var4 = var1.getLabelOffsetType();
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.text.TextAnchor var7 = var6.getLabelTextAnchor();
//     var1.setLabelTextAnchor(var7);
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
//     double var10 = var9.getLowerMargin();
//     org.jfree.chart.axis.NumberTickUnit var11 = var9.getTickUnit();
//     var9.setAutoTickUnitSelection(false);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     java.awt.Color var26 = java.awt.Color.getColor("", 1);
//     var18.setOutlinePaint((java.awt.Paint)var26);
//     java.awt.Stroke var28 = var18.getDomainGridlineStroke();
//     org.jfree.chart.axis.ValueAxis var29 = var18.getRangeAxis();
//     var18.setWeight((-16777216));
//     var9.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var18);
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var18);
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var34, var35, var36, var37);
//     double var39 = var38.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var40 = var38.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     int var42 = var38.getIndexOf(var41);
//     java.util.List var43 = var38.getCategories();
//     org.jfree.chart.axis.AxisLocation var44 = var38.getDomainAxisLocation();
//     org.jfree.chart.plot.DatasetRenderingOrder var45 = var38.getDatasetRenderingOrder();
//     var38.setRangeCrosshairValue(1.0d, true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var49 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var50 = var49.getColumnCount();
//     org.jfree.data.Range var52 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var49, 10.0d);
//     java.lang.Number var55 = var49.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
//     org.jfree.data.Range var56 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var49);
//     double var58 = var49.getRangeLowerBound(true);
//     boolean var59 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var49);
//     var38.setDataset((org.jfree.data.category.CategoryDataset)var49);
//     var1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var38);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var62 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var63 = var62.getColumnCount();
//     org.jfree.data.Range var65 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var62, 10.0d);
//     boolean var66 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var62);
//     java.lang.Number var67 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var62);
//     var38.setDataset((org.jfree.data.category.CategoryDataset)var62);
//     
//     // Checks the contract:  equals-hashcode on var49 and var62
//     assertTrue("Contract failed: equals-hashcode on var49 and var62", var49.equals(var62) ? var49.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var49
//     assertTrue("Contract failed: equals-hashcode on var62 and var49", var62.equals(var49) ? var62.hashCode() == var49.hashCode() : true);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test296"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=");

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test297"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    java.awt.Color var8 = java.awt.Color.getColor("", 1);
    var4.setDomainGridlinePaint((java.awt.Paint)var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var15 = new org.jfree.chart.entity.TickLabelEntity(var12, "hi!", "hi!");
    org.jfree.data.Range var16 = null;
    org.jfree.data.Range var17 = null;
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(var16, var17);
    boolean var19 = var15.equals((java.lang.Object)var16);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var15.setArea(var22);
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    double var29 = var28.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var30 = var28.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var31 = null;
    java.util.List var32 = var28.getCategoriesForAxis(var31);
    double var33 = var28.getAnchorValue();
    java.awt.Color var36 = java.awt.Color.getColor("", 1);
    var28.setOutlinePaint((java.awt.Paint)var36);
    java.awt.Stroke var38 = var28.getDomainGridlineStroke();
    java.awt.Color var41 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var42 = var41.getColorSpace();
    java.awt.image.ColorModel var43 = null;
    java.awt.Rectangle var44 = null;
    org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("hi!");
    var46.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var52 = var46.getBounds();
    java.awt.geom.AffineTransform var53 = null;
    java.awt.RenderingHints var54 = null;
    java.awt.PaintContext var55 = var41.createContext(var43, var44, var52, var53, var54);
    var28.setNoDataMessagePaint((java.awt.Paint)var41);
    org.jfree.chart.title.LegendGraphic var57 = new org.jfree.chart.title.LegendGraphic(var22, (java.awt.Paint)var41);
    java.awt.color.ColorSpace var58 = var41.getColorSpace();
    float[] var59 = null;
    float[] var60 = var41.getRGBComponents(var59);
    float[] var61 = var8.getComponents(var60);
    int var62 = var8.getBlue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 1);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test298"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.chart.util.RectangleAnchor var11 = var10.getLegendItemGraphicLocation();
//     org.jfree.chart.util.HorizontalAlignment var12 = var10.getHorizontalAlignment();
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var18 = new org.jfree.chart.entity.TickLabelEntity(var15, "hi!", "hi!");
//     org.jfree.data.Range var19 = null;
//     org.jfree.data.Range var20 = null;
//     org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var19, var20);
//     boolean var22 = var18.equals((java.lang.Object)var19);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var18.setArea(var25);
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var27, var28, var29, var30);
//     double var32 = var31.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var33 = var31.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     java.util.List var35 = var31.getCategoriesForAxis(var34);
//     double var36 = var31.getAnchorValue();
//     java.awt.Color var39 = java.awt.Color.getColor("", 1);
//     var31.setOutlinePaint((java.awt.Paint)var39);
//     java.awt.Stroke var41 = var31.getDomainGridlineStroke();
//     java.awt.Color var44 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var45 = var44.getColorSpace();
//     java.awt.image.ColorModel var46 = null;
//     java.awt.Rectangle var47 = null;
//     org.jfree.chart.block.LabelBlock var49 = new org.jfree.chart.block.LabelBlock("hi!");
//     var49.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var55 = var49.getBounds();
//     java.awt.geom.AffineTransform var56 = null;
//     java.awt.RenderingHints var57 = null;
//     java.awt.PaintContext var58 = var44.createContext(var46, var47, var55, var56, var57);
//     var31.setNoDataMessagePaint((java.awt.Paint)var44);
//     org.jfree.chart.title.LegendGraphic var60 = new org.jfree.chart.title.LegendGraphic(var25, (java.awt.Paint)var44);
//     java.awt.Shape var61 = var60.getShape();
//     var60.setShapeOutlineVisible(true);
//     org.jfree.chart.util.GradientPaintTransformer var64 = var60.getFillPaintTransformer();
//     java.awt.Stroke var65 = var60.getOutlineStroke();
//     java.awt.Shape var66 = var60.getLine();
//     org.jfree.chart.util.RectangleAnchor var67 = var60.getShapeAnchor();
//     var10.setLegendItemGraphicAnchor(var67);
//     
//     // Checks the contract:  equals-hashcode on var6 and var33
//     assertTrue("Contract failed: equals-hashcode on var6 and var33", var6.equals(var33) ? var6.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var6
//     assertTrue("Contract failed: equals-hashcode on var33 and var6", var33.equals(var6) ? var33.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test299"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    int var5 = var0.getRowCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = var0.getSeriesToolTipGenerator(1);
    java.awt.Paint var10 = var0.getItemOutlinePaint((-16777216), (-165));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var12 = var11.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var11.getLegendItemToolTipGenerator();
    java.awt.Shape var15 = var11.lookupSeriesShape(0);
    var11.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var11.setSeriesURLGenerator(0, var19);
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = var11.getBaseToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var23 = var11.getSeriesNegativeItemLabelPosition(0);
    var0.setBaseNegativeItemLabelPosition(var23);
    java.awt.Shape var25 = var0.getBaseShape();
    java.awt.Stroke var26 = var0.getErrorIndicatorStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test300"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var2 = var1.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var1.getLegendItemToolTipGenerator();
    java.awt.Shape var5 = var1.lookupSeriesShape(0);
    var1.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var1.setSeriesURLGenerator(0, var9);
    org.jfree.chart.labels.CategoryToolTipGenerator var11 = var1.getBaseToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var13 = var1.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    var1.setBaseURLGenerator(var14);
    java.awt.Stroke var17 = var1.getSeriesOutlineStroke((-165));
    org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var20.setAlpha(0.0f);
    java.awt.Stroke var23 = var20.getOutlineStroke();
    java.awt.Stroke var24 = var20.getOutlineStroke();
    java.awt.Stroke var25 = var20.getStroke();
    var1.setSeriesStroke(0, var25, false);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var29 = var28.getLeftArrow();
    org.jfree.data.category.CategoryDataset var30 = null;
    org.jfree.chart.axis.CategoryAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var30, var31, var32, var33);
    double var35 = var34.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var36 = var34.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var37 = null;
    java.util.List var38 = var34.getCategoriesForAxis(var37);
    double var39 = var34.getAnchorValue();
    org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    java.awt.Paint var41 = var40.getBackgroundPaint();
    java.awt.Font var42 = var40.getItemFont();
    var28.setTickLabelFont(var42);
    var1.setBaseItemLabelFont(var42);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var45 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var46 = var45.getRowCount();
    java.awt.Paint var47 = var45.getBasePaint();
    java.awt.Stroke var49 = var45.getSeriesStroke(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var50 = null;
    var45.setLegendItemToolTipGenerator(var50);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var53 = var52.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var54 = var52.getLegendItemToolTipGenerator();
    java.awt.Shape var56 = var52.lookupSeriesShape(0);
    org.jfree.chart.labels.ItemLabelPosition var57 = new org.jfree.chart.labels.ItemLabelPosition();
    var52.setPositiveItemLabelPositionFallback(var57);
    org.jfree.chart.text.TextAnchor var59 = var57.getTextAnchor();
    var45.setNegativeItemLabelPositionFallback(var57);
    java.awt.Paint var62 = var45.lookupSeriesFillPaint((-165));
    org.jfree.chart.block.LabelBlock var63 = new org.jfree.chart.block.LabelBlock("PlotOrientation.VERTICAL version VerticalAlignment.CENTER.\norg.jfree.chart.event.ChartChangeEvent[source=0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY PlotOrientation.VERTICAL:None\nPlotOrientation.VERTICAL LICENCE TERMS:\n10", var42, var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test301"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    var0.setAutoPopulateSeriesStroke(true);
    java.awt.Paint var11 = var0.getItemFillPaint(100, 100);
    var0.setDrawBarOutline(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test302"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
    var0.setLegendItemToolTipGenerator(var5);
    java.awt.Color var9 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var10 = var9.getColorSpace();
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("hi!");
    var14.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var20 = var14.getBounds();
    java.awt.geom.AffineTransform var21 = null;
    java.awt.RenderingHints var22 = null;
    java.awt.PaintContext var23 = var9.createContext(var11, var12, var20, var21, var22);
    boolean var24 = var0.equals((java.lang.Object)var9);
    java.awt.color.ColorSpace var25 = var9.getColorSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test303"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Point2D var17 = null;
    var4.zoomRangeAxes((-1.0d), 1.0d, var16, var17);
    var4.clearDomainMarkers(10);
    org.jfree.chart.event.PlotChangeListener var21 = null;
    var4.addChangeListener(var21);
    org.jfree.chart.axis.AxisLocation var24 = var4.getRangeAxisLocation((-253));
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var25 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var26 = var25.getColumnCount();
    org.jfree.data.Range var28 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var25, 10.0d);
    java.lang.Number var31 = var25.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
    java.lang.Number var34 = var25.getStdDevValue((java.lang.Comparable)(short)100, (java.lang.Comparable)'#');
    org.jfree.data.general.DatasetChangeEvent var35 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(-253), (org.jfree.data.general.Dataset)var25);
    int var36 = var25.getColumnCount();
    org.jfree.data.Range var38 = var25.getRangeBounds(true);
    org.jfree.chart.axis.TickUnits var39 = new org.jfree.chart.axis.TickUnits();
    java.lang.Object var40 = var39.clone();
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
    double var42 = var41.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var43 = var41.getTickUnit();
    var41.setAutoTickUnitSelection(false);
    var41.setLabelAngle(100.0d);
    org.jfree.chart.axis.NumberTickUnit var48 = var41.getTickUnit();
    var41.setAutoRange(false);
    org.jfree.chart.axis.NumberTickUnit var52 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    var41.setTickUnit(var52);
    var39.add((org.jfree.chart.axis.TickUnit)var52);
    java.lang.String var55 = var52.toString();
    int var56 = var25.getRowIndex((java.lang.Comparable)var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + "[size=1]"+ "'", var55.equals("[size=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == (-1));

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test304"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("PlotOrientation.VERTICAL version VerticalAlignment.CENTER.\norg.jfree.chart.event.ChartChangeEvent[source=0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY PlotOrientation.VERTICAL:None\nPlotOrientation.VERTICAL LICENCE TERMS:\n10", "Range[-1.0,-1.0]");

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test305"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    org.jfree.chart.util.RectangleEdge var10 = var8.getDomainAxisEdge((-1));
    java.lang.String var11 = var10.toString();
    org.jfree.chart.axis.CategoryLabelPosition var12 = var3.getLabelPosition(var10);
    var0.moveCursor(0.0d, var10);
    double var14 = var0.getMax();
    var0.cursorRight(2.05d);
    var0.cursorLeft(0.05d);
    java.util.List var19 = var0.getTicks();
    java.util.Collection var20 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "RectangleEdge.TOP"+ "'", var11.equals("RectangleEdge.TOP"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test306"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     java.awt.Color var13 = java.awt.Color.getColor("", 1);
//     var5.setOutlinePaint((java.awt.Paint)var13);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     java.awt.geom.Point2D var18 = null;
//     var5.zoomRangeAxes((-1.0d), 1.0d, var17, var18);
//     var5.clearDomainMarkers(10);
//     org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("0,0,1,1", (org.jfree.chart.plot.Plot)var5);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var28 = new org.jfree.chart.entity.TickLabelEntity(var25, "hi!", "hi!");
//     org.jfree.data.Range var29 = null;
//     org.jfree.data.Range var30 = null;
//     org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint(var29, var30);
//     boolean var32 = var28.equals((java.lang.Object)var29);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var28.setArea(var35);
//     org.jfree.data.category.CategoryDataset var37 = null;
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
//     double var42 = var41.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var43 = var41.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var44 = null;
//     java.util.List var45 = var41.getCategoriesForAxis(var44);
//     double var46 = var41.getAnchorValue();
//     java.awt.Color var49 = java.awt.Color.getColor("", 1);
//     var41.setOutlinePaint((java.awt.Paint)var49);
//     java.awt.Stroke var51 = var41.getDomainGridlineStroke();
//     java.awt.Color var54 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var55 = var54.getColorSpace();
//     java.awt.image.ColorModel var56 = null;
//     java.awt.Rectangle var57 = null;
//     org.jfree.chart.block.LabelBlock var59 = new org.jfree.chart.block.LabelBlock("hi!");
//     var59.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var65 = var59.getBounds();
//     java.awt.geom.AffineTransform var66 = null;
//     java.awt.RenderingHints var67 = null;
//     java.awt.PaintContext var68 = var54.createContext(var56, var57, var65, var66, var67);
//     var41.setNoDataMessagePaint((java.awt.Paint)var54);
//     org.jfree.chart.title.LegendGraphic var70 = new org.jfree.chart.title.LegendGraphic(var35, (java.awt.Paint)var54);
//     org.jfree.chart.util.RectangleAnchor var71 = var70.getShapeAnchor();
//     java.awt.Paint var72 = var70.getOutlinePaint();
//     java.lang.Object var73 = var70.clone();
//     java.lang.Object var74 = var70.clone();
//     var70.setShapeOutlineVisible(true);
//     org.jfree.chart.plot.ValueMarker var78 = new org.jfree.chart.plot.ValueMarker((-1.0d));
//     java.awt.Paint var79 = var78.getLabelPaint();
//     var70.setOutlinePaint(var79);
//     var22.setBorderPaint(var79);
//     
//     // Checks the contract:  equals-hashcode on var7 and var43
//     assertTrue("Contract failed: equals-hashcode on var7 and var43", var7.equals(var43) ? var7.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var7
//     assertTrue("Contract failed: equals-hashcode on var43 and var7", var43.equals(var7) ? var43.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test307"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var1.setAlpha(0.0f);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("hi!");
    var8.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var14 = var8.getBounds();
    org.jfree.chart.util.RectangleAnchor var15 = null;
    java.awt.geom.Point2D var16 = org.jfree.chart.util.RectangleAnchor.coordinates(var14, var15);
    org.jfree.chart.util.RectangleEdge var17 = null;
    double var18 = var4.getCategoryStart((-16777216), (-16777216), var14, var17);
    var4.setMaximumCategoryLabelLines(10);
    float var21 = var4.getMaximumCategoryLabelWidthRatio();
    java.lang.String var22 = var4.getLabel();
    java.awt.Font var23 = var4.getLabelFont();
    var1.setLabelFont(var23);
    double var25 = var1.getValue();
    org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var27 = var26.getInsets();
    org.jfree.chart.util.RectangleInsets var28 = var26.getInsets();
    org.jfree.data.category.CategoryDataset var29 = null;
    org.jfree.chart.axis.CategoryAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var29, var30, var31, var32);
    double var34 = var33.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var35 = var33.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var36 = null;
    java.util.List var37 = var33.getCategoriesForAxis(var36);
    double var38 = var33.getAnchorValue();
    var33.clearDomainAxes();
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
    java.awt.Paint var41 = var40.getBackgroundPaint();
    org.jfree.chart.block.BlockBorder var42 = new org.jfree.chart.block.BlockBorder(var28, var41);
    double var43 = var28.getTop();
    var1.setLabelOffset(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test308"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    double var6 = var5.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var8 = null;
    java.util.List var9 = var5.getCategoriesForAxis(var8);
    double var10 = var5.getAnchorValue();
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    java.awt.Paint var12 = var11.getBackgroundPaint();
    java.awt.Font var13 = var11.getItemFont();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
    java.awt.Graphics2D var15 = null;
    java.awt.Color var18 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var19 = var18.getColorSpace();
    java.awt.image.ColorModel var20 = null;
    java.awt.Rectangle var21 = null;
    org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("hi!");
    var23.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var29 = var23.getBounds();
    java.awt.geom.AffineTransform var30 = null;
    java.awt.RenderingHints var31 = null;
    java.awt.PaintContext var32 = var18.createContext(var20, var21, var29, var30, var31);
    var14.draw(var15, var29);
    org.jfree.chart.block.BlockFrame var34 = var14.getFrame();
    org.jfree.chart.util.VerticalAlignment var35 = var14.getVerticalAlignment();
    java.lang.String var36 = var14.getID();
    var14.setText("CONTRACT");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test309"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.util.RectangleEdge var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = var1.getLabelPosition(var2);
    org.jfree.chart.util.Size2D var6 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
    var6.setHeight((-1.0d));
    var6.setWidth((-1.0d));
    double var11 = var6.getHeight();
    boolean var12 = var1.equals((java.lang.Object)var11);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("");
    double var16 = var15.getHeight();
    java.awt.Paint var17 = var15.getPaint();
    java.awt.Font var18 = var15.getFont();
    var13.setLabelFont(var18);
    var13.setUpperMargin(100.0d);
    org.jfree.chart.axis.CategoryLabelPositions var23 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0d);
    var13.setCategoryLabelPositions(var23);
    org.jfree.data.category.CategoryDataset var26 = null;
    org.jfree.chart.axis.CategoryAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
    double var31 = var30.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var32 = var30.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var33 = null;
    java.util.List var34 = var30.getCategoriesForAxis(var33);
    double var35 = var30.getAnchorValue();
    org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
    java.awt.Paint var37 = var36.getBackgroundPaint();
    java.awt.Font var38 = var36.getItemFont();
    org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("hi!", var38);
    org.jfree.chart.util.RectangleEdge var40 = var39.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var41 = var23.getLabelPosition(var40);
    org.jfree.chart.axis.CategoryLabelPositions var42 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var1, var41);
    org.jfree.chart.axis.CategoryLabelWidthType var43 = var41.getWidthType();
    org.jfree.chart.util.StandardGradientPaintTransformer var44 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var45 = var44.getType();
    boolean var46 = var43.equals((java.lang.Object)var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test310"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("", "ChartEntity: tooltip = hi!");
    java.lang.String var3 = var2.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + ""+ "'", var3.equals(""));

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test311"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
    var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var10 = var4.getBounds();
    org.jfree.chart.util.RectangleAnchor var11 = null;
    java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
    org.jfree.chart.util.RectangleEdge var13 = null;
    double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
    var0.setTickMarkOutsideLength(0.0f);
    java.lang.String var17 = var0.getLabel();
    java.awt.Font var18 = var0.getLabelFont();
    org.jfree.chart.block.LabelBlock var21 = new org.jfree.chart.block.LabelBlock("");
    double var22 = var21.getHeight();
    java.awt.Paint var23 = var21.getPaint();
    java.awt.Font var24 = var21.getFont();
    var0.setTickLabelFont((java.lang.Comparable)10.0d, var24);
    var0.setUpperMargin(7.0d);
    org.jfree.chart.plot.Plot var28 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test312"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var1 = var0.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
//     java.awt.Shape var4 = var0.lookupSeriesShape(0);
//     var0.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.urls.CategoryURLGenerator var8 = null;
//     var0.setSeriesURLGenerator(0, var8);
//     var0.setItemMargin(6.0d);
//     java.awt.Shape var13 = var0.lookupSeriesShape(100);
//     java.awt.Paint var16 = var0.getItemLabelPaint(100, 10);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     var21.clearAnnotations();
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     double var28 = var27.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var29 = var27.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     java.util.List var31 = var27.getCategoriesForAxis(var30);
//     double var32 = var27.getAnchorValue();
//     var27.clearDomainMarkers();
//     org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("");
//     double var36 = var35.getHeight();
//     java.awt.Paint var37 = var35.getPaint();
//     var27.setRangeCrosshairPaint(var37);
//     int var39 = var27.getDomainAxisCount();
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
//     java.awt.Color var43 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
//     var27.setRangeCrosshairPaint((java.awt.Paint)var43);
//     int var45 = var43.getRed();
//     var21.setDomainGridlinePaint((java.awt.Paint)var43);
//     var0.setBaseItemLabelPaint((java.awt.Paint)var43, false);
//     org.jfree.chart.block.BlockBorder var49 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var43);
//     int var50 = var43.getAlpha();
//     org.jfree.chart.block.BlockBorder var51 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var43);
//     
//     // Checks the contract:  equals-hashcode on var49 and var51
//     assertTrue("Contract failed: equals-hashcode on var49 and var51", var49.equals(var51) ? var49.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var49
//     assertTrue("Contract failed: equals-hashcode on var51 and var49", var51.equals(var49) ? var51.hashCode() == var49.hashCode() : true);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test313"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.util.PaintList var1 = new org.jfree.chart.util.PaintList();
    boolean var2 = var0.equals((java.lang.Object)var1);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 1.0f);
    var0.setShape(255, var6);
    java.awt.Shape var9 = var0.getShape(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test314"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    int var8 = var4.getIndexOf(var7);
    java.util.List var9 = var4.getCategories();
    org.jfree.chart.axis.AxisLocation var10 = var4.getDomainAxisLocation();
    org.jfree.chart.axis.AxisSpace var11 = null;
    var4.setFixedDomainAxisSpace(var11);
    int var13 = var4.getRangeAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test315"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
//     double var3 = var2.getHeight();
//     java.awt.Paint var4 = var2.getPaint();
//     java.awt.Font var5 = var2.getFont();
//     var0.setLabelFont(var5);
//     java.lang.String var8 = var0.getCategoryLabelToolTip((java.lang.Comparable)(byte)10);
//     java.lang.String var10 = var0.getCategoryLabelToolTip((java.lang.Comparable)(short)0);
//     boolean var11 = var0.isAxisLineVisible();
//     var0.setUpperMargin(Double.NaN);
//     double var14 = var0.getUpperMargin();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.axis.AxisState var16 = new org.jfree.chart.axis.AxisState();
//     var16.cursorDown(4.0d);
//     double var19 = var16.getMax();
//     var16.setCursor(0.05d);
//     var16.cursorLeft(6.0d);
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.Object var25 = var24.clone();
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("hi!");
//     var32.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var38 = var32.getBounds();
//     org.jfree.chart.util.RectangleAnchor var39 = null;
//     java.awt.geom.Point2D var40 = org.jfree.chart.util.RectangleAnchor.coordinates(var38, var39);
//     org.jfree.chart.util.RectangleEdge var41 = null;
//     double var42 = var28.getCategoryStart((-16777216), (-16777216), var38, var41);
//     org.jfree.chart.axis.AxisSpace var43 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.data.category.CategoryDataset var46 = null;
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var46, var47, var48, var49);
//     double var51 = var50.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var52 = var50.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     java.util.List var54 = var50.getCategoriesForAxis(var53);
//     double var55 = var50.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50);
//     java.awt.Paint var57 = var56.getBackgroundPaint();
//     java.awt.Font var58 = var56.getItemFont();
//     org.jfree.chart.title.TextTitle var59 = new org.jfree.chart.title.TextTitle("hi!", var58);
//     org.jfree.chart.util.RectangleEdge var60 = var59.getPosition();
//     var43.add(100.0d, var60);
//     double var62 = var24.getCategoryMiddle(0, 100, var38, var60);
//     org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis();
//     var63.setNegativeArrowVisible(false);
//     org.jfree.chart.axis.MarkerAxisBand var66 = var63.getMarkerBand();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var67 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var68 = var67.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var69 = var67.getLegendItemToolTipGenerator();
//     java.awt.Shape var71 = var67.lookupSeriesShape(0);
//     var67.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.urls.CategoryURLGenerator var75 = null;
//     var67.setSeriesURLGenerator(0, var75);
//     var67.setItemMargin(6.0d);
//     org.jfree.data.category.CategoryDataset var79 = null;
//     org.jfree.chart.axis.CategoryAxis var80 = null;
//     org.jfree.chart.axis.ValueAxis var81 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var82 = null;
//     org.jfree.chart.plot.CategoryPlot var83 = new org.jfree.chart.plot.CategoryPlot(var79, var80, var81, var82);
//     double var84 = var83.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var85 = var83.getDrawingSupplier();
//     var83.clearAnnotations();
//     var67.setPlot(var83);
//     java.lang.Object var88 = var83.clone();
//     var63.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var83);
//     org.jfree.chart.axis.CategoryAxis var90 = var83.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var92 = var83.getDomainAxisEdge(100);
//     java.util.List var93 = var0.refreshTicks(var15, var16, var38, var92);
//     
//     // Checks the contract:  equals-hashcode on var50 and var83
//     assertTrue("Contract failed: equals-hashcode on var50 and var83", var50.equals(var83) ? var50.hashCode() == var83.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var83 and var50
//     assertTrue("Contract failed: equals-hashcode on var83 and var50", var83.equals(var50) ? var83.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var85
//     assertTrue("Contract failed: equals-hashcode on var52 and var85", var52.equals(var85) ? var52.hashCode() == var85.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var85 and var52
//     assertTrue("Contract failed: equals-hashcode on var85 and var52", var85.equals(var52) ? var85.hashCode() == var52.hashCode() : true);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test316"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
    double var3 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.0d));

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test317"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "ItemLabelAnchor.OUTSIDE12");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test318"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var1 = var0.getRowCount();
//     java.awt.Paint var2 = var0.getBasePaint();
//     java.awt.Stroke var4 = var0.getSeriesStroke(1);
//     var0.setItemMargin(0.05d);
//     var0.setAutoPopulateSeriesShape(false);
//     var0.setIncludeBaseInRange(true);
//     java.awt.Stroke var12 = var0.getSeriesStroke(255);
//     var0.setBaseCreateEntities(false);
//     org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement();
//     java.awt.Color var18 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var19 = var18.getColorSpace();
//     java.awt.image.ColorModel var20 = null;
//     java.awt.Rectangle var21 = null;
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("hi!");
//     var23.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var29 = var23.getBounds();
//     java.awt.geom.AffineTransform var30 = null;
//     java.awt.RenderingHints var31 = null;
//     java.awt.PaintContext var32 = var18.createContext(var20, var21, var29, var30, var31);
//     org.jfree.data.category.CategoryDataset var33 = null;
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var33, var34, var35, var36);
//     double var38 = var37.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var39 = var37.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     java.util.List var41 = var37.getCategoriesForAxis(var40);
//     double var42 = var37.getAnchorValue();
//     java.awt.Color var45 = java.awt.Color.getColor("", 1);
//     var37.setOutlinePaint((java.awt.Paint)var45);
//     org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var29, (java.awt.Paint)var45);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var48 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var49 = var48.getColumnCount();
//     org.jfree.data.Range var51 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var48, 10.0d);
//     java.lang.Number var54 = var48.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
//     org.jfree.data.Range var55 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var48);
//     double var57 = var48.getRangeLowerBound(true);
//     boolean var58 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var48);
//     java.lang.Number var59 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var48);
//     var15.add((org.jfree.chart.block.Block)var47, (java.lang.Object)var59);
//     org.jfree.chart.plot.DefaultDrawingSupplier var61 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Stroke var62 = var61.getNextOutlineStroke();
//     java.awt.Paint var63 = var61.getNextFillPaint();
//     java.awt.Paint var64 = var61.getNextOutlinePaint();
//     java.awt.Shape var65 = var61.getNextShape();
//     java.awt.Stroke var66 = var61.getNextStroke();
//     var47.setOutlineStroke(var66);
//     var0.setBaseStroke(var66, true);
//     java.awt.Paint var72 = var0.getItemFillPaint((-83), (-3670018));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var59 + "' != '" + 0.0d+ "'", var59.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test319"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
    double var10 = var9.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var11 = var9.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var12 = null;
    java.util.List var13 = var9.getCategoriesForAxis(var12);
    double var14 = var9.getAnchorValue();
    var9.clearDomainAxes();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var9);
    org.jfree.chart.title.LegendTitle var18 = var16.getLegend(10);
    java.awt.Stroke var19 = var16.getBorderStroke();
    var0.setBaseStroke(var19);
    boolean var23 = var0.isItemLabelVisible(0, (-165));
    var0.setSeriesVisible(15, (java.lang.Boolean)true, true);
    org.jfree.chart.labels.ItemLabelPosition var28 = null;
    var0.setPositiveItemLabelPositionFallback(var28);
    java.awt.Font var31 = var0.getSeriesItemLabelFont(10);
    org.jfree.chart.labels.ItemLabelPosition var32 = var0.getPositiveItemLabelPositionFallback();
    org.jfree.chart.plot.DrawingSupplier var33 = var0.getDrawingSupplier();
    int var34 = var0.getPassCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test320"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     double var1 = var0.getLowerMargin();
//     org.jfree.chart.axis.TickUnitSource var2 = var0.getStandardTickUnits();
//     var0.setAutoRangeStickyZero(false);
//     double var5 = var0.getLowerBound();
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 100.0d);
//     org.jfree.data.Range var9 = null;
//     org.jfree.data.Range var10 = null;
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(var9, var10);
//     org.jfree.data.Range var12 = null;
//     org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(var14, 10.0d);
//     org.jfree.data.Range var17 = null;
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(var14, var17);
//     double var19 = var14.getLowerBound();
//     org.jfree.chart.block.RectangleConstraint var20 = var11.toRangeHeight(var14);
//     org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var8, var14);
//     org.jfree.data.Range var24 = org.jfree.data.Range.expand(var8, 100.0d, 0.0d);
//     double var26 = var24.constrain(2.0d);
//     org.jfree.data.Range var29 = org.jfree.data.Range.shift(var24, 6.0d, true);
//     boolean var30 = var0.equals((java.lang.Object)true);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.axis.AxisState var32 = new org.jfree.chart.axis.AxisState();
//     org.jfree.chart.axis.CategoryLabelPositions var35 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.axis.CategoryAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var36, var37, var38, var39);
//     org.jfree.chart.util.RectangleEdge var42 = var40.getDomainAxisEdge((-1));
//     java.lang.String var43 = var42.toString();
//     org.jfree.chart.axis.CategoryLabelPosition var44 = var35.getLabelPosition(var42);
//     var32.moveCursor(0.0d, var42);
//     double var46 = var32.getMax();
//     java.util.List var47 = var32.getTicks();
//     org.jfree.chart.title.TextTitle var49 = new org.jfree.chart.title.TextTitle("SortOrder.ASCENDING");
//     var49.setNotify(false);
//     java.awt.Graphics2D var52 = null;
//     org.jfree.chart.block.LineBorder var55 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var56 = null;
//     org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("hi!");
//     var58.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var64 = var58.getBounds();
//     org.jfree.data.category.CategoryDataset var66 = null;
//     org.jfree.chart.axis.CategoryAxis var67 = null;
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var69 = null;
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot(var66, var67, var68, var69);
//     double var71 = var70.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var72 = var70.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var73 = null;
//     java.util.List var74 = var70.getCategoriesForAxis(var73);
//     double var75 = var70.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var76 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var70);
//     java.awt.Paint var77 = var76.getBackgroundPaint();
//     java.awt.Font var78 = var76.getItemFont();
//     org.jfree.chart.title.TextTitle var79 = new org.jfree.chart.title.TextTitle("hi!", var78);
//     java.awt.Graphics2D var80 = null;
//     java.awt.geom.Rectangle2D var81 = null;
//     var79.draw(var80, var81);
//     java.awt.Paint var83 = var79.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var84 = var79.getBounds();
//     boolean var85 = org.jfree.chart.util.ShapeUtilities.intersects(var64, var84);
//     var55.draw(var56, var64);
//     java.awt.geom.Point2D var87 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(2.0d, 2.0d, var64);
//     var49.draw(var52, var64);
//     org.jfree.data.category.CategoryDataset var89 = null;
//     org.jfree.chart.axis.CategoryAxis var90 = null;
//     org.jfree.chart.axis.ValueAxis var91 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var92 = null;
//     org.jfree.chart.plot.CategoryPlot var93 = new org.jfree.chart.plot.CategoryPlot(var89, var90, var91, var92);
//     org.jfree.chart.util.RectangleEdge var95 = var93.getDomainAxisEdge((-1));
//     java.lang.String var96 = var95.toString();
//     java.util.List var97 = var0.refreshTicks(var31, var32, var64, var95);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test321"); }
// 
// 
//     java.awt.Color var8 = java.awt.Color.getHSBColor(100.0f, 100.0f, 0.0f);
//     org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder(0.0d, 2.0d, 2.0d, 0.0d, (java.awt.Paint)var8);
//     java.awt.Color var10 = var8.darker();
//     org.jfree.chart.util.StrokeList var11 = new org.jfree.chart.util.StrokeList();
//     java.lang.Object var12 = var11.clone();
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     var18.clearDomainAxes();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var18);
//     java.awt.RenderingHints var26 = var25.getRenderingHints();
//     java.awt.Stroke var27 = var25.getBorderStroke();
//     var11.setStroke(15, var27);
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(8.0d, (java.awt.Paint)var10, var27);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.data.category.CategoryDataset var32 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var32, var33, var34, var35);
//     double var37 = var36.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var38 = var36.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var39 = var36.getRowRenderingOrder();
//     java.awt.Stroke var40 = var36.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = var36.getRendererForDataset(var41);
//     org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var36);
//     boolean var44 = var30.hasListener((java.util.EventListener)var43);
//     java.awt.Paint var47 = var30.getItemOutlinePaint((-253), (-8323073));
//     java.awt.Paint var48 = var30.getBasePaint();
//     var29.setLabelPaint(var48);
//     
//     // Checks the contract:  equals-hashcode on var18 and var36
//     assertTrue("Contract failed: equals-hashcode on var18 and var36", var18.equals(var36) ? var18.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var18
//     assertTrue("Contract failed: equals-hashcode on var36 and var18", var36.equals(var18) ? var36.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var38
//     assertTrue("Contract failed: equals-hashcode on var20 and var38", var20.equals(var38) ? var20.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var20
//     assertTrue("Contract failed: equals-hashcode on var38 and var20", var38.equals(var20) ? var38.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test322"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.Object var1 = var0.clone();
//     var0.setFixedDimension(10.0d);
//     double var4 = var0.getUpperMargin();
//     org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
//     org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("hi!");
//     var10.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var16 = var10.getBounds();
//     org.jfree.chart.util.RectangleAnchor var17 = null;
//     java.awt.geom.Point2D var18 = org.jfree.chart.util.RectangleAnchor.coordinates(var16, var17);
//     var7.setShape(0, (java.awt.Shape)var16);
//     org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.util.RectangleInsets var21 = var20.getInsets();
//     org.jfree.chart.util.UnitType var22 = var21.getUnitType();
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     double var28 = var27.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var29 = var27.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     java.util.List var31 = var27.getCategoriesForAxis(var30);
//     double var32 = var27.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
//     boolean var34 = var22.equals((java.lang.Object)var27);
//     org.jfree.chart.util.RectangleEdge var36 = var27.getDomainAxisEdge(10);
//     java.lang.String var37 = var36.toString();
//     double var38 = var0.getCategoryMiddle((-589829), 1, var16, var36);
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     double var40 = var39.getLowerMargin();
//     org.jfree.chart.axis.NumberTickUnit var41 = var39.getTickUnit();
//     var39.setAutoTickUnitSelection(false);
//     var39.setLabelAngle(100.0d);
//     org.jfree.chart.axis.TickUnits var46 = new org.jfree.chart.axis.TickUnits();
//     int var47 = var46.size();
//     int var48 = var46.size();
//     var39.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource)var46);
//     org.jfree.data.category.CategoryDataset var50 = null;
//     org.jfree.chart.axis.CategoryAxis var51 = null;
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var50, var51, var52, var53);
//     double var55 = var54.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var56 = var54.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var57 = null;
//     java.util.List var58 = var54.getCategoriesForAxis(var57);
//     double var59 = var54.getAnchorValue();
//     var54.clearDomainMarkers();
//     var54.mapDatasetToRangeAxis(1, (-253));
//     org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis();
//     double var65 = var64.getLowerMargin();
//     org.jfree.chart.axis.NumberTickUnit var66 = var64.getTickUnit();
//     org.jfree.data.Range var67 = var54.getDataRange((org.jfree.chart.axis.ValueAxis)var64);
//     boolean var68 = var64.isAutoRange();
//     var64.setRangeAboutValue(2.0d, Double.NaN);
//     org.jfree.chart.axis.NumberTickUnit var73 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     org.jfree.chart.block.LabelBlock var75 = new org.jfree.chart.block.LabelBlock("hi!");
//     java.lang.String var76 = var75.getID();
//     int var77 = var73.compareTo((java.lang.Object)var75);
//     var64.setTickUnit(var73);
//     boolean var79 = var46.equals((java.lang.Object)var73);
//     java.lang.String var81 = var73.valueToString((-2.0d));
//     java.awt.Paint var82 = var0.getTickLabelPaint((java.lang.Comparable)var73);
//     
//     // Checks the contract:  equals-hashcode on var27 and var54
//     assertTrue("Contract failed: equals-hashcode on var27 and var54", var27.equals(var54) ? var27.hashCode() == var54.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var27 and var54.", var27.equals(var54) == var54.equals(var27));
//     
//     // Checks the contract:  equals-hashcode on var29 and var56
//     assertTrue("Contract failed: equals-hashcode on var29 and var56", var29.equals(var56) ? var29.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var29
//     assertTrue("Contract failed: equals-hashcode on var56 and var29", var56.equals(var29) ? var56.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test323"); }


    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "hi!", "hi!");
    org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var6);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var6, var13);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var16 = var15.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var15.getLegendItemToolTipGenerator();
    java.awt.Shape var19 = var15.lookupSeriesShape(0);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    double var25 = var24.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var26 = var24.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var27 = null;
    java.util.List var28 = var24.getCategoriesForAxis(var27);
    double var29 = var24.getAnchorValue();
    var24.clearDomainAxes();
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
    org.jfree.chart.title.LegendTitle var33 = var31.getLegend(10);
    java.awt.Stroke var34 = var31.getBorderStroke();
    var15.setBaseStroke(var34);
    boolean var38 = var15.isItemLabelVisible(0, (-165));
    java.awt.Stroke var41 = var15.getItemOutlineStroke(15, (-16777215));
    java.awt.Paint var42 = null;
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=0]", "RectangleConstraintType.RANGE", "[size=1]", "VerticalAlignment.CENTER", var6, var41, var42);
    java.lang.Comparable var44 = var43.getSeriesKey();
    java.awt.Stroke var45 = var43.getOutlineStroke();
    java.awt.Paint var46 = var43.getLinePaint();
    boolean var47 = var43.isShapeOutlineVisible();
    java.lang.String var48 = var43.getLabel();
    java.awt.Shape var49 = var43.getShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=0]"+ "'", var48.equals("org.jfree.chart.event.ChartChangeEvent[source=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test324"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    double var2 = var1.getLowerMargin();
    var1.setLabelToolTip("org.jfree.chart.event.ChartChangeEvent[source=0]");
    java.awt.Shape var5 = var1.getUpArrow();
    org.jfree.chart.entity.CategoryLabelEntity var8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"Category Plot", var5, "Range[-1.0,-1.0]", "AxisLocation.TOP_OR_LEFT");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test325"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var4.rendererChanged(var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    int var12 = var4.getRangeAxisIndex(var11);
    org.jfree.chart.block.LineBorder var13 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var14 = var13.getPaint();
    var4.setOutlinePaint(var14);
    java.awt.Paint var16 = var4.getDomainGridlinePaint();
    org.jfree.chart.axis.AxisSpace var17 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var18 = var17.clone();
    org.jfree.chart.axis.AxisSpace var19 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var20 = var19.clone();
    var17.ensureAtLeast(var19);
    org.jfree.chart.axis.AxisSpace var22 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var23 = var22.clone();
    org.jfree.chart.axis.AxisSpace var24 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var25 = var24.clone();
    var22.ensureAtLeast(var24);
    var17.ensureAtLeast(var24);
    java.lang.Object var28 = var17.clone();
    java.lang.Object var29 = var17.clone();
    var4.setFixedDomainAxisSpace(var17);
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.Object var32 = var31.clone();
    var31.setFixedDimension(10.0d);
    double var35 = var31.getUpperMargin();
    org.jfree.chart.event.AxisChangeEvent var36 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var31);
    var4.axisChanged(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.05d);

  }

}
