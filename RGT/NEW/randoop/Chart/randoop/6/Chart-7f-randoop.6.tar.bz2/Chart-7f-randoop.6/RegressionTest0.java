import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues3.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        try {
            timePeriodValues3.delete((int) (short) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues3.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = null;
        try {
            timePeriodValues3.add(timePeriodValue11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = null;
        try {
            timePeriodValues3.add(timePeriodValue4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = null;
        try {
            timePeriodValues3.add(timePeriodValue7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.update(100, (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(100, (int) ' ');
        int int10 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=-1]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (int) (short) 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day8.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day8.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test036");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        long long13 = day8.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues3.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = null;
        try {
            timePeriodValues3.add(timePeriodValue5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day8.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.Number number10 = null;
        try {
            timePeriodValues3.update(2019, number10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        java.lang.String str2 = day0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
        timePeriodValues3.add(timePeriodValue12);
        timePeriodValue12.setValue((java.lang.Number) (short) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass20 = timePeriodValues19.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues19);
        int int22 = timePeriodValues19.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues19.createCopy(100, (int) ' ');
        boolean boolean26 = timePeriodValue12.equals((java.lang.Object) ' ');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.Class<?> wildcardClass9 = timePeriodValues3.getClass();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date11);
        boolean boolean13 = timePeriodValues3.equals((java.lang.Object) seriesChangeEvent12);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = day0.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.SerialDate serialDate12 = day0.getSerialDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.previous();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day8.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day8.getMiddleMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=-1]");
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        java.lang.String str2 = day0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.String str7 = timePeriodValues6.getDescription();
        boolean boolean8 = year0.equals((java.lang.Object) str7);
        java.util.Calendar calendar9 = null;
        try {
            year0.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1) + "'", obj2.equals((-1)));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues3.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.previous();
//        long long12 = regularTimePeriod11.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560365999999L + "'", long12 == 1560365999999L);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        java.lang.Number number9 = null;
        try {
            timePeriodValues7.update((int) (byte) 0, number9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 8, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        boolean boolean6 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = day19.getLastMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.lang.String str12 = day8.toString();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day8.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        org.jfree.data.time.TimePeriod timePeriod17 = null;
        java.lang.Number number18 = null;
        try {
            timePeriodValues16.add(timePeriod17, number18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        int int14 = day8.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, 7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue21 = timePeriodValues3.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (7) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        timePeriodValues3.setNotify(false);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        java.util.Date date14 = regularTimePeriod13.getEnd();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) seriesChangeEvent5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) (short) 1);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) (short) 1);
        timePeriodValue10.setValue((java.lang.Number) 12);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) (short) 1);
        boolean boolean19 = timePeriodValue10.equals((java.lang.Object) timePeriodValue18);
        try {
            int int20 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValue18);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValue cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Calendar calendar12 = null;
//        try {
//            day8.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = regularTimePeriod13.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        try {
            java.lang.Number number9 = timePeriodValues7.getValue(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int6 = timePeriodValues5.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues5.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (-1));
//        long long13 = day10.getFirstMillisecond();
//        java.util.Date date14 = day10.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long18 = simpleTimePeriod17.getStartMillis();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean20 = simpleTimePeriod17.equals((java.lang.Object) timeZone19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date14, timeZone19);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long27 = simpleTimePeriod26.getStartMillis();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean29 = simpleTimePeriod26.equals((java.lang.Object) timeZone28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date23, timeZone28);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date14, timeZone28);
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date1, date14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '#', 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        int int9 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(100, (int) ' ');
        try {
            java.lang.Number number11 = timePeriodValues3.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int16 = timePeriodValues15.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues15.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (-1));
//        long long23 = day20.getFirstMillisecond();
//        java.util.Date date24 = day20.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long28 = simpleTimePeriod27.getStartMillis();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean30 = simpleTimePeriod27.equals((java.lang.Object) timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date24, timeZone29);
//        int int32 = day8.compareTo((java.lang.Object) date24);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date36 = simpleTimePeriod35.getEnd();
//        java.lang.Object obj37 = null;
//        boolean boolean38 = simpleTimePeriod35.equals(obj37);
//        long long39 = simpleTimePeriod35.getStartMillis();
//        java.util.Date date40 = simpleTimePeriod35.getStart();
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date24, date40);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(date40);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        int int14 = timePeriodValues3.getMinMiddleIndex();
        try {
            timePeriodValues3.update((int) (short) 10, (java.lang.Number) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        int int14 = day8.getMonth();
//        long long15 = day8.getLastMillisecond();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = day8.getMiddleMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues3.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day8.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod14);
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = regularTimePeriod14.getMiddleMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = null;
        try {
            timePeriodValues3.add(timePeriodValue17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (short) -1 + "'", obj3.equals((short) -1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
//        long long6 = day5.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.lang.Object obj4 = null;
        boolean boolean5 = simpleTimePeriod2.equals(obj4);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 100L);
        try {
            int int9 = simpleTimePeriod2.compareTo((java.lang.Object) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
        timePeriodValues3.add(timePeriodValue12);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date18 = simpleTimePeriod17.getEnd();
        java.lang.Object obj19 = null;
        boolean boolean20 = simpleTimePeriod17.equals(obj19);
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod17, (double) 100L);
        timePeriodValues3.add(timePeriodValue22);
        java.lang.Object obj24 = timePeriodValue22.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 10.0d + "'", comparable14.equals(10.0d));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj24);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        long long14 = regularTimePeriod13.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560538799999L + "'", long14 == 1560538799999L);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date15);
        boolean boolean17 = day8.equals((java.lang.Object) seriesChangeEvent16);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = day8.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, 0.0d);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day3.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        timePeriodValue3.setValue((java.lang.Number) 5);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) -1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        java.lang.String str14 = day8.toString();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day8.getMiddleMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) seriesChangeEvent5);
        long long7 = simpleTimePeriod2.getStartMillis();
        try {
            int int9 = simpleTimePeriod2.compareTo((java.lang.Object) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Float cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a', "hi!", "");
        java.lang.Class<?> wildcardClass6 = timePeriodValues5.getClass();
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.String str7 = timePeriodValues6.getDescription();
        boolean boolean8 = year0.equals((java.lang.Object) str7);
        long long9 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.next();
        long long11 = regularTimePeriod10.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1593676799999L + "'", long11 == 1593676799999L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        java.lang.Object obj8 = timePeriodValues3.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day11, (double) 7);
        java.lang.String str14 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.lang.String str12 = day8.toString();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day8.getMiddleMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "", "org.jfree.data.general.SeriesChangeEvent[source=-1]", "13-June-2019");
        boolean boolean4 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean35 = timePeriodValues33.equals((java.lang.Object) (short) -1);
//        int int36 = timePeriodValues33.getMinEndIndex();
//        timePeriodValues33.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDescription("");
//        int int43 = timePeriodValues33.getMaxStartIndex();
//        int int44 = timePeriodValues33.getMinMiddleIndex();
//        int int45 = year29.compareTo((java.lang.Object) timePeriodValues33);
//        java.lang.Object obj46 = null;
//        int int47 = year29.compareTo(obj46);
//        java.util.Calendar calendar48 = null;
//        try {
//            year29.peg(calendar48);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', (int) (byte) 1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        timePeriodValue3.setValue((java.lang.Number) 0);
//        java.lang.String str6 = timePeriodValue3.toString();
//        java.lang.Number number7 = timePeriodValue3.getValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[13-June-2019,0]" + "'", str6.equals("TimePeriodValue[13-June-2019,0]"));
//        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
        int int14 = day8.getMonth();
        org.jfree.data.time.SerialDate serialDate15 = day8.getSerialDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560538799999L, "hi!", "TimePeriodValue[13-June-2019,0]");
        timePeriodValues3.delete(12, (int) (byte) -1);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getFirstMillisecond();
//        boolean boolean7 = day0.equals((java.lang.Object) (short) 10);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date5);
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
//        boolean boolean9 = day3.equals((java.lang.Object) year8);
//        long long10 = day3.getLastMillisecond();
//        long long11 = day3.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 1560409200000L);
        long long12 = simpleTimePeriod8.getStartMillis();
        long long13 = simpleTimePeriod8.getStartMillis();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("");
        java.lang.String str11 = timePeriodValues3.getDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
        boolean boolean9 = day3.equals((java.lang.Object) year8);
        long long10 = year8.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean9 = timePeriodValues7.equals((java.lang.Object) (short) -1);
        int int10 = timePeriodValues7.getMinEndIndex();
        timePeriodValues7.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues7.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener15);
        int int17 = year0.compareTo((java.lang.Object) timePeriodValues7);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year0.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long7 = simpleTimePeriod6.getStartMillis();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean9 = simpleTimePeriod6.equals((java.lang.Object) timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        boolean boolean12 = day0.equals((java.lang.Object) year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day0.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.previous();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day8.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.util.Date date0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day1.previous();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(date0, date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        java.util.Date date18 = day17.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18);
        java.util.Date date21 = day20.getStart();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 10L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMaxStartIndex();
        boolean boolean9 = timePeriodValues3.getNotify();
        java.lang.String str10 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        java.lang.Class<?> wildcardClass8 = regularTimePeriod7.getClass();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
//        timePeriodValues3.add(timePeriodValue12);
//        java.lang.String str14 = timePeriodValue12.toString();
//        java.lang.Number number15 = timePeriodValue12.getValue();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[13-June-2019,1]" + "'", str14.equals("TimePeriodValue[13-June-2019,1]"));
//        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) 1 + "'", number15.equals((short) 1));
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        try {
            java.lang.Number number9 = timePeriodValues3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
        timePeriodValues3.add(timePeriodValue12);
        timePeriodValue12.setValue((java.lang.Number) (short) 10);
        timePeriodValue12.setValue((java.lang.Number) 13);
        java.lang.Object obj18 = timePeriodValue12.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) seriesChangeEvent5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean6, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getEnd();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day14.previous();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 8);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        int int14 = day8.getMonth();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day8.getMiddleMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean14 = timePeriodValues12.equals((java.lang.Object) (short) -1);
        int int15 = timePeriodValues12.getMinEndIndex();
        timePeriodValues12.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues12.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues12.addChangeListener(seriesChangeListener20);
        int int22 = timePeriodValues12.getMaxStartIndex();
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues12);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue25 = timePeriodValues12.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
        java.util.Date date10 = day6.getStart();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day6.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
        boolean boolean9 = day3.equals((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day3.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = day0.equals((java.lang.Object) timePeriodValues7);
        try {
            timePeriodValues7.update((int) (byte) -1, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("hi!");
        boolean boolean10 = timePeriodValues3.getNotify();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        java.lang.Object obj11 = timePeriodValues3.clone();
        try {
            timePeriodValues3.update(6, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj11);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day8.next();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        timePeriodValues3.setRangeDescription("13-June-2019");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        long long3 = year0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,1]");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues3.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        int int3 = day0.getMonth();
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date15);
        boolean boolean17 = day8.equals((java.lang.Object) seriesChangeEvent16);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = day8.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getItemCount();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        try {
            org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValues3.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "TimePeriodValue[13-June-2019,0]", "");
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str5.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        timePeriodValues3.fireSeriesChanged();
        java.lang.Comparable comparable21 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 10.0d + "'", comparable21.equals(10.0d));
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
//        timePeriodValue3.setValue((java.lang.Number) 12);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (short) 1);
//        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) timePeriodValue11);
//        java.lang.String str13 = timePeriodValue11.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[13-June-2019,1]" + "'", str13.equals("TimePeriodValue[13-June-2019,1]"));
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,1]");
        java.lang.String str11 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        long long14 = day8.getFirstMillisecond();
//        int int15 = day8.getMonth();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[13-June-2019,1]");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: TimePeriodValue[13-June-2019,1]" + "'", str2.equals("org.jfree.data.general.SeriesException: TimePeriodValue[13-June-2019,1]"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getItemCount();
        java.lang.Comparable comparable5 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 10.0d + "'", comparable5.equals(10.0d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        java.lang.String str17 = timePeriodValues16.getRangeDescription();
        int int18 = timePeriodValues16.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, (int) (short) 0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long5 = simpleTimePeriod4.getStartMillis();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean7 = simpleTimePeriod4.equals((java.lang.Object) timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        int int10 = year8.getYear();
        java.lang.Object obj11 = null;
        boolean boolean12 = year8.equals(obj11);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues3.createCopy((int) (short) 1, 0);
        try {
            java.lang.Number number24 = timePeriodValues3.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriodValues22);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 1560409200000L);
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        java.lang.Comparable comparable13 = null;
        try {
            timePeriodValues3.setKey(comparable13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        long long14 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day8.previous();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = regularTimePeriod15.getMiddleMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        int int14 = day8.getMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day8.getSerialDate();
//        java.lang.String str16 = day8.toString();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date15);
//        boolean boolean17 = day8.equals((java.lang.Object) seriesChangeEvent16);
//        long long18 = day8.getLastMillisecond();
//        java.lang.Class<?> wildcardClass19 = day8.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560495599999L + "'", long18 == 1560495599999L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long7 = simpleTimePeriod6.getStartMillis();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean9 = simpleTimePeriod6.equals((java.lang.Object) timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        boolean boolean12 = day0.equals((java.lang.Object) year10);
        long long13 = year10.getLastMillisecond();
        long long14 = year10.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        int int9 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        long long3 = year0.getFirstMillisecond();
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
        timePeriodValue3.setValue((java.lang.Number) 12);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (short) 1);
        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) timePeriodValue11);
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue11.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriod13);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a', "hi!", "");
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues5.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        timePeriodValues3.setRangeDescription("13-June-2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean18 = timePeriodValues16.equals((java.lang.Object) (short) -1);
        int int19 = timePeriodValues16.getMinEndIndex();
        timePeriodValues16.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        java.util.Date date23 = day22.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day22, (java.lang.Number) (short) 1);
        timePeriodValues16.add(timePeriodValue25);
        java.lang.Comparable comparable27 = timePeriodValues16.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        java.lang.Object obj32 = null;
        boolean boolean33 = simpleTimePeriod30.equals(obj32);
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod30, (double) 100L);
        timePeriodValues16.add(timePeriodValue35);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date40 = simpleTimePeriod39.getEnd();
        boolean boolean41 = timePeriodValue35.equals((java.lang.Object) date40);
        java.lang.Class<?> wildcardClass42 = timePeriodValue35.getClass();
        timePeriodValues3.add(timePeriodValue35);
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues46 = timePeriodValues3.createCopy((int) (byte) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 10.0d + "'", comparable27.equals(10.0d));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
        boolean boolean9 = day3.equals((java.lang.Object) year8);
        int int10 = year8.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        int int7 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) ' ', (long) (short) 100);
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) (short) 100);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date8 = simpleTimePeriod7.getEnd();
//        long long9 = simpleTimePeriod7.getStartMillis();
//        java.util.Date date10 = simpleTimePeriod7.getStart();
//        boolean boolean12 = simpleTimePeriod7.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        int int17 = simpleTimePeriod7.compareTo((java.lang.Object) simpleTimePeriod15);
//        java.util.Date date18 = simpleTimePeriod15.getEnd();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass24 = timePeriodValues23.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass30 = timePeriodValues29.getClass();
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int36 = timePeriodValues35.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = timePeriodValues35.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        timePeriodValues39.add((org.jfree.data.time.TimePeriod) day40, (java.lang.Number) (-1));
//        long long43 = day40.getFirstMillisecond();
//        java.util.Date date44 = day40.getStart();
//        java.util.Date date45 = day40.getStart();
//        java.util.TimeZone timeZone46 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date45, timeZone46);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long51 = simpleTimePeriod50.getStartMillis();
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean53 = simpleTimePeriod50.equals((java.lang.Object) timeZone52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date45, timeZone52);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date18, timeZone52);
//        boolean boolean56 = simpleTimePeriod2.equals((java.lang.Object) date18);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560409200000L + "'", long43 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,1]");
        int int11 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 1560409200000L);
        long long12 = simpleTimePeriod8.getStartMillis();
        java.lang.Number number13 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, number13);
        java.lang.Number number15 = timePeriodValue14.getValue();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setRangeDescription("");
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int10 = timePeriodValues9.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues9.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) (-1));
//        long long17 = day14.getFirstMillisecond();
//        java.util.Date date18 = day14.getStart();
//        java.util.Date date19 = day14.getStart();
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date19, timeZone20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass26 = timePeriodValues25.getClass();
//        timePeriodValues25.fireSeriesChanged();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day28, (double) 12);
//        java.util.Date date32 = day28.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass37 = timePeriodValues36.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass43 = timePeriodValues42.getClass();
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int49 = timePeriodValues48.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues48.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        timePeriodValues52.add((org.jfree.data.time.TimePeriod) day53, (java.lang.Number) (-1));
//        long long56 = day53.getFirstMillisecond();
//        java.util.Date date57 = day53.getStart();
//        java.util.Date date58 = day53.getStart();
//        java.util.TimeZone timeZone59 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date58, timeZone59);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long64 = simpleTimePeriod63.getStartMillis();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean66 = simpleTimePeriod63.equals((java.lang.Object) timeZone65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date58, timeZone65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date32, timeZone65);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date32);
//        java.util.Calendar calendar70 = null;
//        try {
//            year69.peg(calendar70);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560409200000L + "'", long56 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date22 = simpleTimePeriod21.getEnd();
        long long23 = simpleTimePeriod21.getStartMillis();
        java.util.Date date24 = simpleTimePeriod21.getStart();
        boolean boolean26 = simpleTimePeriod21.equals((java.lang.Object) false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long30 = simpleTimePeriod29.getStartMillis();
        int int31 = simpleTimePeriod21.compareTo((java.lang.Object) simpleTimePeriod29);
        java.lang.Number number32 = null;
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, number32);
        java.util.Date date34 = simpleTimePeriod21.getStart();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(date34);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        java.util.Date date4 = day3.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        long long6 = day3.getFirstMillisecond();
//        long long7 = day3.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean35 = timePeriodValues33.equals((java.lang.Object) (short) -1);
//        int int36 = timePeriodValues33.getMinEndIndex();
//        timePeriodValues33.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDescription("");
//        int int43 = timePeriodValues33.getMaxStartIndex();
//        int int44 = timePeriodValues33.getMinMiddleIndex();
//        int int45 = year29.compareTo((java.lang.Object) timePeriodValues33);
//        java.lang.Object obj46 = null;
//        int int47 = year29.compareTo(obj46);
//        int int48 = year29.getYear();
//        java.lang.String str49 = year29.toString();
//        java.util.Calendar calendar50 = null;
//        try {
//            year29.peg(calendar50);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019" + "'", str49.equals("2019"));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,0]");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException6.addSuppressed((java.lang.Throwable) seriesException8);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, 0.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (double) (byte) -1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("13-June-2019");
        try {
            timePeriodValues3.update(0, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        java.lang.Class<?> wildcardClass20 = day19.getClass();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMaxMiddleIndex();
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) 10);
//        long long13 = day10.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getItemCount();
        try {
            java.lang.Number number6 = timePeriodValues3.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long11 = simpleTimePeriod10.getStartMillis();
        int int12 = simpleTimePeriod2.compareTo((java.lang.Object) simpleTimePeriod10);
        java.util.Date date13 = simpleTimePeriod10.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getEnd();
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener23);
        boolean boolean25 = year14.equals((java.lang.Object) timePeriodValues18);
        int int26 = timePeriodValues18.getMinStartIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues3.createCopy((int) (short) 1, 0);
        try {
            timePeriodValues3.delete((int) (short) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriodValues22);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.previous();
//        long long12 = day8.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues3.createCopy((int) (short) 1, 0);
        java.lang.Object obj23 = timePeriodValues3.clone();
        java.lang.String str24 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriodValues22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.general.SeriesException: ", "");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
        timePeriodValues3.add(timePeriodValue12);
        int int14 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean35 = timePeriodValues33.equals((java.lang.Object) (short) -1);
//        int int36 = timePeriodValues33.getMinEndIndex();
//        timePeriodValues33.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDescription("");
//        int int43 = timePeriodValues33.getMaxStartIndex();
//        int int44 = timePeriodValues33.getMinMiddleIndex();
//        int int45 = year29.compareTo((java.lang.Object) timePeriodValues33);
//        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int50 = timePeriodValues49.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = timePeriodValues49.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        timePeriodValues53.add((org.jfree.data.time.TimePeriod) day54, (java.lang.Number) (-1));
//        long long57 = day54.getFirstMillisecond();
//        java.util.Date date58 = day54.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long62 = simpleTimePeriod61.getStartMillis();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean64 = simpleTimePeriod61.equals((java.lang.Object) timeZone63);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date58, timeZone63);
//        int int66 = day65.getDayOfMonth();
//        timePeriodValues33.add((org.jfree.data.time.TimePeriod) day65, (double) (short) 10);
//        java.lang.String str69 = day65.toString();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues53);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560409200000L + "'", long57 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 13 + "'", int66 == 13);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "13-June-2019" + "'", str69.equals("13-June-2019"));
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int10 = timePeriodValues9.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues9.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) (-1));
//        long long17 = day14.getFirstMillisecond();
//        java.util.Date date18 = day14.getStart();
//        java.util.Date date19 = day14.getStart();
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date19, timeZone20);
//        java.util.TimeZone timeZone22 = null;
//        try {
//            org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19, timeZone22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
        timePeriodValues3.add(timePeriodValue12);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date18 = simpleTimePeriod17.getEnd();
        java.lang.Object obj19 = null;
        boolean boolean20 = simpleTimePeriod17.equals(obj19);
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod17, (double) 100L);
        timePeriodValues3.add(timePeriodValue22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date27 = simpleTimePeriod26.getEnd();
        boolean boolean28 = timePeriodValue22.equals((java.lang.Object) date27);
        java.lang.Class<?> wildcardClass29 = timePeriodValue22.getClass();
        java.lang.String str30 = timePeriodValue22.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 10.0d + "'", comparable14.equals(10.0d));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        long long14 = day8.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
//        boolean boolean17 = day8.equals((java.lang.Object) "");
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day8.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod14);
//        int int16 = timePeriodValues15.getMinMiddleIndex();
//        int int17 = timePeriodValues15.getMaxEndIndex();
//        java.lang.String str18 = timePeriodValues15.getRangeDescription();
//        try {
//            timePeriodValues15.update(10, (java.lang.Number) 0.0f);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        int int7 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        int int14 = day8.getMonth();
//        long long15 = day8.getLastMillisecond();
//        long long16 = day8.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate17 = day8.getSerialDate();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate17);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
        timePeriodValues3.add(timePeriodValue12);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date18 = simpleTimePeriod17.getEnd();
        java.lang.Object obj19 = null;
        boolean boolean20 = simpleTimePeriod17.equals(obj19);
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod17, (double) 100L);
        timePeriodValues3.add(timePeriodValue22);
        int int24 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 10.0d + "'", comparable14.equals(10.0d));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean9 = timePeriodValues7.equals((java.lang.Object) (short) -1);
        int int10 = timePeriodValues7.getMinEndIndex();
        timePeriodValues7.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues7.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener15);
        int int17 = year0.compareTo((java.lang.Object) timePeriodValues7);
        int int18 = year0.getYear();
        long long19 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean35 = timePeriodValues33.equals((java.lang.Object) (short) -1);
//        int int36 = timePeriodValues33.getMinEndIndex();
//        timePeriodValues33.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDescription("");
//        int int43 = timePeriodValues33.getMaxStartIndex();
//        int int44 = timePeriodValues33.getMinMiddleIndex();
//        int int45 = year29.compareTo((java.lang.Object) timePeriodValues33);
//        long long46 = year29.getFirstMillisecond();
//        java.lang.Object obj47 = null;
//        int int48 = year29.compareTo(obj47);
//        java.util.Calendar calendar49 = null;
//        try {
//            year29.peg(calendar49);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        int int9 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        long long14 = day8.getSerialIndex();
//        int int15 = day8.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int15, "13-June-2019", "2019");
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long11 = simpleTimePeriod10.getStartMillis();
        int int12 = simpleTimePeriod2.compareTo((java.lang.Object) simpleTimePeriod10);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean18 = timePeriodValues16.equals((java.lang.Object) (short) -1);
        int int19 = timePeriodValues16.getMinEndIndex();
        timePeriodValues16.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues16.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) ' ', (long) (short) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (double) (short) 100);
        timePeriodValues16.add(timePeriodValue30);
        try {
            int int32 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues16);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.delete(8, (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        java.lang.String str9 = seriesChangeEvent8.toString();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, 12, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, 0.0d);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 1546329600000L);
        int int12 = day3.compareTo((java.lang.Object) 1546329600000L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
        java.util.Date date10 = day6.getStart();
        java.util.Calendar calendar11 = null;
        try {
            day6.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timePeriod4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        try {
            timePeriodValues3.update(3, (java.lang.Number) 1560409200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) 10);
        java.lang.Class<?> wildcardClass13 = timePeriodValues3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass16 = timePeriodValues15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int22 = timePeriodValues21.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues21.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (-1));
//        long long29 = day26.getFirstMillisecond();
//        java.util.Date date30 = day26.getStart();
//        java.util.Date date31 = day26.getStart();
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date31, timeZone32);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long37 = simpleTimePeriod36.getStartMillis();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean39 = simpleTimePeriod36.equals((java.lang.Object) timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date31, timeZone38);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date5, timeZone38);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date3, timeZone38);
//        java.util.Calendar calendar43 = null;
//        try {
//            day42.peg(calendar43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: 13-June-2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getEnd();
//        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
//        java.util.Date date6 = day3.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int11 = timePeriodValues10.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues10.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) (-1));
//        long long18 = day15.getFirstMillisecond();
//        java.util.Date date19 = day15.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long23 = simpleTimePeriod22.getStartMillis();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean25 = simpleTimePeriod22.equals((java.lang.Object) timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date19, timeZone24);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.util.Date date28 = day27.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long32 = simpleTimePeriod31.getStartMillis();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean34 = simpleTimePeriod31.equals((java.lang.Object) timeZone33);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date28, timeZone33);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date19, timeZone33);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date6, timeZone33);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,0]");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable throwable9 = null;
        try {
            timePeriodFormatException7.addSuppressed(throwable9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1);
        java.lang.String str7 = year6.toString();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year6.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) ' ', (long) (short) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) (short) 100);
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) simpleTimePeriod15);
        boolean boolean17 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setDescription("");
//        int int13 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
//        timePeriodValues3.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener19);
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int25 = timePeriodValues24.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = timePeriodValues24.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) (-1));
//        long long32 = day29.getFirstMillisecond();
//        java.util.Date date33 = day29.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day29.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod35);
//        int int37 = timePeriodValues36.getMinMiddleIndex();
//        int int38 = timePeriodValues36.getMaxEndIndex();
//        java.lang.Object obj39 = timePeriodValues36.clone();
//        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean45 = timePeriodValues43.equals((java.lang.Object) (short) -1);
//        int int46 = timePeriodValues43.getMinEndIndex();
//        timePeriodValues43.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        java.util.Date date50 = day49.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day49, (java.lang.Number) (short) 1);
//        timePeriodValues43.add(timePeriodValue52);
//        java.lang.Comparable comparable54 = timePeriodValues43.getKey();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date58 = simpleTimePeriod57.getEnd();
//        java.lang.Object obj59 = null;
//        boolean boolean60 = simpleTimePeriod57.equals(obj59);
//        org.jfree.data.time.TimePeriodValue timePeriodValue62 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod57, (double) 100L);
//        timePeriodValues43.add(timePeriodValue62);
//        java.lang.String str64 = timePeriodValue62.toString();
//        timePeriodValues36.add(timePeriodValue62);
//        boolean boolean66 = timePeriodValues3.equals((java.lang.Object) timePeriodValues36);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues16);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560409200000L + "'", long32 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertNotNull(obj39);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + comparable54 + "' != '" + 10.0d + "'", comparable54.equals(10.0d));
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.String str7 = timePeriodValues6.getDescription();
        boolean boolean8 = year0.equals((java.lang.Object) str7);
        long long9 = year0.getFirstMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            year0.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        java.util.Calendar calendar8 = null;
        try {
            year6.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long5 = simpleTimePeriod4.getStartMillis();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean7 = simpleTimePeriod4.equals((java.lang.Object) timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        int int10 = year8.getYear();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year8.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day8.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod14);
//        int int16 = timePeriodValues15.getMinMiddleIndex();
//        int int17 = timePeriodValues15.getMaxEndIndex();
//        java.lang.Object obj18 = timePeriodValues15.clone();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean24 = timePeriodValues22.equals((java.lang.Object) (short) -1);
//        int int25 = timePeriodValues22.getMinEndIndex();
//        timePeriodValues22.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (short) 1);
//        timePeriodValues22.add(timePeriodValue31);
//        java.lang.Comparable comparable33 = timePeriodValues22.getKey();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date37 = simpleTimePeriod36.getEnd();
//        java.lang.Object obj38 = null;
//        boolean boolean39 = simpleTimePeriod36.equals(obj38);
//        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod36, (double) 100L);
//        timePeriodValues22.add(timePeriodValue41);
//        java.lang.String str43 = timePeriodValue41.toString();
//        timePeriodValues15.add(timePeriodValue41);
//        try {
//            org.jfree.data.time.TimePeriod timePeriod46 = timePeriodValues15.getTimePeriod(6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 10.0d + "'", comparable33.equals(10.0d));
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.String str7 = timePeriodValues6.getDescription();
        boolean boolean8 = year0.equals((java.lang.Object) str7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues3.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.lang.Object obj4 = null;
        boolean boolean5 = simpleTimePeriod2.equals(obj4);
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues3.createCopy((int) (short) 1, 0);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) (short) 1);
        boolean boolean28 = timePeriodValue26.equals((java.lang.Object) (short) 1);
        timePeriodValue26.setValue((java.lang.Number) 12);
        timePeriodValues22.add(timePeriodValue26);
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues34 = timePeriodValues22.createCopy(5, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriodValues22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.previous();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day4.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
        timePeriodValues7.fireSeriesChanged();
        int int12 = timePeriodValues7.getMaxEndIndex();
        try {
            timePeriodValues7.update(13, (java.lang.Number) 1562097599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        java.lang.String str30 = year29.toString();
//        long long31 = year29.getLastMillisecond();
//        java.lang.String str32 = year29.toString();
//        long long33 = year29.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean39 = timePeriodValues37.equals((java.lang.Object) (short) -1);
//        int int40 = timePeriodValues37.getMinEndIndex();
//        timePeriodValues37.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
//        timePeriodValues37.removeChangeListener(seriesChangeListener43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timePeriodValues37.addPropertyChangeListener(propertyChangeListener45);
//        int int47 = year29.compareTo((java.lang.Object) propertyChangeListener45);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        long long12 = simpleTimePeriod10.getStartMillis();
        java.util.Date date13 = simpleTimePeriod10.getStart();
        int int14 = day3.compareTo((java.lang.Object) simpleTimePeriod10);
        long long15 = simpleTimePeriod10.getEndMillis();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.String str7 = timePeriodValues6.getDescription();
        boolean boolean8 = year0.equals((java.lang.Object) str7);
        java.lang.String str9 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long5 = simpleTimePeriod4.getStartMillis();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean7 = simpleTimePeriod4.equals((java.lang.Object) timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        int int10 = year8.getYear();
        java.lang.String str11 = year8.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
//        java.lang.String str6 = timePeriodValue3.toString();
//        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue3.getPeriod();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[13-June-2019,1]" + "'", str6.equals("TimePeriodValue[13-June-2019,1]"));
//        org.junit.Assert.assertNotNull(timePeriod7);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getFirstMillisecond();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day8.getLastMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        long long4 = day3.getLastMillisecond();
//        java.lang.String str5 = day3.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        java.lang.Object obj11 = timePeriodValues3.clone();
        int int12 = timePeriodValues3.getItemCount();
        try {
            java.lang.Number number14 = timePeriodValues3.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        long long2 = day0.getFirstMillisecond();
//        java.util.Date date3 = day0.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(0, (int) (byte) -1);
        java.lang.Object obj14 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(obj14);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        long long14 = day8.getFirstMillisecond();
//        long long15 = day8.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        int int14 = day8.getMonth();
//        long long15 = day8.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass20 = timePeriodValues19.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues19);
//        int int22 = timePeriodValues19.getMinMiddleIndex();
//        java.lang.String str23 = timePeriodValues19.getDomainDescription();
//        timePeriodValues19.setNotify(false);
//        timePeriodValues19.setNotify(false);
//        int int28 = day8.compareTo((java.lang.Object) timePeriodValues19);
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int33 = timePeriodValues32.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = timePeriodValues32.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        timePeriodValues36.add((org.jfree.data.time.TimePeriod) day37, (java.lang.Number) (-1));
//        long long40 = day37.getFirstMillisecond();
//        java.util.Date date41 = day37.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long45 = simpleTimePeriod44.getStartMillis();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean47 = simpleTimePeriod44.equals((java.lang.Object) timeZone46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date41, timeZone46);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        java.util.Date date50 = day49.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long54 = simpleTimePeriod53.getStartMillis();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean56 = simpleTimePeriod53.equals((java.lang.Object) timeZone55);
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date50, timeZone55);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date41, timeZone55);
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year58, (java.lang.Number) (short) 10);
//        java.util.Calendar calendar61 = null;
//        try {
//            long long62 = year58.getLastMillisecond(calendar61);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560452399999L + "'", long15 == 1560452399999L);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560409200000L + "'", long40 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
        java.util.Date date10 = day6.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
        timePeriodValues11.setDescription("org.jfree.data.general.SeriesException: 13-June-2019");
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: 13-June-2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        int int12 = timePeriodValues9.getMaxMiddleIndex();
//        boolean boolean13 = timePeriodValues9.isEmpty();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        boolean boolean15 = timePeriodValue3.equals((java.lang.Object) timePeriodValues9);
//        java.lang.String str16 = timePeriodValue3.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass21 = timePeriodValues20.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues20);
//        int int23 = timePeriodValues20.getMaxMiddleIndex();
//        java.lang.Comparable comparable24 = timePeriodValues20.getKey();
//        boolean boolean25 = timePeriodValue3.equals((java.lang.Object) timePeriodValues20);
//        java.lang.Number number26 = timePeriodValue3.getValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[13-June-2019,1]" + "'", str16.equals("TimePeriodValue[13-June-2019,1]"));
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 10.0d + "'", comparable24.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (short) 1 + "'", number26.equals((short) 1));
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setNotify(false);
        java.lang.Class<?> wildcardClass11 = timePeriodValues3.getClass();
        try {
            timePeriodValues3.update(100, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener14);
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(97L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
//        int int6 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
//        long long7 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int12 = timePeriodValues11.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues11.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) (-1));
//        long long19 = day16.getFirstMillisecond();
//        int int20 = day16.getYear();
//        long long21 = day16.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day16.previous();
//        int int23 = day16.getMonth();
//        boolean boolean24 = simpleTimePeriod2.equals((java.lang.Object) day16);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4L + "'", long7 == 4L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        java.lang.Object obj6 = seriesChangeEvent5.getSource();
        java.lang.String str7 = seriesChangeEvent5.toString();
        java.lang.String str8 = seriesChangeEvent5.toString();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        java.lang.String str9 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        int int15 = simpleTimePeriod12.compareTo((java.lang.Object) day13);
        java.util.Date date16 = day13.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day13.next();
        org.jfree.data.time.SerialDate serialDate18 = day13.getSerialDate();
        java.lang.Object obj19 = null;
        boolean boolean20 = day13.equals(obj19);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 0L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10.0d + "'", comparable8.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        int int13 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.String str14 = timePeriodValues3.getDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setKey((java.lang.Comparable) 3);
        try {
            timePeriodValues3.update((int) (byte) 10, (java.lang.Number) 97L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean14 = timePeriodValues12.equals((java.lang.Object) (short) -1);
        int int15 = timePeriodValues12.getMinEndIndex();
        timePeriodValues12.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues12.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues12.addChangeListener(seriesChangeListener20);
        int int22 = timePeriodValues12.getMaxStartIndex();
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues12);
        java.lang.String str24 = timePeriodValues12.getDomainDescription();
        try {
            timePeriodValues12.delete(12, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int16 = timePeriodValues15.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues15.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (-1));
//        long long23 = day20.getFirstMillisecond();
//        java.util.Date date24 = day20.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long28 = simpleTimePeriod27.getStartMillis();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean30 = simpleTimePeriod27.equals((java.lang.Object) timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date24, timeZone29);
//        int int32 = day8.compareTo((java.lang.Object) date24);
//        java.util.Calendar calendar33 = null;
//        try {
//            long long34 = day8.getMiddleMillisecond(calendar33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        java.lang.String str15 = timePeriodValues3.getRangeDescription();
        try {
            java.lang.Number number17 = timePeriodValues3.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        long long12 = simpleTimePeriod10.getStartMillis();
        java.util.Date date13 = simpleTimePeriod10.getStart();
        int int14 = day3.compareTo((java.lang.Object) simpleTimePeriod10);
        java.util.Date date15 = simpleTimePeriod10.getStart();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.Class class0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getEnd();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
        java.util.Date date10 = day5.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.util.Date date21 = day20.getEnd();
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day20.previous();
        java.util.Date date25 = day20.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date25, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date10, timeZone26);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = day28.getLastMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = null;
        try {
            timePeriodValues3.add(timePeriodValue9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str9);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean35 = timePeriodValues33.equals((java.lang.Object) (short) -1);
//        int int36 = timePeriodValues33.getMinEndIndex();
//        timePeriodValues33.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDescription("");
//        int int43 = timePeriodValues33.getMaxStartIndex();
//        int int44 = timePeriodValues33.getMinMiddleIndex();
//        int int45 = year29.compareTo((java.lang.Object) timePeriodValues33);
//        long long46 = year29.getFirstMillisecond();
//        java.lang.Object obj47 = null;
//        int int48 = year29.compareTo(obj47);
//        long long49 = year29.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 2019L + "'", long49 == 2019L);
//    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        long long14 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day8.previous();
//        int int16 = day8.getMonth();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
//        int int12 = timePeriodValues9.getMinEndIndex();
//        timePeriodValues9.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues9.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues9.setDescription("");
//        int int19 = timePeriodValues9.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues9.createCopy((int) (byte) 0, 3);
//        boolean boolean23 = timePeriodValues22.getNotify();
//        boolean boolean24 = day0.equals((java.lang.Object) timePeriodValues22);
//        int int25 = timePeriodValues22.getMaxEndIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date5);
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
//        boolean boolean9 = day3.equals((java.lang.Object) year8);
//        long long10 = day3.getLastMillisecond();
//        long long11 = day3.getFirstMillisecond();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day3.getLastMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setDescription("");
//        int int13 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) (short) 1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
//        boolean boolean21 = timePeriodValue17.equals((java.lang.Object) throwableArray20);
//        timePeriodValues3.add(timePeriodValue17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int27 = timePeriodValues26.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues26.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        timePeriodValues30.add((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) (-1));
//        long long34 = day31.getFirstMillisecond();
//        long long35 = day31.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day31.previous();
//        boolean boolean37 = timePeriodValues3.equals((java.lang.Object) regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(throwableArray20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560409200000L + "'", long34 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560409200000L + "'", long35 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long7 = simpleTimePeriod6.getStartMillis();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean9 = simpleTimePeriod6.equals((java.lang.Object) timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        boolean boolean12 = day0.equals((java.lang.Object) year10);
        java.util.Calendar calendar13 = null;
        try {
            year10.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day3.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        try {
            java.lang.Number number11 = timePeriodValues3.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.util.Date date3 = day2.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long7 = simpleTimePeriod6.getStartMillis();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean9 = simpleTimePeriod6.equals((java.lang.Object) timeZone8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        boolean boolean12 = day0.equals((java.lang.Object) year10);
//        org.jfree.data.time.SerialDate serialDate13 = day0.getSerialDate();
//        long long14 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener20);
        try {
            java.lang.Number number23 = timePeriodValues3.getValue(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
//        timePeriodValue3.setValue((java.lang.Number) 12);
//        java.lang.Number number8 = null;
//        timePeriodValue3.setValue(number8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass18 = timePeriodValues17.getClass();
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
//        boolean boolean21 = day10.equals((java.lang.Object) timePeriodValues17);
//        long long22 = day10.getSerialIndex();
//        boolean boolean23 = timePeriodValue3.equals((java.lang.Object) day10);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43629L + "'", long22 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.previous();
        java.util.Date date9 = day4.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod2, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "TimePeriodValue[13-June-2019,0]");
        java.lang.String str7 = timePeriodValues6.getRangeDescription();
        int int8 = timePeriodValues6.getItemCount();
        timePeriodValues6.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[13-June-2019,0]" + "'", str7.equals("TimePeriodValue[13-June-2019,0]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.previous();
//        java.util.Date date9 = day4.getEnd();
//        java.lang.String str10 = day4.toString();
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.Class<?> wildcardClass9 = timePeriodValues3.getClass();
        org.jfree.data.time.TimePeriod timePeriod10 = null;
        try {
            timePeriodValues3.add(timePeriod10, (java.lang.Number) 1560409200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1577865599999L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass12 = timePeriodValues11.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues11);
        java.lang.String str14 = seriesChangeEvent13.toString();
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) str14);
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener18);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) false);
        long long8 = simpleTimePeriod2.getStartMillis();
        long long9 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        try {
            java.lang.Number number9 = timePeriodValues3.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, (int) 'a', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Object obj9 = timePeriodValues3.clone();
        java.lang.String str10 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        java.lang.String str14 = day8.toString();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        java.lang.Object obj8 = timePeriodValues3.clone();
        timePeriodValues3.setDescription("");
        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,0]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues3.getTimePeriod(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) seriesChangeEvent5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean6, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues9.getItemCount();
        int int13 = timePeriodValues9.getMaxEndIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long11 = simpleTimePeriod10.getStartMillis();
        int int12 = simpleTimePeriod2.compareTo((java.lang.Object) simpleTimePeriod10);
        java.util.Date date13 = simpleTimePeriod10.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        long long16 = regularTimePeriod15.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 15796799999L + "'", long16 == 15796799999L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass12 = timePeriodValues11.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues11);
        java.lang.String str14 = seriesChangeEvent13.toString();
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) str14);
        timePeriodValues3.setRangeDescription("");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue19 = timePeriodValues3.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        java.util.Date date7 = day3.getEnd();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int34 = timePeriodValues33.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = timePeriodValues33.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) (-1));
//        long long41 = day38.getFirstMillisecond();
//        java.util.Date date42 = day38.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long46 = simpleTimePeriod45.getStartMillis();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean48 = simpleTimePeriod45.equals((java.lang.Object) timeZone47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date42, timeZone47);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.util.Date date51 = day50.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long55 = simpleTimePeriod54.getStartMillis();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean57 = simpleTimePeriod54.equals((java.lang.Object) timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date51, timeZone56);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date42, timeZone56);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(date12, date42);
//        java.util.Date date61 = simpleTimePeriod60.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date65 = simpleTimePeriod64.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent67 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
//        boolean boolean68 = simpleTimePeriod64.equals((java.lang.Object) seriesChangeEvent67);
//        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean68, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!");
//        try {
//            int int72 = simpleTimePeriod60.compareTo((java.lang.Object) "org.jfree.data.general.SeriesChangeEvent[source=-1]");
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560409200000L + "'", long41 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int34 = timePeriodValues33.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = timePeriodValues33.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) (-1));
//        long long41 = day38.getFirstMillisecond();
//        java.util.Date date42 = day38.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long46 = simpleTimePeriod45.getStartMillis();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean48 = simpleTimePeriod45.equals((java.lang.Object) timeZone47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date42, timeZone47);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.util.Date date51 = day50.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long55 = simpleTimePeriod54.getStartMillis();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean57 = simpleTimePeriod54.equals((java.lang.Object) timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date51, timeZone56);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date42, timeZone56);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(date12, date42);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year61.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int67 = timePeriodValues66.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues70 = timePeriodValues66.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        timePeriodValues70.add((org.jfree.data.time.TimePeriod) day71, (java.lang.Number) (-1));
//        long long74 = day71.getFirstMillisecond();
//        java.util.Date date75 = day71.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod78 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long79 = simpleTimePeriod78.getStartMillis();
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean81 = simpleTimePeriod78.equals((java.lang.Object) timeZone80);
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date75, timeZone80);
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day();
//        java.util.Date date84 = day83.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod87 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long88 = simpleTimePeriod87.getStartMillis();
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean90 = simpleTimePeriod87.equals((java.lang.Object) timeZone89);
//        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date84, timeZone89);
//        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date75, timeZone89);
//        boolean boolean93 = year61.equals((java.lang.Object) date75);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod94 = new org.jfree.data.time.SimpleTimePeriod(date12, date75);
//        org.jfree.data.time.Year year95 = new org.jfree.data.time.Year(date12);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560409200000L + "'", long41 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues70);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560409200000L + "'", long74 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 0L + "'", long79 == 0L);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 0L + "'", long88 == 0L);
//        org.junit.Assert.assertNotNull(timeZone89);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        java.lang.Object obj8 = timePeriodValues3.clone();
        int int9 = timePeriodValues3.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        org.jfree.data.time.SerialDate serialDate13 = day8.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(serialDate13);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getMiddleMillisecond();
//        int int4 = day0.getYear();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass12 = timePeriodValues11.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues11);
        java.lang.String str14 = seriesChangeEvent13.toString();
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) str14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener16);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 1560409200000L);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (-1));
        java.lang.String str14 = timePeriodValue13.toString();
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue13.getPeriod();
        timePeriodValue13.setValue((java.lang.Number) 4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timePeriod15);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long24 = simpleTimePeriod23.getStartMillis();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean26 = simpleTimePeriod23.equals((java.lang.Object) timeZone25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date12, timeZone25);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,1]");
        int int11 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        java.lang.String str5 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date15 = simpleTimePeriod14.getEnd();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int24 = timePeriodValues23.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues23.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        timePeriodValues27.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (-1));
//        long long31 = day28.getFirstMillisecond();
//        java.util.Date date32 = day28.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long36 = simpleTimePeriod35.getStartMillis();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean38 = simpleTimePeriod35.equals((java.lang.Object) timeZone37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date32, timeZone37);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.util.Date date41 = day40.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long45 = simpleTimePeriod44.getStartMillis();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean47 = simpleTimePeriod44.equals((java.lang.Object) timeZone46);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date41, timeZone46);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date32, timeZone46);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean55 = timePeriodValues53.equals((java.lang.Object) (short) -1);
//        int int56 = timePeriodValues53.getMinEndIndex();
//        timePeriodValues53.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues53.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues53.setDescription("");
//        int int63 = timePeriodValues53.getMaxStartIndex();
//        int int64 = timePeriodValues53.getMinMiddleIndex();
//        int int65 = year49.compareTo((java.lang.Object) timePeriodValues53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year49.next();
//        timePeriodValues3.setKey((java.lang.Comparable) regularTimePeriod66);
//        java.lang.Number number68 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue69 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod66, number68);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560409200000L + "'", long31 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 5);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long5 = simpleTimePeriod4.getStartMillis();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean7 = simpleTimePeriod4.equals((java.lang.Object) timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1, timeZone6);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year8.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]");
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, 0.0d);
        int int11 = day3.getYear();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMaxMiddleIndex();
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean14 = timePeriodValues12.equals((java.lang.Object) (short) -1);
//        int int15 = timePeriodValues12.getMinEndIndex();
//        timePeriodValues12.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues12.setDescription("");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timePeriodValues12.addChangeListener(seriesChangeListener20);
//        int int22 = timePeriodValues12.getMaxStartIndex();
//        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues12);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getEnd();
//        timePeriodValues27.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.previous();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date38);
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date38, timeZone40);
//        boolean boolean42 = day36.equals((java.lang.Object) year41);
//        boolean boolean43 = day28.equals((java.lang.Object) boolean42);
//        long long44 = day28.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 10L);
//        try {
//            org.jfree.data.time.TimePeriod timePeriod48 = timePeriodValues3.getTimePeriod(2019);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 43629L + "'", long44 == 43629L);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 1560409200000L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        java.lang.String str14 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Object obj13 = timePeriodValues3.clone();
        int int14 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = regularTimePeriod7.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1530561599999L + "'", long8 == 1530561599999L);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean35 = timePeriodValues33.equals((java.lang.Object) (short) -1);
//        int int36 = timePeriodValues33.getMinEndIndex();
//        timePeriodValues33.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDescription("");
//        int int43 = timePeriodValues33.getMaxStartIndex();
//        int int44 = timePeriodValues33.getMinMiddleIndex();
//        int int45 = year29.compareTo((java.lang.Object) timePeriodValues33);
//        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int50 = timePeriodValues49.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = timePeriodValues49.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        timePeriodValues53.add((org.jfree.data.time.TimePeriod) day54, (java.lang.Number) (-1));
//        long long57 = day54.getFirstMillisecond();
//        java.util.Date date58 = day54.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long62 = simpleTimePeriod61.getStartMillis();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean64 = simpleTimePeriod61.equals((java.lang.Object) timeZone63);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date58, timeZone63);
//        int int66 = day65.getDayOfMonth();
//        timePeriodValues33.add((org.jfree.data.time.TimePeriod) day65, (double) (short) 10);
//        java.lang.Number number70 = timePeriodValues33.getValue(0);
//        timePeriodValues33.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues53);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560409200000L + "'", long57 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 13 + "'", int66 == 13);
//        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 10.0d + "'", number70.equals(10.0d));
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]", "");
        timePeriodValues3.delete((int) '4', 13);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
        java.util.Date date10 = day6.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date10);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date5);
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
//        boolean boolean9 = day3.equals((java.lang.Object) year8);
//        long long10 = day3.getLastMillisecond();
//        long long11 = day3.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long11, "13-June-2019", "hi!");
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        java.util.Date date0 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int5 = timePeriodValues4.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues4.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (-1));
//        long long12 = day9.getFirstMillisecond();
//        java.util.Date date13 = day9.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long17 = simpleTimePeriod16.getStartMillis();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean19 = simpleTimePeriod16.equals((java.lang.Object) timeZone18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date13, timeZone18);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long26 = simpleTimePeriod25.getStartMillis();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean28 = simpleTimePeriod25.equals((java.lang.Object) timeZone27);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date22, timeZone27);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date13, timeZone27);
//        try {
//            org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date0, timeZone27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener17);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray6 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]");
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
//        int int12 = timePeriodValues9.getMinEndIndex();
//        timePeriodValues9.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues9.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues9.setDescription("");
//        int int19 = timePeriodValues9.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues9.createCopy((int) (byte) 0, 3);
//        boolean boolean23 = timePeriodValues22.getNotify();
//        boolean boolean24 = day0.equals((java.lang.Object) timePeriodValues22);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues22);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass12 = timePeriodValues11.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues11);
        java.lang.String str14 = seriesChangeEvent13.toString();
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) str14);
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 0.0d);
        int int8 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getEnd();
        int int13 = simpleTimePeriod10.compareTo((java.lang.Object) day11);
        java.util.Date date14 = day11.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (double) 1560409200000L);
        timePeriodValues3.add(timePeriodValue16);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(date14);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass6 = timePeriodValue3.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass11 = timePeriodValues10.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass17 = timePeriodValues16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int23 = timePeriodValues22.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = timePeriodValues22.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) (-1));
//        long long30 = day27.getFirstMillisecond();
//        java.util.Date date31 = day27.getStart();
//        java.util.Date date32 = day27.getStart();
//        java.util.TimeZone timeZone33 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date32, timeZone33);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long38 = simpleTimePeriod37.getStartMillis();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean40 = simpleTimePeriod37.equals((java.lang.Object) timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date32, timeZone39);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date32);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.util.Date date49 = day48.getEnd();
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day48.previous();
//        java.util.Date date53 = day48.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date53, timeZone54);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date53);
//        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date53);
//        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int62 = timePeriodValues61.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues65 = timePeriodValues61.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        timePeriodValues65.add((org.jfree.data.time.TimePeriod) day66, (java.lang.Number) (-1));
//        long long69 = day66.getFirstMillisecond();
//        java.util.Date date70 = day66.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long74 = simpleTimePeriod73.getStartMillis();
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean76 = simpleTimePeriod73.equals((java.lang.Object) timeZone75);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date70, timeZone75);
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        java.util.Date date79 = day78.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod82 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long83 = simpleTimePeriod82.getStartMillis();
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean85 = simpleTimePeriod82.equals((java.lang.Object) timeZone84);
//        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date79, timeZone84);
//        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date70, timeZone84);
//        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date53, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date32, timeZone84);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560409200000L + "'", long30 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues65);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560409200000L + "'", long69 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 0L + "'", long74 == 0L);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 0L + "'", long83 == 0L);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNull(regularTimePeriod89);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        try {
            java.lang.Number number21 = timePeriodValues3.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod2, "", "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]");
        int int6 = timePeriodValues5.getMinEndIndex();
        int int7 = timePeriodValues5.getMinEndIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        int int12 = timePeriodValues9.getMaxMiddleIndex();
//        boolean boolean13 = timePeriodValues9.isEmpty();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        boolean boolean15 = timePeriodValue3.equals((java.lang.Object) timePeriodValues9);
//        java.lang.String str16 = timePeriodValue3.toString();
//        timePeriodValue3.setValue((java.lang.Number) (byte) 10);
//        java.lang.Object obj19 = timePeriodValue3.clone();
//        java.lang.Object obj20 = timePeriodValue3.clone();
//        java.lang.String str21 = timePeriodValue3.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[13-June-2019,1]" + "'", str16.equals("TimePeriodValue[13-June-2019,1]"));
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TimePeriodValue[13-June-2019,10]" + "'", str21.equals("TimePeriodValue[13-June-2019,10]"));
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,0]");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.String str9 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        try {
            java.lang.Number number10 = timePeriodValues3.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        int int13 = day8.getMonth();
//        int int14 = day8.getMonth();
//        int int15 = day8.getYear();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        int int2 = year0.getYear();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.String str7 = timePeriodValues6.getDescription();
//        boolean boolean8 = year0.equals((java.lang.Object) str7);
//        long long9 = year0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int15 = timePeriodValues14.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues14.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        timePeriodValues18.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) (-1));
//        long long22 = day19.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int27 = timePeriodValues26.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues26.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        timePeriodValues30.add((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) (-1));
//        long long34 = day31.getFirstMillisecond();
//        java.util.Date date35 = day31.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long39 = simpleTimePeriod38.getStartMillis();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean41 = simpleTimePeriod38.equals((java.lang.Object) timeZone40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date35, timeZone40);
//        int int43 = day19.compareTo((java.lang.Object) date35);
//        int int44 = year0.compareTo((java.lang.Object) date35);
//        int int45 = year0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560409200000L + "'", long34 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        timePeriodValues3.delete(11, (int) (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setNotify(false);
        java.lang.Class<?> wildcardClass11 = timePeriodValues3.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMaxMiddleIndex();
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean14 = timePeriodValues12.equals((java.lang.Object) (short) -1);
//        int int15 = timePeriodValues12.getMinEndIndex();
//        timePeriodValues12.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues12.setDescription("");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timePeriodValues12.addChangeListener(seriesChangeListener20);
//        int int22 = timePeriodValues12.getMaxStartIndex();
//        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues12);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getEnd();
//        timePeriodValues27.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.previous();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date38);
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date38, timeZone40);
//        boolean boolean42 = day36.equals((java.lang.Object) year41);
//        boolean boolean43 = day28.equals((java.lang.Object) boolean42);
//        long long44 = day28.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 10L);
//        int int47 = timePeriodValues3.getMinEndIndex();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 43629L + "'", long44 == 43629L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-1), (-1), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long7 = simpleTimePeriod6.getStartMillis();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean9 = simpleTimePeriod6.equals((java.lang.Object) timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        boolean boolean12 = day0.equals((java.lang.Object) year10);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year10.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[13-June-2019,10]");
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
//        java.util.Date date10 = day6.getStart();
//        long long11 = day6.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        int int2 = year0.getYear();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.String str7 = timePeriodValues6.getDescription();
//        boolean boolean8 = year0.equals((java.lang.Object) str7);
//        long long9 = year0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int15 = timePeriodValues14.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues14.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        timePeriodValues18.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) (-1));
//        long long22 = day19.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int27 = timePeriodValues26.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues26.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        timePeriodValues30.add((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) (-1));
//        long long34 = day31.getFirstMillisecond();
//        java.util.Date date35 = day31.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long39 = simpleTimePeriod38.getStartMillis();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean41 = simpleTimePeriod38.equals((java.lang.Object) timeZone40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date35, timeZone40);
//        int int43 = day19.compareTo((java.lang.Object) date35);
//        int int44 = year0.compareTo((java.lang.Object) date35);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        java.util.Date date50 = day49.getEnd();
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) day49, (java.lang.Number) 0.0d);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
//        timePeriodValues48.addChangeListener(seriesChangeListener53);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener55 = null;
//        timePeriodValues48.addChangeListener(seriesChangeListener55);
//        boolean boolean57 = year0.equals((java.lang.Object) timePeriodValues48);
//        long long58 = year0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560409200000L + "'", long34 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, (int) 'a', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int16 = timePeriodValues15.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues15.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (-1));
//        long long23 = day20.getFirstMillisecond();
//        java.util.Date date24 = day20.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long28 = simpleTimePeriod27.getStartMillis();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean30 = simpleTimePeriod27.equals((java.lang.Object) timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date24, timeZone29);
//        int int32 = day8.compareTo((java.lang.Object) date24);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean19 = timePeriodValues17.equals((java.lang.Object) (short) -1);
        int int20 = timePeriodValues17.getMinEndIndex();
        timePeriodValues17.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) (short) 1);
        timePeriodValues17.add(timePeriodValue26);
        java.lang.Comparable comparable28 = timePeriodValues17.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date32 = simpleTimePeriod31.getEnd();
        java.lang.Object obj33 = null;
        boolean boolean34 = simpleTimePeriod31.equals(obj33);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod31, (double) 100L);
        timePeriodValues17.add(timePeriodValue36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date41 = simpleTimePeriod40.getEnd();
        boolean boolean42 = timePeriodValue36.equals((java.lang.Object) date41);
        java.lang.Class<?> wildcardClass43 = timePeriodValue36.getClass();
        timePeriodValues3.add(timePeriodValue36);
        int int45 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 10.0d + "'", comparable28.equals(10.0d));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) seriesChangeEvent5);
        java.lang.Object obj7 = seriesChangeEvent5.getSource();
        java.lang.Object obj8 = seriesChangeEvent5.getSource();
        java.lang.Object obj9 = seriesChangeEvent5.getSource();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + (short) -1 + "'", obj7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + (short) -1 + "'", obj8.equals((short) -1));
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + (short) -1 + "'", obj9.equals((short) -1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) false);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) day10);
        java.util.Date date12 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        int int7 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener8);
        java.lang.Object obj10 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[13-June-2019,0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day8.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod14);
//        int int16 = timePeriodValues15.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues15.removePropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date22 = simpleTimePeriod21.getEnd();
//        long long23 = simpleTimePeriod21.getStartMillis();
//        java.util.Date date24 = simpleTimePeriod21.getStart();
//        boolean boolean26 = simpleTimePeriod21.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long30 = simpleTimePeriod29.getStartMillis();
//        int int31 = simpleTimePeriod21.compareTo((java.lang.Object) simpleTimePeriod29);
//        java.util.Date date32 = simpleTimePeriod29.getStart();
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod29, (double) 7);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(date32);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        int int14 = day8.getMonth();
//        long long15 = day8.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass20 = timePeriodValues19.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues19);
//        int int22 = timePeriodValues19.getMinMiddleIndex();
//        java.lang.String str23 = timePeriodValues19.getDomainDescription();
//        timePeriodValues19.setNotify(false);
//        timePeriodValues19.setNotify(false);
//        int int28 = day8.compareTo((java.lang.Object) timePeriodValues19);
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int33 = timePeriodValues32.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = timePeriodValues32.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        timePeriodValues36.add((org.jfree.data.time.TimePeriod) day37, (java.lang.Number) (-1));
//        long long40 = day37.getFirstMillisecond();
//        java.util.Date date41 = day37.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long45 = simpleTimePeriod44.getStartMillis();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean47 = simpleTimePeriod44.equals((java.lang.Object) timeZone46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date41, timeZone46);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        java.util.Date date50 = day49.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long54 = simpleTimePeriod53.getStartMillis();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean56 = simpleTimePeriod53.equals((java.lang.Object) timeZone55);
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date50, timeZone55);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date41, timeZone55);
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year58, (java.lang.Number) (short) 10);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        java.util.Date date65 = day64.getEnd();
//        int int66 = simpleTimePeriod63.compareTo((java.lang.Object) day64);
//        java.util.Date date67 = day64.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue69 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day64, 0.0d);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod72 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        java.util.Date date74 = day73.getEnd();
//        int int75 = simpleTimePeriod72.compareTo((java.lang.Object) day73);
//        boolean boolean76 = timePeriodValue69.equals((java.lang.Object) simpleTimePeriod72);
//        org.jfree.data.time.TimePeriod timePeriod77 = timePeriodValue69.getPeriod();
//        timePeriodValues19.add(timePeriodValue69);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560452399999L + "'", long15 == 1560452399999L);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560409200000L + "'", long40 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(timePeriod77);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        java.util.Calendar calendar5 = null;
        try {
            year4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setDescription("Value");
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass6 = timePeriodValues5.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues5);
//        int int8 = timePeriodValues5.getMinMiddleIndex();
//        java.lang.String str9 = timePeriodValues5.getDomainDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day10.previous();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day10.previous();
//        int int16 = day10.getMonth();
//        long long17 = day10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day10.next();
//        boolean boolean19 = day0.equals((java.lang.Object) regularTimePeriod18);
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) -1);
//        long long22 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean35 = timePeriodValues33.equals((java.lang.Object) (short) -1);
//        int int36 = timePeriodValues33.getMinEndIndex();
//        timePeriodValues33.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDescription("");
//        int int43 = timePeriodValues33.getMaxStartIndex();
//        int int44 = timePeriodValues33.getMinMiddleIndex();
//        int int45 = year29.compareTo((java.lang.Object) timePeriodValues33);
//        long long46 = year29.getFirstMillisecond();
//        java.lang.Object obj47 = null;
//        int int48 = year29.compareTo(obj47);
//        java.util.Calendar calendar49 = null;
//        try {
//            long long50 = year29.getFirstMillisecond(calendar49);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(100, (int) ' ');
        int int10 = timePeriodValues9.getItemCount();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day8.next();
//        int int15 = day8.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date22 = simpleTimePeriod21.getEnd();
        long long23 = simpleTimePeriod21.getStartMillis();
        java.util.Date date24 = simpleTimePeriod21.getStart();
        boolean boolean26 = simpleTimePeriod21.equals((java.lang.Object) false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long30 = simpleTimePeriod29.getStartMillis();
        int int31 = simpleTimePeriod21.compareTo((java.lang.Object) simpleTimePeriod29);
        java.lang.Number number32 = null;
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, number32);
        try {
            timePeriodValues16.update(6, (java.lang.Number) 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass16 = timePeriodValues15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int22 = timePeriodValues21.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues21.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (-1));
//        long long29 = day26.getFirstMillisecond();
//        java.util.Date date30 = day26.getStart();
//        java.util.Date date31 = day26.getStart();
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date31, timeZone32);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long37 = simpleTimePeriod36.getStartMillis();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean39 = simpleTimePeriod36.equals((java.lang.Object) timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date31, timeZone38);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date5, timeZone38);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date3, timeZone38);
//        long long43 = day42.getSerialIndex();
//        java.util.Calendar calendar44 = null;
//        try {
//            long long45 = day42.getMiddleMillisecond(calendar44);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 25568L + "'", long43 == 25568L);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        timePeriodValues3.setDomainDescription("2019");
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, (int) '4', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        try {
            timePeriodValues3.delete(0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int10 = timePeriodValues9.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues9.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) (-1));
//        long long17 = day14.getFirstMillisecond();
//        java.util.Date date18 = day14.getStart();
//        java.util.Date date19 = day14.getStart();
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date19, timeZone20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass26 = timePeriodValues25.getClass();
//        timePeriodValues25.fireSeriesChanged();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day28, (double) 12);
//        java.util.Date date32 = day28.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass37 = timePeriodValues36.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass43 = timePeriodValues42.getClass();
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int49 = timePeriodValues48.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues48.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        timePeriodValues52.add((org.jfree.data.time.TimePeriod) day53, (java.lang.Number) (-1));
//        long long56 = day53.getFirstMillisecond();
//        java.util.Date date57 = day53.getStart();
//        java.util.Date date58 = day53.getStart();
//        java.util.TimeZone timeZone59 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date58, timeZone59);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long64 = simpleTimePeriod63.getStartMillis();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean66 = simpleTimePeriod63.equals((java.lang.Object) timeZone65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date58, timeZone65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date32, timeZone65);
//        java.util.TimeZone timeZone69 = null;
//        try {
//            org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date32, timeZone69);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560409200000L + "'", long56 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        java.util.Calendar calendar5 = null;
        try {
            year4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        int int20 = timePeriodValues3.getMaxEndIndex();
        int int21 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setRangeDescription("hi!");
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getEnd();
//        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
//        java.util.Date date6 = day3.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
//        java.lang.String str8 = day3.toString();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4L + "'", long3 == 4L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4L + "'", long4 == 4L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getItemCount();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        java.lang.String str17 = timePeriodValues16.getRangeDescription();
        timePeriodValues16.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        int int7 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str8 = timePeriodValues3.getDescription();
        java.lang.String str9 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass12 = timePeriodValues11.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues11);
        java.lang.String str14 = seriesChangeEvent13.toString();
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) str14);
        timePeriodValues3.setRangeDescription("");
        int int18 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) seriesChangeEvent5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean6, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues9.addChangeListener(seriesChangeListener10);
        boolean boolean12 = timePeriodValues9.getNotify();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.Object obj4 = seriesChangeEvent2.getSource();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        java.lang.String str19 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str19.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        int int14 = day8.getMonth();
//        long long15 = day8.getMiddleMillisecond();
//        java.util.Calendar calendar16 = null;
//        try {
//            day8.peg(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560452399999L + "'", long15 == 1560452399999L);
//    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int34 = timePeriodValues33.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = timePeriodValues33.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) (-1));
//        long long41 = day38.getFirstMillisecond();
//        java.util.Date date42 = day38.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long46 = simpleTimePeriod45.getStartMillis();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean48 = simpleTimePeriod45.equals((java.lang.Object) timeZone47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date42, timeZone47);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.util.Date date51 = day50.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long55 = simpleTimePeriod54.getStartMillis();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean57 = simpleTimePeriod54.equals((java.lang.Object) timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date51, timeZone56);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date42, timeZone56);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(date12, date42);
//        java.util.Date date61 = simpleTimePeriod60.getStart();
//        java.util.Date date62 = simpleTimePeriod60.getEnd();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560409200000L + "'", long41 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date62);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, 0.0d);
        java.lang.Object obj9 = timePeriodValue8.clone();
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue8.getPeriod();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(timePeriod10);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener8);
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues7.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        long long12 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        int int14 = day8.getMonth();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
        java.lang.Class<?> wildcardClass6 = timePeriodValue3.getClass();
        timePeriodValue3.setValue((java.lang.Number) 1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long11 = simpleTimePeriod10.getStartMillis();
        int int12 = simpleTimePeriod2.compareTo((java.lang.Object) simpleTimePeriod10);
        java.util.Date date13 = simpleTimePeriod10.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getEnd();
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener23);
        boolean boolean25 = year14.equals((java.lang.Object) timePeriodValues18);
        long long26 = year14.getLastMillisecond();
        long long27 = year14.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 28799999L + "'", long26 == 28799999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1969L + "'", long27 == 1969L);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = simpleTimePeriod2.equals(obj4);
//        long long6 = simpleTimePeriod2.getStartMillis();
//        java.util.Date date7 = simpleTimePeriod2.getStart();
//        long long8 = simpleTimePeriod2.getStartMillis();
//        java.util.Date date9 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date11);
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11, timeZone13);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date9, date11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass20 = timePeriodValues19.getClass();
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int26 = timePeriodValues25.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = timePeriodValues25.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day30, (java.lang.Number) (-1));
//        long long33 = day30.getFirstMillisecond();
//        java.util.Date date34 = day30.getStart();
//        java.util.Date date35 = day30.getStart();
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date35, timeZone36);
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass42 = timePeriodValues41.getClass();
//        timePeriodValues41.fireSeriesChanged();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate45 = day44.getSerialDate();
//        timePeriodValues41.add((org.jfree.data.time.TimePeriod) day44, (double) 12);
//        java.util.Date date48 = day44.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass53 = timePeriodValues52.getClass();
//        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass53);
//        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass59 = timePeriodValues58.getClass();
//        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass59);
//        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int65 = timePeriodValues64.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues68 = timePeriodValues64.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        timePeriodValues68.add((org.jfree.data.time.TimePeriod) day69, (java.lang.Number) (-1));
//        long long72 = day69.getFirstMillisecond();
//        java.util.Date date73 = day69.getStart();
//        java.util.Date date74 = day69.getStart();
//        java.util.TimeZone timeZone75 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date74, timeZone75);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod79 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long80 = simpleTimePeriod79.getStartMillis();
//        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean82 = simpleTimePeriod79.equals((java.lang.Object) timeZone81);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date74, timeZone81);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date48, timeZone81);
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod85 = new org.jfree.data.time.SimpleTimePeriod(date11, date48);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560409200000L + "'", long33 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertNotNull(class60);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues68);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560409200000L + "'", long72 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 0L + "'", long80 == 0L);
//        org.junit.Assert.assertNotNull(timeZone81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//        org.junit.Assert.assertNull(regularTimePeriod84);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '4', 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
        java.util.Date date10 = day6.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day6.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560538799999L, "hi!", "TimePeriodValue[13-June-2019,0]");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setDomainDescription("TimePeriodValue[13-June-2019,1]");
        int int8 = timePeriodValues3.getMinStartIndex();
        java.lang.Number number10 = null;
        try {
            timePeriodValues3.update(0, number10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
        org.jfree.data.time.SerialDate serialDate14 = day8.getSerialDate();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day8.getMiddleMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int16 = timePeriodValues15.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues15.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (-1));
//        long long23 = day20.getFirstMillisecond();
//        java.util.Date date24 = day20.getStart();
//        java.util.Date date25 = day20.getStart();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date25, timeZone26);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long31 = simpleTimePeriod30.getStartMillis();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean33 = simpleTimePeriod30.equals((java.lang.Object) timeZone32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date25, timeZone32);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date38 = simpleTimePeriod37.getEnd();
//        long long39 = simpleTimePeriod37.getStartMillis();
//        java.util.Date date40 = simpleTimePeriod37.getStart();
//        boolean boolean42 = simpleTimePeriod37.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long46 = simpleTimePeriod45.getStartMillis();
//        int int47 = simpleTimePeriod37.compareTo((java.lang.Object) simpleTimePeriod45);
//        java.util.Date date48 = simpleTimePeriod45.getEnd();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date48);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass54 = timePeriodValues53.getClass();
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
//        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass60 = timePeriodValues59.getClass();
//        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass60);
//        org.jfree.data.time.TimePeriodValues timePeriodValues65 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int66 = timePeriodValues65.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues69 = timePeriodValues65.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        timePeriodValues69.add((org.jfree.data.time.TimePeriod) day70, (java.lang.Number) (-1));
//        long long73 = day70.getFirstMillisecond();
//        java.util.Date date74 = day70.getStart();
//        java.util.Date date75 = day70.getStart();
//        java.util.TimeZone timeZone76 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date75, timeZone76);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod80 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long81 = simpleTimePeriod80.getStartMillis();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean83 = simpleTimePeriod80.equals((java.lang.Object) timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date75, timeZone82);
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date48, timeZone82);
//        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date25, timeZone82);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(class55);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(class61);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues69);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560409200000L + "'", long73 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 0L + "'", long81 == 0L);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNull(regularTimePeriod84);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1);
        long long7 = year6.getSerialIndex();
        long long8 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass14 = timePeriodValues13.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues13);
        int int16 = timePeriodValues13.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues13.createCopy(100, (int) ' ');
        int int20 = timePeriodValues13.getItemCount();
        int int21 = year6.compareTo((java.lang.Object) timePeriodValues13);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getMiddleMillisecond();
//        int int4 = day0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass13 = timePeriodValues12.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues12);
//        int int15 = timePeriodValues12.getMinMiddleIndex();
//        java.lang.String str16 = timePeriodValues12.getDomainDescription();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.previous();
//        timePeriodValues12.add((org.jfree.data.time.TimePeriod) day17, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day17.previous();
//        int int23 = day17.getMonth();
//        long long24 = day17.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day17.next();
//        boolean boolean26 = day7.equals((java.lang.Object) regularTimePeriod25);
//        int int27 = day0.compareTo((java.lang.Object) regularTimePeriod25);
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod25, (java.lang.Number) (-1L));
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560495599999L + "'", long24 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.lang.Object obj4 = null;
        boolean boolean5 = simpleTimePeriod2.equals(obj4);
        long long6 = simpleTimePeriod2.getStartMillis();
        long long7 = simpleTimePeriod2.getEndMillis();
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[13-June-2019,1]");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date15);
//        boolean boolean17 = day8.equals((java.lang.Object) seriesChangeEvent16);
//        java.lang.Object obj18 = seriesChangeEvent16.getSource();
//        java.lang.String str19 = seriesChangeEvent16.toString();
//        java.lang.String str20 = seriesChangeEvent16.toString();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 23:59:59 PDT 2019]" + "'", str19.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 23:59:59 PDT 2019]"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 23:59:59 PDT 2019]" + "'", str20.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 23:59:59 PDT 2019]"));
//    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.util.Date date3 = day2.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long7 = simpleTimePeriod6.getStartMillis();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean9 = simpleTimePeriod6.equals((java.lang.Object) timeZone8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        boolean boolean12 = day0.equals((java.lang.Object) year10);
//        long long13 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        java.util.Date date4 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date9, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9);
        java.lang.String str15 = year14.toString();
        java.lang.String str16 = year14.toString();
        int int17 = day7.compareTo((java.lang.Object) str16);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = day7.getMiddleMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean35 = timePeriodValues33.equals((java.lang.Object) (short) -1);
//        int int36 = timePeriodValues33.getMinEndIndex();
//        timePeriodValues33.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDescription("");
//        int int43 = timePeriodValues33.getMaxStartIndex();
//        int int44 = timePeriodValues33.getMinMiddleIndex();
//        int int45 = year29.compareTo((java.lang.Object) timePeriodValues33);
//        java.lang.Object obj46 = null;
//        int int47 = year29.compareTo(obj46);
//        int int48 = year29.getYear();
//        java.lang.String str49 = year29.toString();
//        long long50 = year29.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year29.next();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019" + "'", str49.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2019L + "'", long50 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getMiddleMillisecond();
//        int int4 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.lang.Object obj4 = null;
        boolean boolean5 = simpleTimePeriod2.equals(obj4);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 100L);
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        long long9 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        long long14 = day8.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) seriesChangeEvent5);
        java.lang.Object obj7 = seriesChangeEvent5.getSource();
        java.lang.Object obj8 = seriesChangeEvent5.getSource();
        java.lang.String str9 = seriesChangeEvent5.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + (short) -1 + "'", obj7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + (short) -1 + "'", obj8.equals((short) -1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str9.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
//        timePeriodValues3.add(timePeriodValue12);
//        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date18 = simpleTimePeriod17.getEnd();
//        java.lang.Object obj19 = null;
//        boolean boolean20 = simpleTimePeriod17.equals(obj19);
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod17, (double) 100L);
//        timePeriodValues3.add(timePeriodValue22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date27 = simpleTimePeriod26.getEnd();
//        boolean boolean28 = timePeriodValue22.equals((java.lang.Object) date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.util.Date date30 = day29.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass35 = timePeriodValues34.getClass();
//        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
//        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass41 = timePeriodValues40.getClass();
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
//        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int47 = timePeriodValues46.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues50 = timePeriodValues46.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        timePeriodValues50.add((org.jfree.data.time.TimePeriod) day51, (java.lang.Number) (-1));
//        long long54 = day51.getFirstMillisecond();
//        java.util.Date date55 = day51.getStart();
//        java.util.Date date56 = day51.getStart();
//        java.util.TimeZone timeZone57 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date56, timeZone57);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long62 = simpleTimePeriod61.getStartMillis();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean64 = simpleTimePeriod61.equals((java.lang.Object) timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date56, timeZone63);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date30, timeZone63);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent67 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day66);
//        boolean boolean68 = timePeriodValue22.equals((java.lang.Object) seriesChangeEvent67);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 10.0d + "'", comparable14.equals(10.0d));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues50);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560409200000L + "'", long54 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        long long4 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int10 = timePeriodValues9.getMinStartIndex();
        try {
            int int11 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        boolean boolean8 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10);
        java.lang.String str16 = year15.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.previous();
        boolean boolean18 = timePeriodValues3.equals((java.lang.Object) year15);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int6 = timePeriodValues5.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues5.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (-1));
//        long long13 = day10.getFirstMillisecond();
//        java.util.Date date14 = day10.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long18 = simpleTimePeriod17.getStartMillis();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean20 = simpleTimePeriod17.equals((java.lang.Object) timeZone19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date14, timeZone19);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long27 = simpleTimePeriod26.getStartMillis();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean29 = simpleTimePeriod26.equals((java.lang.Object) timeZone28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date23, timeZone28);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date14, timeZone28);
//        boolean boolean32 = year0.equals((java.lang.Object) date14);
//        int int33 = year0.getYear();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = year0.equals(obj34);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1);
        long long7 = year6.getSerialIndex();
        long long8 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        java.util.Date date10 = year6.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year6.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) 1.0f);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        int int12 = timePeriodValues9.getMaxMiddleIndex();
//        boolean boolean13 = timePeriodValues9.isEmpty();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        boolean boolean15 = timePeriodValue3.equals((java.lang.Object) timePeriodValues9);
//        java.lang.String str16 = timePeriodValue3.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean22 = timePeriodValues20.equals((java.lang.Object) (short) -1);
//        int int23 = timePeriodValues20.getMinEndIndex();
//        timePeriodValues20.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (short) 1);
//        timePeriodValues20.add(timePeriodValue29);
//        java.lang.Comparable comparable31 = timePeriodValues20.getKey();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date35 = simpleTimePeriod34.getEnd();
//        java.lang.Object obj36 = null;
//        boolean boolean37 = simpleTimePeriod34.equals(obj36);
//        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod34, (double) 100L);
//        timePeriodValues20.add(timePeriodValue39);
//        boolean boolean41 = timePeriodValue3.equals((java.lang.Object) timePeriodValues20);
//        int int42 = timePeriodValues20.getMinMiddleIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[13-June-2019,1]" + "'", str16.equals("TimePeriodValue[13-June-2019,1]"));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 10.0d + "'", comparable31.equals(10.0d));
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
        timePeriodValues3.add(timePeriodValue12);
        timePeriodValue12.setValue((java.lang.Number) (short) 10);
        timePeriodValue12.setValue((java.lang.Number) 13);
        java.lang.Number number18 = timePeriodValue12.getValue();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 13 + "'", number18.equals(13));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,1]");
        timePeriodValues3.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        java.lang.Object obj8 = timePeriodValues3.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day11, (double) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener14);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int16 = timePeriodValues15.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues15.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (-1));
//        long long23 = day20.getFirstMillisecond();
//        java.util.Date date24 = day20.getStart();
//        java.util.Date date25 = day20.getStart();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date25, timeZone26);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long31 = simpleTimePeriod30.getStartMillis();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean33 = simpleTimePeriod30.equals((java.lang.Object) timeZone32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date25, timeZone32);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date25);
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day35);
//        try {
//            java.lang.Number number38 = timePeriodValues36.getValue(13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) throwableArray6);
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean13 = timePeriodValues11.equals((java.lang.Object) (short) -1);
//        java.lang.String str14 = timePeriodValues11.getRangeDescription();
//        int int15 = timePeriodValues11.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timePeriodValues11.addChangeListener(seriesChangeListener16);
//        boolean boolean18 = timePeriodValue3.equals((java.lang.Object) timePeriodValues11);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date22 = simpleTimePeriod21.getEnd();
//        long long23 = simpleTimePeriod21.getStartMillis();
//        java.util.Date date24 = simpleTimePeriod21.getStart();
//        boolean boolean26 = simpleTimePeriod21.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long30 = simpleTimePeriod29.getStartMillis();
//        int int31 = simpleTimePeriod21.compareTo((java.lang.Object) simpleTimePeriod29);
//        java.util.Date date32 = simpleTimePeriod29.getEnd();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass38 = timePeriodValues37.getClass();
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
//        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass44 = timePeriodValues43.getClass();
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass44);
//        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int50 = timePeriodValues49.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = timePeriodValues49.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        timePeriodValues53.add((org.jfree.data.time.TimePeriod) day54, (java.lang.Number) (-1));
//        long long57 = day54.getFirstMillisecond();
//        java.util.Date date58 = day54.getStart();
//        java.util.Date date59 = day54.getStart();
//        java.util.TimeZone timeZone60 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date59, timeZone60);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long65 = simpleTimePeriod64.getStartMillis();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean67 = simpleTimePeriod64.equals((java.lang.Object) timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date59, timeZone66);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date32, timeZone66);
//        int int70 = day69.getMonth();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day69, (java.lang.Number) 10.0f);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues53);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560409200000L + "'", long57 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 12 + "'", int70 == 12);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMaxStartIndex();
        boolean boolean9 = timePeriodValues3.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day8.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod14);
//        int int16 = timePeriodValues15.getMinMiddleIndex();
//        int int17 = timePeriodValues15.getMaxEndIndex();
//        java.lang.Object obj18 = timePeriodValues15.clone();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean24 = timePeriodValues22.equals((java.lang.Object) (short) -1);
//        int int25 = timePeriodValues22.getMinEndIndex();
//        timePeriodValues22.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (short) 1);
//        timePeriodValues22.add(timePeriodValue31);
//        java.lang.Comparable comparable33 = timePeriodValues22.getKey();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date37 = simpleTimePeriod36.getEnd();
//        java.lang.Object obj38 = null;
//        boolean boolean39 = simpleTimePeriod36.equals(obj38);
//        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod36, (double) 100L);
//        timePeriodValues22.add(timePeriodValue41);
//        java.lang.String str43 = timePeriodValue41.toString();
//        timePeriodValues15.add(timePeriodValue41);
//        int int45 = timePeriodValues15.getMaxEndIndex();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 10.0d + "'", comparable33.equals(10.0d));
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
        java.util.Date date10 = day6.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
        java.lang.String str13 = timePeriodValues12.getDescription();
        int int14 = timePeriodValues12.getMaxEndIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10.0d + "'", comparable8.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        long long20 = simpleTimePeriod14.getStartMillis();
        long long21 = simpleTimePeriod14.getStartMillis();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean14 = timePeriodValues12.equals((java.lang.Object) (short) -1);
        int int15 = timePeriodValues12.getMinEndIndex();
        timePeriodValues12.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues12.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues12.addChangeListener(seriesChangeListener20);
        int int22 = timePeriodValues12.getMaxStartIndex();
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues12);
        java.lang.String str24 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues3.getRangeDescription();
        int int14 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        java.util.Date date4 = day3.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        long long8 = day7.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
//        int int8 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("");
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: 13-June-2019");
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int17 = timePeriodValues16.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues16.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day21, (java.lang.Number) (-1));
//        long long24 = day21.getFirstMillisecond();
//        java.util.Date date25 = day21.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long29 = simpleTimePeriod28.getStartMillis();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean31 = simpleTimePeriod28.equals((java.lang.Object) timeZone30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date25, timeZone30);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long38 = simpleTimePeriod37.getStartMillis();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean40 = simpleTimePeriod37.equals((java.lang.Object) timeZone39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date34, timeZone39);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date25, timeZone39);
//        java.lang.String str43 = year42.toString();
//        long long44 = year42.getLastMillisecond();
//        java.lang.String str45 = year42.toString();
//        java.util.Date date46 = year42.getStart();
//        timePeriodValues3.setKey((java.lang.Comparable) date46);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2019" + "'", str43.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
//        org.junit.Assert.assertNotNull(date46);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 31);
        long long6 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        int int13 = timePeriodValues3.getMaxMiddleIndex();
        int int14 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues3.createCopy((int) (short) 1, 0);
        java.lang.Object obj23 = timePeriodValues3.clone();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue25 = timePeriodValues3.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriodValues22);
        org.junit.Assert.assertNotNull(obj23);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0f, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int8 = timePeriodValues7.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues7.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) (-1));
//        long long15 = day12.getFirstMillisecond();
//        int int16 = day12.getYear();
//        long long17 = day12.getMiddleMillisecond();
//        long long18 = day12.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day12.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 10L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560452399999L + "'", long17 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
//        timePeriodValues3.add(timePeriodValue12);
//        java.lang.Number number14 = timePeriodValue12.getValue();
//        java.lang.String str15 = timePeriodValue12.toString();
//        java.lang.String str16 = timePeriodValue12.toString();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 1 + "'", number14.equals((short) 1));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[13-June-2019,1]" + "'", str15.equals("TimePeriodValue[13-June-2019,1]"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[13-June-2019,1]" + "'", str16.equals("TimePeriodValue[13-June-2019,1]"));
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        timePeriodValues3.delete(100, (int) '4');
        boolean boolean16 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        org.jfree.data.time.SerialDate serialDate14 = day8.getSerialDate();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int21 = timePeriodValues20.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = timePeriodValues20.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        timePeriodValues24.add((org.jfree.data.time.TimePeriod) day25, (java.lang.Number) (-1));
//        long long28 = day25.getFirstMillisecond();
//        java.util.Date date29 = day25.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long33 = simpleTimePeriod32.getStartMillis();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean35 = simpleTimePeriod32.equals((java.lang.Object) timeZone34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date29, timeZone34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long42 = simpleTimePeriod41.getStartMillis();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean44 = simpleTimePeriod41.equals((java.lang.Object) timeZone43);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date38, timeZone43);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date29, timeZone43);
//        boolean boolean47 = year15.equals((java.lang.Object) date29);
//        int int48 = day8.compareTo((java.lang.Object) year15);
//        long long49 = year15.getLastMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560409200000L + "'", long28 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1);
        long long7 = year6.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year6.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        java.util.Date date13 = day8.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (double) (short) 10);
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = day8.getLastMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod2, "", "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]");
        java.lang.Object obj6 = timePeriodValues5.clone();
        int int7 = timePeriodValues5.getMinStartIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 1560409200000L);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (-1));
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue13.getPeriod();
        java.lang.Class<?> wildcardClass15 = timePeriod14.getClass();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass12 = timePeriodValues11.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues11);
        java.lang.String str14 = seriesChangeEvent13.toString();
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) str14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener16);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass12 = timePeriodValues11.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues11);
        java.lang.String str14 = seriesChangeEvent13.toString();
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) str14);
        timePeriodValues3.setRangeDescription("");
        java.lang.String str18 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod2, "", "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues5.addChangeListener(seriesChangeListener6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560538799999L, (long) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        timePeriodValues3.setNotify(true);
        java.lang.Object obj19 = timePeriodValues3.clone();
        java.lang.String str20 = timePeriodValues3.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod22 = timePeriodValues3.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        timePeriodValues3.fireSeriesChanged();
        java.lang.String str14 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 9, 28799999L);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        timePeriodValues3.setDomainDescription("hi!");
//        java.lang.Class<?> wildcardClass9 = timePeriodValues3.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date11);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date16 = simpleTimePeriod15.getEnd();
//        long long17 = simpleTimePeriod15.getStartMillis();
//        java.util.Date date18 = simpleTimePeriod15.getStart();
//        boolean boolean20 = simpleTimePeriod15.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long24 = simpleTimePeriod23.getStartMillis();
//        int int25 = simpleTimePeriod15.compareTo((java.lang.Object) simpleTimePeriod23);
//        java.util.Date date26 = simpleTimePeriod23.getEnd();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass32 = timePeriodValues31.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass38 = timePeriodValues37.getClass();
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
//        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int44 = timePeriodValues43.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = timePeriodValues43.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) (-1));
//        long long51 = day48.getFirstMillisecond();
//        java.util.Date date52 = day48.getStart();
//        java.util.Date date53 = day48.getStart();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date53, timeZone54);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long59 = simpleTimePeriod58.getStartMillis();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean61 = simpleTimePeriod58.equals((java.lang.Object) timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date53, timeZone60);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date26, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date11, timeZone60);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date11);
//        java.util.Date date66 = year65.getEnd();
//        int int67 = year65.getYear();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues47);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560409200000L + "'", long51 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2019 + "'", int67 == 2019);
//    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
//        int int12 = timePeriodValues9.getMinEndIndex();
//        timePeriodValues9.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues9.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues9.setDescription("");
//        int int19 = timePeriodValues9.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues9.createCopy((int) (byte) 0, 3);
//        boolean boolean23 = timePeriodValues22.getNotify();
//        boolean boolean24 = day0.equals((java.lang.Object) timePeriodValues22);
//        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMaxStartIndex();
        boolean boolean9 = timePeriodValues3.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues3.createCopy((int) (short) 100, 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean18 = timePeriodValues16.equals((java.lang.Object) (short) -1);
        int int19 = timePeriodValues16.getMinEndIndex();
        timePeriodValues16.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues16.setDescription("TimePeriodValue[13-June-2019,1]");
        boolean boolean24 = timePeriodValues3.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.TimePeriod timePeriod25 = null;
        try {
            timePeriodValues3.add(timePeriod25, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.String str7 = timePeriodValues6.getDescription();
        boolean boolean8 = year0.equals((java.lang.Object) str7);
        long long9 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.previous();
        java.util.Calendar calendar12 = null;
        try {
            year0.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: 13-June-2019");
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560538799999L, "hi!", "TimePeriodValue[13-June-2019,0]");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setDomainDescription("TimePeriodValue[13-June-2019,1]");
        int int8 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.delete(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
        int int12 = timePeriodValues9.getMaxMiddleIndex();
        boolean boolean13 = timePeriodValues9.isEmpty();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
        boolean boolean15 = timePeriodValue3.equals((java.lang.Object) timePeriodValues9);
        timePeriodValues9.setRangeDescription("");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, 0.0d);
        java.lang.Object obj11 = timePeriodValue10.clone();
        java.lang.Number number12 = timePeriodValue10.getValue();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        java.util.Date date4 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "", "org.jfree.data.general.SeriesChangeEvent[source=-1]", "13-June-2019");
        timePeriodValues10.setDomainDescription("13-June-2019");
        int int13 = day3.compareTo((java.lang.Object) "13-June-2019");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        long long14 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day8.previous();
//        long long16 = day8.getFirstMillisecond();
//        long long17 = day8.getMiddleMillisecond();
//        int int18 = day8.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560452399999L + "'", long17 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, 7, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = null;
        try {
            timePeriodValues3.add(timePeriodValue6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
    }
}

