import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        timePeriodValues16.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date22 = simpleTimePeriod21.getEnd();
        long long23 = simpleTimePeriod21.getStartMillis();
        java.util.Date date24 = simpleTimePeriod21.getStart();
        boolean boolean26 = simpleTimePeriod21.equals((java.lang.Object) false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long30 = simpleTimePeriod29.getStartMillis();
        int int31 = simpleTimePeriod21.compareTo((java.lang.Object) simpleTimePeriod29);
        java.lang.Number number32 = null;
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, number32);
        timePeriodValues16.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "org.jfree.data.general.SeriesException: ", "org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener7);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: 13-June-2019");
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMaxStartIndex();
        int int9 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener17);
        java.lang.Object obj19 = timePeriodValues3.clone();
        try {
            java.lang.Number number21 = timePeriodValues3.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Object obj9 = timePeriodValues3.clone();
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, 0.0d);
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue10.getPeriod();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(timePeriod11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("hi!");
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,1]");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
//        java.lang.String str10 = day6.toString();
//        java.lang.Class<?> wildcardClass11 = day6.getClass();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener12);
        int int14 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10.0d + "'", comparable11.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod13, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!");
//        int int17 = timePeriodValues16.getMaxEndIndex();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = day0.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.SerialDate serialDate12 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate12, "org.jfree.data.general.SeriesException: ", "org.jfree.data.general.SeriesException: 13-June-2019");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue17 = timePeriodValues15.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        boolean boolean17 = timePeriodValues16.isEmpty();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        int int20 = year18.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.String str25 = timePeriodValues24.getDescription();
        boolean boolean26 = year18.equals((java.lang.Object) str25);
        long long27 = year18.getFirstMillisecond();
        int int28 = year18.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year18);
        boolean boolean30 = timePeriodValues16.equals((java.lang.Object) timePeriodValues29);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.Class class0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getEnd();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
        java.util.Date date10 = day5.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year13.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        java.util.Calendar calendar8 = null;
        try {
            day3.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long5 = simpleTimePeriod4.getStartMillis();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean7 = simpleTimePeriod4.equals((java.lang.Object) timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        long long14 = day8.getSerialIndex();
//        long long15 = day8.getMiddleMillisecond();
//        java.util.Calendar calendar16 = null;
//        try {
//            day8.peg(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560452399999L + "'", long15 == 1560452399999L);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        try {
            java.lang.Number number12 = timePeriodValues3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
        timePeriodValues3.add(timePeriodValue12);
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,0]");
        int int16 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues3.createCopy((int) (short) 1, 0);
        java.lang.String str23 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date27 = simpleTimePeriod26.getEnd();
        java.lang.Object obj28 = null;
        boolean boolean29 = simpleTimePeriod26.equals(obj28);
        long long30 = simpleTimePeriod26.getStartMillis();
        long long31 = simpleTimePeriod26.getEndMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date35 = simpleTimePeriod34.getEnd();
        java.lang.Object obj36 = null;
        boolean boolean37 = simpleTimePeriod34.equals(obj36);
        long long38 = simpleTimePeriod34.getStartMillis();
        java.util.Date date39 = simpleTimePeriod34.getStart();
        long long40 = simpleTimePeriod34.getStartMillis();
        int int41 = simpleTimePeriod26.compareTo((java.lang.Object) simpleTimePeriod34);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod34, (double) 2019L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriodValues22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 97L + "'", long31 == 97L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        timePeriodValues3.fireSeriesChanged();
        int int21 = timePeriodValues3.getMinStartIndex();
        int int22 = timePeriodValues3.getMinEndIndex();
        java.lang.String str23 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.lang.Object obj4 = null;
        boolean boolean5 = simpleTimePeriod2.equals(obj4);
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getStart();
        long long8 = simpleTimePeriod2.getStartMillis();
        java.util.Date date9 = simpleTimePeriod2.getStart();
        java.util.Date date10 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int15 = timePeriodValues14.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        java.lang.Class<?> wildcardClass18 = timePeriodValues14.getClass();
        try {
            int int19 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues14);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
        timePeriodValues3.add(timePeriodValue12);
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,0]");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,1]");
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues3.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10.0d + "'", comparable11.equals(10.0d));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 1, (long) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
        java.util.Date date10 = day6.getStart();
        int int12 = day6.compareTo((java.lang.Object) "2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day6.previous();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setNotify(false);
        int int12 = timePeriodValues3.getMinEndIndex();
        java.lang.String str13 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        java.lang.String str16 = timePeriodValues3.getDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.lang.Object obj4 = null;
        boolean boolean5 = simpleTimePeriod2.equals(obj4);
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getStart();
        long long8 = simpleTimePeriod2.getStartMillis();
        java.util.Date date9 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str6 = seriesException4.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str6.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int16 = timePeriodValues15.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues15.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (-1));
//        long long23 = day20.getFirstMillisecond();
//        java.util.Date date24 = day20.getStart();
//        java.util.Date date25 = day20.getStart();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date25, timeZone26);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long31 = simpleTimePeriod30.getStartMillis();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean33 = simpleTimePeriod30.equals((java.lang.Object) timeZone32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date25, timeZone32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass39 = timePeriodValues38.getClass();
//        timePeriodValues38.fireSeriesChanged();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate42 = day41.getSerialDate();
//        timePeriodValues38.add((org.jfree.data.time.TimePeriod) day41, (double) 12);
//        java.util.Date date45 = day41.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long49 = simpleTimePeriod48.getStartMillis();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean51 = simpleTimePeriod48.equals((java.lang.Object) timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date45, timeZone50);
//        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass57 = timePeriodValues56.getClass();
//        java.lang.Class class58 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass57);
//        org.jfree.data.time.TimePeriodValues timePeriodValues62 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int63 = timePeriodValues62.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues66 = timePeriodValues62.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        timePeriodValues66.add((org.jfree.data.time.TimePeriod) day67, (java.lang.Number) (-1));
//        long long70 = day67.getFirstMillisecond();
//        java.util.Date date71 = day67.getStart();
//        java.util.Date date72 = day67.getStart();
//        java.util.TimeZone timeZone73 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date72, timeZone73);
//        org.jfree.data.time.TimePeriodValues timePeriodValues78 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int79 = timePeriodValues78.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues82 = timePeriodValues78.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day();
//        timePeriodValues82.add((org.jfree.data.time.TimePeriod) day83, (java.lang.Number) (-1));
//        long long86 = day83.getFirstMillisecond();
//        java.util.Date date87 = day83.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod88 = new org.jfree.data.time.SimpleTimePeriod(date72, date87);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod91 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long92 = simpleTimePeriod91.getStartMillis();
//        java.util.TimeZone timeZone93 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean94 = simpleTimePeriod91.equals((java.lang.Object) timeZone93);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date72, timeZone93);
//        try {
//            org.jfree.data.time.TimePeriodValues timePeriodValues98 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod95, "TimePeriodValue[13-June-2019,10]", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(class58);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues66);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560409200000L + "'", long70 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues82);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 1560409200000L + "'", long86 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 0L + "'", long92 == 0L);
//        org.junit.Assert.assertNotNull(timeZone93);
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//        org.junit.Assert.assertNull(regularTimePeriod95);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setDescription("");
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(0, (int) (byte) -1);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
//        java.util.Date date18 = day17.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.next();
//        long long20 = day17.getFirstMillisecond();
//        timePeriodValues3.setKey((java.lang.Comparable) day17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day17.next();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod7.equals(obj9);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod7, (double) 100L);
        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) simpleTimePeriod7);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass18 = timePeriodValues17.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues17);
        int int20 = timePeriodValues17.getMinMiddleIndex();
        java.lang.Comparable comparable21 = timePeriodValues17.getKey();
        int int22 = timePeriodValues17.getMaxStartIndex();
        boolean boolean23 = timePeriodValues17.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = timePeriodValues17.createCopy((int) (short) 100, 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean32 = timePeriodValues30.equals((java.lang.Object) (short) -1);
        int int33 = timePeriodValues30.getMinEndIndex();
        timePeriodValues30.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues30.setDescription("TimePeriodValue[13-June-2019,1]");
        boolean boolean38 = timePeriodValues17.equals((java.lang.Object) timePeriodValues30);
        try {
            int int39 = simpleTimePeriod2.compareTo((java.lang.Object) boolean38);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Boolean cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 10.0d + "'", comparable21.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(timePeriodValues26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener9);
        int int11 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getEnd();
//        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
//        java.util.Date date10 = day5.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int19 = timePeriodValues18.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues18.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) (-1));
//        long long26 = day23.getFirstMillisecond();
//        java.util.Date date27 = day23.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long31 = simpleTimePeriod30.getStartMillis();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean33 = simpleTimePeriod30.equals((java.lang.Object) timeZone32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date27, timeZone32);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long40 = simpleTimePeriod39.getStartMillis();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean42 = simpleTimePeriod39.equals((java.lang.Object) timeZone41);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date36, timeZone41);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date27, timeZone41);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date10, timeZone41);
//        java.util.Calendar calendar46 = null;
//        try {
//            long long47 = day45.getFirstMillisecond(calendar46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560409200000L + "'", long26 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setDescription("");
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(0, (int) (byte) -1);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
//        java.util.Date date18 = day17.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.next();
//        long long20 = day17.getFirstMillisecond();
//        timePeriodValues3.setKey((java.lang.Comparable) day17);
//        int int22 = day17.getMonth();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        int int12 = timePeriodValues9.getMaxMiddleIndex();
//        boolean boolean13 = timePeriodValues9.isEmpty();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean20 = timePeriodValues18.equals((java.lang.Object) (short) -1);
//        int int21 = timePeriodValues18.getMinEndIndex();
//        timePeriodValues18.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues18.setDescription("");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timePeriodValues18.addChangeListener(seriesChangeListener26);
//        int int28 = timePeriodValues18.getMaxStartIndex();
//        boolean boolean29 = timePeriodValues9.equals((java.lang.Object) timePeriodValues18);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getEnd();
//        timePeriodValues33.add((org.jfree.data.time.TimePeriod) day34, (java.lang.Number) 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day34.previous();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.util.Date date40 = day39.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.util.Date date44 = day43.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date44);
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date44, timeZone46);
//        boolean boolean48 = day42.equals((java.lang.Object) year47);
//        boolean boolean49 = day34.equals((java.lang.Object) boolean48);
//        long long50 = day34.getSerialIndex();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day34, (java.lang.Number) 10L);
//        java.util.Date date53 = day34.getEnd();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date53, timeZone54);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 43629L + "'", long50 == 43629L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) throwableArray6);
        java.lang.Number number8 = timePeriodValue3.getValue();
        java.lang.Object obj9 = timePeriodValue3.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 1 + "'", number8.equals((short) 1));
        org.junit.Assert.assertNotNull(obj9);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        int int13 = day8.getYear();
//        java.util.Date date14 = day8.getStart();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setNotify(false);
        int int10 = timePeriodValues3.getMaxStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues3.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues3.createCopy((int) (short) 1, 0);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) (short) 1);
        boolean boolean28 = timePeriodValue26.equals((java.lang.Object) (short) 1);
        timePeriodValue26.setValue((java.lang.Number) 12);
        timePeriodValues22.add(timePeriodValue26);
        int int32 = timePeriodValues22.getMaxEndIndex();
        try {
            java.lang.Number number34 = timePeriodValues22.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriodValues22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int16 = timePeriodValues15.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues15.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (-1));
//        long long23 = day20.getFirstMillisecond();
//        java.util.Date date24 = day20.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long28 = simpleTimePeriod27.getStartMillis();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean30 = simpleTimePeriod27.equals((java.lang.Object) timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date24, timeZone29);
//        int int32 = day8.compareTo((java.lang.Object) date24);
//        long long33 = day8.getLastMillisecond();
//        java.lang.String str34 = day8.toString();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 23:59:59 PDT 2019]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long7 = simpleTimePeriod6.getStartMillis();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean9 = simpleTimePeriod6.equals((java.lang.Object) timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        boolean boolean12 = day0.equals((java.lang.Object) year10);
        long long13 = year10.getLastMillisecond();
        long long14 = year10.getFirstMillisecond();
        long long15 = year10.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass20 = timePeriodValues19.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues19);
        int int22 = timePeriodValues19.getMaxMiddleIndex();
        java.lang.Comparable comparable23 = timePeriodValues19.getKey();
        int int24 = year10.compareTo((java.lang.Object) timePeriodValues19);
        long long25 = year10.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 10.0d + "'", comparable23.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMaxStartIndex();
        boolean boolean9 = timePeriodValues3.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues3.createCopy((int) (short) 100, 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean18 = timePeriodValues16.equals((java.lang.Object) (short) -1);
        int int19 = timePeriodValues16.getMinEndIndex();
        timePeriodValues16.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues16.setDescription("TimePeriodValue[13-June-2019,1]");
        boolean boolean24 = timePeriodValues3.equals((java.lang.Object) timePeriodValues16);
        java.lang.String str25 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean9 = timePeriodValues7.equals((java.lang.Object) (short) -1);
        int int10 = timePeriodValues7.getMinEndIndex();
        timePeriodValues7.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues7.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener15);
        int int17 = year0.compareTo((java.lang.Object) timePeriodValues7);
        int int18 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day8.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod14);
//        int int16 = timePeriodValues15.getMinMiddleIndex();
//        int int17 = timePeriodValues15.getMaxEndIndex();
//        java.lang.Object obj18 = timePeriodValues15.clone();
//        timePeriodValues15.setNotify(false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(obj18);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) seriesChangeEvent5);
        long long7 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: 13-June-2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: 13-June-2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: 13-June-2019"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.lang.Object obj4 = null;
        boolean boolean5 = simpleTimePeriod2.equals(obj4);
        long long6 = simpleTimePeriod2.getStartMillis();
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod10.equals(obj12);
        long long14 = simpleTimePeriod10.getStartMillis();
        java.util.Date date15 = simpleTimePeriod10.getStart();
        long long16 = simpleTimePeriod10.getStartMillis();
        int int17 = simpleTimePeriod2.compareTo((java.lang.Object) simpleTimePeriod10);
        java.lang.Class<?> wildcardClass18 = simpleTimePeriod10.getClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = seriesException1.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date15);
//        boolean boolean17 = day8.equals((java.lang.Object) seriesChangeEvent16);
//        long long18 = day8.getLastMillisecond();
//        java.lang.Class<?> wildcardClass19 = day8.getClass();
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = day8.getFirstMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560495599999L + "'", long18 == 1560495599999L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.Class class0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getEnd();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
        java.util.Date date10 = day5.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date10);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 1560409200000L);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (-1));
        java.lang.String str14 = timePeriodValue13.toString();
        java.lang.String str15 = timePeriodValue13.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) (short) -1);
        int int22 = timePeriodValues19.getMinEndIndex();
        timePeriodValues19.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues19.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues19.setDescription("");
        int int29 = timePeriodValues19.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = timePeriodValues19.createCopy((int) (byte) 0, 3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues32.removeChangeListener(seriesChangeListener33);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date38 = simpleTimePeriod37.getEnd();
        long long39 = simpleTimePeriod37.getStartMillis();
        java.util.Date date40 = simpleTimePeriod37.getStart();
        boolean boolean42 = simpleTimePeriod37.equals((java.lang.Object) false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long46 = simpleTimePeriod45.getStartMillis();
        int int47 = simpleTimePeriod37.compareTo((java.lang.Object) simpleTimePeriod45);
        java.lang.Number number48 = null;
        timePeriodValues32.add((org.jfree.data.time.TimePeriod) simpleTimePeriod37, number48);
        boolean boolean50 = timePeriodValue13.equals((java.lang.Object) timePeriodValues32);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues32);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
        java.lang.Class<?> wildcardClass6 = timePeriodValue3.getClass();
        java.lang.Number number7 = timePeriodValue3.getValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 1 + "'", number7.equals((short) 1));
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass11 = timePeriodValues10.getClass();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
//        boolean boolean14 = day3.equals((java.lang.Object) timePeriodValues10);
//        long long15 = day3.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day3.next();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date20 = simpleTimePeriod19.getEnd();
//        long long21 = simpleTimePeriod19.getStartMillis();
//        java.util.Date date22 = simpleTimePeriod19.getStart();
//        boolean boolean24 = simpleTimePeriod19.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long28 = simpleTimePeriod27.getStartMillis();
//        int int29 = simpleTimePeriod19.compareTo((java.lang.Object) simpleTimePeriod27);
//        java.util.Date date30 = simpleTimePeriod27.getEnd();
//        int int31 = day3.compareTo((java.lang.Object) simpleTimePeriod27);
//        int int32 = simpleTimePeriod2.compareTo((java.lang.Object) simpleTimePeriod27);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean35 = timePeriodValues33.equals((java.lang.Object) (short) -1);
//        int int36 = timePeriodValues33.getMinEndIndex();
//        timePeriodValues33.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDescription("");
//        int int43 = timePeriodValues33.getMaxStartIndex();
//        int int44 = timePeriodValues33.getMinMiddleIndex();
//        int int45 = year29.compareTo((java.lang.Object) timePeriodValues33);
//        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int50 = timePeriodValues49.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = timePeriodValues49.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        timePeriodValues53.add((org.jfree.data.time.TimePeriod) day54, (java.lang.Number) (-1));
//        long long57 = day54.getFirstMillisecond();
//        java.util.Date date58 = day54.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long62 = simpleTimePeriod61.getStartMillis();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean64 = simpleTimePeriod61.equals((java.lang.Object) timeZone63);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date58, timeZone63);
//        int int66 = day65.getDayOfMonth();
//        timePeriodValues33.add((org.jfree.data.time.TimePeriod) day65, (double) (short) 10);
//        long long69 = day65.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues53);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560409200000L + "'", long57 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 13 + "'", int66 == 13);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560452399999L + "'", long69 == 1560452399999L);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day3.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod2, "", "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]");
        int int6 = timePeriodValues5.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues5.createCopy(100, 3);
        int int10 = timePeriodValues9.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean9 = timePeriodValues7.equals((java.lang.Object) (short) -1);
        int int10 = timePeriodValues7.getMinEndIndex();
        timePeriodValues7.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues7.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues7.setDescription("");
        try {
            int int17 = simpleTimePeriod2.compareTo((java.lang.Object) "");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        java.lang.String str30 = year29.toString();
//        int int31 = year29.getYear();
//        java.lang.Object obj32 = null;
//        boolean boolean33 = year29.equals(obj32);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        java.lang.String str14 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass11 = timePeriodValues10.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues10);
        int int13 = timePeriodValues10.getMinMiddleIndex();
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day15, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day15.previous();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date22);
        boolean boolean24 = day15.equals((java.lang.Object) seriesChangeEvent23);
        timePeriodValues3.setKey((java.lang.Comparable) day15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("hi!");
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,1]");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues3.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        java.lang.String str14 = day8.toString();
//        long long15 = day8.getFirstMillisecond();
//        long long16 = day8.getSerialIndex();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues3.getMaxEndIndex();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean16 = timePeriodValues14.equals((java.lang.Object) (short) -1);
        int int17 = timePeriodValues14.getMinEndIndex();
        timePeriodValues14.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.util.Date date21 = day20.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (short) 1);
        timePeriodValues14.add(timePeriodValue23);
        timePeriodValue23.setValue((java.lang.Number) (short) 10);
        timePeriodValue23.setValue((java.lang.Number) 13);
        timePeriodValues3.add(timePeriodValue23);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray8 = seriesException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,0]");
        seriesException4.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int16 = timePeriodValues15.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues15.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (-1));
//        long long23 = day20.getFirstMillisecond();
//        java.util.Date date24 = day20.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long28 = simpleTimePeriod27.getStartMillis();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean30 = simpleTimePeriod27.equals((java.lang.Object) timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date24, timeZone29);
//        int int32 = day8.compareTo((java.lang.Object) date24);
//        long long33 = day8.getLastMillisecond();
//        java.util.Date date34 = day8.getStart();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date34);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: 13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean14 = timePeriodValues12.equals((java.lang.Object) (short) -1);
        int int15 = timePeriodValues12.getMinEndIndex();
        timePeriodValues12.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues12.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues12.addChangeListener(seriesChangeListener20);
        int int22 = timePeriodValues12.getMaxStartIndex();
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues12);
        java.lang.String str24 = timePeriodValues12.getDomainDescription();
        java.lang.Comparable comparable25 = timePeriodValues12.getKey();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 10.0d + "'", comparable25.equals(10.0d));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        java.lang.Comparable comparable13 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        java.util.Date date17 = simpleTimePeriod16.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
        timePeriodValues3.setKey((java.lang.Comparable) date17);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 10.0d + "'", comparable13.equals(10.0d));
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 13);
        int int7 = year0.compareTo((java.lang.Object) 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
        timePeriodValue3.setValue((java.lang.Number) 12);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (short) 1);
        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) timePeriodValue11);
        java.lang.Number number13 = timePeriodValue3.getValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 12 + "'", number13.equals(12));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 1560409200000L);
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        int int15 = year13.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.String str20 = timePeriodValues19.getDescription();
        boolean boolean21 = year13.equals((java.lang.Object) str20);
        long long22 = year13.getFirstMillisecond();
        timePeriodValues3.setKey((java.lang.Comparable) long22);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        int int12 = timePeriodValues9.getMaxMiddleIndex();
//        boolean boolean13 = timePeriodValues9.isEmpty();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        boolean boolean15 = timePeriodValue3.equals((java.lang.Object) timePeriodValues9);
//        java.lang.String str16 = timePeriodValue3.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean22 = timePeriodValues20.equals((java.lang.Object) (short) -1);
//        int int23 = timePeriodValues20.getMinEndIndex();
//        timePeriodValues20.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (short) 1);
//        timePeriodValues20.add(timePeriodValue29);
//        java.lang.Comparable comparable31 = timePeriodValues20.getKey();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date35 = simpleTimePeriod34.getEnd();
//        java.lang.Object obj36 = null;
//        boolean boolean37 = simpleTimePeriod34.equals(obj36);
//        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod34, (double) 100L);
//        timePeriodValues20.add(timePeriodValue39);
//        boolean boolean41 = timePeriodValue3.equals((java.lang.Object) timePeriodValues20);
//        java.lang.String str42 = timePeriodValues20.getRangeDescription();
//        int int43 = timePeriodValues20.getItemCount();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[13-June-2019,1]" + "'", str16.equals("TimePeriodValue[13-June-2019,1]"));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 10.0d + "'", comparable31.equals(10.0d));
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        timePeriodValues3.setDomainDescription("hi!");
//        java.lang.Class<?> wildcardClass9 = timePeriodValues3.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date11);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date16 = simpleTimePeriod15.getEnd();
//        long long17 = simpleTimePeriod15.getStartMillis();
//        java.util.Date date18 = simpleTimePeriod15.getStart();
//        boolean boolean20 = simpleTimePeriod15.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long24 = simpleTimePeriod23.getStartMillis();
//        int int25 = simpleTimePeriod15.compareTo((java.lang.Object) simpleTimePeriod23);
//        java.util.Date date26 = simpleTimePeriod23.getEnd();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass32 = timePeriodValues31.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass38 = timePeriodValues37.getClass();
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
//        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int44 = timePeriodValues43.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = timePeriodValues43.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) (-1));
//        long long51 = day48.getFirstMillisecond();
//        java.util.Date date52 = day48.getStart();
//        java.util.Date date53 = day48.getStart();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date53, timeZone54);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long59 = simpleTimePeriod58.getStartMillis();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean61 = simpleTimePeriod58.equals((java.lang.Object) timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date53, timeZone60);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date26, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date11, timeZone60);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues69 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int70 = timePeriodValues69.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues73 = timePeriodValues69.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        timePeriodValues73.add((org.jfree.data.time.TimePeriod) day74, (java.lang.Number) (-1));
//        long long77 = day74.getFirstMillisecond();
//        java.util.Date date78 = day74.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod81 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long82 = simpleTimePeriod81.getStartMillis();
//        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean84 = simpleTimePeriod81.equals((java.lang.Object) timeZone83);
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date78, timeZone83);
//        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day();
//        java.util.Date date87 = day86.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod90 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long91 = simpleTimePeriod90.getStartMillis();
//        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean93 = simpleTimePeriod90.equals((java.lang.Object) timeZone92);
//        org.jfree.data.time.Year year94 = new org.jfree.data.time.Year(date87, timeZone92);
//        org.jfree.data.time.Year year95 = new org.jfree.data.time.Year(date78, timeZone92);
//        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(date11, timeZone92);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues47);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560409200000L + "'", long51 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues73);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560409200000L + "'", long77 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
//        org.junit.Assert.assertNotNull(timeZone83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 0L + "'", long91 == 0L);
//        org.junit.Assert.assertNotNull(timeZone92);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        long long12 = day8.getFirstMillisecond();
//        long long13 = day8.getFirstMillisecond();
//        long long14 = day8.getLastMillisecond();
//        java.lang.String str15 = day8.toString();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = simpleTimePeriod2.equals(obj4);
//        long long6 = simpleTimePeriod2.getStartMillis();
//        java.util.Date date7 = simpleTimePeriod2.getStart();
//        long long8 = simpleTimePeriod2.getStartMillis();
//        java.util.Date date9 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass14 = timePeriodValues13.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues13);
//        int int16 = timePeriodValues13.getMinMiddleIndex();
//        timePeriodValues13.setDomainDescription("hi!");
//        java.lang.Class<?> wildcardClass19 = timePeriodValues13.getClass();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date21);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date26 = simpleTimePeriod25.getEnd();
//        long long27 = simpleTimePeriod25.getStartMillis();
//        java.util.Date date28 = simpleTimePeriod25.getStart();
//        boolean boolean30 = simpleTimePeriod25.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long34 = simpleTimePeriod33.getStartMillis();
//        int int35 = simpleTimePeriod25.compareTo((java.lang.Object) simpleTimePeriod33);
//        java.util.Date date36 = simpleTimePeriod33.getEnd();
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass42 = timePeriodValues41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass48 = timePeriodValues47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int54 = timePeriodValues53.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues57 = timePeriodValues53.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        timePeriodValues57.add((org.jfree.data.time.TimePeriod) day58, (java.lang.Number) (-1));
//        long long61 = day58.getFirstMillisecond();
//        java.util.Date date62 = day58.getStart();
//        java.util.Date date63 = day58.getStart();
//        java.util.TimeZone timeZone64 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date63, timeZone64);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long69 = simpleTimePeriod68.getStartMillis();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean71 = simpleTimePeriod68.equals((java.lang.Object) timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date63, timeZone70);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date36, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date21, timeZone70);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod75 = new org.jfree.data.time.SimpleTimePeriod(date9, date21);
//        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date21);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues57);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560409200000L + "'", long61 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        java.lang.Object obj11 = timePeriodValues3.clone();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '4', (long) (short) 100);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int16 = timePeriodValues15.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues15.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (-1));
//        long long23 = day20.getFirstMillisecond();
//        java.util.Date date24 = day20.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long28 = simpleTimePeriod27.getStartMillis();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean30 = simpleTimePeriod27.equals((java.lang.Object) timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date24, timeZone29);
//        int int32 = day8.compareTo((java.lang.Object) date24);
//        long long33 = day8.getLastMillisecond();
//        java.util.Date date34 = day8.getEnd();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date34);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: ");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.String str7 = timePeriodValues6.getDescription();
        boolean boolean8 = year0.equals((java.lang.Object) str7);
        long long9 = year0.getFirstMillisecond();
        int int10 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.next();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year0.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        int int6 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        try {
            int int8 = simpleTimePeriod2.compareTo((java.lang.Object) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Character cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("hi!");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue11 = timePeriodValues3.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(0, (int) (byte) -1);
        int int14 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.delete(100, (int) (short) 0);
        java.lang.String str18 = timePeriodValues3.getDescription();
        int int19 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,0]");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        long long14 = day8.getSerialIndex();
//        java.util.Calendar calendar15 = null;
//        try {
//            day8.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        int int14 = timePeriodValues3.getMinMiddleIndex();
        int int15 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean35 = timePeriodValues33.equals((java.lang.Object) (short) -1);
//        int int36 = timePeriodValues33.getMinEndIndex();
//        timePeriodValues33.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues33.setDescription("");
//        int int43 = timePeriodValues33.getMaxStartIndex();
//        int int44 = timePeriodValues33.getMinMiddleIndex();
//        int int45 = year29.compareTo((java.lang.Object) timePeriodValues33);
//        long long46 = year29.getFirstMillisecond();
//        java.lang.Object obj47 = null;
//        int int48 = year29.compareTo(obj47);
//        java.lang.Class<?> wildcardClass49 = year29.getClass();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
//        boolean boolean11 = day0.equals((java.lang.Object) timePeriodValues7);
//        long long12 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.util.Date date19 = day18.getEnd();
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) day18, (java.lang.Number) 0.0d);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues17.addChangeListener(seriesChangeListener22);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timePeriodValues17.addChangeListener(seriesChangeListener24);
//        int int26 = timePeriodValues17.getMaxMiddleIndex();
//        java.lang.Object obj27 = timePeriodValues17.clone();
//        int int28 = day0.compareTo((java.lang.Object) timePeriodValues17);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int34 = timePeriodValues33.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = timePeriodValues33.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) (-1));
//        long long41 = day38.getFirstMillisecond();
//        java.util.Date date42 = day38.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long46 = simpleTimePeriod45.getStartMillis();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean48 = simpleTimePeriod45.equals((java.lang.Object) timeZone47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date42, timeZone47);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.util.Date date51 = day50.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long55 = simpleTimePeriod54.getStartMillis();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean57 = simpleTimePeriod54.equals((java.lang.Object) timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date51, timeZone56);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date42, timeZone56);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(date12, date42);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year61.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int67 = timePeriodValues66.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues70 = timePeriodValues66.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        timePeriodValues70.add((org.jfree.data.time.TimePeriod) day71, (java.lang.Number) (-1));
//        long long74 = day71.getFirstMillisecond();
//        java.util.Date date75 = day71.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod78 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long79 = simpleTimePeriod78.getStartMillis();
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean81 = simpleTimePeriod78.equals((java.lang.Object) timeZone80);
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date75, timeZone80);
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day();
//        java.util.Date date84 = day83.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod87 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long88 = simpleTimePeriod87.getStartMillis();
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean90 = simpleTimePeriod87.equals((java.lang.Object) timeZone89);
//        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date84, timeZone89);
//        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date75, timeZone89);
//        boolean boolean93 = year61.equals((java.lang.Object) date75);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod94 = new org.jfree.data.time.SimpleTimePeriod(date12, date75);
//        java.util.Date date95 = simpleTimePeriod94.getEnd();
//        long long96 = simpleTimePeriod94.getStartMillis();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560409200000L + "'", long41 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues70);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560409200000L + "'", long74 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 0L + "'", long79 == 0L);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 0L + "'", long88 == 0L);
//        org.junit.Assert.assertNotNull(timeZone89);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//        org.junit.Assert.assertNotNull(date95);
//        org.junit.Assert.assertTrue("'" + long96 + "' != '" + 1560409200000L + "'", long96 == 1560409200000L);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        java.util.Date date6 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass13 = timePeriodValues12.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues12);
        int int15 = timePeriodValues12.getMinMiddleIndex();
        java.lang.Comparable comparable16 = timePeriodValues12.getKey();
        int int17 = timePeriodValues12.getMaxStartIndex();
        boolean boolean18 = timePeriodValues12.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues12.createCopy((int) (short) 100, 100);
        boolean boolean22 = day3.equals((java.lang.Object) (short) 100);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day3.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 10.0d + "'", comparable16.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(timePeriodValues21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        int int14 = day8.getMonth();
//        long long15 = day8.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass20 = timePeriodValues19.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues19);
//        int int22 = timePeriodValues19.getMinMiddleIndex();
//        java.lang.String str23 = timePeriodValues19.getDomainDescription();
//        timePeriodValues19.setNotify(false);
//        timePeriodValues19.setNotify(false);
//        int int28 = day8.compareTo((java.lang.Object) timePeriodValues19);
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int33 = timePeriodValues32.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = timePeriodValues32.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        timePeriodValues36.add((org.jfree.data.time.TimePeriod) day37, (java.lang.Number) (-1));
//        long long40 = day37.getFirstMillisecond();
//        java.util.Date date41 = day37.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long45 = simpleTimePeriod44.getStartMillis();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean47 = simpleTimePeriod44.equals((java.lang.Object) timeZone46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date41, timeZone46);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        java.util.Date date50 = day49.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long54 = simpleTimePeriod53.getStartMillis();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean56 = simpleTimePeriod53.equals((java.lang.Object) timeZone55);
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date50, timeZone55);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date41, timeZone55);
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year58, (java.lang.Number) (short) 10);
//        int int61 = timePeriodValues19.getMinMiddleIndex();
//        java.lang.String str62 = timePeriodValues19.getDomainDescription();
//        timePeriodValues19.setNotify(false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560452399999L + "'", long15 == 1560452399999L);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560409200000L + "'", long40 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "hi!" + "'", str62.equals("hi!"));
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int16 = timePeriodValues15.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues15.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (-1));
//        long long23 = day20.getFirstMillisecond();
//        java.util.Date date24 = day20.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long28 = simpleTimePeriod27.getStartMillis();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean30 = simpleTimePeriod27.equals((java.lang.Object) timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date24, timeZone29);
//        int int32 = day8.compareTo((java.lang.Object) date24);
//        long long33 = day8.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate34 = day8.getSerialDate();
//        java.lang.String str35 = day8.toString();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues3.createCopy((int) (short) 1, 0);
        int int23 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Object obj24 = timePeriodValues3.clone();
        int int25 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriodValues22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) simpleTimePeriod15);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) (short) 100);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getItemCount();
        int int7 = timePeriodValues3.getMaxStartIndex();
        try {
            timePeriodValues3.delete(0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
//        java.util.Date date10 = day6.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass15 = timePeriodValues14.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues14);
//        int int17 = timePeriodValues14.getMinMiddleIndex();
//        java.lang.String str18 = timePeriodValues14.getDomainDescription();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.util.Date date20 = day19.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.previous();
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day19, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day19.previous();
//        int int25 = day19.getMonth();
//        long long26 = day19.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day19.next();
//        boolean boolean28 = day6.equals((java.lang.Object) regularTimePeriod27);
//        long long29 = day6.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate30 = day6.getSerialDate();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560495599999L + "'", long26 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate30);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean9 = timePeriodValues7.equals((java.lang.Object) (short) -1);
        int int10 = timePeriodValues7.getMinEndIndex();
        timePeriodValues7.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues7.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener15);
        int int17 = year0.compareTo((java.lang.Object) timePeriodValues7);
        int int18 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int18, "hi!", "13-June-2019");
        java.lang.Comparable comparable22 = timePeriodValues21.getKey();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 2019 + "'", comparable22.equals(2019));
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        long long14 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day8.previous();
//        java.util.Calendar calendar16 = null;
//        try {
//            day8.peg(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 1560409200000L);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (-1));
        java.lang.String str14 = timePeriodValue13.toString();
        java.lang.String str15 = timePeriodValue13.toString();
        java.lang.Number number16 = timePeriodValue13.getValue();
        timePeriodValue13.setValue((java.lang.Number) 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1) + "'", number16.equals((-1)));
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
//        boolean boolean11 = day0.equals((java.lang.Object) timePeriodValues7);
//        long long12 = day0.getSerialIndex();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day0.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
        timePeriodValues3.add(timePeriodValue12);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date18 = simpleTimePeriod17.getEnd();
        java.lang.Object obj19 = null;
        boolean boolean20 = simpleTimePeriod17.equals(obj19);
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod17, (double) 100L);
        timePeriodValues3.add(timePeriodValue22);
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = timePeriodValues3.getDataItem(1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 10.0d + "'", comparable14.equals(10.0d));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timePeriodValue25);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        java.lang.String str30 = year29.toString();
//        long long31 = year29.getLastMillisecond();
//        java.lang.String str32 = year29.toString();
//        java.util.Date date33 = year29.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) 1560365999999L);
//        long long36 = year29.getLastMillisecond();
//        long long37 = year29.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day8.previous();
//        java.util.Date date15 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day8.next();
//        long long17 = day8.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        java.lang.String str30 = year29.toString();
//        long long31 = year29.getLastMillisecond();
//        java.lang.String str32 = year29.toString();
//        long long33 = year29.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year29.next();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) 10);
        timePeriodValues3.fireSeriesChanged();
        java.lang.String str14 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,1]");
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        int int12 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str13 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10.0d + "'", comparable11.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[13-June-2019,1]" + "'", str13.equals("TimePeriodValue[13-June-2019,1]"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.Class<?> wildcardClass9 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day8.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.previous();
//        java.util.Date date9 = day4.getEnd();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass15 = timePeriodValues14.getClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass21 = timePeriodValues20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int27 = timePeriodValues26.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues26.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        timePeriodValues30.add((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) (-1));
//        long long34 = day31.getFirstMillisecond();
//        java.util.Date date35 = day31.getStart();
//        java.util.Date date36 = day31.getStart();
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date36, timeZone37);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long42 = simpleTimePeriod41.getStartMillis();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean44 = simpleTimePeriod41.equals((java.lang.Object) timeZone43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date36, timeZone43);
//        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass50 = timePeriodValues49.getClass();
//        timePeriodValues49.fireSeriesChanged();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate53 = day52.getSerialDate();
//        timePeriodValues49.add((org.jfree.data.time.TimePeriod) day52, (double) 12);
//        java.util.Date date56 = day52.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long60 = simpleTimePeriod59.getStartMillis();
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean62 = simpleTimePeriod59.equals((java.lang.Object) timeZone61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date56, timeZone61);
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod(date9, date56);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560409200000L + "'", long34 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        long long3 = day2.getFirstMillisecond();
//        int int4 = day2.getMonth();
//        int int5 = day2.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
        java.util.Date date10 = day6.getStart();
        int int12 = day6.compareTo((java.lang.Object) "2019");
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day6.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int34 = timePeriodValues33.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = timePeriodValues33.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) (-1));
//        long long41 = day38.getFirstMillisecond();
//        java.util.Date date42 = day38.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long46 = simpleTimePeriod45.getStartMillis();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean48 = simpleTimePeriod45.equals((java.lang.Object) timeZone47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date42, timeZone47);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.util.Date date51 = day50.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long55 = simpleTimePeriod54.getStartMillis();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean57 = simpleTimePeriod54.equals((java.lang.Object) timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date51, timeZone56);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date42, timeZone56);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(date12, date42);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year61.previous();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560409200000L + "'", long41 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("hi!");
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,1]");
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date5 = simpleTimePeriod4.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass12 = timePeriodValues11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass18 = timePeriodValues17.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int24 = timePeriodValues23.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues23.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        timePeriodValues27.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (-1));
//        long long31 = day28.getFirstMillisecond();
//        java.util.Date date32 = day28.getStart();
//        java.util.Date date33 = day28.getStart();
//        java.util.TimeZone timeZone34 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date33, timeZone34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long39 = simpleTimePeriod38.getStartMillis();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean41 = simpleTimePeriod38.equals((java.lang.Object) timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date33, timeZone40);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date7, timeZone40);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date5, timeZone40);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date1, timeZone40);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560409200000L + "'", long31 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        boolean boolean8 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        int int6 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 100.0f);
        java.lang.Object obj10 = null;
        try {
            int int11 = simpleTimePeriod2.compareTo(obj10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4L + "'", long7 == 4L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
        int int14 = day8.getMonth();
        org.jfree.data.time.SerialDate serialDate15 = day8.getSerialDate();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day8.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(serialDate15);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        int int12 = timePeriodValues9.getMaxMiddleIndex();
//        boolean boolean13 = timePeriodValues9.isEmpty();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        boolean boolean15 = timePeriodValue3.equals((java.lang.Object) timePeriodValues9);
//        java.lang.String str16 = timePeriodValue3.toString();
//        timePeriodValue3.setValue((java.lang.Number) (short) 0);
//        java.lang.Number number19 = timePeriodValue3.getValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[13-June-2019,1]" + "'", str16.equals("TimePeriodValue[13-June-2019,1]"));
//        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (short) 0 + "'", number19.equals((short) 0));
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) (short) 1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        boolean boolean21 = timePeriodValue17.equals((java.lang.Object) throwableArray20);
        timePeriodValues3.add(timePeriodValue17);
        timePeriodValues3.setNotify(true);
        timePeriodValues3.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1);
        long long7 = year6.getSerialIndex();
        long long8 = year6.getLastMillisecond();
        long long9 = year6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        org.jfree.data.time.SerialDate serialDate14 = day8.getSerialDate();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int21 = timePeriodValues20.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = timePeriodValues20.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        timePeriodValues24.add((org.jfree.data.time.TimePeriod) day25, (java.lang.Number) (-1));
//        long long28 = day25.getFirstMillisecond();
//        java.util.Date date29 = day25.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long33 = simpleTimePeriod32.getStartMillis();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean35 = simpleTimePeriod32.equals((java.lang.Object) timeZone34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date29, timeZone34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long42 = simpleTimePeriod41.getStartMillis();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean44 = simpleTimePeriod41.equals((java.lang.Object) timeZone43);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date38, timeZone43);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date29, timeZone43);
//        boolean boolean47 = year15.equals((java.lang.Object) date29);
//        int int48 = day8.compareTo((java.lang.Object) year15);
//        int int49 = year15.getYear();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560409200000L + "'", long28 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long7 = simpleTimePeriod6.getStartMillis();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean9 = simpleTimePeriod6.equals((java.lang.Object) timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        boolean boolean12 = day0.equals((java.lang.Object) year10);
        java.lang.String str13 = year10.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy(0, (int) '4');
        int int11 = timePeriodValues10.getItemCount();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMaxMiddleIndex();
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean14 = timePeriodValues12.equals((java.lang.Object) (short) -1);
//        int int15 = timePeriodValues12.getMinEndIndex();
//        timePeriodValues12.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues12.setDescription("");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timePeriodValues12.addChangeListener(seriesChangeListener20);
//        int int22 = timePeriodValues12.getMaxStartIndex();
//        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues12);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getEnd();
//        timePeriodValues27.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.previous();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date38);
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date38, timeZone40);
//        boolean boolean42 = day36.equals((java.lang.Object) year41);
//        boolean boolean43 = day28.equals((java.lang.Object) boolean42);
//        long long44 = day28.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 10L);
//        java.util.Calendar calendar47 = null;
//        try {
//            long long48 = day28.getMiddleMillisecond(calendar47);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 43629L + "'", long44 == 43629L);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener17);
        try {
            timePeriodValues3.update(2019, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        int int20 = timePeriodValues3.getMinStartIndex();
        java.lang.String str21 = timePeriodValues3.getRangeDescription();
        int int22 = timePeriodValues3.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener23);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = simpleTimePeriod2.equals(obj4);
//        long long6 = simpleTimePeriod2.getStartMillis();
//        java.util.Date date7 = simpleTimePeriod2.getStart();
//        long long8 = simpleTimePeriod2.getStartMillis();
//        java.util.Date date9 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date11);
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11, timeZone13);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date9, date11);
//        long long16 = simpleTimePeriod15.getEndMillis();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        int int14 = day8.getMonth();
//        long long15 = day8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day8.next();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560452399999L + "'", long15 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        long long3 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.lang.Object obj4 = null;
        boolean boolean5 = simpleTimePeriod2.equals(obj4);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 100L);
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) throwableArray6);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean13 = timePeriodValues11.equals((java.lang.Object) (short) -1);
        java.lang.String str14 = timePeriodValues11.getRangeDescription();
        int int15 = timePeriodValues11.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues11.addChangeListener(seriesChangeListener16);
        boolean boolean18 = timePeriodValue3.equals((java.lang.Object) timePeriodValues11);
        java.lang.String str19 = timePeriodValues11.getDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day8.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day8.next();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass16 = timePeriodValues15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int22 = timePeriodValues21.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues21.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (-1));
//        long long29 = day26.getFirstMillisecond();
//        java.util.Date date30 = day26.getStart();
//        java.util.Date date31 = day26.getStart();
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date31, timeZone32);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long37 = simpleTimePeriod36.getStartMillis();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean39 = simpleTimePeriod36.equals((java.lang.Object) timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date31, timeZone38);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date5, timeZone38);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date3, timeZone38);
//        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day42);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
        timePeriodValues3.delete((int) (byte) 10, (int) (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        java.util.Date date4 = day3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        java.util.Calendar calendar7 = null;
        try {
            day3.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        timePeriodValues3.setRangeDescription("13-June-2019");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod7.equals(obj9);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod7, (double) 100L);
        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) simpleTimePeriod7);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass18 = timePeriodValues17.getClass();
        java.lang.String str19 = timePeriodValues17.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean25 = timePeriodValues23.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date29 = simpleTimePeriod28.getEnd();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (java.lang.Number) 1560409200000L);
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = timePeriodValues17.createCopy((int) (short) 1, 0);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener37);
        boolean boolean39 = simpleTimePeriod7.equals((java.lang.Object) timePeriodValues17);
        timePeriodValues17.setDomainDescription("org.jfree.data.general.SeriesException: 13-June-2019");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timePeriodValues36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        java.lang.Comparable comparable5 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 10.0d + "'", comparable5.equals(10.0d));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) throwableArray6);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean13 = timePeriodValues11.equals((java.lang.Object) (short) -1);
        java.lang.String str14 = timePeriodValues11.getRangeDescription();
        int int15 = timePeriodValues11.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues11.addChangeListener(seriesChangeListener16);
        boolean boolean18 = timePeriodValue3.equals((java.lang.Object) timePeriodValues11);
        try {
            org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValues11.getTimePeriod(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getItemCount();
        int int5 = timePeriodValues3.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "", "org.jfree.data.general.SeriesException: TimePeriodValue[13-June-2019,1]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(2019L, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: TimePeriodValue[13-June-2019,1]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,10]");
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues3.getItemCount();
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: 13-June-2019");
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
        timePeriodValues3.add(timePeriodValue12);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date18 = simpleTimePeriod17.getEnd();
        java.lang.Object obj19 = null;
        boolean boolean20 = simpleTimePeriod17.equals(obj19);
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod17, (double) 100L);
        timePeriodValues3.add(timePeriodValue22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date27 = simpleTimePeriod26.getEnd();
        boolean boolean28 = timePeriodValue22.equals((java.lang.Object) date27);
        java.lang.Class<?> wildcardClass29 = timePeriodValue22.getClass();
        java.lang.Object obj30 = timePeriodValue22.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 10.0d + "'", comparable14.equals(10.0d));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "", "org.jfree.data.general.SeriesChangeEvent[source=-1]", "13-June-2019");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day19);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
        boolean boolean9 = day3.equals((java.lang.Object) year8);
        java.lang.Number number10 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, number10);
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timePeriod12);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        timePeriodValues3.setNotify(false);
//        java.lang.Class<?> wildcardClass10 = timePeriodValues3.getClass();
//        java.util.Date date11 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass16 = timePeriodValues15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass22 = timePeriodValues21.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int28 = timePeriodValues27.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = timePeriodValues27.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        timePeriodValues31.add((org.jfree.data.time.TimePeriod) day32, (java.lang.Number) (-1));
//        long long35 = day32.getFirstMillisecond();
//        java.util.Date date36 = day32.getStart();
//        java.util.Date date37 = day32.getStart();
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date37, timeZone38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long43 = simpleTimePeriod42.getStartMillis();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean45 = simpleTimePeriod42.equals((java.lang.Object) timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date37, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone44);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues31);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560409200000L + "'", long35 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
        int int14 = day8.getMonth();
        org.jfree.data.time.SerialDate serialDate15 = day8.getSerialDate();
        java.util.Date date16 = day8.getEnd();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        int int2 = day0.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day8);
//        java.lang.String str15 = seriesChangeEvent14.toString();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]" + "'", str15.equals("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]"));
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,1]");
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
//        int int6 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
//        long long7 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date8 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass13 = timePeriodValues12.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues12);
//        int int15 = timePeriodValues12.getMinMiddleIndex();
//        timePeriodValues12.setDomainDescription("hi!");
//        java.lang.Class<?> wildcardClass18 = timePeriodValues12.getClass();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.util.Date date20 = day19.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date20);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date25 = simpleTimePeriod24.getEnd();
//        long long26 = simpleTimePeriod24.getStartMillis();
//        java.util.Date date27 = simpleTimePeriod24.getStart();
//        boolean boolean29 = simpleTimePeriod24.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long33 = simpleTimePeriod32.getStartMillis();
//        int int34 = simpleTimePeriod24.compareTo((java.lang.Object) simpleTimePeriod32);
//        java.util.Date date35 = simpleTimePeriod32.getEnd();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
//        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass41 = timePeriodValues40.getClass();
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
//        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass47 = timePeriodValues46.getClass();
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int53 = timePeriodValues52.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues56 = timePeriodValues52.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        timePeriodValues56.add((org.jfree.data.time.TimePeriod) day57, (java.lang.Number) (-1));
//        long long60 = day57.getFirstMillisecond();
//        java.util.Date date61 = day57.getStart();
//        java.util.Date date62 = day57.getStart();
//        java.util.TimeZone timeZone63 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date62, timeZone63);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod67 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long68 = simpleTimePeriod67.getStartMillis();
//        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean70 = simpleTimePeriod67.equals((java.lang.Object) timeZone69);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date62, timeZone69);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date35, timeZone69);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date20, timeZone69);
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date8, timeZone69);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4L + "'", long7 == 4L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues56);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560409200000L + "'", long60 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(timeZone69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertNull(regularTimePeriod73);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues3.createCopy((int) (short) 1, 0);
        int int23 = timePeriodValues22.getMaxMiddleIndex();
        java.lang.String str24 = timePeriodValues22.getDomainDescription();
        int int25 = timePeriodValues22.getMinEndIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriodValues22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
//        int int6 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
//        java.lang.String str7 = day3.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day3, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "2019");
//        int int11 = day3.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560409200000L, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        int int6 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 100.0f);
        java.lang.Object obj10 = timePeriodValue9.clone();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4L + "'", long7 == 4L);
        org.junit.Assert.assertNotNull(obj10);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setDescription("");
//        int int13 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
//        int int17 = timePeriodValues16.getMaxMiddleIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int22 = timePeriodValues21.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues21.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (-1));
//        long long29 = day26.getFirstMillisecond();
//        java.util.Date date30 = day26.getStart();
//        int int31 = day26.getYear();
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) 8);
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue35 = timePeriodValues16.getDataItem(7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) false);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) day10);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        java.util.Date date17 = day16.getEnd();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues15.addChangeListener(seriesChangeListener20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues15.addChangeListener(seriesChangeListener22);
        int int24 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        boolean boolean28 = timePeriodValues15.equals((java.lang.Object) simpleTimePeriod27);
        long long29 = simpleTimePeriod27.getStartMillis();
        boolean boolean30 = day10.equals((java.lang.Object) long29);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setKey((java.lang.Comparable) 3);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int17 = timePeriodValues16.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues16.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day21, (java.lang.Number) (-1));
//        long long24 = day21.getFirstMillisecond();
//        int int25 = day21.getYear();
//        long long26 = day21.getMiddleMillisecond();
//        int int27 = day21.getMonth();
//        long long28 = day21.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass33 = timePeriodValues32.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues32);
//        int int35 = timePeriodValues32.getMinMiddleIndex();
//        java.lang.String str36 = timePeriodValues32.getDomainDescription();
//        timePeriodValues32.setNotify(false);
//        timePeriodValues32.setNotify(false);
//        int int41 = day21.compareTo((java.lang.Object) timePeriodValues32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int46 = timePeriodValues45.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues49 = timePeriodValues45.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        timePeriodValues49.add((org.jfree.data.time.TimePeriod) day50, (java.lang.Number) (-1));
//        long long53 = day50.getFirstMillisecond();
//        java.util.Date date54 = day50.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long58 = simpleTimePeriod57.getStartMillis();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean60 = simpleTimePeriod57.equals((java.lang.Object) timeZone59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date54, timeZone59);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.util.Date date63 = day62.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long67 = simpleTimePeriod66.getStartMillis();
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean69 = simpleTimePeriod66.equals((java.lang.Object) timeZone68);
//        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date63, timeZone68);
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date54, timeZone68);
//        timePeriodValues32.add((org.jfree.data.time.TimePeriod) year71, (java.lang.Number) (short) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year71, (java.lang.Number) 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560452399999L + "'", long26 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560452399999L + "'", long28 == 1560452399999L);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues49);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560409200000L + "'", long53 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.Class<?> wildcardClass9 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass9);
        java.lang.Object obj11 = seriesChangeEvent10.getSource();
        java.lang.String str12 = seriesChangeEvent10.toString();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=class org.jfree.data.time.TimePeriodValues]" + "'", str12.equals("org.jfree.data.general.SeriesChangeEvent[source=class org.jfree.data.time.TimePeriodValues]"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=class org.jfree.data.time.TimePeriodValues]");
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener14);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10.0d + "'", comparable11.equals(10.0d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(0, (int) (byte) -1);
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: 13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getItemCount();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriod timePeriod6 = null;
        try {
            timePeriodValues3.add(timePeriod6, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        int int14 = day8.getMonth();
//        long long15 = day8.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass20 = timePeriodValues19.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues19);
//        int int22 = timePeriodValues19.getMinMiddleIndex();
//        java.lang.String str23 = timePeriodValues19.getDomainDescription();
//        timePeriodValues19.setNotify(false);
//        timePeriodValues19.setNotify(false);
//        int int28 = day8.compareTo((java.lang.Object) timePeriodValues19);
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int33 = timePeriodValues32.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = timePeriodValues32.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        timePeriodValues36.add((org.jfree.data.time.TimePeriod) day37, (java.lang.Number) (-1));
//        long long40 = day37.getFirstMillisecond();
//        java.util.Date date41 = day37.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long45 = simpleTimePeriod44.getStartMillis();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean47 = simpleTimePeriod44.equals((java.lang.Object) timeZone46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date41, timeZone46);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        java.util.Date date50 = day49.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long54 = simpleTimePeriod53.getStartMillis();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean56 = simpleTimePeriod53.equals((java.lang.Object) timeZone55);
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date50, timeZone55);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date41, timeZone55);
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year58, (java.lang.Number) (short) 10);
//        java.util.Calendar calendar61 = null;
//        try {
//            long long62 = year58.getFirstMillisecond(calendar61);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560452399999L + "'", long15 == 1560452399999L);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560409200000L + "'", long40 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues3.createCopy((int) (short) 1, 0);
        java.lang.String str23 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getEnd();
        int int29 = simpleTimePeriod26.compareTo((java.lang.Object) day27);
        java.util.Date date30 = day27.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, 0.0d);
        timePeriodValues3.add(timePeriodValue32);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date37 = simpleTimePeriod36.getEnd();
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod36.equals(obj38);
        long long40 = simpleTimePeriod36.getStartMillis();
        java.util.Date date41 = simpleTimePeriod36.getStart();
        long long42 = simpleTimePeriod36.getStartMillis();
        java.util.Date date43 = simpleTimePeriod36.getStart();
        java.util.Date date44 = simpleTimePeriod36.getStart();
        boolean boolean45 = timePeriodValue32.equals((java.lang.Object) date44);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriodValues22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        java.lang.String str9 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: 13-June-2019");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10.0d + "'", comparable8.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener20);
        int int22 = timePeriodValues3.getItemCount();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 13);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod25, (double) 0L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Object obj9 = timePeriodValues3.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date13 = simpleTimePeriod12.getEnd();
        long long14 = simpleTimePeriod12.getStartMillis();
        java.util.Date date15 = simpleTimePeriod12.getStart();
        boolean boolean17 = simpleTimePeriod12.equals((java.lang.Object) false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long21 = simpleTimePeriod20.getStartMillis();
        int int22 = simpleTimePeriod12.compareTo((java.lang.Object) simpleTimePeriod20);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getEnd();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues28.addChangeListener(seriesChangeListener33);
        boolean boolean35 = year24.equals((java.lang.Object) timePeriodValues28);
        long long36 = year24.getFirstMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, (double) 1560365999999L);
        timePeriodValues3.setKey((java.lang.Comparable) 4L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-31507200000L) + "'", long36 == (-31507200000L));
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        int int12 = day8.getYear();
//        long long13 = day8.getMiddleMillisecond();
//        long long14 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day8.previous();
//        long long16 = day8.getFirstMillisecond();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
//        int int19 = year17.getYear();
//        long long20 = year17.getFirstMillisecond();
//        int int21 = day8.compareTo((java.lang.Object) year17);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setDescription("");
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(0, (int) (byte) -1);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
//        java.util.Date date18 = day17.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.next();
//        long long20 = day17.getFirstMillisecond();
//        timePeriodValues3.setKey((java.lang.Comparable) day17);
//        java.lang.String str22 = timePeriodValues3.getDescription();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 8, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getEnd();
//        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
//        java.util.Date date6 = day3.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, 0.0d);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.util.Date date13 = day12.getEnd();
//        int int14 = simpleTimePeriod11.compareTo((java.lang.Object) day12);
//        boolean boolean15 = timePeriodValue8.equals((java.lang.Object) simpleTimePeriod11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int20 = timePeriodValues19.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = timePeriodValues19.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) (-1));
//        long long27 = day24.getFirstMillisecond();
//        int int28 = day24.getYear();
//        long long29 = day24.getMiddleMillisecond();
//        long long30 = day24.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day24.previous();
//        long long32 = day24.getFirstMillisecond();
//        int int33 = simpleTimePeriod11.compareTo((java.lang.Object) day24);
//        long long34 = day24.getSerialIndex();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560409200000L + "'", long27 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560452399999L + "'", long29 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560409200000L + "'", long30 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560409200000L + "'", long32 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 43629L + "'", long34 == 43629L);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
        timePeriodValues7.fireSeriesChanged();
        java.lang.Object obj12 = timePeriodValues7.clone();
        int int13 = timePeriodValues7.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.String str7 = timePeriodValues6.getDescription();
        boolean boolean8 = year0.equals((java.lang.Object) str7);
        long long9 = year0.getFirstMillisecond();
        long long10 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        int int8 = timePeriodValues3.getMinEndIndex();
        int int9 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setDomainDescription("hi!");
        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,1]");
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getEnd();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
//        java.util.Date date15 = day10.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date15, timeZone16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int24 = timePeriodValues23.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues23.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        timePeriodValues27.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (-1));
//        long long31 = day28.getFirstMillisecond();
//        java.util.Date date32 = day28.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long36 = simpleTimePeriod35.getStartMillis();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean38 = simpleTimePeriod35.equals((java.lang.Object) timeZone37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date32, timeZone37);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.util.Date date41 = day40.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long45 = simpleTimePeriod44.getStartMillis();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean47 = simpleTimePeriod44.equals((java.lang.Object) timeZone46);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date41, timeZone46);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date32, timeZone46);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date15, timeZone46);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date3, timeZone46);
//        java.lang.Class<?> wildcardClass52 = year51.getClass();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560409200000L + "'", long31 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = day0.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.SerialDate serialDate12 = day0.getSerialDate();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 1577865599999L);
        int int5 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
//        timePeriodValues3.add(timePeriodValue12);
//        java.lang.String str14 = timePeriodValue12.toString();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass23 = timePeriodValues22.getClass();
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timePeriodValues22.removePropertyChangeListener(propertyChangeListener24);
//        boolean boolean26 = day15.equals((java.lang.Object) timePeriodValues22);
//        long long27 = day15.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day15.next();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date32 = simpleTimePeriod31.getEnd();
//        long long33 = simpleTimePeriod31.getStartMillis();
//        java.util.Date date34 = simpleTimePeriod31.getStart();
//        boolean boolean36 = simpleTimePeriod31.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long40 = simpleTimePeriod39.getStartMillis();
//        int int41 = simpleTimePeriod31.compareTo((java.lang.Object) simpleTimePeriod39);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        int int43 = day15.compareTo((java.lang.Object) simpleTimePeriod39);
//        boolean boolean44 = timePeriodValue12.equals((java.lang.Object) int43);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[13-June-2019,1]" + "'", str14.equals("TimePeriodValue[13-June-2019,1]"));
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43629L + "'", long27 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMaxStartIndex();
        boolean boolean9 = timePeriodValues3.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues3.createCopy((int) (short) 100, 100);
        java.lang.String str13 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        timePeriodValues3.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass9 = timePeriodValues8.getClass();
        java.lang.String str10 = timePeriodValues8.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean16 = timePeriodValues14.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date20 = simpleTimePeriod19.getEnd();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 1560409200000L);
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 2);
        timePeriodValues8.fireSeriesChanged();
        int int26 = timePeriodValues8.getMinStartIndex();
        int int27 = timePeriodValues8.getMinEndIndex();
        boolean boolean28 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues8);
        java.util.Date date29 = simpleTimePeriod2.getStart();
        long long30 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 1560409200000L);
        int int12 = timePeriodValues3.getMaxEndIndex();
        int int13 = timePeriodValues3.getItemCount();
        java.lang.String str14 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
//        boolean boolean11 = day0.equals((java.lang.Object) timePeriodValues7);
//        long long12 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day0.next();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date17 = simpleTimePeriod16.getEnd();
//        long long18 = simpleTimePeriod16.getStartMillis();
//        java.util.Date date19 = simpleTimePeriod16.getStart();
//        boolean boolean21 = simpleTimePeriod16.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        int int26 = simpleTimePeriod16.compareTo((java.lang.Object) simpleTimePeriod24);
//        java.util.Date date27 = simpleTimePeriod24.getEnd();
//        int int28 = day0.compareTo((java.lang.Object) simpleTimePeriod24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        org.jfree.data.time.SerialDate serialDate14 = day8.getSerialDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate14);
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        long long18 = day16.getSerialIndex();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Object obj9 = timePeriodValues3.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date13 = simpleTimePeriod12.getEnd();
        long long14 = simpleTimePeriod12.getStartMillis();
        java.util.Date date15 = simpleTimePeriod12.getStart();
        boolean boolean17 = simpleTimePeriod12.equals((java.lang.Object) false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long21 = simpleTimePeriod20.getStartMillis();
        int int22 = simpleTimePeriod12.compareTo((java.lang.Object) simpleTimePeriod20);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getEnd();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues28.addChangeListener(seriesChangeListener33);
        boolean boolean35 = year24.equals((java.lang.Object) timePeriodValues28);
        long long36 = year24.getFirstMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, (double) 1560365999999L);
        java.lang.Class<?> wildcardClass39 = timePeriodValues3.getClass();
        int int40 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-31507200000L) + "'", long36 == (-31507200000L));
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day8.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod14);
//        int int16 = timePeriodValues15.getMinMiddleIndex();
//        int int17 = timePeriodValues15.getMaxEndIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timePeriodValues15.addChangeListener(seriesChangeListener18);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]", "org.jfree.data.general.SeriesChangeEvent[source=-1]");
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.lang.String str7 = year6.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969" + "'", str7.equals("1969"));
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
//        java.util.Date date10 = day6.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass15 = timePeriodValues14.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues14);
//        int int17 = timePeriodValues14.getMinMiddleIndex();
//        java.lang.String str18 = timePeriodValues14.getDomainDescription();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.util.Date date20 = day19.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.previous();
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day19, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day19.previous();
//        int int25 = day19.getMonth();
//        long long26 = day19.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day19.next();
//        boolean boolean28 = day6.equals((java.lang.Object) regularTimePeriod27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.util.Date date30 = day29.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) (short) 1);
//        boolean boolean34 = timePeriodValue32.equals((java.lang.Object) (short) 1);
//        timePeriodValue32.setValue((java.lang.Number) 12);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day37, (java.lang.Number) (short) 1);
//        boolean boolean41 = timePeriodValue32.equals((java.lang.Object) timePeriodValue40);
//        int int42 = day6.compareTo((java.lang.Object) timePeriodValue32);
//        org.jfree.data.time.SerialDate serialDate43 = day6.getSerialDate();
//        java.util.Calendar calendar44 = null;
//        try {
//            day6.peg(calendar44);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560495599999L + "'", long26 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(serialDate43);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]", "org.jfree.data.general.SeriesChangeEvent[source=-1]");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean19 = timePeriodValues17.equals((java.lang.Object) (short) -1);
        int int20 = timePeriodValues17.getMinEndIndex();
        timePeriodValues17.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) (short) 1);
        timePeriodValues17.add(timePeriodValue26);
        java.lang.Comparable comparable28 = timePeriodValues17.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date32 = simpleTimePeriod31.getEnd();
        java.lang.Object obj33 = null;
        boolean boolean34 = simpleTimePeriod31.equals(obj33);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod31, (double) 100L);
        timePeriodValues17.add(timePeriodValue36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date41 = simpleTimePeriod40.getEnd();
        boolean boolean42 = timePeriodValue36.equals((java.lang.Object) date41);
        java.lang.Class<?> wildcardClass43 = timePeriodValue36.getClass();
        timePeriodValues3.add(timePeriodValue36);
        java.lang.Number number45 = timePeriodValue36.getValue();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 10.0d + "'", comparable28.equals(10.0d));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 100.0d + "'", number45.equals(100.0d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
        java.util.Date date10 = day6.getStart();
        int int12 = day6.compareTo((java.lang.Object) "2019");
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day6.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setKey((java.lang.Comparable) 3);
        int int13 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        try {
            timePeriodValues3.delete((int) ' ', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        int int5 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        long long6 = simpleTimePeriod2.getEndMillis();
        java.lang.Class<?> wildcardClass7 = simpleTimePeriod2.getClass();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4L + "'", long6 == 4L);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass12 = timePeriodValues11.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues11);
        java.lang.String str14 = seriesChangeEvent13.toString();
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) str14);
        timePeriodValues3.setRangeDescription("");
        int int18 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        timePeriodValues3.setDomainDescription("TimePeriodValue[13-June-2019,1]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean15 = timePeriodValues13.equals((java.lang.Object) (short) -1);
        int int16 = timePeriodValues13.getMinEndIndex();
        timePeriodValues13.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) (short) 1);
        timePeriodValues13.add(timePeriodValue22);
        timePeriodValue22.setValue((java.lang.Number) (short) 10);
        timePeriodValue22.setValue((java.lang.Number) 13);
        org.jfree.data.time.TimePeriod timePeriod28 = timePeriodValue22.getPeriod();
        timePeriodValues3.add(timePeriod28, (double) 11);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timePeriod28);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
//        boolean boolean11 = day0.equals((java.lang.Object) timePeriodValues7);
//        org.jfree.data.time.SerialDate serialDate12 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day0.previous();
//        long long14 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        int int13 = day8.getYear();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day8.getLastMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.Class class0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getEnd();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
        java.util.Date date10 = day5.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.util.Date date21 = day20.getEnd();
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day20.previous();
        java.util.Date date25 = day20.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date25, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date10, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
        int int30 = day28.getYear();
        java.util.Date date31 = day28.getStart();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod2, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "TimePeriodValue[13-June-2019,0]");
        int int7 = timePeriodValues6.getMinEndIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date5);
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
//        boolean boolean9 = day3.equals((java.lang.Object) year8);
//        long long10 = day3.getLastMillisecond();
//        long long11 = day3.getFirstMillisecond();
//        long long12 = day3.getLastMillisecond();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date14);
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14, timeZone16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        long long21 = year19.getSerialIndex();
//        boolean boolean22 = day3.equals((java.lang.Object) year19);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        int int12 = timePeriodValues9.getMaxMiddleIndex();
//        boolean boolean13 = timePeriodValues9.isEmpty();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues9);
//        boolean boolean15 = timePeriodValue3.equals((java.lang.Object) timePeriodValues9);
//        java.lang.String str16 = timePeriodValue3.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean22 = timePeriodValues20.equals((java.lang.Object) (short) -1);
//        int int23 = timePeriodValues20.getMinEndIndex();
//        timePeriodValues20.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (short) 1);
//        timePeriodValues20.add(timePeriodValue29);
//        java.lang.Comparable comparable31 = timePeriodValues20.getKey();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date35 = simpleTimePeriod34.getEnd();
//        java.lang.Object obj36 = null;
//        boolean boolean37 = simpleTimePeriod34.equals(obj36);
//        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod34, (double) 100L);
//        timePeriodValues20.add(timePeriodValue39);
//        boolean boolean41 = timePeriodValue3.equals((java.lang.Object) timePeriodValues20);
//        java.lang.String str42 = timePeriodValues20.getDomainDescription();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[13-June-2019,1]" + "'", str16.equals("TimePeriodValue[13-June-2019,1]"));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 10.0d + "'", comparable31.equals(10.0d));
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        java.util.Date date5 = simpleTimePeriod2.getStart();
//        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long11 = simpleTimePeriod10.getStartMillis();
//        int int12 = simpleTimePeriod2.compareTo((java.lang.Object) simpleTimePeriod10);
//        java.util.Date date13 = simpleTimePeriod10.getEnd();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass19 = timePeriodValues18.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass25 = timePeriodValues24.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int31 = timePeriodValues30.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = timePeriodValues30.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) day35, (java.lang.Number) (-1));
//        long long38 = day35.getFirstMillisecond();
//        java.util.Date date39 = day35.getStart();
//        java.util.Date date40 = day35.getStart();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date40, timeZone41);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long46 = simpleTimePeriod45.getStartMillis();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean48 = simpleTimePeriod45.equals((java.lang.Object) timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date40, timeZone47);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date13, timeZone47);
//        int int51 = day50.getMonth();
//        int int52 = day50.getDayOfMonth();
//        int int53 = day50.getMonth();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues34);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560409200000L + "'", long38 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 12 + "'", int51 == 12);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 31 + "'", int52 == 31);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        java.lang.Comparable comparable13 = timePeriodValues3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener14);
        int int16 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 10.0d + "'", comparable13.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day8.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod14);
//        int int16 = timePeriodValues15.getMinMiddleIndex();
//        timePeriodValues15.fireSeriesChanged();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date21 = simpleTimePeriod20.getEnd();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = simpleTimePeriod20.equals(obj22);
//        long long24 = simpleTimePeriod20.getStartMillis();
//        java.util.Date date25 = simpleTimePeriod20.getStart();
//        java.lang.Number number26 = null;
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, number26);
//        java.util.Date date28 = simpleTimePeriod20.getEnd();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date28);
//    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
//        int int6 = timePeriodValues3.getMaxMiddleIndex();
//        int int7 = timePeriodValues3.getMaxEndIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date11 = simpleTimePeriod10.getEnd();
//        java.lang.Object obj12 = null;
//        boolean boolean13 = simpleTimePeriod10.equals(obj12);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod10, (double) 100L);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod10, 1.0d);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date21 = simpleTimePeriod20.getEnd();
//        long long22 = simpleTimePeriod20.getStartMillis();
//        java.util.Date date23 = simpleTimePeriod20.getStart();
//        boolean boolean25 = simpleTimePeriod20.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long29 = simpleTimePeriod28.getStartMillis();
//        int int30 = simpleTimePeriod20.compareTo((java.lang.Object) simpleTimePeriod28);
//        java.util.Date date31 = simpleTimePeriod28.getEnd();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getEnd();
//        timePeriodValues36.add((org.jfree.data.time.TimePeriod) day37, (java.lang.Number) 0.0d);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timePeriodValues36.addChangeListener(seriesChangeListener41);
//        boolean boolean43 = year32.equals((java.lang.Object) timePeriodValues36);
//        boolean boolean44 = simpleTimePeriod10.equals((java.lang.Object) year32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year32.next();
//        java.util.Date date46 = regularTimePeriod45.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date50 = simpleTimePeriod49.getEnd();
//        long long51 = simpleTimePeriod49.getStartMillis();
//        java.util.Date date52 = simpleTimePeriod49.getStart();
//        boolean boolean54 = simpleTimePeriod49.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long58 = simpleTimePeriod57.getStartMillis();
//        int int59 = simpleTimePeriod49.compareTo((java.lang.Object) simpleTimePeriod57);
//        java.util.Date date60 = simpleTimePeriod57.getEnd();
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
//        org.jfree.data.time.TimePeriodValues timePeriodValues65 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass66 = timePeriodValues65.getClass();
//        java.lang.Class class67 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass66);
//        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass72 = timePeriodValues71.getClass();
//        java.lang.Class class73 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass72);
//        org.jfree.data.time.TimePeriodValues timePeriodValues77 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int78 = timePeriodValues77.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues81 = timePeriodValues77.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day();
//        timePeriodValues81.add((org.jfree.data.time.TimePeriod) day82, (java.lang.Number) (-1));
//        long long85 = day82.getFirstMillisecond();
//        java.util.Date date86 = day82.getStart();
//        java.util.Date date87 = day82.getStart();
//        java.util.TimeZone timeZone88 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date87, timeZone88);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod92 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long93 = simpleTimePeriod92.getStartMillis();
//        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean95 = simpleTimePeriod92.equals((java.lang.Object) timeZone94);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date87, timeZone94);
//        org.jfree.data.time.Day day97 = new org.jfree.data.time.Day(date60, timeZone94);
//        org.jfree.data.time.Year year98 = new org.jfree.data.time.Year(date46, timeZone94);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNotNull(class67);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertNotNull(class73);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues81);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560409200000L + "'", long85 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertNull(regularTimePeriod89);
//        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 0L + "'", long93 == 0L);
//        org.junit.Assert.assertNotNull(timeZone94);
//        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
//        org.junit.Assert.assertNull(regularTimePeriod96);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod7.equals(obj9);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod7, (double) 100L);
        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) simpleTimePeriod7);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass18 = timePeriodValues17.getClass();
        java.lang.String str19 = timePeriodValues17.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean25 = timePeriodValues23.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date29 = simpleTimePeriod28.getEnd();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (java.lang.Number) 1560409200000L);
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = timePeriodValues17.createCopy((int) (short) 1, 0);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener37);
        boolean boolean39 = simpleTimePeriod7.equals((java.lang.Object) timePeriodValues17);
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560538799999L, "hi!", "TimePeriodValue[13-June-2019,0]");
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues43.removePropertyChangeListener(propertyChangeListener44);
        try {
            int int46 = simpleTimePeriod7.compareTo((java.lang.Object) timePeriodValues43);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timePeriodValues36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        timePeriodValues7.delete((int) (byte) 100, 11);
        int int11 = timePeriodValues7.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        long long5 = simpleTimePeriod4.getStartMillis();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean7 = simpleTimePeriod4.equals((java.lang.Object) timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year8);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        timePeriodValues3.setNotify(true);
        java.lang.Object obj19 = timePeriodValues3.clone();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        int int22 = year20.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (java.lang.Number) 1577865599999L);
        timePeriodValues3.add(timePeriodValue24);
        int int26 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        int int9 = timePeriodValues3.getMaxStartIndex();
        boolean boolean10 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10.0d + "'", comparable8.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int10 = timePeriodValues9.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues9.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) (-1));
//        long long17 = day14.getFirstMillisecond();
//        java.util.Date date18 = day14.getStart();
//        java.util.Date date19 = day14.getStart();
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date19, timeZone20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass26 = timePeriodValues25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass32 = timePeriodValues31.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int38 = timePeriodValues37.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = timePeriodValues37.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        timePeriodValues41.add((org.jfree.data.time.TimePeriod) day42, (java.lang.Number) (-1));
//        long long45 = day42.getFirstMillisecond();
//        java.util.Date date46 = day42.getStart();
//        java.util.Date date47 = day42.getStart();
//        java.util.TimeZone timeZone48 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date47, timeZone48);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long53 = simpleTimePeriod52.getStartMillis();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean55 = simpleTimePeriod52.equals((java.lang.Object) timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date47, timeZone54);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date47);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(date19, date47);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        java.util.Date date60 = day59.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day59.previous();
//        long long62 = day59.getMiddleMillisecond();
//        int int63 = day59.getYear();
//        java.util.Date date64 = day59.getEnd();
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        java.util.Date date66 = day65.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent67 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date66);
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date66, timeZone68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date47, timeZone68);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560409200000L + "'", long45 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560452399999L + "'", long62 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2019 + "'", int63 == 2019);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(timeZone68);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = day0.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.SerialDate serialDate12 = day0.getSerialDate();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate12);
        java.lang.Class<?> wildcardClass14 = seriesChangeEvent13.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
//        boolean boolean11 = day0.equals((java.lang.Object) timePeriodValues7);
//        long long12 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day0.next();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date17 = simpleTimePeriod16.getEnd();
//        long long18 = simpleTimePeriod16.getStartMillis();
//        java.util.Date date19 = simpleTimePeriod16.getStart();
//        boolean boolean21 = simpleTimePeriod16.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        int int26 = simpleTimePeriod16.compareTo((java.lang.Object) simpleTimePeriod24);
//        java.util.Date date27 = simpleTimePeriod24.getEnd();
//        int int28 = day0.compareTo((java.lang.Object) simpleTimePeriod24);
//        java.util.Date date29 = simpleTimePeriod24.getEnd();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(date29);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) false);
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) (short) 0);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 9);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
//        boolean boolean11 = day0.equals((java.lang.Object) timePeriodValues7);
//        long long12 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day0.next();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date17 = simpleTimePeriod16.getEnd();
//        long long18 = simpleTimePeriod16.getStartMillis();
//        java.util.Date date19 = simpleTimePeriod16.getStart();
//        boolean boolean21 = simpleTimePeriod16.equals((java.lang.Object) false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        int int26 = simpleTimePeriod16.compareTo((java.lang.Object) simpleTimePeriod24);
//        java.util.Date date27 = simpleTimePeriod24.getEnd();
//        int int28 = day0.compareTo((java.lang.Object) simpleTimePeriod24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day0.previous();
//        java.util.Calendar calendar30 = null;
//        try {
//            long long31 = day0.getLastMillisecond(calendar30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        java.lang.String str30 = year29.toString();
//        long long31 = year29.getLastMillisecond();
//        java.lang.String str32 = year29.toString();
//        java.util.Date date33 = year29.getStart();
//        int int34 = year29.getYear();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("hi!");
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,1]");
        try {
            timePeriodValues3.update((int) (short) 100, (java.lang.Number) 4L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.lang.Object obj4 = null;
        boolean boolean5 = simpleTimePeriod2.equals(obj4);
        long long6 = simpleTimePeriod2.getStartMillis();
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long7);
        java.lang.String str9 = seriesChangeEvent8.toString();
        java.lang.String str10 = seriesChangeEvent8.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=97]" + "'", str9.equals("org.jfree.data.general.SeriesChangeEvent[source=97]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=97]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=97]"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.previous();
        java.lang.Object obj12 = null;
        boolean boolean13 = day8.equals(obj12);
        int int14 = day8.getYear();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day8.getMiddleMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, 2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int10 = timePeriodValues9.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues9.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) (-1));
//        long long17 = day14.getFirstMillisecond();
//        java.util.Date date18 = day14.getStart();
//        java.util.Date date19 = day14.getStart();
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date19, timeZone20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass26 = timePeriodValues25.getClass();
//        timePeriodValues25.fireSeriesChanged();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day28, (double) 12);
//        java.util.Date date32 = day28.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass37 = timePeriodValues36.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass43 = timePeriodValues42.getClass();
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int49 = timePeriodValues48.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues48.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        timePeriodValues52.add((org.jfree.data.time.TimePeriod) day53, (java.lang.Number) (-1));
//        long long56 = day53.getFirstMillisecond();
//        java.util.Date date57 = day53.getStart();
//        java.util.Date date58 = day53.getStart();
//        java.util.TimeZone timeZone59 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date58, timeZone59);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long64 = simpleTimePeriod63.getStartMillis();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean66 = simpleTimePeriod63.equals((java.lang.Object) timeZone65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date58, timeZone65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date32, timeZone65);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date32);
//        java.util.Calendar calendar70 = null;
//        try {
//            long long71 = year69.getFirstMillisecond(calendar70);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560409200000L + "'", long56 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setDescription("");
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(0, (int) (byte) -1);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
//        java.util.Date date18 = day17.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.next();
//        long long20 = day17.getFirstMillisecond();
//        timePeriodValues3.setKey((java.lang.Comparable) day17);
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (double) 5);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener17);
        java.lang.Object obj19 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriod timePeriod20 = null;
        try {
            timePeriodValues3.add(timePeriod20, (java.lang.Number) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: hi!");
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test259");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
//        int int3 = day0.getMonth();
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.previous();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date14);
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14, timeZone16);
//        boolean boolean18 = day12.equals((java.lang.Object) year17);
//        boolean boolean19 = day4.equals((java.lang.Object) boolean18);
//        long long20 = day4.getSerialIndex();
//        java.util.Calendar calendar21 = null;
//        try {
//            day4.peg(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43629L + "'", long20 == 43629L);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues3.createCopy((int) (short) 1, 0);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) (short) 1);
        boolean boolean28 = timePeriodValue26.equals((java.lang.Object) (short) 1);
        timePeriodValue26.setValue((java.lang.Number) 12);
        timePeriodValues22.add(timePeriodValue26);
        int int32 = timePeriodValues22.getMaxEndIndex();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        java.util.Date date34 = day33.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day33.previous();
        java.util.Date date36 = regularTimePeriod35.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod35, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "TimePeriodValue[13-June-2019,0]");
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) regularTimePeriod35, (double) ' ');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
        timePeriodValues22.removeChangeListener(seriesChangeListener42);
        int int44 = timePeriodValues22.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriodValues22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
        java.lang.Comparable comparable11 = timePeriodValues7.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10.0d + "'", comparable11.equals(10.0d));
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        java.util.Date date13 = day8.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (double) (short) 10);
//        java.lang.Object obj16 = timePeriodValue15.clone();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(obj16);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        java.lang.String str8 = timePeriodValues3.getDescription();
        int int9 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        int int7 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass12 = timePeriodValues11.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues11);
        int int14 = timePeriodValues11.getMaxMiddleIndex();
        java.lang.Comparable comparable15 = timePeriodValues11.getKey();
        java.lang.Comparable comparable16 = timePeriodValues11.getKey();
        timePeriodValues11.setRangeDescription("hi!");
        boolean boolean19 = timePeriodValues3.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 10.0d + "'", comparable15.equals(10.0d));
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 10.0d + "'", comparable16.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.Class<?> wildcardClass9 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass9);
        java.lang.Object obj11 = seriesChangeEvent10.getSource();
        java.lang.Object obj12 = seriesChangeEvent10.getSource();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj12);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        long long12 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        java.lang.Class<?> wildcardClass14 = regularTimePeriod13.getClass();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod13, 100.0d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) date9);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        boolean boolean14 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10.0d + "'", comparable11.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (-1), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,10]");
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
//        timePeriodValues3.add(timePeriodValue12);
//        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date18 = simpleTimePeriod17.getEnd();
//        java.lang.Object obj19 = null;
//        boolean boolean20 = simpleTimePeriod17.equals(obj19);
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod17, (double) 100L);
//        timePeriodValues3.add(timePeriodValue22);
//        java.lang.String str24 = timePeriodValue22.toString();
//        java.lang.String str25 = timePeriodValue22.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass30 = timePeriodValues29.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues29);
//        int int32 = timePeriodValues29.getMinMiddleIndex();
//        java.lang.String str33 = timePeriodValues29.getDomainDescription();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day34.previous();
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day34, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day34.previous();
//        org.jfree.data.time.SerialDate serialDate40 = day34.getSerialDate();
//        boolean boolean41 = timePeriodValue22.equals((java.lang.Object) day34);
//        long long42 = day34.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 10.0d + "'", comparable14.equals(10.0d));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560409200000L + "'", long42 == 1560409200000L);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 31);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) false);
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.previous();
        int int15 = simpleTimePeriod11.compareTo((java.lang.Object) day12);
        long long16 = simpleTimePeriod11.getEndMillis();
        java.util.Date date17 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (java.lang.Number) 100.0f);
        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue19);
        long long21 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 4L + "'", long16 == 4L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) false);
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) (short) 0);
        java.util.Date date10 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
        int int3 = day0.getMonth();
        int int4 = day0.getYear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), 97L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.previous();
        int int9 = simpleTimePeriod5.compareTo((java.lang.Object) day6);
        long long10 = simpleTimePeriod5.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod5, (java.lang.Number) 100.0f);
        try {
            int int13 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValue12);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValue cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 4L + "'", long10 == 4L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) seriesChangeEvent5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean6, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues9.addChangeListener(seriesChangeListener10);
        timePeriodValues9.setRangeDescription("TimePeriodValue[13-June-2019,10]");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=97]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.lang.Object obj4 = null;
        boolean boolean5 = simpleTimePeriod2.equals(obj4);
        long long6 = simpleTimePeriod2.getStartMillis();
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass12 = timePeriodValues11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        boolean boolean15 = simpleTimePeriod2.equals((java.lang.Object) class14);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.String str7 = timePeriodValues6.getDescription();
        boolean boolean8 = year0.equals((java.lang.Object) str7);
        long long9 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.next();
        long long11 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = day0.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.SerialDate serialDate12 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        java.util.Calendar calendar15 = null;
        try {
            day0.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getMiddleMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,0]");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,0]"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1);
        java.lang.String str7 = year6.toString();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year6.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
//        int int6 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
//        java.lang.String str7 = day3.toString();
//        int int8 = day3.getMonth();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesException: 13-June-2019");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: TimePeriodValue[13-June-2019,1]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day8, (double) (byte) 10);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue14 = timePeriodValues3.getDataItem(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 1560409200000L);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (-1));
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue13.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) timePeriod14);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timePeriod14);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean11 = timePeriodValues9.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues3.createCopy((int) (short) 1, 0);
        int int23 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Object obj24 = timePeriodValues3.clone();
        int int25 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriodValues22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getSerialIndex();
        long long9 = year6.getFirstMillisecond();
        long long10 = year6.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setDescription("");
//        int int13 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        int int19 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int24 = timePeriodValues23.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues23.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        timePeriodValues27.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (-1));
//        long long31 = day28.getFirstMillisecond();
//        java.util.Date date32 = day28.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long36 = simpleTimePeriod35.getStartMillis();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean38 = simpleTimePeriod35.equals((java.lang.Object) timeZone37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date32, timeZone37);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.util.Date date41 = day40.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long45 = simpleTimePeriod44.getStartMillis();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean47 = simpleTimePeriod44.equals((java.lang.Object) timeZone46);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date41, timeZone46);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date32, timeZone46);
//        java.lang.String str50 = year49.toString();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year49, (double) 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560409200000L + "'", long31 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "2019" + "'", str50.equals("2019"));
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
        java.lang.Comparable comparable10 = timePeriodValues3.getKey();
        int int11 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 10.0d + "'", comparable10.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        timePeriodValues3.setDescription("");
        timePeriodValues3.setRangeDescription("13-June-2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean18 = timePeriodValues16.equals((java.lang.Object) (short) -1);
        int int19 = timePeriodValues16.getMinEndIndex();
        timePeriodValues16.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        java.util.Date date23 = day22.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day22, (java.lang.Number) (short) 1);
        timePeriodValues16.add(timePeriodValue25);
        java.lang.Comparable comparable27 = timePeriodValues16.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        java.lang.Object obj32 = null;
        boolean boolean33 = simpleTimePeriod30.equals(obj32);
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod30, (double) 100L);
        timePeriodValues16.add(timePeriodValue35);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date40 = simpleTimePeriod39.getEnd();
        boolean boolean41 = timePeriodValue35.equals((java.lang.Object) date40);
        java.lang.Class<?> wildcardClass42 = timePeriodValue35.getClass();
        timePeriodValues3.add(timePeriodValue35);
        timePeriodValue35.setValue((java.lang.Number) 1560365999999L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 10.0d + "'", comparable27.equals(10.0d));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int34 = timePeriodValues33.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = timePeriodValues33.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) (-1));
//        long long41 = day38.getFirstMillisecond();
//        java.util.Date date42 = day38.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long46 = simpleTimePeriod45.getStartMillis();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean48 = simpleTimePeriod45.equals((java.lang.Object) timeZone47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date42, timeZone47);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.util.Date date51 = day50.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long55 = simpleTimePeriod54.getStartMillis();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean57 = simpleTimePeriod54.equals((java.lang.Object) timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date51, timeZone56);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date42, timeZone56);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(date12, date42);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date12);
//        int int62 = year61.getYear();
//        long long63 = year61.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560409200000L + "'", long41 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1562097599999L + "'", long63 == 1562097599999L);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int34 = timePeriodValues33.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = timePeriodValues33.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) (-1));
//        long long41 = day38.getFirstMillisecond();
//        java.util.Date date42 = day38.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long46 = simpleTimePeriod45.getStartMillis();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean48 = simpleTimePeriod45.equals((java.lang.Object) timeZone47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date42, timeZone47);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.util.Date date51 = day50.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long55 = simpleTimePeriod54.getStartMillis();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean57 = simpleTimePeriod54.equals((java.lang.Object) timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date51, timeZone56);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date42, timeZone56);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(date12, date42);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date42);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560409200000L + "'", long41 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
        timePeriodValues3.add(timePeriodValue12);
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,0]");
        int int16 = timePeriodValues3.getMinMiddleIndex();
        try {
            java.lang.Number number18 = timePeriodValues3.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        java.util.Date date13 = day8.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (double) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day8.next();
//        int int17 = day8.getMonth();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.String str7 = timePeriodValues6.getDescription();
        boolean boolean8 = year0.equals((java.lang.Object) str7);
        long long9 = year0.getLastMillisecond();
        long long10 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.util.Date date2 = day1.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date2);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        boolean boolean9 = timePeriodValues7.equals((java.lang.Object) (short) -1);
//        int int10 = timePeriodValues7.getMinEndIndex();
//        timePeriodValues7.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) (short) 1);
//        timePeriodValues7.add(timePeriodValue16);
//        java.lang.Comparable comparable18 = timePeriodValues7.getKey();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date22 = simpleTimePeriod21.getEnd();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = simpleTimePeriod21.equals(obj23);
//        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod21, (double) 100L);
//        timePeriodValues7.add(timePeriodValue26);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date31 = simpleTimePeriod30.getEnd();
//        boolean boolean32 = timePeriodValue26.equals((java.lang.Object) date31);
//        java.lang.Class<?> wildcardClass33 = timePeriodValue26.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date37 = simpleTimePeriod36.getEnd();
//        java.lang.Object obj38 = null;
//        boolean boolean39 = simpleTimePeriod36.equals(obj38);
//        long long40 = simpleTimePeriod36.getStartMillis();
//        java.util.Date date41 = simpleTimePeriod36.getStart();
//        long long42 = simpleTimePeriod36.getStartMillis();
//        java.util.Date date43 = simpleTimePeriod36.getStart();
//        java.lang.Class class44 = null;
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        java.util.Date date46 = day45.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent47 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date46);
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date46, timeZone48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date46);
//        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass55 = timePeriodValues54.getClass();
//        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
//        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass61 = timePeriodValues60.getClass();
//        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
//        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int67 = timePeriodValues66.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues70 = timePeriodValues66.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        timePeriodValues70.add((org.jfree.data.time.TimePeriod) day71, (java.lang.Number) (-1));
//        long long74 = day71.getFirstMillisecond();
//        java.util.Date date75 = day71.getStart();
//        java.util.Date date76 = day71.getStart();
//        java.util.TimeZone timeZone77 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date76, timeZone77);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod81 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long82 = simpleTimePeriod81.getStartMillis();
//        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean84 = simpleTimePeriod81.equals((java.lang.Object) timeZone83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date76, timeZone83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date46, timeZone83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date43, timeZone83);
//        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date2, timeZone83);
//        try {
//            org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date0, timeZone83);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 10.0d + "'", comparable18.equals(10.0d));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(class56);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(class62);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues70);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560409200000L + "'", long74 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
//        org.junit.Assert.assertNotNull(timeZone83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertNull(regularTimePeriod85);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//        org.junit.Assert.assertNull(regularTimePeriod87);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        int int6 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 100.0f);
        java.lang.String str10 = timePeriodValue9.toString();
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue9.getPeriod();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4L + "'", long7 == 4L);
        org.junit.Assert.assertNotNull(timePeriod11);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.String str7 = timePeriodValues6.getDescription();
        boolean boolean8 = year0.equals((java.lang.Object) str7);
        long long9 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.previous();
        long long12 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1);
        long long7 = year6.getSerialIndex();
        long long8 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        long long10 = year6.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day8);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date18 = simpleTimePeriod17.getEnd();
//        java.lang.Object obj19 = null;
//        boolean boolean20 = simpleTimePeriod17.equals(obj19);
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod17, (double) 100L);
//        int int23 = day8.compareTo((java.lang.Object) 100L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int4 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1));
//        long long11 = day8.getFirstMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long16 = simpleTimePeriod15.getStartMillis();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean18 = simpleTimePeriod15.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long25 = simpleTimePeriod24.getStartMillis();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date12, timeZone26);
//        java.lang.String str30 = year29.toString();
//        long long31 = year29.getLastMillisecond();
//        java.lang.String str32 = year29.toString();
//        java.util.Date date33 = year29.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) 1560365999999L);
//        int int36 = year29.getYear();
//        java.util.Calendar calendar37 = null;
//        try {
//            long long38 = year29.getLastMillisecond(calendar37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass10 = timePeriodValues9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass16 = timePeriodValues15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int22 = timePeriodValues21.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues21.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (-1));
//        long long29 = day26.getFirstMillisecond();
//        java.util.Date date30 = day26.getStart();
//        java.util.Date date31 = day26.getStart();
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date31, timeZone32);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long37 = simpleTimePeriod36.getStartMillis();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean39 = simpleTimePeriod36.equals((java.lang.Object) timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date31, timeZone38);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date5, timeZone38);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date3, timeZone38);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date3);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (double) 12);
        java.util.Date date10 = day6.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
        boolean boolean13 = day6.equals((java.lang.Object) (byte) 0);
        int int14 = day6.getMonth();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        int int3 = year0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean19 = timePeriodValues17.equals((java.lang.Object) (short) -1);
        int int20 = timePeriodValues17.getMinEndIndex();
        timePeriodValues17.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) (short) 1);
        timePeriodValues17.add(timePeriodValue26);
        java.lang.Comparable comparable28 = timePeriodValues17.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date32 = simpleTimePeriod31.getEnd();
        java.lang.Object obj33 = null;
        boolean boolean34 = simpleTimePeriod31.equals(obj33);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod31, (double) 100L);
        timePeriodValues17.add(timePeriodValue36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date41 = simpleTimePeriod40.getEnd();
        boolean boolean42 = timePeriodValue36.equals((java.lang.Object) date41);
        java.lang.Class<?> wildcardClass43 = timePeriodValue36.getClass();
        timePeriodValues3.add(timePeriodValue36);
        java.lang.Object obj45 = timePeriodValues3.clone();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 10.0d + "'", comparable28.equals(10.0d));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(obj45);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 1);
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener14);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        boolean boolean8 = timePeriodValues3.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 0.0d);
        boolean boolean17 = timePeriodValues3.equals((java.lang.Object) timePeriodValues12);
        int int18 = timePeriodValues12.getMinEndIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0d + "'", comparable7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        boolean boolean5 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 1560409200000L);
        timePeriodValues3.setRangeDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getRangeDescription();
        boolean boolean8 = timePeriodValues3.getNotify();
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues3.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test318");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 4);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
//        int int6 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
//        long long7 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date8 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass13 = timePeriodValues12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass19 = timePeriodValues18.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        int int25 = timePeriodValues24.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = timePeriodValues24.createCopy((int) (byte) 100, (int) (byte) 100);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) (-1));
//        long long32 = day29.getFirstMillisecond();
//        java.util.Date date33 = day29.getStart();
//        java.util.Date date34 = day29.getStart();
//        java.util.TimeZone timeZone35 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date34, timeZone35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long40 = simpleTimePeriod39.getStartMillis();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean42 = simpleTimePeriod39.equals((java.lang.Object) timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date34, timeZone41);
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0d, "hi!", "");
//        java.lang.Class<?> wildcardClass48 = timePeriodValues47.getClass();
//        timePeriodValues47.fireSeriesChanged();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate51 = day50.getSerialDate();
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) day50, (double) 12);
//        java.util.Date date54 = day50.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 'a');
//        long long58 = simpleTimePeriod57.getStartMillis();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean60 = simpleTimePeriod57.equals((java.lang.Object) timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date54, timeZone59);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date8, timeZone59);
//        long long63 = day62.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4L + "'", long7 == 4L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560409200000L + "'", long32 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 28799999L + "'", long63 == 28799999L);
//    }
//}

