import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int2 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setMaximumItemCount(11);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries2.setDescription("hi!");
        int int15 = timeSeries2.getMaximumItemCount();
        java.util.List list16 = timeSeries2.getItems();
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertNotNull(list16);
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test04");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "Value", class3);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class6);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries7.removePropertyChangeListener(propertyChangeListener8);
//        java.util.Collection collection10 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean15 = spreadsheetDate12.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        spreadsheetDate14.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond18.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        java.util.Date date23 = fixedMillisecond22.getEnd();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
//        boolean boolean25 = spreadsheetDate14.equals((java.lang.Object) year24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class27);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.removeChangeListener(seriesChangeListener29);
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class32);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries33.removeChangeListener(seriesChangeListener34);
//        timeSeries33.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries28.addAndOrUpdate(timeSeries33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getFirstMillisecond(calendar40);
//        java.util.Date date42 = fixedMillisecond39.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = fixedMillisecond39.previous();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        java.lang.Class<?> wildcardClass46 = timeSeries45.getClass();
//        timeSeries45.setMaximumItemAge(0L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar50 = null;
//        long long51 = fixedMillisecond49.getFirstMillisecond(calendar50);
//        java.util.Date date52 = fixedMillisecond49.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date52);
//        java.util.Date date54 = fixedMillisecond53.getEnd();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year55.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod56, (java.lang.Number) 1560441651761L);
//        try {
//            timeSeries45.add(timeSeriesDataItem58, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560441729480L + "'", long20 == 1560441729480L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560441729493L + "'", long41 == 1560441729493L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560441729495L + "'", long51 == 1560441729495L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//    }

//    @Test
//    public void test05() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test05");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
//        java.util.Date date6 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        long long8 = fixedMillisecond7.getSerialIndex();
//        int int9 = day0.compareTo((java.lang.Object) long8);
//        long long10 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441729521L + "'", long5 == 1560441729521L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560441729521L + "'", long8 == 1560441729521L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-457));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test07() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test07");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.Date date5 = fixedMillisecond4.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond6.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
//        java.util.Date date11 = fixedMillisecond10.getEnd();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class14);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener16);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class19);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener21);
//        timeSeries20.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries15.addAndOrUpdate(timeSeries20);
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries25.addPropertyChangeListener(propertyChangeListener26);
//        timeSeries25.setDomainDescription("Value");
//        boolean boolean30 = timeSeries25.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
//        java.util.Collection collection33 = timeSeries25.getTimePeriodsUniqueToOtherSeries(timeSeries32);
//        java.lang.Object obj34 = timeSeries25.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getFirstMillisecond(calendar36);
//        java.util.Date date38 = fixedMillisecond35.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(date38);
//        timeSeries25.setKey((java.lang.Comparable) date38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date38);
//        java.lang.Class class42 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond43.getFirstMillisecond(calendar44);
//        java.util.Date date46 = fixedMillisecond43.getEnd();
//        java.lang.String str47 = fixedMillisecond43.toString();
//        java.util.Date date48 = fixedMillisecond43.getTime();
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date48, timeZone49);
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date48);
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date48, timeZone52);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date38, timeZone52);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date11, timeZone52);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date5, timeZone52);
//        int int57 = day56.getMonth();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441729561L + "'", long2 == 1560441729561L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560441729563L + "'", long8 == 1560441729563L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(collection33);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560441729568L + "'", long37 == 1560441729568L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560441729570L + "'", long45 == 1560441729570L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Thu Jun 13 09:02:09 PDT 2019" + "'", str47.equals("Thu Jun 13 09:02:09 PDT 2019"));
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
//    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test08");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.Date date5 = fixedMillisecond4.getEnd();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener10);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class13);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.removeChangeListener(seriesChangeListener15);
//        timeSeries14.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries9.addAndOrUpdate(timeSeries14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond20.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        boolean boolean25 = year6.equals((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year6.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 6);
//        java.lang.Object obj29 = timeSeriesDataItem28.clone();
//        java.lang.Number number30 = timeSeriesDataItem28.getValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeriesDataItem28.getPeriod();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441730654L + "'", long2 == 1560441730654L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560441730656L + "'", long22 == 1560441730656L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(obj29);
//        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 6 + "'", number30.equals(6));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 1, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "January" + "'", str2.equals("January"));
    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test10");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.Date date5 = fixedMillisecond4.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond6.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
//        java.util.Date date11 = fixedMillisecond10.getEnd();
//        boolean boolean12 = fixedMillisecond4.equals((java.lang.Object) date11);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441730900L + "'", long2 == 1560441730900L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560441730902L + "'", long8 == 1560441730902L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

//    @Test
//    public void test11() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test11");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String[] strArray2 = org.jfree.data.time.SerialDate.getMonths(false);
//        boolean boolean3 = day0.equals((java.lang.Object) strArray2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String[] strArray14 = org.jfree.data.time.SerialDate.getMonths(false);
//        boolean boolean15 = day12.equals((java.lang.Object) strArray14);
//        int int16 = year10.compareTo((java.lang.Object) strArray14);
//        int int17 = day0.compareTo((java.lang.Object) int16);
//        org.junit.Assert.assertNotNull(strArray2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560441730978L + "'", long6 == 1560441730978L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(strArray14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        java.util.List list5 = timeSeries2.getItems();
        try {
            java.util.Collection collection6 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list5);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list5);
    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test13");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        long long7 = fixedMillisecond6.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = fixedMillisecond6.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Thu Jun 13 09:00:52 PDT 2019", (java.lang.Class) wildcardClass8);
//        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Following", (java.lang.Class) wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441731067L + "'", long4 == 1560441731067L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560441731067L + "'", long7 == 1560441731067L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(inputStream12);
//        org.junit.Assert.assertNull(inputStream13);
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(serialDate3);
    }

//    @Test
//    public void test15() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test15");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean5 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        spreadsheetDate4.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
//        java.util.Date date11 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
//        java.util.Date date13 = fixedMillisecond12.getEnd();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        boolean boolean15 = spreadsheetDate4.equals((java.lang.Object) year14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean20 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        spreadsheetDate19.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        boolean boolean23 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        java.lang.String str24 = spreadsheetDate4.toString();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate4);
//        java.lang.String str26 = spreadsheetDate4.getDescription();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560441731114L + "'", long10 == 1560441731114L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "7-January-1900" + "'", str24.equals("7-January-1900"));
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Thu Jun 13 09:00:45 PDT 2019" + "'", str26.equals("Thu Jun 13 09:00:45 PDT 2019"));
//    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-459) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test17");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.Date date5 = fixedMillisecond4.getEnd();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener10);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class13);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.removeChangeListener(seriesChangeListener15);
//        timeSeries14.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries9.addAndOrUpdate(timeSeries14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond20.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        boolean boolean25 = year6.equals((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year6.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year6.next();
//        java.lang.String str28 = year6.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441731217L + "'", long2 == 1560441731217L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560441731220L + "'", long22 == 1560441731220L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
//    }

//    @Test
//    public void test18() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test18");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560441641670L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 1);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "Value", class7);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class10);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
//        java.util.Collection collection14 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean19 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        spreadsheetDate18.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        java.util.Date date27 = fixedMillisecond26.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
//        boolean boolean29 = spreadsheetDate18.equals((java.lang.Object) year28);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class31);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries32.removeChangeListener(seriesChangeListener33);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class36);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries37.removeChangeListener(seriesChangeListener38);
//        timeSeries37.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries32.addAndOrUpdate(timeSeries37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond43.getFirstMillisecond(calendar44);
//        java.util.Date date46 = fixedMillisecond43.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = fixedMillisecond43.previous();
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        java.lang.String str50 = year28.toString();
//        int int51 = year28.getYear();
//        int int52 = fixedMillisecond1.compareTo((java.lang.Object) int51);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560441731386L + "'", long24 == 1560441731386L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560441731389L + "'", long45 == 1560441731389L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "2019" + "'", str50.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Following");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test20");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener3);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        timeSeries7.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries7);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries2.addChangeListener(seriesChangeListener13);
//        timeSeries2.clear();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond20.getEnd();
//        java.lang.String str24 = fixedMillisecond20.toString();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond20.getMiddleMillisecond(calendar25);
//        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond20.next();
//        java.util.Date date29 = fixedMillisecond20.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 1560441654675L);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560441731693L + "'", long22 == 1560441731693L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Thu Jun 13 09:02:11 PDT 2019" + "'", str24.equals("Thu Jun 13 09:02:11 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560441731693L + "'", long26 == 1560441731693L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test21");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean4 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.lang.String str5 = spreadsheetDate3.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean10 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        spreadsheetDate9.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean17 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        boolean boolean18 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class20);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries21.removeChangeListener(seriesChangeListener22);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries26.removeChangeListener(seriesChangeListener27);
//        timeSeries26.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries21.addAndOrUpdate(timeSeries26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond32.getFirstMillisecond(calendar33);
//        java.util.Date date35 = fixedMillisecond32.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean41 = spreadsheetDate38.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        java.lang.String str42 = spreadsheetDate40.toString();
//        boolean boolean43 = fixedMillisecond32.equals((java.lang.Object) spreadsheetDate40);
//        int int44 = spreadsheetDate40.getMonth();
//        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        boolean boolean46 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        java.util.Date date47 = spreadsheetDate40.toDate();
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date47);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar50 = null;
//        long long51 = fixedMillisecond49.getFirstMillisecond(calendar50);
//        java.util.Date date52 = fixedMillisecond49.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date52);
//        long long54 = fixedMillisecond53.getSerialIndex();
//        java.lang.Class<?> wildcardClass55 = fixedMillisecond53.getClass();
//        java.util.Date date56 = null;
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date56, timeZone57);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date47, timeZone57);
//        java.util.Calendar calendar60 = null;
//        try {
//            year59.peg(calendar60);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "7-January-1900" + "'", str5.equals("7-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560441731770L + "'", long34 == 1560441731770L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "7-January-1900" + "'", str42.equals("7-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560441731774L + "'", long51 == 1560441731774L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560441731774L + "'", long54 == 1560441731774L);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(8);
        boolean boolean6 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        spreadsheetDate5.setDescription("Thu Jun 13 09:00:45 PDT 2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(8);
        boolean boolean13 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(13, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int16 = spreadsheetDate12.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
        org.junit.Assert.assertNotNull(serialDate17);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560441644275L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        boolean boolean4 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test24() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test24");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond5.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond5.getMiddleMillisecond(calendar10);
//        long long12 = fixedMillisecond5.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond5.previous();
//        long long14 = fixedMillisecond5.getSerialIndex();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond5.getMiddleMillisecond(calendar15);
//        java.util.Calendar calendar17 = null;
//        fixedMillisecond5.peg(calendar17);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560441731860L + "'", long7 == 1560441731860L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560441731860L + "'", long11 == 1560441731860L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560441731860L + "'", long12 == 1560441731860L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560441731860L + "'", long14 == 1560441731860L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560441731860L + "'", long16 == 1560441731860L);
//    }

//    @Test
//    public void test25() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test25");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getYear();
//        long long5 = day0.getFirstMillisecond();
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setMaximumItemCount(11);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries7);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        timeSeries12.setDomainDescription("Value");
        boolean boolean17 = timeSeries12.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        java.util.Collection collection20 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        try {
            timeSeries19.delete(0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(collection20);
    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test27");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean4 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        spreadsheetDate3.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean11 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        boolean boolean12 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class14);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener16);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class19);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener21);
//        timeSeries20.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries15.addAndOrUpdate(timeSeries20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getFirstMillisecond(calendar27);
//        java.util.Date date29 = fixedMillisecond26.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean35 = spreadsheetDate32.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        java.lang.String str36 = spreadsheetDate34.toString();
//        boolean boolean37 = fixedMillisecond26.equals((java.lang.Object) spreadsheetDate34);
//        int int38 = spreadsheetDate34.getMonth();
//        org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(8);
//        java.lang.String str42 = spreadsheetDate41.toString();
//        int int43 = spreadsheetDate41.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean48 = spreadsheetDate45.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        org.jfree.data.time.SerialDate serialDate49 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.SerialDate serialDate53 = day50.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate47.getEndOfCurrentMonth(serialDate53);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean60 = spreadsheetDate57.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
//        spreadsheetDate59.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar64 = null;
//        long long65 = fixedMillisecond63.getFirstMillisecond(calendar64);
//        java.util.Date date66 = fixedMillisecond63.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond(date66);
//        java.util.Date date68 = fixedMillisecond67.getEnd();
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date68);
//        boolean boolean70 = spreadsheetDate59.equals((java.lang.Object) year69);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean75 = spreadsheetDate72.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate74);
//        spreadsheetDate74.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        boolean boolean78 = spreadsheetDate59.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate74);
//        java.lang.String str79 = spreadsheetDate59.toString();
//        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate59);
//        int int81 = spreadsheetDate59.getDayOfMonth();
//        boolean boolean83 = spreadsheetDate34.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate47, (org.jfree.data.time.SerialDate) spreadsheetDate59, 4);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560441731943L + "'", long28 == 1560441731943L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "7-January-1900" + "'", str36.equals("7-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "7-January-1900" + "'", str42.equals("7-January-1900"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 7 + "'", int43 == 7);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560441731949L + "'", long65 == 1560441731949L);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "7-January-1900" + "'", str79.equals("7-January-1900"));
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 7 + "'", int81 == 7);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560441691448L);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560441653310L);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1560441653310]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=1560441653310]"));
    }

//    @Test
//    public void test31() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test31");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond5.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(9, year11);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "Value", class19);
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class22);
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timeSeries23.removePropertyChangeListener(propertyChangeListener24);
//        java.util.Collection collection26 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean31 = spreadsheetDate28.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        spreadsheetDate30.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond34.getFirstMillisecond(calendar35);
//        java.util.Date date37 = fixedMillisecond34.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        java.util.Date date39 = fixedMillisecond38.getEnd();
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
//        boolean boolean41 = spreadsheetDate30.equals((java.lang.Object) year40);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class43);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
//        timeSeries44.removeChangeListener(seriesChangeListener45);
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class48);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener50 = null;
//        timeSeries49.removeChangeListener(seriesChangeListener50);
//        timeSeries49.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries44.addAndOrUpdate(timeSeries49);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar56 = null;
//        long long57 = fixedMillisecond55.getFirstMillisecond(calendar56);
//        java.util.Date date58 = fixedMillisecond55.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries49.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond55.previous();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) year40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
//        java.lang.Class<?> wildcardClass62 = timeSeries61.getClass();
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Thu Jun 13 09:00:45 PDT 2019", "", "Thu Jun 13 09:00:46 PDT 2019", (java.lang.Class) wildcardClass62);
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, (java.lang.Class) wildcardClass62);
//        java.beans.PropertyChangeListener propertyChangeListener65 = null;
//        timeSeries64.removePropertyChangeListener(propertyChangeListener65);
//        boolean boolean67 = timeSeries2.equals((java.lang.Object) timeSeries64);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560441733106L + "'", long7 == 1560441733106L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560441733109L + "'", long36 == 1560441733109L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560441733112L + "'", long57 == 1560441733112L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0f);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10.0]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=10.0]"));
    }

//    @Test
//    public void test34() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test34");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond5.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(6, (-460));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 1560441648502L);
//        java.lang.String str17 = month14.toString();
//        java.util.Calendar calendar18 = null;
//        try {
//            month14.peg(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560441733982L + "'", long7 == 1560441733982L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June -460" + "'", str17.equals("June -460"));
//    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Thu Jun 13 09:01:11 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test36");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        long long5 = fixedMillisecond4.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441734016L + "'", long2 == 1560441734016L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441734016L + "'", long5 == 1560441734016L);
//    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Thu Jun 13 09:01:17 PDT 2019");
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("Thu Jun 13 09:01:21 PDT 2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException5);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

//    @Test
//    public void test40() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test40");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.Date date5 = fixedMillisecond4.getEnd();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        java.util.Date date8 = year6.getStart();
//        java.lang.String str9 = year6.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441734115L + "'", long2 == 1560441734115L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test43() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test43");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean4 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        spreadsheetDate3.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        boolean boolean14 = spreadsheetDate3.equals((java.lang.Object) year13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean19 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        spreadsheetDate18.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        boolean boolean22 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean27 = spreadsheetDate24.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        boolean boolean28 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean34 = spreadsheetDate31.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        java.lang.String str35 = spreadsheetDate33.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean40 = spreadsheetDate37.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
//        spreadsheetDate39.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean47 = spreadsheetDate44.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
//        boolean boolean48 = spreadsheetDate39.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class50);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener52 = null;
//        timeSeries51.removeChangeListener(seriesChangeListener52);
//        java.lang.Class class55 = null;
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class55);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener57 = null;
//        timeSeries56.removeChangeListener(seriesChangeListener57);
//        timeSeries56.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries51.addAndOrUpdate(timeSeries56);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar63 = null;
//        long long64 = fixedMillisecond62.getFirstMillisecond(calendar63);
//        java.util.Date date65 = fixedMillisecond62.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries56.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean71 = spreadsheetDate68.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate70);
//        java.lang.String str72 = spreadsheetDate70.toString();
//        boolean boolean73 = fixedMillisecond62.equals((java.lang.Object) spreadsheetDate70);
//        int int74 = spreadsheetDate70.getMonth();
//        org.jfree.data.time.SerialDate serialDate75 = spreadsheetDate39.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate70);
//        boolean boolean76 = spreadsheetDate33.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate70);
//        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate33);
//        boolean boolean78 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        int int79 = spreadsheetDate18.getMonth();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560441734334L + "'", long9 == 1560441734334L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "7-January-1900" + "'", str35.equals("7-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560441734372L + "'", long64 == 1560441734372L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNull(timeSeriesDataItem66);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "7-January-1900" + "'", str72.equals("7-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeries2.equals(obj4);
        timeSeries2.setMaximumItemAge(1560441673288L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate(regularTimePeriod8, (java.lang.Number) 2019L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        int int5 = timeSeries2.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries2.addChangeListener(seriesChangeListener6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setMaximumItemCount(11);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries2.addChangeListener(seriesChangeListener13);
        timeSeries2.clear();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener16);
        try {
            java.lang.Number number19 = timeSeries2.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries12);
    }

//    @Test
//    public void test47() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test47");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        java.lang.String str6 = fixedMillisecond2.toString();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond2.getMiddleMillisecond(calendar7);
//        int int9 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        java.lang.String str10 = timeSeries1.getDescription();
//        java.lang.String str11 = timeSeries1.getDomainDescription();
//        try {
//            java.lang.Number number13 = timeSeries1.getValue((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441734953L + "'", long4 == 1560441734953L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Thu Jun 13 09:02:14 PDT 2019" + "'", str6.equals("Thu Jun 13 09:02:14 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560441734953L + "'", long8 == 1560441734953L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
//    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test49() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test49");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener3);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        timeSeries7.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries7);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        timeSeries12.setDomainDescription("Value");
//        timeSeries12.setDomainDescription("Thu Jun 13 09:00:42 PDT 2019");
//        timeSeries12.setDomainDescription("ThreadContext");
//        timeSeries12.setMaximumItemCount(0);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "Value", class26);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class29);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries30.removePropertyChangeListener(propertyChangeListener31);
//        java.util.Collection collection33 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        java.lang.String str34 = timeSeries27.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries27.createCopy(8, (int) (byte) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond38.next();
//        int int40 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond38.next();
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class43);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
//        timeSeries44.removeChangeListener(seriesChangeListener45);
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class48);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener50 = null;
//        timeSeries49.removeChangeListener(seriesChangeListener50);
//        timeSeries49.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries44.addAndOrUpdate(timeSeries49);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener55 = null;
//        timeSeries44.addChangeListener(seriesChangeListener55);
//        timeSeries44.clear();
//        int int58 = fixedMillisecond38.compareTo((java.lang.Object) timeSeries44);
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "Value", class62);
//        java.lang.Class class65 = null;
//        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class65);
//        java.beans.PropertyChangeListener propertyChangeListener67 = null;
//        timeSeries66.removePropertyChangeListener(propertyChangeListener67);
//        java.util.Collection collection69 = timeSeries63.getTimePeriodsUniqueToOtherSeries(timeSeries66);
//        boolean boolean70 = fixedMillisecond38.equals((java.lang.Object) timeSeries63);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar72 = null;
//        long long73 = fixedMillisecond71.getFirstMillisecond(calendar72);
//        java.util.Date date74 = fixedMillisecond71.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond(date74);
//        java.util.Date date76 = fixedMillisecond75.getEnd();
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date76);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries63.getDataItem((org.jfree.data.time.RegularTimePeriod) year77);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) year77);
//        long long80 = timeSeries12.getMaximumItemAge();
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(collection33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Value" + "'", str34.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(collection69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560441734990L + "'", long73 == 1560441734990L);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNull(timeSeriesDataItem78);
//        org.junit.Assert.assertNull(timeSeriesDataItem79);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 9223372036854775807L + "'", long80 == 9223372036854775807L);
//    }

//    @Test
//    public void test50() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test50");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        long long6 = fixedMillisecond5.getSerialIndex();
//        java.lang.Class<?> wildcardClass7 = fixedMillisecond5.getClass();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getEnd();
//        java.lang.String str13 = fixedMillisecond9.toString();
//        java.util.Date date14 = fixedMillisecond9.getTime();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date14, timeZone15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond17.getFirstMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        long long27 = fixedMillisecond26.getSerialIndex();
//        java.lang.Class<?> wildcardClass28 = fixedMillisecond26.getClass();
//        java.util.Date date29 = null;
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date20, timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date14, timeZone30);
//        java.io.InputStream inputStream34 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Thu Jun 13 09:00:45 PDT 2019", (java.lang.Class) wildcardClass7);
//        java.lang.ClassLoader classLoader35 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441735371L + "'", long3 == 1560441735371L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560441735371L + "'", long6 == 1560441735371L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560441735373L + "'", long11 == 1560441735373L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Thu Jun 13 09:02:15 PDT 2019" + "'", str13.equals("Thu Jun 13 09:02:15 PDT 2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560441735381L + "'", long19 == 1560441735381L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560441735383L + "'", long24 == 1560441735383L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560441735383L + "'", long27 == 1560441735383L);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNull(inputStream34);
//        org.junit.Assert.assertNotNull(classLoader35);
//    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test51");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond7.getEnd();
//        java.lang.String str11 = fixedMillisecond7.toString();
//        java.util.Date date12 = fixedMillisecond7.getTime();
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date12, timeZone13);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date12, timeZone16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date5, timeZone16);
//        int int20 = month18.compareTo((java.lang.Object) 9);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441735954L + "'", long2 == 1560441735954L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560441735959L + "'", long9 == 1560441735959L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Thu Jun 13 09:02:15 PDT 2019" + "'", str11.equals("Thu Jun 13 09:02:15 PDT 2019"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(8);
        boolean boolean5 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getNearestDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Comparable comparable6 = timeSeries2.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries2.removeChangeListener(seriesChangeListener7);
        java.util.Collection collection9 = timeSeries2.getTimePeriods();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 10L + "'", comparable6.equals(10L));
        org.junit.Assert.assertNotNull(collection9);
    }

//    @Test
//    public void test54() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test54");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        java.lang.String str2 = spreadsheetDate1.toString();
//        int int3 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean8 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean14 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        java.lang.String str15 = spreadsheetDate13.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean20 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        spreadsheetDate19.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean27 = spreadsheetDate24.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        boolean boolean28 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class30);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener32);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        timeSeries36.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries31.addAndOrUpdate(timeSeries36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond42.getFirstMillisecond(calendar43);
//        java.util.Date date45 = fixedMillisecond42.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean51 = spreadsheetDate48.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        java.lang.String str52 = spreadsheetDate50.toString();
//        boolean boolean53 = fixedMillisecond42.equals((java.lang.Object) spreadsheetDate50);
//        int int54 = spreadsheetDate50.getMonth();
//        org.jfree.data.time.SerialDate serialDate55 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        boolean boolean56 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.SerialDate serialDate58 = spreadsheetDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7-January-1900" + "'", str2.equals("7-January-1900"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "7-January-1900" + "'", str15.equals("7-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560441736074L + "'", long44 == 1560441736074L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "7-January-1900" + "'", str52.equals("7-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(serialDate58);
//    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test56() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test56");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        java.lang.String str6 = fixedMillisecond2.toString();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond2.getMiddleMillisecond(calendar7);
//        int int9 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        java.lang.String str10 = timeSeries1.getDescription();
//        boolean boolean11 = timeSeries1.getNotify();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441736485L + "'", long4 == 1560441736485L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Thu Jun 13 09:02:16 PDT 2019" + "'", str6.equals("Thu Jun 13 09:02:16 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560441736485L + "'", long8 == 1560441736485L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setMaximumItemCount(11);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries2.setMaximumItemAge((long) (short) 1);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertNotNull(timeSeries12);
    }

//    @Test
//    public void test58() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test58");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean4 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.lang.String str5 = spreadsheetDate3.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean10 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        spreadsheetDate9.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean17 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        boolean boolean18 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class20);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries21.removeChangeListener(seriesChangeListener22);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries26.removeChangeListener(seriesChangeListener27);
//        timeSeries26.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries21.addAndOrUpdate(timeSeries26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond32.getFirstMillisecond(calendar33);
//        java.util.Date date35 = fixedMillisecond32.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean41 = spreadsheetDate38.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        java.lang.String str42 = spreadsheetDate40.toString();
//        boolean boolean43 = fixedMillisecond32.equals((java.lang.Object) spreadsheetDate40);
//        int int44 = spreadsheetDate40.getMonth();
//        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        boolean boolean46 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        int int48 = spreadsheetDate40.getYYYY();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "7-January-1900" + "'", str5.equals("7-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560441736526L + "'", long34 == 1560441736526L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "7-January-1900" + "'", str42.equals("7-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1900 + "'", int48 == 1900);
//    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setMaximumItemCount(11);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries7);
        int int13 = timeSeries2.getItemCount();
        timeSeries2.fireSeriesChanged();
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test60() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test60");
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "Value", class6);
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class9);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries10.removePropertyChangeListener(propertyChangeListener11);
//        java.util.Collection collection13 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean18 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        spreadsheetDate17.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getFirstMillisecond(calendar22);
//        java.util.Date date24 = fixedMillisecond21.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
//        boolean boolean28 = spreadsheetDate17.equals((java.lang.Object) year27);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class30);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener32);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        timeSeries36.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries31.addAndOrUpdate(timeSeries36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond42.getFirstMillisecond(calendar43);
//        java.util.Date date45 = fixedMillisecond42.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond42.previous();
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
//        java.lang.Class<?> wildcardClass49 = timeSeries48.getClass();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "Thu Jun 13 09:00:44 PDT 2019", "hi!", (java.lang.Class) wildcardClass49);
//        java.lang.ClassLoader classLoader51 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass49);
//        org.junit.Assert.assertNotNull(collection13);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560441736736L + "'", long23 == 1560441736736L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560441736741L + "'", long44 == 1560441736741L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(classLoader51);
//    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Thu Jun 13 09:02:07 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeries2.equals(obj4);
        boolean boolean6 = timeSeries2.getNotify();
        timeSeries2.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test63() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test63");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        long long7 = fixedMillisecond6.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = fixedMillisecond6.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        long long17 = fixedMillisecond16.getSerialIndex();
//        java.lang.Class<?> wildcardClass18 = fixedMillisecond16.getClass();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond20.getEnd();
//        java.lang.String str24 = fixedMillisecond20.toString();
//        java.util.Date date25 = fixedMillisecond20.getTime();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date25, timeZone26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getFirstMillisecond(calendar29);
//        java.util.Date date31 = fixedMillisecond28.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
//        java.util.Date date36 = fixedMillisecond33.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
//        long long38 = fixedMillisecond37.getSerialIndex();
//        java.lang.Class<?> wildcardClass39 = fixedMillisecond37.getClass();
//        java.util.Date date40 = null;
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date40, timeZone41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date31, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date25, timeZone41);
//        java.lang.Object obj45 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 09:01:10 PDT 2019", (java.lang.Class) wildcardClass8, (java.lang.Class) wildcardClass18);
//        java.lang.ClassLoader classLoader46 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.lang.Object obj48 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441737221L + "'", long4 == 1560441737221L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560441737221L + "'", long7 == 1560441737221L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560441737222L + "'", long14 == 1560441737222L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560441737222L + "'", long17 == 1560441737222L);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560441737223L + "'", long22 == 1560441737223L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Thu Jun 13 09:02:17 PDT 2019" + "'", str24.equals("Thu Jun 13 09:02:17 PDT 2019"));
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560441737225L + "'", long30 == 1560441737225L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560441737225L + "'", long35 == 1560441737225L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560441737225L + "'", long38 == 1560441737225L);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNull(obj45);
//        org.junit.Assert.assertNotNull(classLoader46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNull(obj48);
//    }

//    @Test
//    public void test64() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test64");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getMonth();
//        java.lang.String str5 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

//    @Test
//    public void test65() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test65");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        long long3 = day0.getSerialIndex();
//        java.lang.String str4 = day0.toString();
//        int int5 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

//    @Test
//    public void test66() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test66");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond5.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(6, (-460));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 1560441648502L);
//        java.lang.String str17 = month14.toString();
//        try {
//            org.jfree.data.time.Year year18 = month14.getYear();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-460) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560441737534L + "'", long7 == 1560441737534L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June -460" + "'", str17.equals("June -460"));
//    }

//    @Test
//    public void test67() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test67");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean4 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        spreadsheetDate3.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        boolean boolean14 = spreadsheetDate3.equals((java.lang.Object) year13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean19 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        spreadsheetDate18.setDescription("Thu Jun 13 09:00:45 PDT 2019");
//        boolean boolean22 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        int int23 = spreadsheetDate18.getDayOfWeek();
//        int int24 = spreadsheetDate18.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560441737552L + "'", long9 == 1560441737552L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

//    @Test
//    public void test68() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test68");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.Date date5 = fixedMillisecond4.getEnd();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener10);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, class13);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.removeChangeListener(seriesChangeListener15);
//        timeSeries14.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries9.addAndOrUpdate(timeSeries14);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries19.addPropertyChangeListener(propertyChangeListener20);
//        timeSeries19.setDomainDescription("Value");
//        boolean boolean24 = timeSeries19.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
//        java.util.Collection collection27 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries26);
//        java.lang.Object obj28 = timeSeries19.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getFirstMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond29.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date32);
//        timeSeries19.setKey((java.lang.Comparable) date32);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date32);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond37.getFirstMillisecond(calendar38);
//        java.util.Date date40 = fixedMillisecond37.getEnd();
//        java.lang.String str41 = fixedMillisecond37.toString();
//        java.util.Date date42 = fixedMillisecond37.getTime();
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date42, timeZone43);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date42);
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date42, timeZone46);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date32, timeZone46);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date5, timeZone46);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(8);
//        java.lang.String str52 = spreadsheetDate51.toString();
//        int int53 = spreadsheetDate51.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean58 = spreadsheetDate55.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        org.jfree.data.time.SerialDate serialDate59 = spreadsheetDate51.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        boolean boolean62 = day60.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.SerialDate serialDate63 = day60.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate64 = spreadsheetDate57.getEndOfCurrentMonth(serialDate63);
//        int int65 = spreadsheetDate57.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond69.getFirstMillisecond(calendar70);
//        java.util.Date date72 = fixedMillisecond69.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond(date72);
//        java.util.Date date74 = fixedMillisecond73.getEnd();
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance(date74);
//        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month(date74);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar80 = null;
//        long long81 = fixedMillisecond79.getFirstMillisecond(calendar80);
//        java.util.Date date82 = fixedMillisecond79.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond(date82);
//        long long84 = fixedMillisecond83.getSerialIndex();
//        java.lang.Class<?> wildcardClass85 = fixedMillisecond83.getClass();
//        java.util.Date date86 = null;
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass85, date86, timeZone87);
//        java.io.InputStream inputStream89 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Nov", (java.lang.Class) wildcardClass85);
//        java.lang.Object obj90 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass85);
//        org.jfree.data.time.TimeSeries timeSeries91 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date74, (java.lang.Class) wildcardClass85);
//        java.io.InputStream inputStream92 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Thu Jun 13 09:01:38 PDT 2019", (java.lang.Class) wildcardClass85);
//        org.jfree.data.time.TimeSeries timeSeries93 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate57, "", "Time", (java.lang.Class) wildcardClass85);
//        org.jfree.data.time.TimeSeries timeSeries94 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5, (java.lang.Class) wildcardClass85);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441737613L + "'", long2 == 1560441737613L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560441737617L + "'", long31 == 1560441737617L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560441737618L + "'", long39 == 1560441737618L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Thu Jun 13 09:02:17 PDT 2019" + "'", str41.equals("Thu Jun 13 09:02:17 PDT 2019"));
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "7-January-1900" + "'", str52.equals("7-January-1900"));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 7 + "'", int53 == 7);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 7 + "'", int65 == 7);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560441737627L + "'", long71 == 1560441737627L);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560441737628L + "'", long81 == 1560441737628L);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560441737628L + "'", long84 == 1560441737628L);
//        org.junit.Assert.assertNotNull(wildcardClass85);
//        org.junit.Assert.assertNotNull(timeZone87);
//        org.junit.Assert.assertNull(regularTimePeriod88);
//        org.junit.Assert.assertNull(inputStream89);
//        org.junit.Assert.assertNull(obj90);
//        org.junit.Assert.assertNull(inputStream92);
//    }
//}

