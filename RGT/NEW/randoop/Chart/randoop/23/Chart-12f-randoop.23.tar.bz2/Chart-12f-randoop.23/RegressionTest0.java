import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = java.awt.Color.RGBtoHSB(0, (int) (short) 1, (-1), floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1, chartChangeEventType2);
        java.awt.Color color4 = color0.brighter();
        int int5 = color0.getTransparency();
        int int6 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-16777216) + "'", int6 == (-16777216));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) ' ', (double) 0, (double) 10L, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("hi!", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("", font1, (java.awt.Paint) color2, rectangleEdge3, horizontalAlignment4, verticalAlignment5, rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1, chartChangeEventType2);
        java.awt.Color color4 = color0.brighter();
        int int5 = color0.getTransparency();
        java.awt.color.ColorSpace colorSpace6 = null;
        float[] floatArray12 = new float[] { 10.0f, 'a', 0, (byte) 100, 0 };
        try {
            float[] floatArray13 = color0.getColorComponents(colorSpace6, floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) -1, (float) 1L, (float) (byte) 100);
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block5 = null;
        columnArrangement4.add(block5, (java.lang.Object) 0L);
        boolean boolean8 = color3.equals((java.lang.Object) 0L);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets1.createOutsetRectangle(rectangle2D2, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1, chartChangeEventType2);
        int int4 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.lang.Object obj2 = blockContainer0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            blockContainer0.setPadding(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str1.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) -1, (int) '4', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) '4', (double) (short) 1, (double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets4.createOutsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke1 = null;
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockContainer2.getMargin();
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets3.getUnitType();
        try {
            org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(unitType4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Color color1 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2, chartChangeEventType3);
        java.awt.Color color5 = color1.brighter();
        java.awt.Color color6 = java.awt.Color.getColor("Rotation.CLOCKWISE", color5);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = new float[] {};
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean2 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge1);
        try {
            double double3 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        blockContainer2.setWidth((double) 0L);
        java.lang.Object obj5 = null;
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer2, obj5);
        double double7 = blockContainer2.getContentYOffset();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment12, (double) (short) 0, (double) (byte) 1);
        try {
            java.lang.Object obj16 = blockContainer2.draw(graphics2D8, rectangle2D9, (java.lang.Object) flowArrangement15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(verticalAlignment12);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.lang.Object obj7 = blockContainer0.draw(graphics2D4, rectangle2D5, (java.lang.Object) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer1.getMargin();
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        blockContainer3.setWidth((double) 0L);
        java.lang.Object obj6 = null;
        blockContainer1.add((org.jfree.chart.block.Block) blockContainer3, obj6);
        try {
            blockContainer0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Character cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 10, (double) 8, (double) 0.0f, (double) (-16777216));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1, chartChangeEventType2);
        java.awt.Color color4 = color0.brighter();
        int int5 = color0.getTransparency();
        java.awt.color.ColorSpace colorSpace6 = null;
        float[] floatArray15 = new float[] { ' ', (byte) 0, 10L, (short) -1, 10.0f };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) '#', 1, (-1), floatArray15);
        try {
            float[] floatArray17 = color0.getColorComponents(colorSpace6, floatArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        try {
            objectList0.set((-16777216), (java.lang.Object) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Color color0 = java.awt.Color.black;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        double double4 = blockContainer0.getWidth();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment7);
        try {
            java.lang.Object obj9 = blockContainer0.draw(graphics2D5, rectangle2D6, (java.lang.Object) chartChangeEvent8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "");
        java.lang.String str5 = library4.getInfo();
        java.lang.String str6 = library4.getInfo();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj2 = textTitle0.clone();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            textTitle0.setBounds(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1, chartChangeEventType2);
        java.lang.Object obj4 = chartChangeEvent3.getSource();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray3 = basicProjectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray4 = basicProjectInfo0.getLibraries();
        basicProjectInfo0.addOptionalLibrary("");
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNotNull(libraryArray4);
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets1.getUnitType();
        double double4 = rectangleInsets1.trimHeight((double) 0.0f);
        double double5 = rectangleInsets1.getRight();
        double double7 = rectangleInsets1.calculateTopInset((double) (short) 10);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("rect", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        java.awt.Paint paint2 = null;
        try {
            textTitle0.setPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 0L);
        blockContainer0.setMargin(0.0d, (double) (byte) -1, 0.0d, (double) (short) 0);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            blockContainer0.setBounds(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel(0, attributedString2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        try {
            java.text.AttributedString attributedString6 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset4, (java.lang.Comparable) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets1.getUnitType();
        double double4 = rectangleInsets1.trimHeight((double) 0.0f);
        double double5 = rectangleInsets1.getRight();
        double double7 = rectangleInsets1.calculateBottomInset(1.0E-5d);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets1.createInsetRectangle(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2);
        org.jfree.chart.plot.Plot plot4 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("rect", font2, plot4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.String str4 = chartEntity2.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rect" + "'", str3.equals("rect"));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        double double2 = rectangleInsets1.getBottom();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets1.createOutsetRectangle(rectangle2D3, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.data.general.Dataset dataset4 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleAnchor3, dataset4);
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 0.5f, (double) 1L, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block2 = null;
        columnArrangement1.add(block2, (java.lang.Object) 0L);
        columnArrangement1.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockContainer7.getMargin();
        boolean boolean9 = columnArrangement6.equals((java.lang.Object) blockContainer7);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement6);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        try {
            org.jfree.chart.util.Size2D size2D13 = legendTitle10.arrange(graphics2D11, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Comparable comparable1 = null;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        try {
            strokeMap0.put(comparable1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, (double) (short) 0, (double) (-1L), (double) (short) 1, (double) 1L);
        textTitle0.setPadding(rectangleInsets7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets7.createOutsetRectangle(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(unitType2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-1), 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.String[] strArray3 = jFreeChartResources0.getStringArray("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets1.getUnitType();
        double double4 = rectangleInsets1.trimHeight((double) 0.0f);
        double double5 = rectangleInsets1.getRight();
        double double7 = rectangleInsets1.calculateBottomInset(1.0E-5d);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets1.createAdjustedRectangle(rectangle2D8, lengthAdjustmentType9, lengthAdjustmentType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            java.awt.Color color1 = java.awt.Color.decode("VerticalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"VerticalAlignment.CENTER\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "");
        java.lang.String str6 = library5.getInfo();
        java.lang.String str7 = library5.getVersion();
        int int8 = objectList0.indexOf((java.lang.Object) str7);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setName("");
        java.lang.String str3 = basicProjectInfo0.getVersion();
        org.jfree.chart.ui.Library[] libraryArray4 = basicProjectInfo0.getLibraries();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(libraryArray4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets1.getUnitType();
        double double4 = rectangleInsets1.trimHeight((double) 0.0f);
        double double5 = rectangleInsets1.getRight();
        double double7 = rectangleInsets1.calculateBottomInset(1.0E-5d);
        double double8 = rectangleInsets1.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("RectangleAnchor.BOTTOM");
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Rotation.CLOCKWISE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Rotation.CLOCKWISE, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle2.getHorizontalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        java.awt.Paint paint5 = textTitle2.getBackgroundPaint();
        textTitle2.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        boolean boolean8 = datasetGroup1.equals((java.lang.Object) textTitle2);
        java.lang.String str9 = datasetGroup1.getID();
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        textTitle2.setNotify(true);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = textTitle2.arrange(graphics2D5, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            legendTitle1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj2 = textTitle0.clone();
        java.awt.Paint paint3 = textTitle0.getBackgroundPaint();
        textTitle0.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        boolean boolean6 = textTitle0.getNotify();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer1.getMargin();
        boolean boolean3 = columnArrangement0.equals((java.lang.Object) blockContainer1);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle4.getHorizontalAlignment();
        java.lang.Object obj6 = textTitle4.clone();
        java.awt.Paint paint7 = textTitle4.getBackgroundPaint();
        textTitle4.setURLText("Rotation.CLOCKWISE");
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getHorizontalAlignment();
        java.lang.Object obj12 = textTitle10.clone();
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle4, (java.lang.Object) textTitle10);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = null;
        try {
            org.jfree.chart.util.Size2D size2D16 = textTitle4.arrange(graphics2D14, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray3 = basicProjectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray4 = basicProjectInfo0.getLibraries();
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo0.getLibraries();
        java.lang.String str6 = basicProjectInfo0.getVersion();
        org.jfree.chart.ui.Library library11 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "");
        basicProjectInfo0.addLibrary(library11);
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNotNull(libraryArray4);
        org.junit.Assert.assertNotNull(libraryArray5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        java.util.List list2 = projectInfo0.getContributors();
        projectInfo0.addOptionalLibrary("VerticalAlignment.CENTER");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleAnchor.BOTTOM", (int) 'a');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer1.getMargin();
        boolean boolean3 = columnArrangement0.equals((java.lang.Object) blockContainer1);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle4.getHorizontalAlignment();
        java.lang.Object obj6 = textTitle4.clone();
        java.awt.Paint paint7 = textTitle4.getBackgroundPaint();
        textTitle4.setURLText("Rotation.CLOCKWISE");
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getHorizontalAlignment();
        java.lang.Object obj12 = textTitle10.clone();
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle4, (java.lang.Object) textTitle10);
        textTitle4.setURLText("");
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 0, 0, (int) (byte) 100);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        chartChangeEvent3.setType(chartChangeEventType4);
        org.jfree.chart.JFreeChart jFreeChart6 = chartChangeEvent3.getChart();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.awt.Color color1 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2, chartChangeEventType3);
        java.awt.Color color5 = color1.brighter();
        java.awt.Color color6 = java.awt.Color.green;
        float[] floatArray12 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray13 = color6.getRGBColorComponents(floatArray12);
        float[] floatArray14 = color1.getRGBColorComponents(floatArray13);
        boolean boolean15 = tableOrder0.equals((java.lang.Object) color1);
        java.lang.Object obj16 = null;
        boolean boolean17 = tableOrder0.equals(obj16);
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer1.getMargin();
        boolean boolean3 = columnArrangement0.equals((java.lang.Object) blockContainer1);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle4.getHorizontalAlignment();
        java.lang.Object obj6 = textTitle4.clone();
        java.awt.Paint paint7 = textTitle4.getBackgroundPaint();
        textTitle4.setURLText("Rotation.CLOCKWISE");
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getHorizontalAlignment();
        java.lang.Object obj12 = textTitle10.clone();
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle4, (java.lang.Object) textTitle10);
        textTitle10.setID("VerticalAlignment.CENTER");
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "-4,-4,4,4");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator3 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator4 = null;
        try {
            java.lang.String str5 = chartEntity2.getImageMapAreaTag(toolTipTagFragmentGenerator3, uRLTagFragmentGenerator4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("ChartEntity: tooltip = ");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ChartEntity: tooltip = ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            multiplePiePlot0.drawOutline(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.String str3 = unknownKeyException1.toString();
        java.lang.String str4 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str2.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str4.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder();
        boolean boolean3 = blockBorder1.equals((java.lang.Object) blockBorder2);
        boolean boolean4 = flowArrangement0.equals((java.lang.Object) blockBorder2);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockContainer5.getMargin();
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        blockContainer7.setWidth((double) 0L);
        java.lang.Object obj10 = null;
        blockContainer5.add((org.jfree.chart.block.Block) blockContainer7, obj10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = null;
        try {
            org.jfree.chart.util.Size2D size2D14 = flowArrangement0.arrange(blockContainer5, graphics2D12, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.data.general.DatasetGroup datasetGroup3 = multiplePiePlot0.getDatasetGroup();
        org.junit.Assert.assertNull(datasetGroup3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, plot2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color1 = color0.darker();
        float[] floatArray10 = new float[] { ' ', (byte) 0, 10L, (short) -1, 10.0f };
        float[] floatArray11 = java.awt.Color.RGBtoHSB((int) '#', 1, (-1), floatArray10);
        float[] floatArray12 = color0.getRGBColorComponents(floatArray10);
        int int13 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-12566273) + "'", int13 == (-12566273));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj2 = textTitle0.clone();
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer3.getMargin();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean6 = blockContainer3.equals((java.lang.Object) color5);
        double double7 = blockContainer3.getWidth();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle8.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment10, (double) (short) 0, (double) (byte) 1);
        blockContainer3.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color16 = color15.darker();
        boolean boolean17 = flowArrangement13.equals((java.lang.Object) color16);
        textTitle0.setBackgroundPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        java.lang.String str2 = pieLabelDistributor1.toString();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        projectInfo0.setName("VerticalAlignment.CENTER");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Color color1 = java.awt.Color.getColor("-4,-4,4,4");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle4.setVerticalAlignment(verticalAlignment5);
        textTitle4.setWidth(1.0E-5d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        try {
            jFreeChart3.draw(graphics2D4, rectangle2D5, point2D6, chartRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        strokeMap0.put((java.lang.Comparable) 1.0E-5d, stroke3);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot6.setOutlineStroke(stroke7);
        try {
            strokeMap0.put((java.lang.Comparable) 1L, stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to java.lang.Long");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        blockContainer2.setWidth((double) 0L);
        java.lang.Object obj5 = null;
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer2, obj5);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle7.getHorizontalAlignment();
        java.lang.Object obj9 = textTitle7.clone();
        java.awt.Paint paint10 = textTitle7.getBackgroundPaint();
        textTitle7.setURLText("Rotation.CLOCKWISE");
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder();
        boolean boolean16 = blockBorder14.equals((java.lang.Object) blockBorder15);
        boolean boolean17 = flowArrangement13.equals((java.lang.Object) blockBorder15);
        textTitle7.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape19, "hi!");
        try {
            blockContainer2.add((org.jfree.chart.block.Block) textTitle7, (java.lang.Object) shape19);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.awt.geom.Rectangle2D$Double cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, 8, 0);
        java.awt.Color color4 = chartColor3.darker();
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.Plot plot10 = multiplePiePlot0.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        try {
            plot10.setInsets(rectangleInsets11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        java.lang.Object obj8 = textTitle6.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle6);
        jFreeChart3.titleChanged(titleChangeEvent9);
        org.jfree.chart.ui.ProjectInfo projectInfo11 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image12 = projectInfo11.getLogo();
        java.util.List list13 = projectInfo11.getContributors();
        try {
            jFreeChart3.setSubtitles(list13);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.ui.Contributor cannot be cast to org.jfree.chart.title.Title");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(projectInfo11);
        org.junit.Assert.assertNotNull(image12);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        textTitle2.setNotify(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle2.setPaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle2.getPosition();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.color.ColorSpace colorSpace3 = color1.getColorSpace();
        java.awt.Color color4 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color4, jFreeChart5, chartChangeEventType6);
        java.awt.Color color8 = color4.brighter();
        java.awt.Color color9 = java.awt.Color.green;
        float[] floatArray15 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray16 = color9.getRGBColorComponents(floatArray15);
        float[] floatArray17 = color4.getRGBColorComponents(floatArray16);
        float[] floatArray18 = null;
        float[] floatArray19 = color4.getRGBColorComponents(floatArray18);
        try {
            float[] floatArray20 = color0.getComponents(colorSpace3, floatArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        java.lang.String str3 = textTitle2.getText();
        textTitle2.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color3.getComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(colorSpace2, floatArray19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot22.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = multiplePiePlot22.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        try {
            lineBorder26.draw(graphics2D27, rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color3.getComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(colorSpace2, floatArray19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot22.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = multiplePiePlot22.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets25);
        double double28 = rectangleInsets25.calculateTopInset((double) (short) 1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.0d + "'", double28 == 4.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder();
        boolean boolean2 = blockBorder0.equals((java.lang.Object) blockBorder1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockBorder1.getInsets();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createInsetRectangle(rectangle2D4, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeColumn((-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -16777216");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Color color0 = java.awt.Color.GREEN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Color color1 = java.awt.Color.getColor("HorizontalAlignment.RIGHT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (-1.0f));
        try {
            defaultKeyedValues2D1.removeColumn((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.lang.String str2 = rectangleInsets1.toString();
        double double4 = rectangleInsets1.calculateRightOutset(0.08d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str2.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray3 = basicProjectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray4 = basicProjectInfo0.getLibraries();
        basicProjectInfo0.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        basicProjectInfo0.setVersion("VerticalAlignment.CENTER");
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNotNull(libraryArray4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block2 = null;
        columnArrangement1.add(block2, (java.lang.Object) 0L);
        columnArrangement1.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockContainer7.getMargin();
        boolean boolean9 = columnArrangement6.equals((java.lang.Object) blockContainer7);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement6);
        columnArrangement1.clear();
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 0L);
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(arrangement3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 0, (double) (-1L), (double) (short) 1, (double) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 10, 0.0d, (double) 1L, (double) 2);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets10.createAdjustedRectangle(rectangle2D11, lengthAdjustmentType12, lengthAdjustmentType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo11);
        float float13 = jFreeChart3.getBackgroundImageAlpha();
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart3.createBufferedImage(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.sort();
        pieLabelDistributor1.sort();
        pieLabelDistributor1.clear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        double double4 = blockContainer0.getWidth();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 0, (double) (byte) 1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement10);
        java.lang.Object obj12 = blockContainer0.clone();
        double double13 = blockContainer0.getHeight();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = null;
        try {
            org.jfree.chart.util.Size2D size2D16 = blockContainer0.arrange(graphics2D14, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = multiplePiePlot0.getInsets();
        org.jfree.data.general.Dataset dataset4 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets3, dataset4);
        boolean boolean7 = rectangleInsets3.equals((java.lang.Object) "RectangleEdge.LEFT");
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Color color1 = java.awt.Color.getColor("PieLabelLinkStyle.QUAD_CURVE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        org.jfree.chart.block.BlockFrame blockFrame3 = textTitle2.getFrame();
        textTitle2.setToolTipText("java.awt.Color[r=0,g=128,b=0]");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockFrame3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot0.setOutlinePaint(paint3);
        java.lang.Object obj5 = multiplePiePlot0.clone();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            multiplePiePlot0.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj5);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = projectInfo0.getLogo();
//        java.awt.Image image2 = projectInfo0.getLogo();
//        java.lang.String str3 = projectInfo0.getLicenceName();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(image1);
//        org.junit.Assert.assertNotNull(image2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LGPL" + "'", str3.equals("LGPL"));
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) "LGPL");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot3.getLabelDistributor();
        abstractPieLabelDistributor8.clear();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.String str3 = unknownKeyException1.toString();
        org.jfree.data.UnknownKeyException unknownKeyException5 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException5);
        java.lang.Throwable[] throwableArray7 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str2.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets1.getUnitType();
        double double4 = rectangleInsets1.trimHeight((double) 0.0f);
        double double6 = rectangleInsets1.extendHeight((double) 0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Shape shape0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 97, (int) (short) 100, (java.lang.Comparable) 'a', "ChartChangeEventType.GENERAL", "ChartChangeEventType.GENERAL");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle2.getHorizontalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        java.awt.Paint paint5 = textTitle2.getBackgroundPaint();
        textTitle2.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        boolean boolean8 = datasetGroup1.equals((java.lang.Object) textTitle2);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            textTitle2.setBounds(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        double double4 = piePlot1.getMaximumExplodePercent();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        java.lang.Object obj8 = textTitle6.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle6);
        jFreeChart3.titleChanged(titleChangeEvent9);
        int int11 = jFreeChart3.getSubtitleCount();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        jFreeChart3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart3.getTitle();
        org.jfree.chart.title.Title title13 = null;
        try {
            jFreeChart3.addSubtitle(0, title13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textTitle11);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            multiplePiePlot0.drawBackground(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.Plot plot10 = multiplePiePlot0.getParent();
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block13 = null;
        columnArrangement12.add(block13, (java.lang.Object) 0L);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0, (org.jfree.chart.block.Arrangement) columnArrangement11, (org.jfree.chart.block.Arrangement) columnArrangement12);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            legendTitle16.setBounds(rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel(0, attributedString2);
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot1.setOutlinePaint(paint4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        multiplePiePlot1.markerChanged(markerChangeEvent7);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.CUBIC_CURVE" + "'", str1.equals("PieLabelLinkStyle.CUBIC_CURVE"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getOptionalLibraries();
        basicProjectInfo0.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str4 = basicProjectInfo0.getInfo();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.Plot plot10 = multiplePiePlot0.getParent();
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block13 = null;
        columnArrangement12.add(block13, (java.lang.Object) 0L);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0, (org.jfree.chart.block.Arrangement) columnArrangement11, (org.jfree.chart.block.Arrangement) columnArrangement12);
        columnArrangement11.clear();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "");
        boolean boolean6 = standardPieSectionLabelGenerator0.equals((java.lang.Object) "");
        java.lang.Object obj7 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        jFreeChart3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textTitle12.getHorizontalAlignment();
        try {
            jFreeChart3.addSubtitle((int) (short) 10, (org.jfree.chart.title.Title) textTitle12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2);
        textTitle3.setNotify(true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle3.setPaint((java.awt.Paint) color6);
        boolean boolean8 = paintMap0.equals((java.lang.Object) color6);
        java.lang.Object obj9 = paintMap0.clone();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.util.Rotation rotation9 = piePlot3.getDirection();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            piePlot3.drawBackground(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rotation9);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        double double3 = rectangleInsets1.calculateRightOutset(0.0d);
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets1.getUnitType();
        java.lang.String str5 = unitType4.toString();
        java.lang.Object obj6 = null;
        boolean boolean7 = unitType4.equals(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UnitType.ABSOLUTE" + "'", str5.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot9.setOutlinePaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot9);
        legendTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        jFreeChart14.setBackgroundImageAlpha(10.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer1.getMargin();
        boolean boolean3 = columnArrangement0.equals((java.lang.Object) blockContainer1);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle4.getHorizontalAlignment();
        java.lang.Object obj6 = textTitle4.clone();
        java.awt.Paint paint7 = textTitle4.getBackgroundPaint();
        textTitle4.setURLText("Rotation.CLOCKWISE");
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getHorizontalAlignment();
        java.lang.Object obj12 = textTitle10.clone();
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle4, (java.lang.Object) textTitle10);
        textTitle10.setURLText("http://www.jfree.org/jfreechart/index.html");
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.awt.Paint paint9 = null;
        try {
            piePlot1.setLabelLinkPaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel(0, attributedString2);
        java.text.AttributedString attributedString5 = standardPieSectionLabelGenerator0.getAttributedLabel((int) (short) 1);
        java.text.AttributedString attributedString7 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel((int) '4', attributedString7);
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke11, stroke12, stroke13 };
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] { stroke15, stroke16 };
        java.awt.Shape[] shapeArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray14, strokeArray17, shapeArray18);
        boolean boolean20 = standardPieSectionLabelGenerator0.equals((java.lang.Object) paintArray9);
        org.junit.Assert.assertNull(attributedString5);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            multiplePiePlot0.drawOutline(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("", font3);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font3);
        boolean boolean6 = chartChangeEventType0.equals((java.lang.Object) font3);
        java.lang.String str7 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str7.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        java.awt.Paint paint10 = multiplePiePlot0.getOutlinePaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        java.awt.color.ColorSpace colorSpace14 = color12.getColorSpace();
        java.awt.Color color18 = java.awt.Color.green;
        float[] floatArray24 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        float[] floatArray26 = java.awt.Color.RGBtoHSB((-16777216), (int) (byte) 100, (int) (short) 100, floatArray25);
        float[] floatArray27 = color11.getColorComponents(colorSpace14, floatArray26);
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        jFreeChart3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = null;
        try {
            jFreeChart3.plotChanged(plotChangeEvent11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Color color2 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2, jFreeChart3, chartChangeEventType4);
        java.awt.Color color6 = color2.brighter();
        java.awt.Color color7 = java.awt.Color.green;
        float[] floatArray13 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        float[] floatArray15 = color2.getRGBColorComponents(floatArray14);
        float[] floatArray16 = color0.getComponents(floatArray14);
        int int17 = color0.getBlue();
        int int18 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) true);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        try {
            java.text.AttributedString attributedString6 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset4, (java.lang.Comparable) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        java.lang.String str3 = textTitle2.getText();
        double double4 = textTitle2.getHeight();
        textTitle2.setURLText("RectangleEdge.LEFT");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            textTitle2.setBounds(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Color color1 = java.awt.Color.getColor("ChartEntity: tooltip = ");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        boolean boolean3 = jFreeChartResources0.containsKey("java.awt.Color[r=0,g=128,b=0]");
        try {
            java.lang.Object obj5 = jFreeChartResources0.getObject("Other");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Other");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        strokeMap0.put((java.lang.Comparable) 1.0E-5d, stroke3);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        try {
            strokeMap0.put((java.lang.Comparable) "Rotation.CLOCKWISE", stroke6);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to java.lang.String");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeCoords();
        java.lang.String str4 = chartEntity2.getURLText();
        java.lang.String str5 = chartEntity2.getURLText();
        java.awt.Shape shape6 = chartEntity2.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-4,-4,4,4" + "'", str3.equals("-4,-4,4,4"));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        java.lang.String str3 = textTitle2.getText();
        double double4 = textTitle2.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle2.getPosition();
        boolean boolean6 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge5);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener1 = null;
        textTitle0.addChangeListener(titleChangeListener1);
        boolean boolean3 = textTitle0.getExpandToFitSpace();
        boolean boolean4 = textTitle0.getExpandToFitSpace();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = null;
        try {
            piePlot3.setLabelPadding(rectangleInsets8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot9.setOutlinePaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot9);
        legendTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        boolean boolean16 = jFreeChart14.isBorderVisible();
        java.awt.Font font19 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font19);
        java.lang.String str21 = textTitle20.getText();
        double double22 = textTitle20.getWidth();
        try {
            jFreeChart14.addSubtitle((int) (byte) 10, (org.jfree.chart.title.Title) textTitle20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str21.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "RectangleAnchor.BOTTOM", "LGPL", "", "-4,-4,4,4");
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("Rotation.CLOCKWISE");
        try {
            java.lang.String[] strArray4 = jFreeChartResources0.getStringArray("HorizontalAlignment.RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key HorizontalAlignment.RIGHT");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        double double2 = rotation0.getFactor();
        double double3 = rotation0.getFactor();
        java.lang.String str4 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Rotation.CLOCKWISE" + "'", str4.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        strokeMap0.put((java.lang.Comparable) 1.0E-5d, stroke3);
        java.lang.Object obj5 = strokeMap0.clone();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        piePlot8.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset11 = piePlot8.getDataset();
        java.awt.Font font12 = piePlot8.getLabelFont();
        piePlot8.setMinimumArcAngleToDraw(0.0d);
        java.awt.Stroke stroke15 = piePlot8.getOutlineStroke();
        try {
            strokeMap0.put((java.lang.Comparable) 97, stroke15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to java.lang.Integer");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(pieDataset11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1, chartChangeEventType2);
        java.awt.Color color4 = color0.brighter();
        float[] floatArray6 = new float[] { 97 };
        try {
            float[] floatArray7 = color4.getRGBColorComponents(floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            piePlot1.drawOutline(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieDataset4);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        piePlot1.drawBackgroundImage(graphics2D10, rectangle2D11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            piePlot1.drawBackground(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle4.setVerticalAlignment(verticalAlignment5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle4.getPadding();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        textTitle2.setNotify(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle2.setPaint((java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textTitle9.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment10, verticalAlignment11, (double) (short) 0, (double) (byte) 1);
        java.awt.Color color15 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color15);
        boolean boolean17 = verticalAlignment11.equals((java.lang.Object) blockBorder16);
        java.lang.Object obj18 = textTitle2.draw(graphics2D7, rectangle2D8, (java.lang.Object) verticalAlignment11);
        textTitle2.setHeight((double) 3);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(obj18);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("rect");
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj2 = textTitle0.clone();
        java.awt.Paint paint3 = textTitle0.getBackgroundPaint();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textTitle0.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        double double1 = rotation0.getFactor();
        java.lang.String str2 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Rotation.CLOCKWISE" + "'", str2.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeRow((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font7);
        java.lang.String str9 = textTitle8.getText();
        double double10 = textTitle8.getHeight();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle8);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot12 = jFreeChart3.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj2 = textTitle0.clone();
        java.awt.Paint paint3 = textTitle0.getBackgroundPaint();
        java.awt.Paint paint4 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "RectangleAnchor.BOTTOM", "-4,-4,4,4");
        chartEntity3.setURLText("ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer1.getMargin();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean4 = blockContainer1.equals((java.lang.Object) color3);
        boolean boolean5 = blockContainer1.isEmpty();
        boolean boolean6 = rectangleEdge0.equals((java.lang.Object) boolean5);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '#', 97, (java.lang.Comparable) (-16777216), "RectangleEdge.LEFT", "ChartEntity: tooltip = ");
        java.lang.Comparable comparable8 = null;
        pieSectionEntity7.setSectionKey(comparable8);
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("UnitType.ABSOLUTE", "rect");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rect" + "'", str3.equals("rect"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot1.setOutlinePaint(paint4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart6.getLegend((int) (byte) 0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(legendTitle8);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        double double7 = legendTitle2.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle2.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray12 = legendTitle10.getSources();
        legendTitle2.setSources(legendItemSourceArray12);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItemSourceArray12);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(legendItemSourceArray12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        java.lang.Object obj8 = textTitle6.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle6);
        jFreeChart3.titleChanged(titleChangeEvent9);
        java.awt.Stroke stroke11 = jFreeChart3.getBorderStroke();
        jFreeChart3.setBackgroundImageAlignment((int) '#');
        try {
            org.jfree.chart.title.Title title15 = jFreeChart3.getSubtitle(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        jFreeChart7.setNotify(true);
        java.awt.Stroke stroke10 = jFreeChart7.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart7.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo15);
        float float17 = jFreeChart7.getBackgroundImageAlpha();
        chartChangeEvent1.setChart(jFreeChart7);
        java.awt.Paint paint19 = jFreeChart7.getBackgroundPaint();
        java.awt.RenderingHints renderingHints20 = jFreeChart7.getRenderingHints();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        try {
            jFreeChart7.handleClick((int) (byte) 1, 0, chartRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(renderingHints20);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateTopInset((double) 10L);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo3.getLibraries();
        boolean boolean9 = rectangleInsets0.equals((java.lang.Object) basicProjectInfo3);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets0.createInsetRectangle(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Color color2 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2, jFreeChart3, chartChangeEventType4);
        java.awt.Color color6 = color2.brighter();
        java.awt.Color color7 = java.awt.Color.green;
        float[] floatArray13 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        float[] floatArray15 = color2.getRGBColorComponents(floatArray14);
        float[] floatArray16 = color0.getComponents(floatArray14);
        int int17 = color0.getBlue();
        java.awt.Color color18 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color18);
        java.awt.Color color20 = java.awt.Color.GREEN;
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace22 = color21.getColorSpace();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color23);
        java.awt.Color color25 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
        java.awt.Color color29 = color25.brighter();
        java.awt.Color color30 = java.awt.Color.green;
        float[] floatArray36 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
        float[] floatArray38 = color25.getRGBColorComponents(floatArray37);
        float[] floatArray39 = color23.getComponents(floatArray37);
        float[] floatArray40 = color20.getColorComponents(colorSpace22, floatArray39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace43 = color42.getColorSpace();
        java.awt.color.ColorSpace colorSpace44 = color42.getColorSpace();
        java.awt.Color color48 = java.awt.Color.green;
        float[] floatArray54 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray55 = color48.getRGBColorComponents(floatArray54);
        float[] floatArray56 = java.awt.Color.RGBtoHSB((-16777216), (int) (byte) 100, (int) (short) 100, floatArray55);
        float[] floatArray57 = color41.getColorComponents(colorSpace44, floatArray56);
        float[] floatArray58 = color18.getComponents(colorSpace22, floatArray56);
        float[] floatArray61 = new float[] { 0.5f, (-16777216) };
        try {
            float[] floatArray62 = color0.getComponents(colorSpace22, floatArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(colorSpace22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(colorSpace43);
        org.junit.Assert.assertNotNull(colorSpace44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray61);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Color color0 = java.awt.Color.BLUE;
        java.awt.Color color1 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        java.awt.Color color3 = java.awt.Color.GREEN;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        java.awt.Color color8 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8, jFreeChart9, chartChangeEventType10);
        java.awt.Color color12 = color8.brighter();
        java.awt.Color color13 = java.awt.Color.green;
        float[] floatArray19 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        float[] floatArray21 = color8.getRGBColorComponents(floatArray20);
        float[] floatArray22 = color6.getComponents(floatArray20);
        float[] floatArray23 = color3.getColorComponents(colorSpace5, floatArray22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace26 = color25.getColorSpace();
        java.awt.color.ColorSpace colorSpace27 = color25.getColorSpace();
        java.awt.Color color31 = java.awt.Color.green;
        float[] floatArray37 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray38 = color31.getRGBColorComponents(floatArray37);
        float[] floatArray39 = java.awt.Color.RGBtoHSB((-16777216), (int) (byte) 100, (int) (short) 100, floatArray38);
        float[] floatArray40 = color24.getColorComponents(colorSpace27, floatArray39);
        float[] floatArray41 = color1.getComponents(colorSpace5, floatArray39);
        java.awt.Color color45 = java.awt.Color.green;
        float[] floatArray51 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray52 = color45.getRGBColorComponents(floatArray51);
        float[] floatArray53 = java.awt.Color.RGBtoHSB((-16777216), (int) (byte) 100, (int) (short) 100, floatArray52);
        float[] floatArray54 = color0.getComponents(colorSpace5, floatArray52);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(colorSpace26);
        org.junit.Assert.assertNotNull(colorSpace27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo11);
        float float13 = jFreeChart3.getBackgroundImageAlpha();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font17);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font17);
        try {
            jFreeChart3.addSubtitle(1, (org.jfree.chart.title.Title) textTitle19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot3.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord10 = abstractPieLabelDistributor8.getPieLabelRecord((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeColumn(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        int int3 = objectList0.indexOf((java.lang.Object) (short) 100);
        objectList0.clear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getNumberFormat();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator0.getNumberFormat();
        java.lang.Object obj3 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        double double7 = piePlot1.getStartAngle();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.event.ChartChangeListener chartChangeListener6 = null;
        try {
            jFreeChart3.removeChangeListener(chartChangeListener6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot3.getDrawingSupplier();
        java.awt.Image image9 = piePlot3.getBackgroundImage();
        piePlot3.setCircular(false);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(image9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        java.awt.Image image2 = projectInfo0.getLogo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
        basicProjectInfo3.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        java.lang.String str11 = projectInfo0.getLicenceText();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot12.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot12.getPieChart();
        jFreeChart15.setNotify(true);
        java.awt.Stroke stroke18 = jFreeChart15.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart15.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo23);
        jFreeChart15.fireChartChanged();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot26 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image27 = multiplePiePlot26.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        piePlot29.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset32 = piePlot29.getDataset();
        multiplePiePlot26.setParent((org.jfree.chart.plot.Plot) piePlot29);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor34 = piePlot29.getLabelDistributor();
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color35);
        java.awt.Color color37 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart38 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType39 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color37, jFreeChart38, chartChangeEventType39);
        java.awt.Color color41 = color37.brighter();
        java.awt.Color color42 = java.awt.Color.green;
        float[] floatArray48 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray49 = color42.getRGBColorComponents(floatArray48);
        float[] floatArray50 = color37.getRGBColorComponents(floatArray49);
        float[] floatArray51 = color35.getComponents(floatArray49);
        piePlot29.setLabelLinkPaint((java.awt.Paint) color35);
        jFreeChart15.setBackgroundPaint((java.awt.Paint) color35);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent54 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) projectInfo0, jFreeChart15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = null;
        try {
            java.awt.image.BufferedImage bufferedImage59 = jFreeChart15.createBufferedImage(100, (int) (byte) 10, 0, chartRenderingInfo58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(image2);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(bufferedImage24);
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertNull(pieDataset32);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("Rotation.CLOCKWISE");
        try {
            java.lang.String[] strArray4 = jFreeChartResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo11);
        jFreeChart3.fireChartChanged();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image15 = multiplePiePlot14.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset20 = piePlot17.getDataset();
        multiplePiePlot14.setParent((org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor22 = piePlot17.getLabelDistributor();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color23);
        java.awt.Color color25 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
        java.awt.Color color29 = color25.brighter();
        java.awt.Color color30 = java.awt.Color.green;
        float[] floatArray36 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
        float[] floatArray38 = color25.getRGBColorComponents(floatArray37);
        float[] floatArray39 = color23.getComponents(floatArray37);
        piePlot17.setLabelLinkPaint((java.awt.Paint) color23);
        jFreeChart3.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = jFreeChart3.getPadding();
        org.jfree.chart.StrokeMap strokeMap43 = new org.jfree.chart.StrokeMap();
        strokeMap43.clear();
        boolean boolean45 = rectangleInsets42.equals((java.lang.Object) strokeMap43);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNull(pieDataset20);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape3, "");
        java.lang.String str6 = chartEntity5.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image8 = projectInfo7.getLogo();
        java.awt.Image image9 = projectInfo7.getLogo();
        boolean boolean10 = chartEntity5.equals((java.lang.Object) image9);
        java.lang.Object obj11 = chartEntity5.clone();
        boolean boolean12 = color2.equals((java.lang.Object) chartEntity5);
        boolean boolean13 = objectList0.equals((java.lang.Object) chartEntity5);
        chartEntity5.setToolTipText("rect");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-4,-4,4,4" + "'", str6.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(image8);
        org.junit.Assert.assertNotNull(image9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleAnchor8, dataset9);
        piePlot3.datasetChanged(datasetChangeEvent10);
        org.jfree.data.general.Dataset dataset12 = datasetChangeEvent10.getDataset();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNull(dataset12);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset1, (java.lang.Comparable) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("RectangleEdge.LEFT");
        java.util.Enumeration<java.lang.String> strEnumeration4 = jFreeChartResources0.getKeys();
        try {
            java.lang.String str6 = jFreeChartResources0.getString("RectangleAnchor.BOTTOM");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleAnchor.BOTTOM");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(strEnumeration4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block2 = null;
        columnArrangement1.add(block2, (java.lang.Object) 0L);
        columnArrangement1.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockContainer7.getMargin();
        boolean boolean9 = columnArrangement6.equals((java.lang.Object) blockContainer7);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement6);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        try {
            java.lang.Object obj14 = legendTitle10.draw(graphics2D11, rectangle2D12, (java.lang.Object) color13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        int int5 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100L);
        try {
            java.lang.Comparable comparable7 = defaultCategoryDataset0.getRowKey(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font2);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset9 = piePlot6.getDataset();
        java.awt.Font font10 = piePlot6.getLabelFont();
        piePlot6.setMinimumArcAngleToDraw(0.0d);
        boolean boolean13 = textTitle4.equals((java.lang.Object) 0.0d);
        java.awt.Font font14 = textTitle4.getFont();
        textTitle4.setPadding((double) (byte) 10, 10.0d, (double) (-12566273), 100.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartChangeListener chartChangeListener4 = null;
        try {
            jFreeChart3.removeChangeListener(chartChangeListener4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot9.setOutlinePaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot9);
        legendTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        boolean boolean16 = jFreeChart14.isBorderVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        try {
            jFreeChart14.plotChanged(plotChangeEvent17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        try {
            defaultKeyedValues2D1.removeRow((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.awt.Color color1 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2, chartChangeEventType3);
        java.awt.Color color5 = color1.brighter();
        java.awt.Color color6 = java.awt.Color.green;
        float[] floatArray12 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray13 = color6.getRGBColorComponents(floatArray12);
        float[] floatArray14 = color1.getRGBColorComponents(floatArray13);
        boolean boolean15 = tableOrder0.equals((java.lang.Object) color1);
        java.lang.String str16 = tableOrder0.toString();
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TableOrder.BY_ROW" + "'", str16.equals("TableOrder.BY_ROW"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str1 = horizontalAlignment0.toString();
        java.lang.String str2 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str1.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str2.equals("HorizontalAlignment.RIGHT"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        piePlot1.setNoDataMessage("");
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        java.awt.Color color11 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Color color15 = color11.brighter();
        int int16 = color11.getRGB();
        piePlot3.setLabelShadowPaint((java.awt.Paint) color11);
        piePlot3.setLabelLinkMargin(0.4d);
        piePlot3.setShadowXOffset((double) 0.0f);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-16777216) + "'", int16 == (-16777216));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent3);
        org.jfree.chart.util.TableOrder tableOrder5 = multiplePiePlot0.getDataExtractOrder();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(tableOrder5);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = jFreeChart9.getPadding();
        java.lang.Object obj11 = jFreeChart9.getTextAntiAlias();
        java.util.List list12 = jFreeChart9.getSubtitles();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot13 = jFreeChart9.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj2 = textTitle0.clone();
        java.awt.Paint paint3 = textTitle0.getBackgroundPaint();
        textTitle0.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        textTitle0.setURLText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle0.getHorizontalAlignment();
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("", font10);
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font14);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle16.setVerticalAlignment(verticalAlignment17);
        textTitle11.setVerticalAlignment(verticalAlignment17);
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment17, (double) (short) 100, (double) (-1.0f));
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str1 = rectangleEdge0.toString();
        boolean boolean2 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.LEFT" + "'", str1.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = null;
        piePlot1.setURLGenerator(pieURLGenerator9);
        double double11 = piePlot1.getMaximumExplodePercent();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2);
        textTitle3.setNotify(true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle3.setPaint((java.awt.Paint) color6);
        boolean boolean8 = paintMap0.equals((java.lang.Object) color6);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(0, 2, (int) (byte) 0);
        paintMap0.put((java.lang.Comparable) (-1L), (java.awt.Paint) chartColor13);
        java.awt.Paint paint16 = paintMap0.getPaint((java.lang.Comparable) "RectangleEdge.LEFT");
        java.lang.Comparable comparable17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        try {
            paintMap0.put(comparable17, (java.awt.Paint) color18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int1 = color0.getBlue();
        int int2 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str3 = contributor2.getName();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) contributor2);
        java.lang.String str5 = chartChangeEvent4.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 2, (-1.0d), (double) 100.0f, (double) 1L, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("http://www.jfree.org/jfreechart/index.html", "HorizontalAlignment.RIGHT", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "");
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Stroke stroke5 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.util.Rotation rotation6 = piePlot1.getDirection();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rotation6);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("RectangleEdge.LEFT");
        boolean boolean5 = jFreeChartResources0.containsKey("LGPL");
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        chartChangeEvent1.setType(chartChangeEventType4);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        chartChangeEvent1.setType(chartChangeEventType6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = chartChangeEvent1.getType();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNull(chartChangeEventType8);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setName("Rotation.CLOCKWISE");
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color3.getComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(colorSpace2, floatArray19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot22.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = multiplePiePlot22.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets25);
        java.lang.String str27 = rectangleInsets25.toString();
        double double29 = rectangleInsets25.calculateRightInset((double) 1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str27.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 8.0d + "'", double29 == 8.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get((-12566273));
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.sort();
        pieLabelDistributor1.sort();
        pieLabelDistributor1.distributeLabels(1.0E-5d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "-4,-4,4,4");
        java.lang.String str3 = chartEntity2.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleAnchor8, dataset9);
        piePlot3.datasetChanged(datasetChangeEvent10);
        org.jfree.chart.block.Arrangement arrangement12 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = blockContainer14.getMargin();
        boolean boolean16 = columnArrangement13.equals((java.lang.Object) blockContainer14);
        try {
            org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3, arrangement12, (org.jfree.chart.block.Arrangement) columnArrangement13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.PaintMap paintMap1 = new org.jfree.chart.PaintMap();
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font3);
        textTitle4.setNotify(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle4.setPaint((java.awt.Paint) color7);
        boolean boolean9 = paintMap1.equals((java.lang.Object) color7);
        java.awt.Color color10 = java.awt.Color.getColor("TableOrder.BY_ROW", color7);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.chart.util.UnitType unitType12 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType12, (double) (short) 0, (double) (-1L), (double) (short) 1, (double) 1L);
        double double19 = rectangleInsets17.calculateLeftOutset((double) 0.0f);
        double double21 = rectangleInsets17.extendWidth((double) 100.0f);
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke11, rectangleInsets17);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartChangeListener chartChangeListener7 = null;
        try {
            jFreeChart3.removeChangeListener(chartChangeListener7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        basicProjectInfo0.setVersion("RectangleEdge.LEFT");
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj2 = textTitle0.clone();
        java.awt.Paint paint3 = textTitle0.getBackgroundPaint();
        textTitle0.setURLText("Rotation.CLOCKWISE");
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder();
        boolean boolean9 = blockBorder7.equals((java.lang.Object) blockBorder8);
        boolean boolean10 = flowArrangement6.equals((java.lang.Object) blockBorder8);
        textTitle0.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            blockBorder8.draw(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int8 = pieSectionEntity7.getPieIndex();
        int int9 = pieSectionEntity7.getSectionIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot9.setOutlinePaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot9);
        legendTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot16 = jFreeChart14.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key hi!");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2);
        textTitle3.setNotify(true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle3.setPaint((java.awt.Paint) color6);
        boolean boolean8 = paintMap0.equals((java.lang.Object) color6);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(0, 2, (int) (byte) 0);
        paintMap0.put((java.lang.Comparable) (-1L), (java.awt.Paint) chartColor13);
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment19);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = null;
        chartChangeEvent20.setType(chartChangeEventType21);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot23.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart26 = multiplePiePlot23.getPieChart();
        jFreeChart26.setNotify(true);
        java.awt.Stroke stroke29 = jFreeChart26.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = null;
        java.awt.image.BufferedImage bufferedImage35 = jFreeChart26.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo34);
        float float36 = jFreeChart26.getBackgroundImageAlpha();
        chartChangeEvent20.setChart(jFreeChart26);
        java.awt.Paint paint38 = jFreeChart26.getBackgroundPaint();
        java.awt.RenderingHints renderingHints39 = jFreeChart26.getRenderingHints();
        java.awt.PaintContext paintContext40 = chartColor13.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints39);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(jFreeChart26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(bufferedImage35);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.5f + "'", float36 == 0.5f);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(renderingHints39);
        org.junit.Assert.assertNotNull(paintContext40);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (-1.0f));
        java.util.List list8 = defaultKeyedValues2D1.getColumnKeys();
        int int9 = defaultKeyedValues2D1.getRowCount();
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleAnchor0, dataset1);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer3.getMargin();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean6 = blockContainer3.equals((java.lang.Object) color5);
        double double7 = blockContainer3.getWidth();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle8.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment10, (double) (short) 0, (double) (byte) 1);
        blockContainer3.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement13);
        blockContainer3.setPadding(0.0d, 0.0d, 0.0d, 1.0E-5d);
        boolean boolean20 = rectangleAnchor0.equals((java.lang.Object) 1.0E-5d);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color3.getComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(colorSpace2, floatArray19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot22.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = multiplePiePlot22.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets25);
        java.awt.Paint paint27 = lineBorder26.getPaint();
        boolean boolean29 = lineBorder26.equals((java.lang.Object) "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        double double4 = blockContainer0.getWidth();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 0, (double) (byte) 1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement10);
        java.lang.Object obj12 = blockContainer0.clone();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray15 = legendTitle14.getSources();
        boolean boolean16 = blockContainer0.equals((java.lang.Object) legendItemSourceArray15);
        boolean boolean17 = blockContainer0.isEmpty();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(legendItemSourceArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str5 = chartChangeEventType4.toString();
        chartChangeEvent1.setType(chartChangeEventType4);
        java.lang.String str7 = chartChangeEventType4.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str7.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray10 = legendTitle8.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle8.getItemLabelPadding();
        boolean boolean12 = rectangleAnchor6.equals((java.lang.Object) legendTitle8);
        double double13 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle8.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle16);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray18 = legendTitle16.getSources();
        legendTitle8.setSources(legendItemSourceArray18);
        jFreeChart3.addLegend(legendTitle8);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.Point2D point2D23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        try {
            jFreeChart3.draw(graphics2D21, rectangle2D22, point2D23, chartRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(legendItemSourceArray10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(legendItemSourceArray18);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("RectangleEdge.LEFT");
        java.util.Enumeration<java.lang.String> strEnumeration4 = jFreeChartResources0.getKeys();
        boolean boolean6 = jFreeChartResources0.containsKey("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(strEnumeration4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        java.lang.String str3 = textTitle2.getText();
        double double4 = textTitle2.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle2.getPosition();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot6.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot6.getPieChart();
        jFreeChart9.setNotify(true);
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart9.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo17);
        jFreeChart9.fireChartChanged();
        java.awt.RenderingHints renderingHints20 = jFreeChart9.getRenderingHints();
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart9);
        double double22 = textTitle2.getContentYOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertNotNull(renderingHints20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            rectangleInsets1.trim(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot0.setOutlinePaint(paint3);
        java.lang.Object obj5 = multiplePiePlot0.clone();
        java.awt.Paint paint6 = multiplePiePlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        java.awt.Color color3 = java.awt.Color.GREEN;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        java.awt.Color color8 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8, jFreeChart9, chartChangeEventType10);
        java.awt.Color color12 = color8.brighter();
        java.awt.Color color13 = java.awt.Color.green;
        float[] floatArray19 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        float[] floatArray21 = color8.getRGBColorComponents(floatArray20);
        float[] floatArray22 = color6.getComponents(floatArray20);
        float[] floatArray23 = color3.getColorComponents(colorSpace5, floatArray22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot25.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = multiplePiePlot25.getInsets();
        org.jfree.chart.block.LineBorder lineBorder29 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke24, rectangleInsets28);
        strokeMap0.put((java.lang.Comparable) 128, stroke24);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment0);
        java.lang.String str2 = verticalAlignment0.toString();
        java.lang.String str3 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VerticalAlignment.CENTER" + "'", str2.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.CENTER" + "'", str3.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image3 = projectInfo2.getLogo();
        java.awt.Image image4 = projectInfo2.getLogo();
        java.util.List list5 = projectInfo2.getContributors();
        projectInfo0.setContributors(list5);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertNotNull(image3);
        org.junit.Assert.assertNotNull(image4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot0.setOutlinePaint(paint3);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockContainer5.getMargin();
        java.lang.String str7 = rectangleInsets6.toString();
        double double8 = rectangleInsets6.getRight();
        multiplePiePlot0.setInsets(rectangleInsets6, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str7.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        try {
            java.awt.image.BufferedImage bufferedImage11 = jFreeChart3.createBufferedImage((int) (byte) -1, (-12566273));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (-12566273) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot3.getLabelDistributor();
        double double9 = piePlot3.getLabelLinkMargin();
        double double10 = piePlot3.getMaximumExplodePercent();
        int int11 = piePlot3.getPieIndex();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        java.awt.Paint paint6 = piePlot1.getBaseSectionOutlinePaint();
        double double8 = piePlot1.getExplodePercent((java.lang.Comparable) (-1));
        piePlot1.setPieIndex((int) '4');
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(pieURLGenerator11);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateTopInset((double) 10L);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo3.getLibraries();
        boolean boolean9 = rectangleInsets0.equals((java.lang.Object) basicProjectInfo3);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockContainer10.getMargin();
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets11.getUnitType();
        boolean boolean13 = basicProjectInfo3.equals((java.lang.Object) rectangleInsets11);
        double double15 = rectangleInsets11.trimHeight(0.0d);
        double double16 = rectangleInsets11.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = org.jfree.chart.util.Rotation.CLOCKWISE;
        double double3 = rotation2.getFactor();
        piePlot1.setDirection(rotation2);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot3.getLabelDistributor();
        double double9 = piePlot3.getLabelLinkMargin();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            piePlot3.draw(graphics2D10, rectangle2D11, point2D12, plotState13, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = legendTitle3.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle3.getItemLabelPadding();
        boolean boolean7 = rectangleAnchor1.equals((java.lang.Object) legendTitle3);
        boolean boolean9 = rectangleAnchor1.equals((java.lang.Object) ' ');
        try {
            java.awt.geom.Point2D point2D10 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        double double7 = legendTitle2.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle2.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray12 = legendTitle10.getSources();
        legendTitle2.setSources(legendItemSourceArray12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle2.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(legendItemSourceArray12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) ' ');
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot3.getDrawingSupplier();
        try {
            piePlot3.setInteriorGap((double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(drawingSupplier8);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        java.awt.Color color11 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Color color15 = color11.brighter();
        int int16 = color11.getRGB();
        piePlot3.setLabelShadowPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke19 = piePlot3.getSectionOutlineStroke((java.lang.Comparable) (short) -1);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-16777216) + "'", int16 == (-16777216));
        org.junit.Assert.assertNull(stroke19);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        multiplePiePlot0.setLimit((double) '4');
        multiplePiePlot0.setLimit((double) (byte) 10);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        strokeMap0.clear();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        textTitle2.setURLText("ChartEntity: tooltip = ");
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font9);
        textTitle2.setFont(font9);
        legendTitle1.setItemFont(font9);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = legendTitle1.arrange(graphics2D13, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font9);
        java.awt.Paint paint12 = textTitle11.getPaint();
        piePlot1.setNoDataMessagePaint(paint12);
        java.lang.Comparable comparable14 = null;
        try {
            java.awt.Stroke stroke15 = piePlot1.getSectionOutlineStroke(comparable14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj2 = textTitle0.clone();
        java.awt.Paint paint3 = textTitle0.getBackgroundPaint();
        textTitle0.setURLText("Rotation.CLOCKWISE");
        java.lang.Object obj6 = textTitle0.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = projectInfo0.getLogo();
//        java.awt.Image image2 = projectInfo0.getLogo();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
//        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
//        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
//        basicProjectInfo3.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
//        java.lang.String str11 = projectInfo0.getLicenceText();
//        java.lang.String str12 = projectInfo0.getInfo();
//        java.lang.String str13 = projectInfo0.getLicenceName();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(image1);
//        org.junit.Assert.assertNotNull(image2);
//        org.junit.Assert.assertNotNull(libraryArray6);
//        org.junit.Assert.assertNotNull(libraryArray7);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str12.equals("http://www.jfree.org/jfreechart/index.html"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "LGPL" + "'", str13.equals("LGPL"));
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = null;
        boolean boolean2 = paintMap0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Color color0 = java.awt.Color.black;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        java.awt.Paint paint6 = piePlot1.getBaseSectionOutlinePaint();
        double double8 = piePlot1.getExplodePercent((java.lang.Comparable) (-1));
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        java.awt.Paint paint10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        piePlot1.setLabelPaint(paint10);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color1 = java.awt.Color.GRAY;
        boolean boolean2 = color0.equals((java.lang.Object) color1);
        java.awt.Color color3 = color0.brighter();
        java.awt.Color color4 = color3.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "RectangleAnchor.BOTTOM", "-4,-4,4,4");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity10 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset4, (int) '#', (int) (short) -1, (java.lang.Comparable) (byte) -1, "VerticalAlignment.CENTER", "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        multiplePiePlot0.setBackgroundImageAlpha((float) 0L);
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] { stroke14, stroke15, stroke16 };
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke18, stroke19 };
        java.awt.Shape[] shapeArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray12, paintArray13, strokeArray17, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextFillPaint();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font27 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("", font27);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font27);
        boolean boolean30 = chartChangeEventType24.equals((java.lang.Object) font27);
        boolean boolean31 = defaultDrawingSupplier22.equals((java.lang.Object) boolean30);
        java.awt.Stroke stroke32 = defaultDrawingSupplier22.getNextOutlineStroke();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        java.lang.Object obj34 = defaultDrawingSupplier22.clone();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(chartChangeEventType24);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        java.lang.String str3 = textTitle2.getText();
        double double4 = textTitle2.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle2.getPosition();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot6.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot6.getPieChart();
        jFreeChart9.setNotify(true);
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart9.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo17);
        jFreeChart9.fireChartChanged();
        java.awt.RenderingHints renderingHints20 = jFreeChart9.getRenderingHints();
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart9);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color23 = color22.darker();
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color23.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        jFreeChart9.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.event.ChartProgressListener chartProgressListener31 = null;
        jFreeChart9.addProgressListener(chartProgressListener31);
        org.jfree.chart.event.ChartProgressListener chartProgressListener33 = null;
        jFreeChart9.addProgressListener(chartProgressListener33);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertNotNull(renderingHints20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintContext29);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        jFreeChart3.setAntiAlias(true);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("HorizontalAlignment.RIGHT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockContainer10.getMargin();
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets11.getUnitType();
        double double14 = rectangleInsets11.trimHeight((double) 0.0f);
        double double15 = rectangleInsets11.getRight();
        double double17 = rectangleInsets11.calculateBottomInset(1.0E-5d);
        legendTitle8.setItemLabelPadding(rectangleInsets11);
        piePlot1.setInsets(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer1.getMargin();
        boolean boolean3 = columnArrangement0.equals((java.lang.Object) blockContainer1);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle4.getHorizontalAlignment();
        java.lang.Object obj6 = textTitle4.clone();
        java.awt.Paint paint7 = textTitle4.getBackgroundPaint();
        textTitle4.setURLText("Rotation.CLOCKWISE");
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getHorizontalAlignment();
        java.lang.Object obj12 = textTitle10.clone();
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle4, (java.lang.Object) textTitle10);
        textTitle10.setHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        try {
            defaultCategoryDataset0.removeColumn((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot7.getDataset();
        java.awt.Stroke stroke11 = piePlot7.getLabelLinkStroke();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        org.jfree.data.general.DatasetGroup datasetGroup13 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot14.setOutlineStroke(stroke15);
        java.awt.Color color17 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color17, jFreeChart18, chartChangeEventType19);
        java.awt.Color color21 = color17.brighter();
        int int22 = color17.getRGB();
        multiplePiePlot14.setNoDataMessagePaint((java.awt.Paint) color17);
        multiplePiePlot14.setBackgroundImageAlpha((float) 0L);
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray31 = new java.awt.Stroke[] { stroke28, stroke29, stroke30 };
        java.awt.Stroke stroke32 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke32, stroke33 };
        java.awt.Shape[] shapeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray26, paintArray27, strokeArray31, strokeArray34, shapeArray35);
        java.awt.Paint paint37 = defaultDrawingSupplier36.getNextFillPaint();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font41 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("", font41);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font41);
        boolean boolean44 = chartChangeEventType38.equals((java.lang.Object) font41);
        boolean boolean45 = defaultDrawingSupplier36.equals((java.lang.Object) boolean44);
        java.awt.Stroke stroke46 = defaultDrawingSupplier36.getNextOutlineStroke();
        multiplePiePlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier36);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot14);
        try {
            defaultCategoryDataset0.removeRow(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(datasetGroup13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16777216) + "'", int22 == (-16777216));
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(shapeArray35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image8 = projectInfo7.getLogo();
        java.util.List list9 = projectInfo7.getContributors();
        try {
            jFreeChart3.setSubtitles(list9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.ui.Contributor cannot be cast to org.jfree.chart.title.Title");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(image8);
        org.junit.Assert.assertNotNull(list9);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = projectInfo0.getLogo();
//        java.awt.Image image2 = projectInfo0.getLogo();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
//        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
//        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
//        basicProjectInfo3.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
//        java.lang.String str11 = projectInfo0.getLicenceText();
//        java.lang.String str12 = projectInfo0.getInfo();
//        projectInfo0.setLicenceText("UnitType.ABSOLUTE");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(image1);
//        org.junit.Assert.assertNotNull(image2);
//        org.junit.Assert.assertNotNull(libraryArray6);
//        org.junit.Assert.assertNotNull(libraryArray7);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str12.equals("http://www.jfree.org/jfreechart/index.html"));
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int8 = pieSectionEntity7.getPieIndex();
        java.lang.Comparable comparable9 = pieSectionEntity7.getSectionKey();
        int int10 = pieSectionEntity7.getSectionIndex();
        int int11 = pieSectionEntity7.getPieIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100L + "'", comparable9.equals(100L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        java.awt.Paint paint6 = piePlot1.getBaseSectionOutlinePaint();
        double double8 = piePlot1.getExplodePercent((java.lang.Comparable) (-1));
        org.jfree.chart.util.Rotation rotation9 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str10 = rotation9.toString();
        double double11 = rotation9.getFactor();
        java.lang.String str12 = rotation9.toString();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot13.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot13.getPieChart();
        boolean boolean17 = rotation9.equals((java.lang.Object) multiplePiePlot13);
        piePlot1.setDirection(rotation9);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rotation9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Rotation.CLOCKWISE" + "'", str10.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Rotation.CLOCKWISE" + "'", str12.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray3 = basicProjectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray4 = basicProjectInfo0.getLibraries();
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo0.getLibraries();
        java.lang.String str6 = basicProjectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNotNull(libraryArray4);
        org.junit.Assert.assertNotNull(libraryArray5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        java.awt.Paint paint11 = null;
        try {
            piePlot3.setBaseSectionOutlinePaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.lang.String str2 = rectangleInsets1.toString();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint4 = defaultDrawingSupplier3.getNextFillPaint();
        boolean boolean5 = rectangleInsets1.equals((java.lang.Object) paint4);
        double double7 = rectangleInsets1.calculateTopInset(0.4d);
        double double9 = rectangleInsets1.calculateBottomOutset((double) (short) 10);
        double double11 = rectangleInsets1.calculateLeftOutset((double) 100);
        double double13 = rectangleInsets1.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str2.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("http://www.jfree.org/jfreechart/index.html", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape3, "");
        java.lang.String str6 = chartEntity5.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image8 = projectInfo7.getLogo();
        java.awt.Image image9 = projectInfo7.getLogo();
        boolean boolean10 = chartEntity5.equals((java.lang.Object) image9);
        java.lang.Object obj11 = chartEntity5.clone();
        boolean boolean12 = color2.equals((java.lang.Object) chartEntity5);
        boolean boolean13 = objectList0.equals((java.lang.Object) chartEntity5);
        objectList0.clear();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-4,-4,4,4" + "'", str6.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(image8);
        org.junit.Assert.assertNotNull(image9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.Plot plot10 = multiplePiePlot0.getParent();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape14, "");
        java.lang.String str17 = chartEntity16.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo18 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image19 = projectInfo18.getLogo();
        java.awt.Image image20 = projectInfo18.getLogo();
        boolean boolean21 = chartEntity16.equals((java.lang.Object) image20);
        org.jfree.chart.ui.ProjectInfo projectInfo25 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "UnitType.ABSOLUTE", image20, "java.awt.Color[r=0,g=128,b=0]", "HorizontalAlignment.RIGHT", "ChartEntity: tooltip = ");
        multiplePiePlot0.setBackgroundImage(image20);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.awt.Paint paint28 = legendTitle27.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = legendTitle27.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-4,-4,4,4" + "'", str17.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo18);
        org.junit.Assert.assertNotNull(image19);
        org.junit.Assert.assertNotNull(image20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("RectangleEdge.LEFT");
        java.lang.Object[][] objArray4 = jFreeChartResources0.getContents();
        try {
            java.lang.String[] strArray6 = jFreeChartResources0.getStringArray("-4,-4,4,4");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key -4,-4,4,4");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color3.getComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(colorSpace2, floatArray19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot22.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = multiplePiePlot22.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets25);
        double double28 = rectangleInsets25.extendWidth(8.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 24.0d + "'", double28 == 24.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        java.lang.String str3 = textTitle2.getText();
        double double4 = textTitle2.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle2.getPosition();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot6.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot6.getPieChart();
        jFreeChart9.setNotify(true);
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart9.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo17);
        jFreeChart9.fireChartChanged();
        java.awt.RenderingHints renderingHints20 = jFreeChart9.getRenderingHints();
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart9);
        boolean boolean22 = textTitle2.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertNotNull(renderingHints20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = multiplePiePlot0.getInsets();
        org.jfree.data.general.Dataset dataset4 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets3, dataset4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets3.createInsetRectangle(rectangle2D6, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo11);
        try {
            org.jfree.chart.title.Title title14 = jFreeChart3.getSubtitle(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(bufferedImage12);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot3.getDrawingSupplier();
        java.awt.Paint paint9 = piePlot3.getLabelOutlinePaint();
        java.awt.Color color10 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Color color14 = color10.brighter();
        java.awt.Color color15 = java.awt.Color.green;
        float[] floatArray21 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray22 = color15.getRGBColorComponents(floatArray21);
        float[] floatArray23 = color10.getRGBColorComponents(floatArray22);
        piePlot3.setBaseSectionOutlinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        java.lang.String str2 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        java.awt.Image image2 = projectInfo0.getLogo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
        basicProjectInfo3.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        java.lang.String str11 = projectInfo0.getLicenceText();
        java.lang.String str12 = projectInfo0.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(image2);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnitType.ABSOLUTE" + "'", str11.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str12.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        boolean boolean3 = multiplePiePlot0.isSubplot();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            multiplePiePlot0.drawBackground(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Paint[] paintArray0 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke2, stroke3, stroke4 };
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke6, stroke7 };
        java.awt.Shape[] shapeArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray5, strokeArray8, shapeArray9);
        java.awt.Paint paint11 = defaultDrawingSupplier10.getNextFillPaint();
        java.lang.Object obj12 = defaultDrawingSupplier10.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(shapeArray9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image3 = projectInfo2.getLogo();
        java.awt.Image image4 = projectInfo2.getLogo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo5.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo5.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray9 = basicProjectInfo5.getLibraries();
        basicProjectInfo5.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        projectInfo2.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo5);
        java.lang.String str13 = projectInfo2.getLicenceText();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot14.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart17 = multiplePiePlot14.getPieChart();
        jFreeChart17.setNotify(true);
        java.awt.Stroke stroke20 = jFreeChart17.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart17.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo25);
        jFreeChart17.fireChartChanged();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image29 = multiplePiePlot28.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        piePlot31.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset34 = piePlot31.getDataset();
        multiplePiePlot28.setParent((org.jfree.chart.plot.Plot) piePlot31);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor36 = piePlot31.getLabelDistributor();
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color37);
        java.awt.Color color39 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart40 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType41 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color39, jFreeChart40, chartChangeEventType41);
        java.awt.Color color43 = color39.brighter();
        java.awt.Color color44 = java.awt.Color.green;
        float[] floatArray50 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray51 = color44.getRGBColorComponents(floatArray50);
        float[] floatArray52 = color39.getRGBColorComponents(floatArray51);
        float[] floatArray53 = color37.getComponents(floatArray51);
        piePlot31.setLabelLinkPaint((java.awt.Paint) color37);
        jFreeChart17.setBackgroundPaint((java.awt.Paint) color37);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent56 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) projectInfo2, jFreeChart17);
        boolean boolean57 = pieLabelLinkStyle0.equals((java.lang.Object) jFreeChart17);
        org.jfree.chart.block.BlockContainer blockContainer58 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = blockContainer58.getMargin();
        org.jfree.chart.util.UnitType unitType60 = rectangleInsets59.getUnitType();
        java.lang.String str61 = rectangleInsets59.toString();
        boolean boolean62 = pieLabelLinkStyle0.equals((java.lang.Object) rectangleInsets59);
        double double64 = rectangleInsets59.calculateBottomInset((double) (-1));
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str1.equals("PieLabelLinkStyle.QUAD_CURVE"));
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertNotNull(image3);
        org.junit.Assert.assertNotNull(image4);
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertNotNull(libraryArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UnitType.ABSOLUTE" + "'", str13.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(jFreeChart17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(bufferedImage26);
        org.junit.Assert.assertNull(image29);
        org.junit.Assert.assertNull(pieDataset34);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(unitType60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str61.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        multiplePiePlot0.setBackgroundImageAlpha((float) 0L);
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] { stroke14, stroke15, stroke16 };
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke18, stroke19 };
        java.awt.Shape[] shapeArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray12, paintArray13, strokeArray17, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextFillPaint();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font27 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("", font27);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font27);
        boolean boolean30 = chartChangeEventType24.equals((java.lang.Object) font27);
        boolean boolean31 = defaultDrawingSupplier22.equals((java.lang.Object) boolean30);
        java.awt.Stroke stroke32 = defaultDrawingSupplier22.getNextOutlineStroke();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.data.category.CategoryDataset categoryDataset34 = multiplePiePlot0.getDataset();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(chartChangeEventType24);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(categoryDataset34);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleAnchor8, dataset9);
        piePlot3.datasetChanged(datasetChangeEvent10);
        boolean boolean12 = piePlot3.getLabelLinksVisible();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font9);
        java.awt.Paint paint12 = textTitle11.getPaint();
        piePlot1.setNoDataMessagePaint(paint12);
        boolean boolean14 = piePlot1.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.util.Rotation rotation9 = piePlot3.getDirection();
        piePlot3.setIgnoreZeroValues(false);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rotation9);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        java.lang.Object obj8 = textTitle6.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle6);
        jFreeChart3.titleChanged(titleChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        try {
            jFreeChart3.draw(graphics2D11, rectangle2D12, chartRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        java.lang.Object obj8 = textTitle6.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle6);
        jFreeChart3.titleChanged(titleChangeEvent9);
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font12);
        java.lang.String str14 = textTitle13.getText();
        jFreeChart3.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart3.getLegend((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart3.getLegend(8);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        try {
            java.awt.image.BufferedImage bufferedImage25 = jFreeChart3.createBufferedImage(0, 10, (double) (-16777216), (double) 10, chartRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (10) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str14.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNull(legendTitle17);
        org.junit.Assert.assertNull(legendTitle19);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str5 = chartChangeEventType4.toString();
        chartChangeEvent1.setType(chartChangeEventType4);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) chartChangeEventType4);
        java.lang.Object obj8 = chartChangeEvent7.getSource();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("PieLabelLinkStyle.QUAD_CURVE");
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) 100, (double) 0.0f, (double) 1.0f, 10.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        java.lang.Object obj8 = textTitle6.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle6);
        jFreeChart3.titleChanged(titleChangeEvent9);
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font12);
        java.lang.String str14 = textTitle13.getText();
        jFreeChart3.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart3.getLegend((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart3.getLegend(8);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getHorizontalAlignment();
        java.lang.Object obj22 = textTitle20.clone();
        jFreeChart3.setTitle(textTitle20);
        java.lang.Class<?> wildcardClass24 = textTitle20.getClass();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str14.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNull(legendTitle17);
        org.junit.Assert.assertNull(legendTitle19);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.awt.Paint paint8 = null;
        try {
            piePlot1.setBaseSectionPaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        java.lang.String str3 = textTitle2.getText();
        double double4 = textTitle2.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle2.getMargin();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color3.getComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(colorSpace2, floatArray19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot22.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = multiplePiePlot22.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets25);
        java.lang.String str27 = rectangleInsets25.toString();
        double double29 = rectangleInsets25.trimHeight((double) (-12566273));
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str27.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-1.2566281E7d) + "'", double29 == (-1.2566281E7d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        java.util.List list4 = defaultCategoryDataset0.getRowKeys();
        int int5 = defaultCategoryDataset0.getRowCount();
        java.lang.Comparable comparable7 = null;
        try {
            java.lang.Number number8 = defaultCategoryDataset0.getValue((java.lang.Comparable) "Other", comparable7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1, chartChangeEventType2);
        java.awt.Color color4 = color0.brighter();
        java.awt.Color color5 = color0.brighter();
        int int6 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        int int5 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100L);
        java.lang.Object obj6 = defaultCategoryDataset0.clone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer3.getMargin();
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        double double7 = rectangleInsets4.trimHeight((double) 0.0f);
        double double8 = rectangleInsets4.getRight();
        double double10 = rectangleInsets4.calculateBottomInset(1.0E-5d);
        legendTitle1.setItemLabelPadding(rectangleInsets4);
        java.awt.Font font12 = legendTitle1.getItemFont();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) '4', (double) (short) 1, (double) (byte) 10);
        double double6 = rectangleInsets4.calculateBottomInset((double) '#');
        double double8 = rectangleInsets4.trimWidth((double) 8);
        java.awt.Paint paint9 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-54.0d) + "'", double8 == (-54.0d));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.LEFT" + "'", str1.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        textTitle2.setNotify(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle2.setPaint((java.awt.Paint) color5);
        java.awt.Color color7 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color7);
        java.awt.Color color9 = java.awt.Color.GREEN;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color14, jFreeChart15, chartChangeEventType16);
        java.awt.Color color18 = color14.brighter();
        java.awt.Color color19 = java.awt.Color.green;
        float[] floatArray25 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray26 = color19.getRGBColorComponents(floatArray25);
        float[] floatArray27 = color14.getRGBColorComponents(floatArray26);
        float[] floatArray28 = color12.getComponents(floatArray26);
        float[] floatArray29 = color9.getColorComponents(colorSpace11, floatArray28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace32 = color31.getColorSpace();
        java.awt.color.ColorSpace colorSpace33 = color31.getColorSpace();
        java.awt.Color color37 = java.awt.Color.green;
        float[] floatArray43 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray44 = color37.getRGBColorComponents(floatArray43);
        float[] floatArray45 = java.awt.Color.RGBtoHSB((-16777216), (int) (byte) 100, (int) (short) 100, floatArray44);
        float[] floatArray46 = color30.getColorComponents(colorSpace33, floatArray45);
        float[] floatArray47 = color7.getComponents(colorSpace11, floatArray45);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        float[] floatArray54 = new float[] { '#', (-1), (byte) 100, (byte) 100, (byte) 1 };
        float[] floatArray55 = color48.getRGBComponents(floatArray54);
        float[] floatArray56 = color5.getColorComponents(colorSpace11, floatArray55);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(colorSpace32);
        org.junit.Assert.assertNotNull(colorSpace33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets1.getUnitType();
        double double4 = rectangleInsets1.trimHeight((double) 0.0f);
        double double5 = rectangleInsets1.getRight();
        java.awt.Paint paint6 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets1.getUnitType();
        double double4 = rectangleInsets1.trimHeight((double) 0.0f);
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity12 = new org.jfree.chart.entity.PieSectionEntity(shape5, pieDataset6, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int13 = pieSectionEntity12.getPieIndex();
        java.lang.Comparable comparable14 = pieSectionEntity12.getSectionKey();
        boolean boolean15 = rectangleInsets1.equals((java.lang.Object) comparable14);
        double double17 = rectangleInsets1.extendWidth((double) 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100L + "'", comparable14.equals(100L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5d + "'", double17 == 0.5d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray11 = legendTitle9.getSources();
        legendTitle2.setSources(legendItemSourceArray11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = legendTitle2.getVerticalAlignment();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(legendItemSourceArray11);
        org.junit.Assert.assertNotNull(verticalAlignment13);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        boolean boolean3 = multiplePiePlot0.isSubplot();
        java.lang.String str4 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Multiple Pie Plot" + "'", str4.equals("Multiple Pie Plot"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image11 = multiplePiePlot10.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset16 = piePlot13.getDataset();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) piePlot13);
        java.awt.Shape shape18 = piePlot13.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = jFreeChart19.getPadding();
        java.lang.Object obj21 = jFreeChart19.getTextAntiAlias();
        java.util.List list22 = jFreeChart19.getSubtitles();
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        piePlot1.setSectionOutlinesVisible(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNull(pieDataset16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        double double4 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 35.0d + "'", double4 == 35.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.awt.Color color7 = java.awt.Color.red;
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) 100, (double) (short) 0, 1.0d, (double) (short) 100, (java.awt.Paint) color7);
        boolean boolean9 = chartEntity2.equals((java.lang.Object) blockBorder8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            blockBorder8.draw(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("Rotation.CLOCKWISE");
        try {
            java.lang.String str4 = jFreeChartResources0.getString("HorizontalAlignment.RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key HorizontalAlignment.RIGHT");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block1 = null;
        columnArrangement0.add(block1, (java.lang.Object) 0L);
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font6);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font6);
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("", font11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font11);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset18 = piePlot15.getDataset();
        java.awt.Font font19 = piePlot15.getLabelFont();
        piePlot15.setMinimumArcAngleToDraw(0.0d);
        boolean boolean22 = textTitle13.equals((java.lang.Object) 0.0d);
        java.awt.Font font23 = textTitle13.getFont();
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle8, (java.lang.Object) textTitle13);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(pieDataset18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        double double4 = blockContainer0.getWidth();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 0, (double) (byte) 1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement10);
        java.lang.Object obj12 = blockContainer0.clone();
        double double13 = blockContainer0.getHeight();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image17 = multiplePiePlot16.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        piePlot19.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset22 = piePlot19.getDataset();
        multiplePiePlot16.setParent((org.jfree.chart.plot.Plot) piePlot19);
        java.awt.Shape shape24 = piePlot19.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot19);
        java.awt.Paint paint26 = piePlot19.getBackgroundPaint();
        piePlot19.setSimpleLabels(true);
        try {
            java.lang.Object obj29 = blockContainer0.draw(graphics2D14, rectangle2D15, (java.lang.Object) true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNull(pieDataset22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleAnchor.LEFT", "HorizontalAlignment.RIGHT");
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font7);
        java.lang.String str9 = textTitle8.getText();
        double double10 = textTitle8.getHeight();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle8);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        textTitle8.draw(graphics2D12, rectangle2D13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = null;
        try {
            org.jfree.chart.util.Size2D size2D17 = textTitle8.arrange(graphics2D15, rectangleConstraint16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape1, "");
        java.lang.String str4 = chartEntity3.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image6 = projectInfo5.getLogo();
        java.awt.Image image7 = projectInfo5.getLogo();
        boolean boolean8 = chartEntity3.equals((java.lang.Object) image7);
        java.lang.Object obj9 = chartEntity3.clone();
        boolean boolean10 = color0.equals((java.lang.Object) chartEntity3);
        java.awt.Shape shape11 = null;
        try {
            chartEntity3.setArea(shape11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-4,-4,4,4" + "'", str4.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertNotNull(image6);
        org.junit.Assert.assertNotNull(image7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        double double4 = blockContainer0.getWidth();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 0, (double) (byte) 1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color13 = color12.darker();
        boolean boolean14 = flowArrangement10.equals((java.lang.Object) color13);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockContainer15.getMargin();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean18 = blockContainer15.equals((java.lang.Object) color17);
        double double19 = blockContainer15.getWidth();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = null;
        try {
            org.jfree.chart.util.Size2D size2D22 = flowArrangement10.arrange(blockContainer15, graphics2D20, rectangleConstraint21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("java.awt.Color[r=255,g=0,b=255]");
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        multiplePiePlot0.setLimit(4.0d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        java.lang.String str3 = textTitle2.getText();
        double double4 = textTitle2.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle2.getPosition();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot6.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot6.getPieChart();
        jFreeChart9.setNotify(true);
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart9.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo17);
        jFreeChart9.fireChartChanged();
        java.awt.RenderingHints renderingHints20 = jFreeChart9.getRenderingHints();
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart9);
        java.awt.Stroke stroke22 = jFreeChart9.getBorderStroke();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertNotNull(renderingHints20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font2);
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.lang.String str6 = textTitle4.getToolTipText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color3.getComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(colorSpace2, floatArray19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot22.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = multiplePiePlot22.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets25);
        java.awt.Stroke stroke27 = lineBorder26.getStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        jFreeChart3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart3.getTitle();
        jFreeChart3.setBackgroundImageAlpha(1.0f);
        jFreeChart3.setNotify(false);
        jFreeChart3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle21);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray23 = legendTitle21.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle21.getItemLabelPadding();
        boolean boolean25 = rectangleAnchor19.equals((java.lang.Object) legendTitle21);
        double double26 = legendTitle21.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = legendTitle21.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent30 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle29);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray31 = legendTitle29.getSources();
        legendTitle21.setSources(legendItemSourceArray31);
        try {
            jFreeChart3.addSubtitle((int) (byte) 100, (org.jfree.chart.title.Title) legendTitle21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(legendItemSourceArray23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(legendItemSourceArray31);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        jFreeChart3.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray14 = legendTitle12.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle12.getItemLabelPadding();
        boolean boolean16 = rectangleAnchor10.equals((java.lang.Object) legendTitle12);
        double double17 = legendTitle12.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = legendTitle12.getLegendItemGraphicEdge();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color19);
        java.awt.Color color21 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color21, jFreeChart22, chartChangeEventType23);
        java.awt.Color color25 = color21.brighter();
        java.awt.Color color26 = java.awt.Color.green;
        float[] floatArray32 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray33 = color26.getRGBColorComponents(floatArray32);
        float[] floatArray34 = color21.getRGBColorComponents(floatArray33);
        float[] floatArray35 = color19.getComponents(floatArray33);
        boolean boolean36 = legendTitle12.equals((java.lang.Object) floatArray35);
        try {
            jFreeChart3.addSubtitle(1, (org.jfree.chart.title.Title) legendTitle12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(legendItemSourceArray14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list6 = defaultKeyedValues2D1.getRowKeys();
        int int8 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) (byte) 1);
        try {
            defaultKeyedValues2D1.removeColumn((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = multiplePiePlot0.getInsets();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle6);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray8 = legendTitle6.getSources();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray11 = legendTitle10.getSources();
        legendTitle6.setSources(legendItemSourceArray11);
        java.awt.Font font13 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        legendTitle6.setItemFont(font13);
        java.awt.geom.Rectangle2D rectangle2D15 = legendTitle6.getBounds();
        try {
            multiplePiePlot0.drawBackground(graphics2D4, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(legendItemSourceArray8);
        org.junit.Assert.assertNotNull(legendItemSourceArray11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color13);
        java.awt.Color color15 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color15, jFreeChart16, chartChangeEventType17);
        java.awt.Color color19 = color15.brighter();
        java.awt.Color color20 = java.awt.Color.green;
        float[] floatArray26 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray27 = color20.getRGBColorComponents(floatArray26);
        float[] floatArray28 = color15.getRGBColorComponents(floatArray27);
        float[] floatArray29 = color13.getComponents(floatArray27);
        float[] floatArray30 = color10.getColorComponents(colorSpace12, floatArray29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color32 = color31.darker();
        float[] floatArray41 = new float[] { ' ', (byte) 0, 10L, (short) -1, 10.0f };
        float[] floatArray42 = java.awt.Color.RGBtoHSB((int) '#', 1, (-1), floatArray41);
        float[] floatArray43 = color31.getRGBColorComponents(floatArray41);
        float[] floatArray44 = color3.getComponents(colorSpace12, floatArray43);
        java.awt.Color color45 = color3.brighter();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinkMargin(0.08d);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        piePlot5.setLabelLinksVisible(false);
        piePlot5.setLabelLinksVisible(true);
        boolean boolean10 = piePlot5.getSectionOutlinesVisible();
        piePlot5.setCircular(false, false);
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot5);
        piePlot1.zoom(92.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        textTitle0.setURLText("ChartEntity: tooltip = ");
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle0.getVerticalAlignment();
        org.junit.Assert.assertNotNull(verticalAlignment6);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = jFreeChart9.getPadding();
        java.lang.Object obj11 = jFreeChart9.getTextAntiAlias();
        jFreeChart9.setBackgroundImageAlpha((float) 128);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        try {
            java.awt.image.BufferedImage bufferedImage17 = jFreeChart9.createBufferedImage((int) (byte) -1, 1, chartRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        double double4 = blockContainer0.getWidth();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 0, (double) (byte) 1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color13 = color12.darker();
        boolean boolean14 = flowArrangement10.equals((java.lang.Object) color13);
        flowArrangement10.clear();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj2 = textTitle0.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        double double4 = textTitle0.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle0.getPosition();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = projectInfo0.getLogo();
//        java.awt.Image image2 = projectInfo0.getLogo();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
//        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
//        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
//        basicProjectInfo3.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
//        java.lang.String str11 = projectInfo0.getLicenceText();
//        java.lang.String str12 = projectInfo0.getInfo();
//        java.util.List list13 = projectInfo0.getContributors();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(image1);
//        org.junit.Assert.assertNotNull(image2);
//        org.junit.Assert.assertNotNull(libraryArray6);
//        org.junit.Assert.assertNotNull(libraryArray7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnitType.ABSOLUTE" + "'", str11.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str12.equals("http://www.jfree.org/jfreechart/index.html"));
//        org.junit.Assert.assertNotNull(list13);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Color color1 = java.awt.Color.getColor("PieLabelLinkStyle.CUBIC_CURVE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = java.awt.Color.GRAY;
        boolean boolean12 = color10.equals((java.lang.Object) color11);
        piePlot3.setLabelShadowPaint((java.awt.Paint) color11);
        java.lang.Object obj14 = piePlot3.clone();
        java.awt.Stroke stroke15 = piePlot3.getLabelOutlineStroke();
        java.awt.Paint paint17 = piePlot3.getSectionOutlinePaint((java.lang.Comparable) 0.0d);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setCircular(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color11 = color10.darker();
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color10);
        java.awt.Font font13 = piePlot1.getLabelFont();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        piePlot1.setNoDataMessageFont(font14);
        piePlot1.setSimpleLabels(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray3 = basicProjectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray4 = basicProjectInfo0.getLibraries();
        basicProjectInfo0.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library library11 = new org.jfree.chart.ui.Library("ChartEntity: tooltip = ", "RectangleAnchor.BOTTOM", "rect", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        basicProjectInfo0.addOptionalLibrary(library11);
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNotNull(libraryArray4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        strokeMap0.put((java.lang.Comparable) 1.0E-5d, stroke3);
        org.jfree.chart.PaintMap paintMap6 = new org.jfree.chart.PaintMap();
        java.awt.Font font8 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font8);
        textTitle9.setNotify(true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle9.setPaint((java.awt.Paint) color12);
        boolean boolean14 = paintMap6.equals((java.lang.Object) color12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot15.setOutlineStroke(stroke16);
        boolean boolean18 = paintMap6.equals((java.lang.Object) stroke16);
        strokeMap0.put((java.lang.Comparable) (-1.0d), stroke16);
        java.lang.Object obj20 = strokeMap0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        int int5 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100L);
        org.jfree.data.general.DatasetGroup datasetGroup6 = defaultCategoryDataset0.getGroup();
        java.lang.Object obj7 = datasetGroup6.clone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(datasetGroup6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (-1.0f));
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) 0.4d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        java.awt.Image image2 = projectInfo0.getLogo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
        basicProjectInfo3.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        java.util.List list11 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(image2);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        java.lang.String str3 = textTitle2.getText();
        double double4 = textTitle2.getHeight();
        textTitle2.setURLText("RectangleEdge.LEFT");
        textTitle2.setToolTipText("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textTitle9.getHorizontalAlignment();
        java.lang.Object obj11 = textTitle9.clone();
        java.awt.Paint paint12 = textTitle9.getBackgroundPaint();
        textTitle9.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        textTitle9.setURLText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle9.getHorizontalAlignment();
        textTitle2.setTextAlignment(horizontalAlignment17);
        textTitle2.setExpandToFitSpace(true);
        boolean boolean21 = textTitle2.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer3.getMargin();
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        double double7 = rectangleInsets4.trimHeight((double) 0.0f);
        double double8 = rectangleInsets4.getRight();
        double double10 = rectangleInsets4.calculateBottomInset(1.0E-5d);
        legendTitle1.setItemLabelPadding(rectangleInsets4);
        java.lang.Object obj12 = legendTitle1.clone();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = legendTitle1.arrange(graphics2D13, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateTopInset((double) 10L);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo3.getLibraries();
        boolean boolean9 = rectangleInsets0.equals((java.lang.Object) basicProjectInfo3);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockContainer10.getMargin();
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets11.getUnitType();
        boolean boolean13 = basicProjectInfo3.equals((java.lang.Object) rectangleInsets11);
        double double15 = rectangleInsets11.trimHeight(0.0d);
        double double17 = rectangleInsets11.calculateRightOutset((double) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot1.setOutlinePaint(paint4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        java.awt.Image image7 = multiplePiePlot1.getBackgroundImage();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray12 = legendTitle10.getSources();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray15 = legendTitle14.getSources();
        legendTitle10.setSources(legendItemSourceArray15);
        java.awt.Font font17 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        legendTitle10.setItemFont(font17);
        java.awt.geom.Rectangle2D rectangle2D19 = legendTitle10.getBounds();
        java.awt.geom.Point2D point2D20 = null;
        org.jfree.chart.plot.PlotState plotState21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            multiplePiePlot1.draw(graphics2D8, rectangle2D19, point2D20, plotState21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(legendItemSourceArray12);
        org.junit.Assert.assertNotNull(legendItemSourceArray15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 8, (int) 'a', (java.lang.Comparable) 15, "", "ChartEntity: tooltip = ");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("RectangleEdge.LEFT");
        java.lang.Object[][] objArray4 = jFreeChartResources0.getContents();
        try {
            java.lang.Object obj6 = jFreeChartResources0.getObject("PieLabelLinkStyle.CUBIC_CURVE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key PieLabelLinkStyle.CUBIC_CURVE");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot9.setOutlinePaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot9);
        legendTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        boolean boolean16 = jFreeChart14.isBorderVisible();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.Point2D point2D19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        try {
            jFreeChart14.draw(graphics2D17, rectangle2D18, point2D19, chartRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-12566273), (int) (byte) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("java.awt.Color[r=0,g=128,b=0]", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray3 = legendTitle1.getSources();
        java.awt.Paint paint4 = legendTitle1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(legendItemSourceArray3);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        jFreeChart7.setNotify(true);
        java.awt.Stroke stroke10 = jFreeChart7.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart7.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo15);
        float float17 = jFreeChart7.getBackgroundImageAlpha();
        chartChangeEvent1.setChart(jFreeChart7);
        java.awt.Paint paint19 = jFreeChart7.getBackgroundPaint();
        java.lang.Object obj20 = jFreeChart7.clone();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.lang.String str1 = tableOrder0.toString();
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TableOrder.BY_COLUMN" + "'", str1.equals("TableOrder.BY_COLUMN"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.util.Rotation rotation9 = piePlot3.getDirection();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = null;
        try {
            piePlot3.setLabelPadding(rectangleInsets10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rotation9);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int8 = pieSectionEntity7.getPieIndex();
        org.jfree.data.general.PieDataset pieDataset9 = pieSectionEntity7.getDataset();
        java.awt.Shape shape10 = pieSectionEntity7.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape10);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) 4.0d);
        java.awt.Stroke stroke4 = strokeMap0.getStroke((java.lang.Comparable) 128);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font9);
        java.awt.Paint paint12 = textTitle11.getPaint();
        piePlot1.setNoDataMessagePaint(paint12);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = piePlot1.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(drawingSupplier14);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) 4.0d);
        java.lang.Object obj3 = strokeMap0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        double double3 = rectangleInsets1.calculateRightOutset(0.0d);
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets1.getUnitType();
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        int int10 = color5.getTransparency();
        boolean boolean11 = unitType4.equals((java.lang.Object) color5);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color3.getComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(colorSpace2, floatArray19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot22.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = multiplePiePlot22.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets25);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D28 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean29 = lineBorder26.equals((java.lang.Object) defaultKeyedValues2D28);
        java.awt.Stroke stroke30 = lineBorder26.getStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.ui.Contributor contributor3 = new org.jfree.chart.ui.Contributor("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        int int4 = objectList0.indexOf((java.lang.Object) "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        objectList0.clear();
        java.lang.Object obj6 = objectList0.clone();
        int int7 = objectList0.size();
        int int8 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        piePlot1.setCircular(true);
        float float12 = piePlot1.getForegroundAlpha();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot0.setOutlinePaint(paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        multiplePiePlot0.setInsets(rectangleInsets5, false);
        java.awt.Paint paint8 = multiplePiePlot0.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        int int5 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100L);
        java.util.List list6 = defaultCategoryDataset0.getColumnKeys();
        try {
            defaultCategoryDataset0.removeColumn(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = multiplePiePlot0.getInsets();
        double double5 = rectangleInsets3.trimHeight((double) 100.0f);
        double double7 = rectangleInsets3.calculateLeftInset((double) (short) -1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 92.0d + "'", double5 == 92.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleEdge.TOP", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        piePlot3.setSimpleLabels(true);
        piePlot3.setOutlineVisible(false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        piePlot3.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat19 = standardPieSectionLabelGenerator18.getNumberFormat();
        java.text.NumberFormat numberFormat20 = standardPieSectionLabelGenerator18.getNumberFormat();
        piePlot3.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator18);
        java.lang.Object obj22 = standardPieSectionLabelGenerator18.clone();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(numberFormat19);
        org.junit.Assert.assertNotNull(numberFormat20);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.Plot plot10 = multiplePiePlot0.getParent();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape14, "");
        java.lang.String str17 = chartEntity16.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo18 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image19 = projectInfo18.getLogo();
        java.awt.Image image20 = projectInfo18.getLogo();
        boolean boolean21 = chartEntity16.equals((java.lang.Object) image20);
        org.jfree.chart.ui.ProjectInfo projectInfo25 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "UnitType.ABSOLUTE", image20, "java.awt.Color[r=0,g=128,b=0]", "HorizontalAlignment.RIGHT", "ChartEntity: tooltip = ");
        multiplePiePlot0.setBackgroundImage(image20);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.awt.Paint paint28 = legendTitle27.getBackgroundPaint();
        org.jfree.chart.block.BlockContainer blockContainer29 = legendTitle27.getItemContainer();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-4,-4,4,4" + "'", str17.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo18);
        org.junit.Assert.assertNotNull(image19);
        org.junit.Assert.assertNotNull(image20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(blockContainer29);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo11);
        jFreeChart3.fireChartChanged();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image15 = multiplePiePlot14.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset20 = piePlot17.getDataset();
        multiplePiePlot14.setParent((org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor22 = piePlot17.getLabelDistributor();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color23);
        java.awt.Color color25 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
        java.awt.Color color29 = color25.brighter();
        java.awt.Color color30 = java.awt.Color.green;
        float[] floatArray36 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
        float[] floatArray38 = color25.getRGBColorComponents(floatArray37);
        float[] floatArray39 = color23.getComponents(floatArray37);
        piePlot17.setLabelLinkPaint((java.awt.Paint) color23);
        jFreeChart3.setBackgroundPaint((java.awt.Paint) color23);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent45 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle44);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray46 = legendTitle44.getSources();
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray49 = legendTitle48.getSources();
        legendTitle44.setSources(legendItemSourceArray49);
        java.awt.Font font51 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        legendTitle44.setItemFont(font51);
        java.awt.geom.Rectangle2D rectangle2D53 = legendTitle44.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo54 = null;
        try {
            jFreeChart3.draw(graphics2D42, rectangle2D53, chartRenderingInfo54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNull(pieDataset20);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(legendItemSourceArray46);
        org.junit.Assert.assertNotNull(legendItemSourceArray49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(rectangle2D53);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.lang.Object obj5 = defaultKeyedValues2D1.clone();
        try {
            java.lang.Number number8 = defaultKeyedValues2D1.getValue((java.lang.Comparable) true, (java.lang.Comparable) true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: true");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.block.BlockContainer blockContainer8 = legendTitle2.getItemContainer();
        legendTitle2.setNotify(false);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray11 = null;
        try {
            legendTitle2.setSources(legendItemSourceArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'sources' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(blockContainer8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.awt.Paint[] paintArray0 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke2, stroke3, stroke4 };
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke6, stroke7 };
        java.awt.Shape[] shapeArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray5, strokeArray8, shapeArray9);
        java.awt.Paint paint11 = defaultDrawingSupplier10.getNextFillPaint();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font15 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("", font15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font15);
        boolean boolean18 = chartChangeEventType12.equals((java.lang.Object) font15);
        boolean boolean19 = defaultDrawingSupplier10.equals((java.lang.Object) boolean18);
        java.awt.Stroke stroke20 = defaultDrawingSupplier10.getNextStroke();
        java.lang.Object obj21 = null;
        boolean boolean22 = defaultDrawingSupplier10.equals(obj21);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(shapeArray9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.plot.Plot plot7 = null;
        piePlot1.setParent(plot7);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        java.awt.Color color12 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Color color16 = color12.brighter();
        int int17 = color12.getRGB();
        multiplePiePlot9.setNoDataMessagePaint((java.awt.Paint) color12);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color12);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent23 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle22);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray24 = legendTitle22.getSources();
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray27 = legendTitle26.getSources();
        legendTitle22.setSources(legendItemSourceArray27);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        legendTitle22.setItemFont(font29);
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle22.getBounds();
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.plot.PlotState plotState33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        try {
            piePlot1.draw(graphics2D20, rectangle2D31, point2D32, plotState33, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-16777216) + "'", int17 == (-16777216));
        org.junit.Assert.assertNotNull(legendItemSourceArray24);
        org.junit.Assert.assertNotNull(legendItemSourceArray27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        int int5 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100L);
        defaultCategoryDataset0.validateObject();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        float float8 = multiplePiePlot7.getForegroundAlpha();
        boolean boolean9 = defaultCategoryDataset0.hasListener((java.util.EventListener) multiplePiePlot7);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.block.BlockContainer blockContainer8 = legendTitle2.getItemContainer();
        legendTitle2.setNotify(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        try {
            org.jfree.chart.util.Size2D size2D13 = legendTitle2.arrange(graphics2D11, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(blockContainer8);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Number number4 = defaultKeyedValues2D1.getValue(8, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("VerticalAlignment.CENTER", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        textTitle1.setPosition(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        int int5 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100L);
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.validateObject();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 1, (float) 128, (float) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-32384) + "'", int3 == (-32384));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int8 = pieSectionEntity7.getPieIndex();
        java.lang.Comparable comparable9 = pieSectionEntity7.getSectionKey();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        pieSectionEntity7.setDataset(pieDataset10);
        int int12 = pieSectionEntity7.getPieIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100L + "'", comparable9.equals(100L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray10 = legendTitle8.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle8.getItemLabelPadding();
        boolean boolean12 = rectangleAnchor6.equals((java.lang.Object) legendTitle8);
        double double13 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle8.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle16);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray18 = legendTitle16.getSources();
        legendTitle8.setSources(legendItemSourceArray18);
        jFreeChart3.addLegend(legendTitle8);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockContainer21.getMargin();
        java.lang.String str23 = rectangleInsets22.toString();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextFillPaint();
        boolean boolean26 = rectangleInsets22.equals((java.lang.Object) paint25);
        double double28 = rectangleInsets22.calculateTopInset(0.4d);
        legendTitle8.setItemLabelPadding(rectangleInsets22);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(legendItemSourceArray10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(legendItemSourceArray18);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str23.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        boolean boolean3 = multiplePiePlot0.isSubplot();
        org.jfree.chart.util.TableOrder tableOrder4 = org.jfree.chart.util.TableOrder.BY_ROW;
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString7 = null;
        standardPieSectionLabelGenerator5.setAttributedLabel(0, attributedString7);
        java.text.AttributedString attributedString10 = standardPieSectionLabelGenerator5.getAttributedLabel((int) (short) 1);
        boolean boolean11 = tableOrder4.equals((java.lang.Object) (short) 1);
        multiplePiePlot0.setDataExtractOrder(tableOrder4);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.Font font16 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font16);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font16);
        java.awt.Paint paint19 = textTitle18.getPaint();
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle18.getBounds();
        try {
            multiplePiePlot0.drawOutline(graphics2D13, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(tableOrder4);
        org.junit.Assert.assertNull(attributedString10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image4 = multiplePiePlot3.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset9 = piePlot6.getDataset();
        multiplePiePlot3.setParent((org.jfree.chart.plot.Plot) piePlot6);
        java.awt.Shape shape11 = piePlot6.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        java.awt.Color color13 = java.awt.Color.green;
        java.awt.Color color14 = java.awt.Color.GRAY;
        boolean boolean15 = color13.equals((java.lang.Object) color14);
        piePlot6.setLabelShadowPaint((java.awt.Paint) color14);
        java.lang.Object obj17 = piePlot6.clone();
        boolean boolean18 = defaultKeyedValues2D1.equals((java.lang.Object) piePlot6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = piePlot6.getURLGenerator();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(pieURLGenerator19);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        java.lang.String str3 = textTitle2.getText();
        double double4 = textTitle2.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle2.getPosition();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot6.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot6.getPieChart();
        jFreeChart9.setNotify(true);
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart9.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo17);
        jFreeChart9.fireChartChanged();
        java.awt.RenderingHints renderingHints20 = jFreeChart9.getRenderingHints();
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart9);
        textTitle2.setURLText("-4,-4,4,4");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertNotNull(renderingHints20);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        chartChangeEvent3.setType(chartChangeEventType4);
        java.lang.String str6 = chartChangeEvent3.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("", font10);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font10);
        boolean boolean13 = chartChangeEventType7.equals((java.lang.Object) font10);
        chartChangeEvent3.setType(chartChangeEventType7);
        org.jfree.chart.ui.ProjectInfo projectInfo15 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image16 = projectInfo15.getLogo();
        java.awt.Image image17 = projectInfo15.getLogo();
        java.util.List list18 = projectInfo15.getContributors();
        boolean boolean19 = chartChangeEventType7.equals((java.lang.Object) projectInfo15);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]" + "'", str6.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]"));
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(projectInfo15);
        org.junit.Assert.assertNotNull(image16);
        org.junit.Assert.assertNotNull(image17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }
}

