import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getLabelPadding();
        boolean boolean5 = piePlot1.getIgnoreZeroValues();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot1.addChangeListener(plotChangeListener6);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        piePlot10.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset13 = piePlot10.getDataset();
        java.awt.Font font14 = piePlot10.getLabelFont();
        piePlot10.setMinimumArcAngleToDraw(0.0d);
        double double17 = piePlot10.getLabelGap();
        java.lang.String str18 = piePlot10.getNoDataMessage();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        piePlot10.drawBackgroundImage(graphics2D19, rectangle2D20);
        boolean boolean22 = piePlot10.getIgnoreNullValues();
        piePlot10.setPieIndex(8);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        piePlot26.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset29 = piePlot26.getDataset();
        java.awt.Font font30 = piePlot26.getLabelFont();
        piePlot26.setMinimumArcAngleToDraw(0.0d);
        java.awt.Stroke stroke33 = piePlot26.getOutlineStroke();
        piePlot10.setBaseSectionOutlineStroke(stroke33);
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 15, stroke33);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(pieDataset13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.025d + "'", double17 == 0.025d);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(pieDataset29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getColumnCount();
        try {
            java.lang.Number number6 = defaultKeyedValues2D1.getValue((java.lang.Comparable) (-12566273), (java.lang.Comparable) "ChartChangeEventType.GENERAL");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: ChartChangeEventType.GENERAL");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.lang.Object obj5 = piePlot1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot1.getLabelPadding();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator7);
        piePlot1.setPieIndex((int) (short) 10);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape1, "");
        java.lang.String str4 = chartEntity3.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image6 = projectInfo5.getLogo();
        java.awt.Image image7 = projectInfo5.getLogo();
        boolean boolean8 = chartEntity3.equals((java.lang.Object) image7);
        java.lang.Object obj9 = chartEntity3.clone();
        boolean boolean10 = color0.equals((java.lang.Object) chartEntity3);
        java.lang.String str11 = chartEntity3.getShapeCoords();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-4,-4,4,4" + "'", str4.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertNotNull(image6);
        org.junit.Assert.assertNotNull(image7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-4,-4,4,4" + "'", str11.equals("-4,-4,4,4"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot3.getLabelDistributor();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Color color15 = color11.brighter();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = color11.getRGBColorComponents(floatArray23);
        float[] floatArray25 = color9.getComponents(floatArray23);
        piePlot3.setLabelLinkPaint((java.awt.Paint) color9);
        int int27 = color9.getRed();
        int int28 = color9.getRGB();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 192 + "'", int27 == 192);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-4145152) + "'", int28 == (-4145152));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot1.getLegendLabelURLGenerator();
        java.awt.Paint paint9 = piePlot1.getBaseSectionPaint();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "");
        boolean boolean6 = standardPieSectionLabelGenerator0.equals((java.lang.Object) "");
        org.jfree.data.general.PieDataset pieDataset7 = null;
        java.lang.String str9 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset7, (java.lang.Comparable) "PieLabelLinkStyle.QUAD_CURVE");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.chart.plot.Plot plot9 = piePlot1.getRootPlot();
        boolean boolean10 = piePlot1.getIgnoreZeroValues();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        try {
            org.jfree.chart.plot.XYPlot xYPlot7 = jFreeChart3.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.sort();
        pieLabelDistributor1.distributeLabels((-1.6777216E7d), (double) (byte) 100);
        pieLabelDistributor1.distributeLabels((double) (short) 100, 0.08d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list6 = defaultKeyedValues2D1.getRowKeys();
        try {
            java.lang.Number number9 = defaultKeyedValues2D1.getValue((int) '4', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        piePlot1.setCircular(true);
        java.awt.Color color12 = java.awt.Color.BLACK;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color12);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        piePlot1.setCircular(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot1.getLabelGenerator();
        try {
            piePlot1.setInteriorGap((double) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (15.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot9.setOutlinePaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot9);
        legendTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        org.jfree.chart.plot.Plot plot16 = jFreeChart14.getPlot();
        try {
            org.jfree.chart.plot.XYPlot xYPlot17 = jFreeChart14.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartEntity: tooltip = ", "HorizontalAlignment.RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        double double4 = blockContainer0.getWidth();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 0, (double) (byte) 1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement10);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockContainer12.getMargin();
        double double15 = rectangleInsets13.calculateRightOutset(0.0d);
        double double17 = rectangleInsets13.calculateBottomInset((double) (byte) 0);
        blockContainer0.setMargin(rectangleInsets13);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener20 = null;
        textTitle19.addChangeListener(titleChangeListener20);
        java.awt.Font font24 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font24);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font24);
        java.awt.Paint paint27 = textTitle26.getPaint();
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        textTitle19.setBounds(rectangle2D28);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets13.createAdjustedRectangle(rectangle2D28, lengthAdjustmentType30, lengthAdjustmentType31);
        java.awt.Font font34 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font34);
        java.lang.String str36 = textTitle35.getText();
        double double37 = textTitle35.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = textTitle35.getPosition();
        double double39 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D32, rectangleEdge38);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str36.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ChartChangeEventType.GENERAL", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("java.awt.Color[r=255,g=0,b=255]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key java.awt.Color[r=255,g=0,b=255]");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        try {
            java.lang.Comparable comparable5 = defaultKeyedValues2D0.getRowKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = legendTitle2.getLegendItemGraphicEdge();
        try {
            double double4 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        multiplePiePlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        multiplePiePlot0.setDataset(categoryDataset12);
        java.lang.Comparable comparable14 = multiplePiePlot0.getAggregatedItemsKey();
        java.lang.Comparable comparable15 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot16.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart19 = multiplePiePlot16.getPieChart();
        jFreeChart19.setNotify(true);
        java.awt.Stroke stroke22 = jFreeChart19.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        java.awt.image.BufferedImage bufferedImage28 = jFreeChart19.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo27);
        float float29 = jFreeChart19.getBackgroundImageAlpha();
        multiplePiePlot0.setPieChart(jFreeChart19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        try {
            java.awt.image.BufferedImage bufferedImage36 = jFreeChart19.createBufferedImage((int) (short) 10, 0, 8.0d, (double) 0, chartRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (10) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "Other" + "'", comparable14.equals("Other"));
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + "Other" + "'", comparable15.equals("Other"));
        org.junit.Assert.assertNotNull(jFreeChart19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(bufferedImage28);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("UnitType.ABSOLUTE");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getPercentFormat();
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray2 = legendTitle1.getSources();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color3);
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke7, stroke8, stroke9 };
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] { stroke11, stroke12 };
        java.awt.Shape[] shapeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray5, paintArray6, strokeArray10, strokeArray13, shapeArray14);
        boolean boolean16 = legendTitle1.equals((java.lang.Object) shapeArray14);
        org.junit.Assert.assertNotNull(legendItemSourceArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int8 = pieSectionEntity7.getPieIndex();
        org.jfree.data.general.PieDataset pieDataset9 = pieSectionEntity7.getDataset();
        java.lang.Object obj10 = pieSectionEntity7.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        java.awt.Paint paint10 = piePlot6.getLabelOutlinePaint();
        piePlot6.setShadowYOffset(0.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot3.getLabelDistributor();
        piePlot3.setMaximumLabelWidth(4.0d);
        piePlot3.setLabelGap((double) (-16777216));
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.util.Rotation rotation9 = piePlot3.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rotation9);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = jFreeChart9.getPadding();
        java.lang.Object obj11 = jFreeChart9.getTextAntiAlias();
        org.jfree.chart.title.TextTitle textTitle12 = jFreeChart9.getTitle();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(textTitle12);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = multiplePiePlot0.getInsets();
        org.jfree.data.general.Dataset dataset4 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets3, dataset4);
        org.jfree.data.general.Dataset dataset6 = datasetChangeEvent5.getDataset();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(dataset6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        java.lang.Comparable comparable5 = null;
        try {
            defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) 0.5d, comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray10 = legendTitle8.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle8.getItemLabelPadding();
        boolean boolean12 = rectangleAnchor6.equals((java.lang.Object) legendTitle8);
        double double13 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle8.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle16);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray18 = legendTitle16.getSources();
        legendTitle8.setSources(legendItemSourceArray18);
        jFreeChart3.addLegend(legendTitle8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle8.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(legendItemSourceArray10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(legendItemSourceArray18);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        double double4 = blockContainer0.getWidth();
        blockContainer0.clear();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color3.getComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(colorSpace2, floatArray19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot22.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = multiplePiePlot22.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets25);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D28 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean29 = lineBorder26.equals((java.lang.Object) defaultKeyedValues2D28);
        java.lang.Object obj30 = null;
        boolean boolean31 = lineBorder26.equals(obj30);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.String str3 = unknownKeyException1.toString();
        org.jfree.data.UnknownKeyException unknownKeyException5 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str6 = unknownKeyException5.toString();
        java.lang.String str7 = unknownKeyException5.toString();
        org.jfree.data.UnknownKeyException unknownKeyException9 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        unknownKeyException5.addSuppressed((java.lang.Throwable) unknownKeyException9);
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException5);
        java.lang.Throwable[] throwableArray12 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str2.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str6.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str7.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("Multiple Pie Plot", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        float[] floatArray9 = new float[] { '#', (-1), (byte) 100, (byte) 100, (byte) 1 };
        float[] floatArray10 = color3.getRGBComponents(floatArray9);
        float[] floatArray11 = java.awt.Color.RGBtoHSB(10, (int) '#', 0, floatArray10);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, 3, (-12566273));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj1 = datasetGroup0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle2.getHorizontalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        java.awt.Paint paint5 = textTitle2.getBackgroundPaint();
        textTitle2.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        boolean boolean8 = datasetGroup1.equals((java.lang.Object) textTitle2);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        textTitle9.draw(graphics2D10, rectangle2D11);
        boolean boolean13 = datasetGroup1.equals((java.lang.Object) rectangle2D11);
        java.lang.String str14 = datasetGroup1.getID();
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        java.util.List list2 = projectInfo0.getContributors();
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image4 = projectInfo3.getLogo();
        java.util.List list5 = projectInfo3.getContributors();
        java.awt.Image image6 = projectInfo3.getLogo();
        projectInfo0.setLogo(image6);
        projectInfo0.addOptionalLibrary("UnitType.ABSOLUTE");
        java.lang.String str10 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(image4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(image6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "LGPL" + "'", str10.equals("LGPL"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot7.getDataset();
        java.awt.Stroke stroke11 = piePlot7.getLabelLinkStroke();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        org.jfree.data.general.DatasetGroup datasetGroup13 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot14.setOutlineStroke(stroke15);
        java.awt.Color color17 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color17, jFreeChart18, chartChangeEventType19);
        java.awt.Color color21 = color17.brighter();
        int int22 = color17.getRGB();
        multiplePiePlot14.setNoDataMessagePaint((java.awt.Paint) color17);
        multiplePiePlot14.setBackgroundImageAlpha((float) 0L);
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray31 = new java.awt.Stroke[] { stroke28, stroke29, stroke30 };
        java.awt.Stroke stroke32 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke32, stroke33 };
        java.awt.Shape[] shapeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray26, paintArray27, strokeArray31, strokeArray34, shapeArray35);
        java.awt.Paint paint37 = defaultDrawingSupplier36.getNextFillPaint();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font41 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("", font41);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font41);
        boolean boolean44 = chartChangeEventType38.equals((java.lang.Object) font41);
        boolean boolean45 = defaultDrawingSupplier36.equals((java.lang.Object) boolean44);
        java.awt.Stroke stroke46 = defaultDrawingSupplier36.getNextOutlineStroke();
        multiplePiePlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier36);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot14);
        java.awt.Paint paint49 = multiplePiePlot14.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(datasetGroup13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16777216) + "'", int22 == (-16777216));
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(shapeArray35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        strokeMap0.put((java.lang.Comparable) 1.0E-5d, stroke3);
        org.jfree.chart.PaintMap paintMap6 = new org.jfree.chart.PaintMap();
        java.awt.Font font8 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font8);
        textTitle9.setNotify(true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle9.setPaint((java.awt.Paint) color12);
        boolean boolean14 = paintMap6.equals((java.lang.Object) color12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot15.setOutlineStroke(stroke16);
        boolean boolean18 = paintMap6.equals((java.lang.Object) stroke16);
        strokeMap0.put((java.lang.Comparable) (-1.0d), stroke16);
        try {
            java.awt.Stroke stroke21 = strokeMap0.getStroke((java.lang.Comparable) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to java.lang.Integer");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setCircular(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color11 = color10.darker();
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment13);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        chartChangeEvent14.setType(chartChangeEventType15);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot17.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot17.getPieChart();
        jFreeChart20.setNotify(true);
        java.awt.Stroke stroke23 = jFreeChart20.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        java.awt.image.BufferedImage bufferedImage29 = jFreeChart20.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo28);
        float float30 = jFreeChart20.getBackgroundImageAlpha();
        chartChangeEvent14.setChart(jFreeChart20);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        java.lang.Object obj33 = jFreeChart20.getTextAntiAlias();
        org.jfree.chart.event.ChartProgressListener chartProgressListener34 = null;
        jFreeChart20.removeProgressListener(chartProgressListener34);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(bufferedImage29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNull(obj33);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = standardPieSectionLabelGenerator0.getAttributedLabel((-1));
        java.lang.Object obj3 = standardPieSectionLabelGenerator0.clone();
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator0.getNumberFormat();
        org.junit.Assert.assertNull(attributedString2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo11);
        jFreeChart3.fireChartChanged();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image15 = multiplePiePlot14.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset20 = piePlot17.getDataset();
        multiplePiePlot14.setParent((org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor22 = piePlot17.getLabelDistributor();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color23);
        java.awt.Color color25 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
        java.awt.Color color29 = color25.brighter();
        java.awt.Color color30 = java.awt.Color.green;
        float[] floatArray36 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
        float[] floatArray38 = color25.getRGBColorComponents(floatArray37);
        float[] floatArray39 = color23.getComponents(floatArray37);
        piePlot17.setLabelLinkPaint((java.awt.Paint) color23);
        jFreeChart3.setBackgroundPaint((java.awt.Paint) color23);
        jFreeChart3.setBackgroundImageAlignment(0);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.ChartColor chartColor48 = new org.jfree.chart.ChartColor((int) (short) 10, 8, 0);
        org.jfree.chart.block.BlockBorder blockBorder49 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) chartColor48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = blockBorder49.getInsets();
        org.jfree.chart.LegendItemSource legendItemSource51 = null;
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle(legendItemSource51);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent53 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle52);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray54 = legendTitle52.getSources();
        org.jfree.chart.LegendItemSource legendItemSource55 = null;
        org.jfree.chart.title.LegendTitle legendTitle56 = new org.jfree.chart.title.LegendTitle(legendItemSource55);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray57 = legendTitle56.getSources();
        legendTitle52.setSources(legendItemSourceArray57);
        java.awt.Font font59 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        legendTitle52.setItemFont(font59);
        java.awt.geom.Rectangle2D rectangle2D61 = legendTitle52.getBounds();
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets50.createOutsetRectangle(rectangle2D61, false, true);
        try {
            jFreeChart3.draw(graphics2D44, rectangle2D64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNull(pieDataset20);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(legendItemSourceArray54);
        org.junit.Assert.assertNotNull(legendItemSourceArray57);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangle2D64);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color2 = java.awt.Color.cyan;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color2);
        java.awt.Color color7 = java.awt.Color.getHSBColor((float) (byte) -1, (float) 1L, (float) (byte) 100);
        legendTitle1.setItemPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getInfo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str1.equals("http://www.jfree.org/jfreechart/index.html"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list6 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list7 = defaultKeyedValues2D1.getRowKeys();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        piePlot9.setLabelLinksVisible(false);
        java.awt.Stroke stroke13 = piePlot9.getSectionOutlineStroke((java.lang.Comparable) 'a');
        boolean boolean14 = defaultKeyedValues2D1.equals((java.lang.Object) stroke13);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        try {
            java.lang.Comparable comparable6 = defaultKeyedValues2D1.getRowKey((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        piePlot1.drawBackgroundImage(graphics2D10, rectangle2D11);
        piePlot1.setSimpleLabels(false);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = jFreeChart9.getPadding();
        java.lang.Object obj11 = jFreeChart9.getTextAntiAlias();
        java.awt.Font font13 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font13);
        java.lang.String str15 = textTitle14.getText();
        double double16 = textTitle14.getWidth();
        jFreeChart9.setTitle(textTitle14);
        textTitle14.setMargin(0.0d, (double) (short) -1, (double) (-4145152), 24.0d);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str15.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = java.awt.Color.GRAY;
        boolean boolean12 = color10.equals((java.lang.Object) color11);
        piePlot3.setLabelShadowPaint((java.awt.Paint) color11);
        java.lang.Object obj14 = piePlot3.clone();
        java.awt.Stroke stroke15 = piePlot3.getLabelOutlineStroke();
        boolean boolean16 = piePlot3.getSectionOutlinesVisible();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = projectInfo0.getLogo();
//        java.awt.Image image2 = projectInfo0.getLogo();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
//        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
//        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
//        basicProjectInfo3.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
//        java.lang.String str11 = projectInfo0.getLicenceText();
//        java.lang.String str12 = projectInfo0.getName();
//        java.lang.String str13 = projectInfo0.getLicenceText();
//        org.jfree.chart.ui.ProjectInfo projectInfo14 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image15 = projectInfo14.getLogo();
//        java.util.List list16 = projectInfo14.getContributors();
//        projectInfo0.setContributors(list16);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(image1);
//        org.junit.Assert.assertNotNull(image2);
//        org.junit.Assert.assertNotNull(libraryArray6);
//        org.junit.Assert.assertNotNull(libraryArray7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnitType.ABSOLUTE" + "'", str11.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str12.equals("http://www.jfree.org/jfreechart/index.html"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UnitType.ABSOLUTE" + "'", str13.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertNotNull(projectInfo14);
//        org.junit.Assert.assertNotNull(image15);
//        org.junit.Assert.assertNotNull(list16);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!");
        java.awt.Shape shape3 = chartEntity2.getArea();
        java.lang.String str4 = chartEntity2.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-4,-4,4,4" + "'", str4.equals("-4,-4,4,4"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        int int5 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.clear();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setStartAngle((double) 10);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot1.getLabelDistributor();
        piePlot1.setLabelGap(0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '#', (double) (-1L), 0.5d, (double) 0L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        double double3 = rectangleInsets1.calculateRightOutset(0.0d);
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets1.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (short) -1, 10.0d, 0.0d, (double) (-1L));
        double double11 = rectangleInsets9.trimWidth((double) 1L);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-8.0d) + "'", double11 == (-8.0d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-32384));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot0.setOutlinePaint(paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        multiplePiePlot0.setInsets(rectangleInsets5, false);
        double double9 = rectangleInsets5.extendWidth((double) (-16777216));
        double double11 = rectangleInsets5.extendWidth(35.0d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.6777216E7d) + "'", double9 == (-1.6777216E7d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 35.0d + "'", double11 == 35.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("RectangleEdge.LEFT");
        java.lang.Object[][] objArray4 = jFreeChartResources0.getContents();
        try {
            java.lang.String[] strArray6 = jFreeChartResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.addValue((java.lang.Number) (-1.2566281E7d), (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        try {
            java.lang.Number number9 = defaultKeyedValues2D1.getValue((int) (byte) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        java.lang.Object obj8 = textTitle6.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle6);
        jFreeChart3.titleChanged(titleChangeEvent9);
        java.awt.Stroke stroke11 = jFreeChart3.getBorderStroke();
        boolean boolean12 = jFreeChart3.isBorderVisible();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        double double2 = rotation0.getFactor();
        java.lang.String str3 = rotation0.toString();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        boolean boolean8 = rotation0.equals((java.lang.Object) multiplePiePlot4);
        java.lang.String str9 = multiplePiePlot4.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = multiplePiePlot4.getLegendItems();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Rotation.CLOCKWISE" + "'", str3.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Multiple Pie Plot" + "'", str9.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Rotation.CLOCKWISE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        java.awt.Color color11 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Color color15 = color11.brighter();
        int int16 = color11.getRGB();
        piePlot3.setLabelShadowPaint((java.awt.Paint) color11);
        piePlot3.setLabelLinkMargin(0.4d);
        piePlot3.setPieIndex((int) (short) 0);
        org.jfree.chart.util.Rotation rotation22 = piePlot3.getDirection();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-16777216) + "'", int16 == (-16777216));
        org.junit.Assert.assertNotNull(rotation22);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("RectangleEdge.LEFT");
        boolean boolean5 = jFreeChartResources0.containsKey("");
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, 2, (int) (byte) 0);
        java.awt.Color color4 = chartColor3.brighter();
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = null;
        float[] floatArray20 = color5.getRGBColorComponents(floatArray19);
        float[] floatArray21 = chartColor3.getColorComponents(floatArray19);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.lang.Object obj5 = defaultKeyedValues2D1.clone();
        java.util.List list6 = defaultKeyedValues2D1.getColumnKeys();
        int int7 = defaultKeyedValues2D1.getRowCount();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape1, "");
        java.lang.String str4 = chartEntity3.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image6 = projectInfo5.getLogo();
        java.awt.Image image7 = projectInfo5.getLogo();
        boolean boolean8 = chartEntity3.equals((java.lang.Object) image7);
        java.lang.Object obj9 = chartEntity3.clone();
        boolean boolean10 = color0.equals((java.lang.Object) chartEntity3);
        java.lang.Object obj11 = null;
        boolean boolean12 = chartEntity3.equals(obj11);
        java.lang.String str13 = chartEntity3.getURLText();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-4,-4,4,4" + "'", str4.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertNotNull(image6);
        org.junit.Assert.assertNotNull(image7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library6 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "");
        boolean boolean7 = standardPieSectionLabelGenerator1.equals((java.lang.Object) "");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        java.lang.String str10 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset8, (java.lang.Comparable) 0.0f);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle11 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        boolean boolean12 = standardPieSectionLabelGenerator1.equals((java.lang.Object) pieLabelLinkStyle11);
        java.text.NumberFormat numberFormat13 = standardPieSectionLabelGenerator1.getPercentFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("UnitType.ABSOLUTE");
        java.lang.String str16 = standardPieSectionLabelGenerator15.getLabelFormat();
        java.text.NumberFormat numberFormat17 = standardPieSectionLabelGenerator15.getNumberFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("rect", numberFormat13, numberFormat17);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(numberFormat13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnitType.ABSOLUTE" + "'", str16.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(numberFormat17);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot1.setOutlinePaint(paint4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        java.awt.Image image7 = multiplePiePlot1.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(jFreeChart8);
        org.junit.Assert.assertNotNull(textTitle9);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getLabelPadding();
        boolean boolean5 = piePlot1.getIgnoreZeroValues();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot1.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = piePlot1.getLabelOutlinePaint();
        piePlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.awt.Stroke stroke8 = piePlot1.getOutlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        java.awt.Paint paint10 = piePlot1.getBaseSectionOutlinePaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator11);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot3.getLabelDistributor();
        boolean boolean9 = piePlot3.getSimpleLabels();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setLabelLinkMargin((double) (short) 100);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        java.awt.color.ColorSpace colorSpace12 = color10.getColorSpace();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = java.awt.Color.RGBtoHSB((-16777216), (int) (byte) 100, (int) (short) 100, floatArray23);
        float[] floatArray25 = color9.getColorComponents(colorSpace12, floatArray24);
        piePlot1.setShadowPaint((java.awt.Paint) color9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str28 = horizontalAlignment27.toString();
        java.lang.Object obj29 = null;
        boolean boolean30 = horizontalAlignment27.equals(obj29);
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment27, verticalAlignment31, (-54.0d), 100.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement35 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = blockContainer36.getMargin();
        boolean boolean38 = columnArrangement35.equals((java.lang.Object) blockContainer36);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = textTitle39.getHorizontalAlignment();
        java.lang.Object obj41 = textTitle39.clone();
        java.awt.Paint paint42 = textTitle39.getBackgroundPaint();
        textTitle39.setURLText("Rotation.CLOCKWISE");
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = textTitle45.getHorizontalAlignment();
        java.lang.Object obj47 = textTitle45.clone();
        columnArrangement35.add((org.jfree.chart.block.Block) textTitle39, (java.lang.Object) textTitle45);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement35);
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement34, (org.jfree.chart.block.Arrangement) columnArrangement35);
        org.jfree.chart.block.BlockContainer blockContainer51 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = blockContainer51.getMargin();
        java.awt.Color color53 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean54 = blockContainer51.equals((java.lang.Object) color53);
        double double55 = blockContainer51.getWidth();
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment57 = textTitle56.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement61 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment57, verticalAlignment58, (double) (short) 0, (double) (byte) 1);
        blockContainer51.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement61);
        java.lang.Object obj63 = blockContainer51.clone();
        double double64 = blockContainer51.getHeight();
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint66 = null;
        try {
            org.jfree.chart.util.Size2D size2D67 = flowArrangement34.arrange(blockContainer51, graphics2D65, rectangleConstraint66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str28.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment57);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        textTitle2.setHeight(0.0d);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        double double2 = rotation0.getFactor();
        java.lang.String str3 = rotation0.toString();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        boolean boolean8 = rotation0.equals((java.lang.Object) multiplePiePlot4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = multiplePiePlot4.getDrawingSupplier();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Rotation.CLOCKWISE" + "'", str3.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(drawingSupplier9);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer1.getMargin();
        boolean boolean3 = columnArrangement0.equals((java.lang.Object) blockContainer1);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle4.getHorizontalAlignment();
        java.lang.Object obj6 = textTitle4.clone();
        java.awt.Paint paint7 = textTitle4.getBackgroundPaint();
        textTitle4.setURLText("Rotation.CLOCKWISE");
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getHorizontalAlignment();
        java.lang.Object obj12 = textTitle10.clone();
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle4, (java.lang.Object) textTitle10);
        textTitle10.setToolTipText("PieLabelLinkStyle.CUBIC_CURVE");
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.plot.Plot plot7 = null;
        piePlot1.setParent(plot7);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        java.awt.Color color12 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Color color16 = color12.brighter();
        int int17 = color12.getRGB();
        multiplePiePlot9.setNoDataMessagePaint((java.awt.Paint) color12);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color12);
        java.awt.Paint paint20 = piePlot1.getLabelBackgroundPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator22 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("UnitType.ABSOLUTE");
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator22);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-16777216) + "'", int17 == (-16777216));
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.text.AttributedString attributedString3 = null;
        try {
            standardPieSectionLabelGenerator0.setAttributedLabel((-1), attributedString3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        textTitle0.setToolTipText("ChartEntity: tooltip = ");
        textTitle0.setWidth((double) 1);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset5 = piePlot2.getDataset();
        java.awt.Font font6 = piePlot2.getLabelFont();
        piePlot2.setMinimumArcAngleToDraw(0.0d);
        java.awt.Stroke stroke9 = piePlot2.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setLabelLinksVisible(false);
        piePlot11.setLabelLinksVisible(true);
        boolean boolean16 = piePlot11.getSectionOutlinesVisible();
        piePlot11.setCircular(false, false);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color21 = color20.darker();
        piePlot11.setLabelOutlinePaint((java.awt.Paint) color20);
        java.awt.Font font23 = piePlot11.getLabelFont();
        java.awt.Font font24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        piePlot11.setNoDataMessageFont(font24);
        piePlot2.setLabelFont(font24);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER", font24);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        textTitle2.setNotify(true);
        java.lang.Object obj5 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        boolean boolean10 = piePlot1.isOutlineVisible();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.awt.Paint paint8 = piePlot1.getLabelLinkPaint();
        double double9 = piePlot1.getInteriorGap();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.08d + "'", double9 == 0.08d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        int int3 = objectList0.indexOf((java.lang.Object) "");
        objectList0.clear();
        int int5 = objectList0.size();
        java.lang.Object obj7 = objectList0.get(100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color1 = java.awt.Color.GRAY;
        boolean boolean2 = color0.equals((java.lang.Object) color1);
        java.awt.Color color3 = color0.brighter();
        java.lang.String str4 = color3.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str4.equals("java.awt.Color[r=0,g=255,b=0]"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.block.BlockContainer blockContainer8 = legendTitle2.getItemContainer();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray11 = legendTitle10.getSources();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = legendTitle10.getLegendItemGraphicEdge();
        legendTitle2.setLegendItemGraphicEdge(rectangleEdge12);
        java.lang.String str14 = legendTitle2.getID();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(blockContainer8);
        org.junit.Assert.assertNotNull(legendItemSourceArray11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (-1.0f));
        try {
            java.lang.Number number10 = defaultKeyedValues2D1.getValue(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color3.getComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(colorSpace2, floatArray19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot22.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = multiplePiePlot22.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets25);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D28 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean29 = lineBorder26.equals((java.lang.Object) defaultKeyedValues2D28);
        int int31 = defaultKeyedValues2D28.getColumnIndex((java.lang.Comparable) 0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
//        java.lang.String str1 = pieLabelLinkStyle0.toString();
//        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image3 = projectInfo2.getLogo();
//        java.awt.Image image4 = projectInfo2.getLogo();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
//        basicProjectInfo5.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo5.getOptionalLibraries();
//        org.jfree.chart.ui.Library[] libraryArray9 = basicProjectInfo5.getLibraries();
//        basicProjectInfo5.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        projectInfo2.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo5);
//        java.lang.String str13 = projectInfo2.getLicenceText();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
//        multiplePiePlot14.setLimit((double) '#');
//        org.jfree.chart.JFreeChart jFreeChart17 = multiplePiePlot14.getPieChart();
//        jFreeChart17.setNotify(true);
//        java.awt.Stroke stroke20 = jFreeChart17.getBorderStroke();
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
//        java.awt.image.BufferedImage bufferedImage26 = jFreeChart17.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo25);
//        jFreeChart17.fireChartChanged();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot();
//        java.awt.Image image29 = multiplePiePlot28.getBackgroundImage();
//        org.jfree.data.general.PieDataset pieDataset30 = null;
//        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
//        piePlot31.setLabelLinksVisible(false);
//        org.jfree.data.general.PieDataset pieDataset34 = piePlot31.getDataset();
//        multiplePiePlot28.setParent((org.jfree.chart.plot.Plot) piePlot31);
//        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor36 = piePlot31.getLabelDistributor();
//        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_YELLOW;
//        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color37);
//        java.awt.Color color39 = java.awt.Color.black;
//        org.jfree.chart.JFreeChart jFreeChart40 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType41 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color39, jFreeChart40, chartChangeEventType41);
//        java.awt.Color color43 = color39.brighter();
//        java.awt.Color color44 = java.awt.Color.green;
//        float[] floatArray50 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
//        float[] floatArray51 = color44.getRGBColorComponents(floatArray50);
//        float[] floatArray52 = color39.getRGBColorComponents(floatArray51);
//        float[] floatArray53 = color37.getComponents(floatArray51);
//        piePlot31.setLabelLinkPaint((java.awt.Paint) color37);
//        jFreeChart17.setBackgroundPaint((java.awt.Paint) color37);
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent56 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) projectInfo2, jFreeChart17);
//        boolean boolean57 = pieLabelLinkStyle0.equals((java.lang.Object) jFreeChart17);
//        java.lang.String str58 = pieLabelLinkStyle0.toString();
//        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str1.equals("PieLabelLinkStyle.QUAD_CURVE"));
//        org.junit.Assert.assertNotNull(projectInfo2);
//        org.junit.Assert.assertNotNull(image3);
//        org.junit.Assert.assertNotNull(image4);
//        org.junit.Assert.assertNotNull(libraryArray8);
//        org.junit.Assert.assertNotNull(libraryArray9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UnitType.ABSOLUTE" + "'", str13.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertNotNull(jFreeChart17);
//        org.junit.Assert.assertNotNull(stroke20);
//        org.junit.Assert.assertNotNull(bufferedImage26);
//        org.junit.Assert.assertNull(image29);
//        org.junit.Assert.assertNull(pieDataset34);
//        org.junit.Assert.assertNotNull(abstractPieLabelDistributor36);
//        org.junit.Assert.assertNotNull(color37);
//        org.junit.Assert.assertNotNull(color39);
//        org.junit.Assert.assertNotNull(color43);
//        org.junit.Assert.assertNotNull(color44);
//        org.junit.Assert.assertNotNull(floatArray50);
//        org.junit.Assert.assertNotNull(floatArray51);
//        org.junit.Assert.assertNotNull(floatArray52);
//        org.junit.Assert.assertNotNull(floatArray53);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str58.equals("PieLabelLinkStyle.QUAD_CURVE"));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot3.setOutlineStroke(stroke4);
        java.awt.Paint paint6 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot3.setOutlinePaint(paint6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot3);
        java.awt.Image image9 = multiplePiePlot3.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart10 = multiplePiePlot3.getPieChart();
        jFreeChart10.fireChartChanged();
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart10);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNotNull(jFreeChart10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, 2, (int) (byte) 0);
        java.awt.Color color4 = chartColor3.brighter();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace7 = color6.getColorSpace();
        java.awt.color.ColorSpace colorSpace8 = color6.getColorSpace();
        java.awt.Color color12 = java.awt.Color.green;
        float[] floatArray18 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray19 = color12.getRGBColorComponents(floatArray18);
        float[] floatArray20 = java.awt.Color.RGBtoHSB((-16777216), (int) (byte) 100, (int) (short) 100, floatArray19);
        float[] floatArray21 = color5.getColorComponents(colorSpace8, floatArray20);
        java.awt.Color color22 = java.awt.Color.lightGray;
        float[] floatArray27 = new float[] { '#', '#', (byte) -1, '4' };
        float[] floatArray28 = color22.getRGBComponents(floatArray27);
        float[] floatArray29 = chartColor3.getColorComponents(colorSpace8, floatArray28);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        piePlot3.setSimpleLabels(true);
        piePlot3.setOutlineVisible(false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        piePlot3.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat19 = standardPieSectionLabelGenerator18.getNumberFormat();
        java.text.NumberFormat numberFormat20 = standardPieSectionLabelGenerator18.getNumberFormat();
        piePlot3.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator18);
        java.text.NumberFormat numberFormat22 = standardPieSectionLabelGenerator18.getNumberFormat();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(numberFormat19);
        org.junit.Assert.assertNotNull(numberFormat20);
        org.junit.Assert.assertNotNull(numberFormat22);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image4 = projectInfo3.getLogo();
        java.util.List list5 = projectInfo3.getContributors();
        java.awt.Image image6 = projectInfo3.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo10 = new org.jfree.chart.ui.ProjectInfo("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "", "PieLabelLinkStyle.CUBIC_CURVE", image6, "java.awt.Color[r=0,g=255,b=0]", "RectangleAnchor.BOTTOM", "RectangleEdge.TOP");
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(image4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(image6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        double double7 = legendTitle2.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle2.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray12 = legendTitle10.getSources();
        legendTitle2.setSources(legendItemSourceArray12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle2.getItemLabelPadding();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, 8, 0);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) chartColor19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent24 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle23);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray25 = legendTitle23.getSources();
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray28 = legendTitle27.getSources();
        legendTitle23.setSources(legendItemSourceArray28);
        java.awt.Font font30 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        legendTitle23.setItemFont(font30);
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle23.getBounds();
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets21.createOutsetRectangle(rectangle2D32, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D35, "PieLabelLinkStyle.CUBIC_CURVE", "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.data.general.PieDataset pieDataset39 = null;
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot(pieDataset39);
        piePlot40.setLabelLinksVisible(false);
        piePlot40.setLabelLinksVisible(true);
        boolean boolean45 = piePlot40.getSectionOutlinesVisible();
        piePlot40.setCircular(false, false);
        java.awt.Color color49 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color50 = color49.darker();
        piePlot40.setLabelOutlinePaint((java.awt.Paint) color49);
        java.awt.Font font52 = piePlot40.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset53 = null;
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot(pieDataset53);
        piePlot54.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset57 = piePlot54.getDataset();
        java.awt.Stroke stroke58 = piePlot54.getLabelLinkStroke();
        piePlot40.setLabelOutlineStroke(stroke58);
        try {
            java.lang.Object obj60 = legendTitle2.draw(graphics2D15, rectangle2D35, (java.lang.Object) piePlot40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(legendItemSourceArray12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(legendItemSourceArray25);
        org.junit.Assert.assertNotNull(legendItemSourceArray28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNull(pieDataset57);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.PaintMap paintMap1 = new org.jfree.chart.PaintMap();
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font3);
        textTitle4.setNotify(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle4.setPaint((java.awt.Paint) color7);
        boolean boolean9 = paintMap1.equals((java.lang.Object) color7);
        java.awt.Color color10 = java.awt.Color.getColor("TableOrder.BY_ROW", color7);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        piePlot12.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset15 = piePlot12.getDataset();
        java.awt.Font font16 = piePlot12.getLabelFont();
        piePlot12.setMinimumArcAngleToDraw(0.0d);
        java.awt.Stroke stroke19 = piePlot12.getBaseSectionOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double22 = rectangleInsets20.calculateTopInset((double) 10L);
        double double23 = rectangleInsets20.getRight();
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke19, rectangleInsets20);
        double double25 = rectangleInsets20.getRight();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(pieDataset15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font3);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle5.setVerticalAlignment(verticalAlignment6);
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment6, 1.0E-5d, 1.0E-5d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(verticalAlignment6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setLabelLinkMargin((double) (short) 100);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        java.awt.color.ColorSpace colorSpace12 = color10.getColorSpace();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = java.awt.Color.RGBtoHSB((-16777216), (int) (byte) 100, (int) (short) 100, floatArray23);
        float[] floatArray25 = color9.getColorComponents(colorSpace12, floatArray24);
        piePlot1.setShadowPaint((java.awt.Paint) color9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str28 = horizontalAlignment27.toString();
        java.lang.Object obj29 = null;
        boolean boolean30 = horizontalAlignment27.equals(obj29);
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment27, verticalAlignment31, (-54.0d), 100.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement35 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = blockContainer36.getMargin();
        boolean boolean38 = columnArrangement35.equals((java.lang.Object) blockContainer36);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = textTitle39.getHorizontalAlignment();
        java.lang.Object obj41 = textTitle39.clone();
        java.awt.Paint paint42 = textTitle39.getBackgroundPaint();
        textTitle39.setURLText("Rotation.CLOCKWISE");
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = textTitle45.getHorizontalAlignment();
        java.lang.Object obj47 = textTitle45.clone();
        columnArrangement35.add((org.jfree.chart.block.Block) textTitle39, (java.lang.Object) textTitle45);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement35);
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement34, (org.jfree.chart.block.Arrangement) columnArrangement35);
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        textTitle51.draw(graphics2D52, rectangle2D53);
        textTitle51.setURLText("ChartEntity: tooltip = ");
        java.awt.Font font58 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font58);
        textTitle51.setFont(font58);
        piePlot1.setLabelFont(font58);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str28.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(font58);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 128, (float) 2, (float) 0L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        chartChangeEvent3.setChart(jFreeChart4);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        chartChangeEvent3.setType(chartChangeEventType6);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.lang.Object obj2 = blockContainer0.clone();
        double double3 = blockContainer0.getWidth();
        org.jfree.chart.block.Arrangement arrangement4 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(arrangement4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setLabelLinkMargin((double) (short) 100);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        java.awt.color.ColorSpace colorSpace12 = color10.getColorSpace();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = java.awt.Color.RGBtoHSB((-16777216), (int) (byte) 100, (int) (short) 100, floatArray23);
        float[] floatArray25 = color9.getColorComponents(colorSpace12, floatArray24);
        piePlot1.setShadowPaint((java.awt.Paint) color9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str28 = horizontalAlignment27.toString();
        java.lang.Object obj29 = null;
        boolean boolean30 = horizontalAlignment27.equals(obj29);
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment27, verticalAlignment31, (-54.0d), 100.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement35 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = blockContainer36.getMargin();
        boolean boolean38 = columnArrangement35.equals((java.lang.Object) blockContainer36);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = textTitle39.getHorizontalAlignment();
        java.lang.Object obj41 = textTitle39.clone();
        java.awt.Paint paint42 = textTitle39.getBackgroundPaint();
        textTitle39.setURLText("Rotation.CLOCKWISE");
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = textTitle45.getHorizontalAlignment();
        java.lang.Object obj47 = textTitle45.clone();
        columnArrangement35.add((org.jfree.chart.block.Block) textTitle39, (java.lang.Object) textTitle45);
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement35);
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement34, (org.jfree.chart.block.Arrangement) columnArrangement35);
        org.jfree.chart.block.BlockContainer blockContainer51 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = blockContainer51.getMargin();
        java.awt.Color color53 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean54 = blockContainer51.equals((java.lang.Object) color53);
        double double55 = blockContainer51.getWidth();
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = null;
        try {
            org.jfree.chart.util.Size2D size2D58 = flowArrangement34.arrange(blockContainer51, graphics2D56, rectangleConstraint57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str28.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        piePlot1.drawBackgroundImage(graphics2D10, rectangle2D11);
        boolean boolean13 = piePlot1.getIgnoreNullValues();
        piePlot1.setPieIndex(8);
        piePlot1.zoom((-1.0d));
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray19 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] { stroke20, stroke21, stroke22 };
        java.awt.Stroke stroke24 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray26 = new java.awt.Stroke[] { stroke24, stroke25 };
        java.awt.Shape[] shapeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray19, strokeArray23, strokeArray26, shapeArray27);
        java.awt.Paint paint29 = defaultDrawingSupplier28.getNextFillPaint();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font33 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("", font33);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font33);
        boolean boolean36 = chartChangeEventType30.equals((java.lang.Object) font33);
        boolean boolean37 = defaultDrawingSupplier28.equals((java.lang.Object) boolean36);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier28);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shapeArray27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(chartChangeEventType30);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setLabelLinksVisible(false);
        piePlot2.setLabelLinksVisible(true);
        boolean boolean7 = piePlot2.getSectionOutlinesVisible();
        piePlot2.setCircular(false, false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color12 = color11.darker();
        piePlot2.setLabelOutlinePaint((java.awt.Paint) color11);
        java.awt.Font font14 = piePlot2.getLabelFont();
        java.awt.Font font15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        piePlot2.setNoDataMessageFont(font15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        int int2 = pieLabelDistributor1.getItemCount();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        java.lang.String str3 = textTitle2.getText();
        double double4 = textTitle2.getHeight();
        textTitle2.setURLText("RectangleEdge.LEFT");
        textTitle2.setToolTipText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle2.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener1 = null;
        textTitle0.addChangeListener(titleChangeListener1);
        boolean boolean3 = textTitle0.getExpandToFitSpace();
        textTitle0.setToolTipText("java.awt.Color[r=0,g=128,b=0]");
        boolean boolean6 = textTitle0.getExpandToFitSpace();
        textTitle0.setID("java.awt.Color[r=0,g=128,b=0]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        java.lang.Object obj8 = textTitle6.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle6);
        jFreeChart3.titleChanged(titleChangeEvent9);
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font12);
        java.lang.String str14 = textTitle13.getText();
        jFreeChart3.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart3.getLegend((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart3.getLegend(8);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getHorizontalAlignment();
        java.lang.Object obj22 = textTitle20.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent23 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle20);
        java.lang.Object obj24 = textTitle20.clone();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle20);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str27 = rectangleEdge26.toString();
        textTitle20.setPosition(rectangleEdge26);
        double double29 = textTitle20.getContentYOffset();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str14.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNull(legendTitle17);
        org.junit.Assert.assertNull(legendTitle19);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleEdge.LEFT" + "'", str27.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        piePlot3.setSimpleLabels(true);
        try {
            piePlot3.setInteriorGap((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (-1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.sort();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot7.getDataset();
        java.awt.Stroke stroke11 = piePlot7.getLabelLinkStroke();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle14);
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockContainer16.getMargin();
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        double double20 = rectangleInsets17.trimHeight((double) 0.0f);
        double double21 = rectangleInsets17.getRight();
        double double23 = rectangleInsets17.calculateBottomInset(1.0E-5d);
        legendTitle14.setItemLabelPadding(rectangleInsets17);
        piePlot7.setInsets(rectangleInsets17);
        boolean boolean26 = piePlot7.isOutlineVisible();
        double double27 = piePlot7.getShadowYOffset();
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        multiplePiePlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        multiplePiePlot0.setDataset(categoryDataset12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = multiplePiePlot0.getInsets();
        org.jfree.data.category.CategoryDataset categoryDataset15 = multiplePiePlot0.getDataset();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener19 = null;
        textTitle18.addChangeListener(titleChangeListener19);
        java.awt.Font font23 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font23);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font23);
        java.awt.Paint paint26 = textTitle25.getPaint();
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle25.getBounds();
        textTitle18.setBounds(rectangle2D27);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets17.createOutsetRectangle(rectangle2D27);
        try {
            multiplePiePlot0.drawBackground(graphics2D16, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(categoryDataset15);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        jFreeChart3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart3.getTitle();
        jFreeChart3.setBackgroundImageAlpha(1.0f);
        jFreeChart3.setNotify(false);
        jFreeChart3.setBorderVisible(false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = null;
        try {
            jFreeChart3.plotChanged(plotChangeEvent18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textTitle11);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        float float3 = multiplePiePlot0.getBackgroundImageAlpha();
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image5 = projectInfo4.getLogo();
        java.awt.Image image6 = projectInfo4.getLogo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo7.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray10 = basicProjectInfo7.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray11 = basicProjectInfo7.getLibraries();
        basicProjectInfo7.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        projectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo7);
        boolean boolean15 = multiplePiePlot0.equals((java.lang.Object) basicProjectInfo7);
        basicProjectInfo7.setLicenceName("HorizontalAlignment.RIGHT");
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertNotNull(image5);
        org.junit.Assert.assertNotNull(image6);
        org.junit.Assert.assertNotNull(libraryArray10);
        org.junit.Assert.assertNotNull(libraryArray11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("-4,-4,4,4", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("java.awt.Color[r=0,g=255,b=0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name java.awt.Color[r=0,g=255,b=0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        double double7 = legendTitle2.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle2.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray12 = legendTitle10.getSources();
        legendTitle2.setSources(legendItemSourceArray12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle2.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle2.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(legendItemSourceArray12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        piePlot3.setSimpleLabels(true);
        piePlot3.setOutlineVisible(false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        piePlot3.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat19 = standardPieSectionLabelGenerator18.getNumberFormat();
        java.text.NumberFormat numberFormat20 = standardPieSectionLabelGenerator18.getNumberFormat();
        piePlot3.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator18);
        boolean boolean22 = piePlot3.getIgnoreNullValues();
        java.lang.Object obj23 = piePlot3.clone();
        double double24 = piePlot3.getLabelLinkMargin();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(numberFormat19);
        org.junit.Assert.assertNotNull(numberFormat20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.025d + "'", double24 == 0.025d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("TableOrder.BY_COLUMN");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name TableOrder.BY_COLUMN, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot7.getDataset();
        java.awt.Stroke stroke11 = piePlot7.getLabelLinkStroke();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        org.jfree.data.general.DatasetGroup datasetGroup13 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot14.setOutlineStroke(stroke15);
        java.awt.Color color17 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color17, jFreeChart18, chartChangeEventType19);
        java.awt.Color color21 = color17.brighter();
        int int22 = color17.getRGB();
        multiplePiePlot14.setNoDataMessagePaint((java.awt.Paint) color17);
        multiplePiePlot14.setBackgroundImageAlpha((float) 0L);
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray31 = new java.awt.Stroke[] { stroke28, stroke29, stroke30 };
        java.awt.Stroke stroke32 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke32, stroke33 };
        java.awt.Shape[] shapeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray26, paintArray27, strokeArray31, strokeArray34, shapeArray35);
        java.awt.Paint paint37 = defaultDrawingSupplier36.getNextFillPaint();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font41 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("", font41);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font41);
        boolean boolean44 = chartChangeEventType38.equals((java.lang.Object) font41);
        boolean boolean45 = defaultDrawingSupplier36.equals((java.lang.Object) boolean44);
        java.awt.Stroke stroke46 = defaultDrawingSupplier36.getNextOutlineStroke();
        multiplePiePlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier36);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot14);
        java.lang.Object obj49 = null;
        boolean boolean50 = defaultCategoryDataset0.equals(obj49);
        java.lang.Number number51 = null;
        defaultCategoryDataset0.setValue(number51, (java.lang.Comparable) (-1.6777216E7d), (java.lang.Comparable) (short) 100);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(datasetGroup13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16777216) + "'", int22 == (-16777216));
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(shapeArray35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font7);
        java.lang.String str9 = textTitle8.getText();
        double double10 = textTitle8.getHeight();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle8);
        java.awt.Stroke stroke12 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart3.removeProgressListener(chartProgressListener13);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart3.getLegend();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(legendTitle15);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        double double6 = piePlot1.getStartAngle();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 90.0d + "'", double6 == 90.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        double double7 = legendTitle2.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle2.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray9 = legendTitle2.getSources();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font12);
        java.lang.String str14 = textTitle13.getText();
        double double15 = textTitle13.getHeight();
        textTitle13.setURLText("RectangleEdge.LEFT");
        textTitle13.setToolTipText("");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getHorizontalAlignment();
        java.lang.Object obj22 = textTitle20.clone();
        java.awt.Paint paint23 = textTitle20.getBackgroundPaint();
        textTitle20.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        textTitle20.setURLText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = textTitle20.getHorizontalAlignment();
        textTitle13.setTextAlignment(horizontalAlignment28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.Font font33 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font33);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font33);
        java.awt.Paint paint36 = textTitle35.getPaint();
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle35.getBounds();
        java.awt.Font font39 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font39);
        java.lang.String str41 = textTitle40.getText();
        java.lang.Object obj42 = textTitle13.draw(graphics2D30, rectangle2D37, (java.lang.Object) textTitle40);
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent45 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle44);
        org.jfree.chart.block.BlockContainer blockContainer46 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = blockContainer46.getMargin();
        org.jfree.chart.util.UnitType unitType48 = rectangleInsets47.getUnitType();
        double double50 = rectangleInsets47.trimHeight((double) 0.0f);
        double double51 = rectangleInsets47.getRight();
        double double53 = rectangleInsets47.calculateBottomInset(1.0E-5d);
        legendTitle44.setItemLabelPadding(rectangleInsets47);
        double double56 = rectangleInsets47.calculateRightOutset(0.0d);
        try {
            java.lang.Object obj57 = legendTitle2.draw(graphics2D10, rectangle2D37, (java.lang.Object) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(legendItemSourceArray9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str14.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str41.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(unitType48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape3, "");
        java.lang.String str6 = chartEntity5.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image8 = projectInfo7.getLogo();
        java.awt.Image image9 = projectInfo7.getLogo();
        boolean boolean10 = chartEntity5.equals((java.lang.Object) image9);
        org.jfree.chart.ui.ProjectInfo projectInfo14 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "UnitType.ABSOLUTE", image9, "java.awt.Color[r=0,g=128,b=0]", "HorizontalAlignment.RIGHT", "ChartEntity: tooltip = ");
        projectInfo14.setName("");
        projectInfo14.setName("rect");
        projectInfo14.setLicenceName("hi!");
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-4,-4,4,4" + "'", str6.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(image8);
        org.junit.Assert.assertNotNull(image9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot1.setOutlinePaint(paint4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray11 = legendTitle9.getSources();
        jFreeChart6.addSubtitle((int) (short) 1, (org.jfree.chart.title.Title) legendTitle9);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(legendItemSourceArray11);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.block.BlockContainer blockContainer8 = legendTitle2.getItemContainer();
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10);
        java.lang.String str12 = textTitle11.getText();
        double double13 = textTitle11.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = textTitle11.getPosition();
        legendTitle2.setPosition(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(blockContainer8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str12.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("rect", "Other", "VerticalAlignment.CENTER", "VerticalAlignment.CENTER", "-4,-4,4,4");
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        piePlot1.drawBackgroundImage(graphics2D10, rectangle2D11);
        boolean boolean13 = piePlot1.getIgnoreNullValues();
        piePlot1.setPieIndex(8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(pieURLGenerator16);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        piePlot3.setSimpleLabels(true);
        piePlot3.setOutlineVisible(false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        piePlot3.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat19 = standardPieSectionLabelGenerator18.getNumberFormat();
        java.text.NumberFormat numberFormat20 = standardPieSectionLabelGenerator18.getNumberFormat();
        piePlot3.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color23 = color22.darker();
        piePlot3.setNoDataMessagePaint((java.awt.Paint) color22);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(numberFormat19);
        org.junit.Assert.assertNotNull(numberFormat20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Color color0 = java.awt.Color.lightGray;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color3.getComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(colorSpace2, floatArray19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot22.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = multiplePiePlot22.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        boolean boolean28 = lineBorder26.equals((java.lang.Object) color27);
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources29 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration30 = jFreeChartResources29.getKeys();
        boolean boolean31 = lineBorder26.equals((java.lang.Object) jFreeChartResources29);
        java.util.Set<java.lang.String> strSet32 = jFreeChartResources29.keySet();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strEnumeration30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strSet32);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 'a');
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockContainer6.getMargin();
        double double9 = rectangleInsets7.calculateRightOutset(0.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets7);
        double double12 = rectangleInsets7.calculateLeftInset((double) (byte) 100);
        double double14 = rectangleInsets7.calculateBottomInset(0.0d);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        jFreeChart3.setNotify(true);
        jFreeChart3.setNotify(true);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("RectangleEdge.TOP");
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        java.awt.Image image2 = projectInfo0.getLogo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
        basicProjectInfo3.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        projectInfo0.setInfo("TableOrder.BY_ROW");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(image2);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.awt.Stroke stroke8 = piePlot1.getOutlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        java.awt.Paint paint10 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.toString();
        java.lang.String str4 = chartEntity2.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ChartEntity: tooltip = " + "'", str3.equals("ChartEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-4,-4,4,4" + "'", str4.equals("-4,-4,4,4"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo11);
        jFreeChart3.fireChartChanged();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image15 = multiplePiePlot14.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset20 = piePlot17.getDataset();
        multiplePiePlot14.setParent((org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor22 = piePlot17.getLabelDistributor();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color23);
        java.awt.Color color25 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
        java.awt.Color color29 = color25.brighter();
        java.awt.Color color30 = java.awt.Color.green;
        float[] floatArray36 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
        float[] floatArray38 = color25.getRGBColorComponents(floatArray37);
        float[] floatArray39 = color23.getComponents(floatArray37);
        piePlot17.setLabelLinkPaint((java.awt.Paint) color23);
        jFreeChart3.setBackgroundPaint((java.awt.Paint) color23);
        jFreeChart3.setTitle("");
        java.awt.Font font46 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font46);
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font46);
        java.lang.String str49 = textTitle48.getToolTipText();
        jFreeChart3.setTitle(textTitle48);
        org.jfree.chart.event.ChartChangeListener chartChangeListener51 = null;
        try {
            jFreeChart3.addChangeListener(chartChangeListener51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNull(pieDataset20);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNull(str49);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.lang.Object obj5 = defaultKeyedValues2D1.clone();
        try {
            defaultKeyedValues2D1.removeColumn((-4145152));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "");
        boolean boolean6 = standardPieSectionLabelGenerator0.equals((java.lang.Object) "");
        java.lang.String str7 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        double double2 = textTitle0.getHeight();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        java.lang.String str8 = standardPieSectionLabelGenerator5.generateSectionLabel(pieDataset6, (java.lang.Comparable) true);
        java.lang.Object obj9 = textTitle0.draw(graphics2D3, rectangle2D4, (java.lang.Object) true);
        textTitle0.setURLText("PieSection: 97, 10(100)");
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        try {
            org.jfree.chart.plot.XYPlot xYPlot4 = jFreeChart3.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot3.getLabelDistributor();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Color color15 = color11.brighter();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = color11.getRGBColorComponents(floatArray23);
        float[] floatArray25 = color9.getComponents(floatArray23);
        piePlot3.setLabelLinkPaint((java.awt.Paint) color9);
        piePlot3.zoom((double) 100L);
        double double29 = piePlot3.getShadowYOffset();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 4.0d + "'", double29 == 4.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.util.List list2 = blockContainer0.getBlocks();
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer3.getMargin();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean6 = blockContainer3.equals((java.lang.Object) color5);
        double double7 = blockContainer3.getWidth();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle8.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment10, (double) (short) 0, (double) (byte) 1);
        blockContainer3.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement13);
        double double15 = blockContainer3.getWidth();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setLabelLinksVisible(false);
        piePlot17.setLabelLinksVisible(true);
        boolean boolean22 = piePlot17.getSectionOutlinesVisible();
        piePlot17.setCircular(false, false);
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color27 = color26.darker();
        piePlot17.setLabelOutlinePaint((java.awt.Paint) color26);
        java.awt.Font font29 = piePlot17.getLabelFont();
        java.awt.Color color30 = java.awt.Color.WHITE;
        piePlot17.setOutlinePaint((java.awt.Paint) color30);
        double double32 = piePlot17.getShadowYOffset();
        try {
            blockContainer0.add((org.jfree.chart.block.Block) blockContainer3, (java.lang.Object) piePlot17);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list6 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list7 = defaultKeyedValues2D1.getRowKeys();
        java.lang.Number number8 = null;
        defaultKeyedValues2D1.setValue(number8, (java.lang.Comparable) 'a', (java.lang.Comparable) 128);
        int int12 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.awt.Stroke stroke8 = piePlot1.getOutlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        java.awt.Paint paint10 = piePlot1.getBaseSectionOutlinePaint();
        float float11 = piePlot1.getBackgroundImageAlpha();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot3.getLabelDistributor();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Color color15 = color11.brighter();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = color11.getRGBColorComponents(floatArray23);
        float[] floatArray25 = color9.getComponents(floatArray23);
        piePlot3.setLabelLinkPaint((java.awt.Paint) color9);
        piePlot3.zoom((double) 100L);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator29 = null;
        piePlot3.setToolTipGenerator(pieToolTipGenerator29);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '#', 97, (java.lang.Comparable) (-16777216), "RectangleEdge.LEFT", "ChartEntity: tooltip = ");
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape0, "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "");
        java.lang.String str8 = chartEntity7.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo9 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image10 = projectInfo9.getLogo();
        java.awt.Image image11 = projectInfo9.getLogo();
        boolean boolean12 = chartEntity7.equals((java.lang.Object) image11);
        org.jfree.chart.ui.ProjectInfo projectInfo16 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "UnitType.ABSOLUTE", image11, "java.awt.Color[r=0,g=128,b=0]", "HorizontalAlignment.RIGHT", "ChartEntity: tooltip = ");
        projectInfo0.setLogo(image11);
        org.jfree.chart.ui.ProjectInfo projectInfo18 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image19 = projectInfo18.getLogo();
        java.awt.Image image20 = projectInfo18.getLogo();
        projectInfo0.setLogo(image20);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-4,-4,4,4" + "'", str8.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo9);
        org.junit.Assert.assertNotNull(image10);
        org.junit.Assert.assertNotNull(image11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(projectInfo18);
        org.junit.Assert.assertNotNull(image19);
        org.junit.Assert.assertNotNull(image20);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int8 = pieSectionEntity7.getPieIndex();
        java.lang.Comparable comparable9 = pieSectionEntity7.getSectionKey();
        java.lang.Object obj10 = pieSectionEntity7.clone();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator11 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator12 = null;
        try {
            java.lang.String str13 = pieSectionEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator11, uRLTagFragmentGenerator12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100L + "'", comparable9.equals(100L));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color3.getComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(colorSpace2, floatArray19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot22.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = multiplePiePlot22.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets25);
        java.awt.Paint paint27 = lineBorder26.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = lineBorder26.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list6 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list7 = defaultKeyedValues2D1.getRowKeys();
        java.lang.Number number8 = null;
        defaultKeyedValues2D1.setValue(number8, (java.lang.Comparable) 'a', (java.lang.Comparable) 128);
        try {
            java.lang.Number number14 = defaultKeyedValues2D1.getValue((java.lang.Comparable) 192, (java.lang.Comparable) "RectangleEdge.TOP");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: RectangleEdge.TOP");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Paint paint0 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.awt.Stroke stroke8 = piePlot1.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        piePlot10.setLabelLinksVisible(false);
        piePlot10.setLabelLinksVisible(true);
        boolean boolean15 = piePlot10.getSectionOutlinesVisible();
        piePlot10.setCircular(false, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color20 = color19.darker();
        piePlot10.setLabelOutlinePaint((java.awt.Paint) color19);
        java.awt.Font font22 = piePlot10.getLabelFont();
        java.awt.Font font23 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        piePlot10.setNoDataMessageFont(font23);
        piePlot1.setLabelFont(font23);
        boolean boolean26 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        jFreeChart7.setNotify(true);
        java.awt.Stroke stroke10 = jFreeChart7.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart7.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo15);
        float float17 = jFreeChart7.getBackgroundImageAlpha();
        chartChangeEvent1.setChart(jFreeChart7);
        org.jfree.chart.ui.Contributor contributor21 = new org.jfree.chart.ui.Contributor("UnitType.ABSOLUTE", "rect");
        boolean boolean22 = jFreeChart7.equals((java.lang.Object) "UnitType.ABSOLUTE");
        org.jfree.chart.title.LegendTitle legendTitle24 = jFreeChart7.getLegend(0);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(legendTitle24);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str1 = horizontalAlignment0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = horizontalAlignment0.equals(obj2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment4, (-54.0d), 100.0d);
        flowArrangement7.clear();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = legendTitle10.getLegendItemGraphicEdge();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString14 = standardPieSectionLabelGenerator12.getAttributedLabel((-1));
        flowArrangement7.add((org.jfree.chart.block.Block) legendTitle10, (java.lang.Object) standardPieSectionLabelGenerator12);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str1.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(attributedString14);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int8 = pieSectionEntity7.getPieIndex();
        org.jfree.data.general.PieDataset pieDataset9 = pieSectionEntity7.getDataset();
        java.awt.Shape shape10 = pieSectionEntity7.getArea();
        java.lang.String str11 = pieSectionEntity7.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "rect" + "'", str11.equals("rect"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        strokeMap0.put((java.lang.Comparable) 1.0E-5d, stroke3);
        boolean boolean6 = strokeMap0.containsKey((java.lang.Comparable) 35.0d);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str1 = horizontalAlignment0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = horizontalAlignment0.equals(obj2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment4, (-54.0d), 100.0d);
        flowArrangement7.clear();
        flowArrangement7.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str1.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        double double4 = blockContainer0.getWidth();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 0, (double) (byte) 1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement10);
        org.jfree.chart.block.Arrangement arrangement12 = blockContainer0.getArrangement();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = blockContainer0.arrange(graphics2D13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) 100, (double) (short) 1, rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(arrangement12);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = java.awt.Color.GRAY;
        boolean boolean12 = color10.equals((java.lang.Object) color11);
        piePlot3.setLabelShadowPaint((java.awt.Paint) color11);
        java.lang.Object obj14 = piePlot3.clone();
        java.awt.Stroke stroke15 = piePlot3.getLabelOutlineStroke();
        java.awt.Paint paint16 = piePlot3.getLabelBackgroundPaint();
        piePlot3.setForegroundAlpha((float) (byte) 10);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.lang.Object obj3 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.PaintMap paintMap1 = new org.jfree.chart.PaintMap();
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font3);
        textTitle4.setNotify(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle4.setPaint((java.awt.Paint) color7);
        boolean boolean9 = paintMap1.equals((java.lang.Object) color7);
        java.awt.Color color10 = java.awt.Color.getColor("TableOrder.BY_ROW", color7);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        piePlot12.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset15 = piePlot12.getDataset();
        java.awt.Font font16 = piePlot12.getLabelFont();
        piePlot12.setMinimumArcAngleToDraw(0.0d);
        java.awt.Stroke stroke19 = piePlot12.getBaseSectionOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double22 = rectangleInsets20.calculateTopInset((double) 10L);
        double double23 = rectangleInsets20.getRight();
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke19, rectangleInsets20);
        int int25 = color10.getRed();
        java.awt.Color color26 = color10.darker();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(pieDataset15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 128 + "'", int25 == 128);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        piePlot1.drawBackgroundImage(graphics2D10, rectangle2D11);
        boolean boolean13 = piePlot1.getIgnoreNullValues();
        java.awt.Paint paint14 = piePlot1.getLabelBackgroundPaint();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = java.awt.Color.GRAY;
        boolean boolean12 = color10.equals((java.lang.Object) color11);
        piePlot3.setLabelShadowPaint((java.awt.Paint) color11);
        java.lang.Object obj14 = piePlot3.clone();
        java.awt.Stroke stroke15 = piePlot3.getBaseSectionOutlineStroke();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color17 = color16.darker();
        piePlot3.setLabelPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        org.jfree.data.UnknownKeyException unknownKeyException4 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str5 = unknownKeyException4.toString();
        java.lang.String str6 = unknownKeyException4.toString();
        objectList0.set((int) (short) 100, (java.lang.Object) unknownKeyException4);
        java.lang.Throwable[] throwableArray8 = unknownKeyException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str5.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str6.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font9);
        java.awt.Paint paint12 = textTitle11.getPaint();
        piePlot1.setNoDataMessagePaint(paint12);
        boolean boolean14 = piePlot1.isCircular();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        java.lang.String str3 = textTitle2.getText();
        double double4 = textTitle2.getHeight();
        java.lang.String str5 = textTitle2.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle2.getTextAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape3, "");
        java.lang.String str6 = chartEntity5.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image8 = projectInfo7.getLogo();
        java.awt.Image image9 = projectInfo7.getLogo();
        boolean boolean10 = chartEntity5.equals((java.lang.Object) image9);
        org.jfree.chart.ui.ProjectInfo projectInfo14 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "UnitType.ABSOLUTE", image9, "java.awt.Color[r=0,g=128,b=0]", "HorizontalAlignment.RIGHT", "ChartEntity: tooltip = ");
        projectInfo14.setName("");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D18 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D18.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.lang.Object obj22 = defaultKeyedValues2D18.clone();
        java.util.List list23 = defaultKeyedValues2D18.getColumnKeys();
        projectInfo14.setContributors(list23);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-4,-4,4,4" + "'", str6.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(image8);
        org.junit.Assert.assertNotNull(image9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color2 = java.awt.Color.cyan;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent8 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle7);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray9 = legendTitle7.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle7.getItemLabelPadding();
        boolean boolean11 = rectangleAnchor5.equals((java.lang.Object) legendTitle7);
        double double12 = legendTitle7.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = legendTitle7.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray14 = legendTitle7.getSources();
        legendTitle1.setSources(legendItemSourceArray14);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(legendItemSourceArray9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(legendItemSourceArray14);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot7.getDataset();
        java.awt.Stroke stroke11 = piePlot7.getLabelLinkStroke();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle14);
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockContainer16.getMargin();
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        double double20 = rectangleInsets17.trimHeight((double) 0.0f);
        double double21 = rectangleInsets17.getRight();
        double double23 = rectangleInsets17.calculateBottomInset(1.0E-5d);
        legendTitle14.setItemLabelPadding(rectangleInsets17);
        piePlot7.setInsets(rectangleInsets17);
        java.awt.Paint paint26 = piePlot7.getLabelOutlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = piePlot7.getLegendItems();
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(legendItemCollection27);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getLegendItemGraphicPadding();
        double double4 = rectangleInsets2.extendHeight((double) 10);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 14.0d + "'", double4 == 14.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        chartChangeEvent3.setType(chartChangeEventType4);
        java.lang.String str6 = chartChangeEvent3.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent3.setType(chartChangeEventType7);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle10.getLegendItemGraphicPadding();
        boolean boolean12 = chartChangeEventType7.equals((java.lang.Object) legendTitle10);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]" + "'", str6.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]"));
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = java.awt.Color.GRAY;
        boolean boolean12 = color10.equals((java.lang.Object) color11);
        piePlot3.setLabelShadowPaint((java.awt.Paint) color11);
        java.lang.Object obj14 = piePlot3.clone();
        piePlot3.zoom((double) 10.0f);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot7.getDataset();
        java.awt.Stroke stroke11 = piePlot7.getLabelLinkStroke();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        org.jfree.data.general.DatasetGroup datasetGroup13 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot14.setOutlineStroke(stroke15);
        java.awt.Color color17 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color17, jFreeChart18, chartChangeEventType19);
        java.awt.Color color21 = color17.brighter();
        int int22 = color17.getRGB();
        multiplePiePlot14.setNoDataMessagePaint((java.awt.Paint) color17);
        multiplePiePlot14.setBackgroundImageAlpha((float) 0L);
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray31 = new java.awt.Stroke[] { stroke28, stroke29, stroke30 };
        java.awt.Stroke stroke32 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke32, stroke33 };
        java.awt.Shape[] shapeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray26, paintArray27, strokeArray31, strokeArray34, shapeArray35);
        java.awt.Paint paint37 = defaultDrawingSupplier36.getNextFillPaint();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font41 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("", font41);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font41);
        boolean boolean44 = chartChangeEventType38.equals((java.lang.Object) font41);
        boolean boolean45 = defaultDrawingSupplier36.equals((java.lang.Object) boolean44);
        java.awt.Stroke stroke46 = defaultDrawingSupplier36.getNextOutlineStroke();
        multiplePiePlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier36);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot14);
        org.jfree.data.UnknownKeyException unknownKeyException50 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str51 = unknownKeyException50.toString();
        java.lang.String str52 = unknownKeyException50.toString();
        org.jfree.data.UnknownKeyException unknownKeyException54 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str55 = unknownKeyException54.toString();
        java.lang.String str56 = unknownKeyException54.toString();
        org.jfree.data.UnknownKeyException unknownKeyException58 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        unknownKeyException54.addSuppressed((java.lang.Throwable) unknownKeyException58);
        unknownKeyException50.addSuppressed((java.lang.Throwable) unknownKeyException54);
        boolean boolean61 = multiplePiePlot14.equals((java.lang.Object) unknownKeyException50);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(datasetGroup13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16777216) + "'", int22 == (-16777216));
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(shapeArray35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str51.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str52.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str55.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str56.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        java.awt.Paint paint10 = piePlot1.getOutlinePaint();
        double double11 = piePlot1.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("http://www.jfree.org/jfreechart/index.html");
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener1 = null;
        textTitle0.addChangeListener(titleChangeListener1);
        boolean boolean3 = textTitle0.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle0.setHorizontalAlignment(horizontalAlignment4);
        java.awt.Color color6 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color6, jFreeChart7, chartChangeEventType8);
        java.awt.Color color10 = color6.brighter();
        java.awt.Color color11 = color6.brighter();
        textTitle0.setPaint((java.awt.Paint) color11);
        java.awt.Font font15 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle17.setVerticalAlignment(verticalAlignment18);
        java.awt.Font font20 = textTitle17.getFont();
        textTitle0.setFont(font20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot1.setLimit((double) '#');
        org.jfree.chart.util.TableOrder tableOrder4 = multiplePiePlot1.getDataExtractOrder();
        boolean boolean5 = horizontalAlignment0.equals((java.lang.Object) tableOrder4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment6, (double) (-1.0f), 0.08d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(tableOrder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer3.getMargin();
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        double double7 = rectangleInsets4.trimHeight((double) 0.0f);
        double double8 = rectangleInsets4.getRight();
        double double10 = rectangleInsets4.calculateBottomInset(1.0E-5d);
        legendTitle1.setItemLabelPadding(rectangleInsets4);
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets4.getUnitType();
        double double14 = rectangleInsets4.calculateLeftOutset((double) (byte) -1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 15);
        try {
            java.lang.Comparable comparable6 = defaultKeyedValues2D1.getRowKey((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font9);
        java.awt.Paint paint12 = textTitle11.getPaint();
        piePlot1.setNoDataMessagePaint(paint12);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = piePlot1.getLabelLinkStyle();
        boolean boolean15 = piePlot1.getSimpleLabels();
        boolean boolean16 = piePlot1.getLabelLinksVisible();
        piePlot1.zoom(35.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int6 = color5.getBlue();
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((double) 100.0f, (double) 100L, 100.0d, (double) 'a', (java.awt.Paint) color5);
        int int8 = color5.getTransparency();
        java.awt.Color color9 = java.awt.Color.getColor("", color5);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 128 + "'", int6 == 128);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("http://www.jfree.org/jfreechart/index.html");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle4);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray6 = legendTitle4.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle4.getItemLabelPadding();
        boolean boolean8 = rectangleAnchor2.equals((java.lang.Object) legendTitle4);
        java.lang.Class<?> wildcardClass9 = legendTitle4.getClass();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot11.setOutlineStroke(stroke12);
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot11.setOutlinePaint(paint14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        legendTitle4.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        boolean boolean18 = jFreeChart16.isBorderVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = jFreeChart16.getPadding();
        jFreeChart16.setAntiAlias(false);
        float float22 = jFreeChart16.getBackgroundImageAlpha();
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(legendItemSourceArray6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.5f + "'", float22 == 0.5f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels(0.0d, (-1.6777216E7d));
        java.lang.String str6 = pieLabelDistributor1.toString();
        pieLabelDistributor1.sort();
        pieLabelDistributor1.sort();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = java.awt.Color.GRAY;
        boolean boolean12 = color10.equals((java.lang.Object) color11);
        piePlot3.setLabelShadowPaint((java.awt.Paint) color11);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot3.setToolTipGenerator(pieToolTipGenerator14);
        piePlot3.setIgnoreZeroValues(false);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        piePlot3.setSimpleLabels(true);
        piePlot3.setOutlineVisible(false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        piePlot3.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat19 = standardPieSectionLabelGenerator18.getNumberFormat();
        java.text.NumberFormat numberFormat20 = standardPieSectionLabelGenerator18.getNumberFormat();
        piePlot3.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator18);
        boolean boolean22 = piePlot3.getIgnoreNullValues();
        java.lang.Object obj23 = piePlot3.clone();
        try {
            piePlot3.setInteriorGap((double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (100.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(numberFormat19);
        org.junit.Assert.assertNotNull(numberFormat20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.Color color5 = java.awt.Color.blue;
        int int6 = color5.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(1.0d, (double) '4', (double) 100L, 0.0d, (java.awt.Paint) color5);
        boolean boolean8 = rectangleAnchor0.equals((java.lang.Object) color5);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1, chartChangeEventType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        double double3 = rectangleInsets1.calculateRightOutset(0.0d);
        double double5 = rectangleInsets1.calculateLeftInset((double) 3);
        double double6 = rectangleInsets1.getTop();
        double double8 = rectangleInsets1.calculateLeftInset(90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.text.NumberFormat numberFormat1 = null;
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat3 = standardPieSectionLabelGenerator2.getPercentFormat();
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TableOrder.BY_COLUMN", numberFormat1, numberFormat3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        double double2 = rotation0.getFactor();
        java.lang.String str3 = rotation0.toString();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        boolean boolean8 = rotation0.equals((java.lang.Object) multiplePiePlot4);
        java.lang.String str9 = multiplePiePlot4.getPlotType();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = multiplePiePlot4.getDrawingSupplier();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Rotation.CLOCKWISE" + "'", str3.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Multiple Pie Plot" + "'", str9.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(drawingSupplier10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        jFreeChart3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart3.getTitle();
        jFreeChart3.setBackgroundImageAlpha(1.0f);
        jFreeChart3.setNotify(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        java.awt.image.BufferedImage bufferedImage20 = jFreeChart3.createBufferedImage(10, (int) (byte) 1, 3, chartRenderingInfo19);
        java.awt.Font font22 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font22);
        textTitle23.setNotify(true);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle23.setPaint((java.awt.Paint) color26);
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle23);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertNotNull(bufferedImage20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = multiplePiePlot0.getInsets();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image6 = multiplePiePlot5.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        piePlot8.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset11 = piePlot8.getDataset();
        multiplePiePlot5.setParent((org.jfree.chart.plot.Plot) piePlot8);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor13 = piePlot8.getLabelDistributor();
        double double14 = piePlot8.getLabelLinkMargin();
        double double15 = piePlot8.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font18);
        java.lang.String str20 = textTitle19.getText();
        double double21 = textTitle19.getHeight();
        textTitle19.setURLText("RectangleEdge.LEFT");
        textTitle19.setToolTipText("");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = textTitle26.getHorizontalAlignment();
        java.lang.Object obj28 = textTitle26.clone();
        java.awt.Paint paint29 = textTitle26.getBackgroundPaint();
        textTitle26.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        textTitle26.setURLText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle26.getHorizontalAlignment();
        textTitle19.setTextAlignment(horizontalAlignment34);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.Font font39 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font39);
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font39);
        java.awt.Paint paint42 = textTitle41.getPaint();
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle41.getBounds();
        java.awt.Font font45 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font45);
        java.lang.String str47 = textTitle46.getText();
        java.lang.Object obj48 = textTitle19.draw(graphics2D36, rectangle2D43, (java.lang.Object) textTitle46);
        org.jfree.data.general.PieDataset pieDataset49 = null;
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot(pieDataset49);
        piePlot50.setLabelLinksVisible(false);
        piePlot50.setLabelLinksVisible(true);
        boolean boolean55 = piePlot50.getSectionOutlinesVisible();
        piePlot50.setCircular(false, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        org.jfree.chart.plot.PiePlotState piePlotState61 = piePlot8.initialise(graphics2D16, rectangle2D43, piePlot50, (java.lang.Integer) 8, plotRenderingInfo60);
        org.jfree.chart.block.BlockContainer blockContainer62 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = blockContainer62.getMargin();
        java.awt.Color color64 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean65 = blockContainer62.equals((java.lang.Object) color64);
        double double66 = blockContainer62.getWidth();
        org.jfree.chart.title.TextTitle textTitle67 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment68 = textTitle67.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment69 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement72 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment68, verticalAlignment69, (double) (short) 0, (double) (byte) 1);
        blockContainer62.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement72);
        org.jfree.chart.block.BlockContainer blockContainer74 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = blockContainer74.getMargin();
        double double77 = rectangleInsets75.calculateRightOutset(0.0d);
        double double79 = rectangleInsets75.calculateBottomInset((double) (byte) 0);
        blockContainer62.setMargin(rectangleInsets75);
        org.jfree.chart.title.TextTitle textTitle81 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener82 = null;
        textTitle81.addChangeListener(titleChangeListener82);
        java.awt.Font font86 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle87 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font86);
        org.jfree.chart.title.TextTitle textTitle88 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font86);
        java.awt.Paint paint89 = textTitle88.getPaint();
        java.awt.geom.Rectangle2D rectangle2D90 = textTitle88.getBounds();
        textTitle81.setBounds(rectangle2D90);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType92 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType93 = null;
        java.awt.geom.Rectangle2D rectangle2D94 = rectangleInsets75.createAdjustedRectangle(rectangle2D90, lengthAdjustmentType92, lengthAdjustmentType93);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor95 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D96 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D94, rectangleAnchor95);
        org.jfree.chart.plot.PlotState plotState97 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo98 = null;
        try {
            multiplePiePlot0.draw(graphics2D4, rectangle2D43, point2D96, plotState97, plotRenderingInfo98);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNull(pieDataset11);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.025d + "'", double14 == 0.025d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str20.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str47.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNull(obj48);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(piePlotState61);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment68);
        org.junit.Assert.assertNotNull(verticalAlignment69);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(font86);
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertNotNull(rectangle2D90);
        org.junit.Assert.assertNotNull(rectangle2D94);
        org.junit.Assert.assertNotNull(rectangleAnchor95);
        org.junit.Assert.assertNotNull(point2D96);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.ui.Contributor contributor3 = new org.jfree.chart.ui.Contributor("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        int int4 = objectList0.indexOf((java.lang.Object) "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        objectList0.clear();
        java.lang.Object obj6 = objectList0.clone();
        objectList0.clear();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot9.setOutlinePaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot9);
        legendTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        boolean boolean16 = jFreeChart14.isBorderVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = jFreeChart14.getPadding();
        jFreeChart14.setAntiAlias(false);
        float float20 = jFreeChart14.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart14.getLegend();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
        org.junit.Assert.assertNotNull(legendTitle21);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setCircular(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color11 = color10.darker();
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color10);
        piePlot1.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setLabelLinkMargin((double) (short) 100);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        java.awt.color.ColorSpace colorSpace12 = color10.getColorSpace();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = java.awt.Color.RGBtoHSB((-16777216), (int) (byte) 100, (int) (short) 100, floatArray23);
        float[] floatArray25 = color9.getColorComponents(colorSpace12, floatArray24);
        piePlot1.setShadowPaint((java.awt.Paint) color9);
        java.awt.color.ColorSpace colorSpace27 = null;
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        float[] floatArray37 = new float[] { '#', (-1), (byte) 100, (byte) 100, (byte) 1 };
        float[] floatArray38 = color31.getRGBComponents(floatArray37);
        float[] floatArray39 = java.awt.Color.RGBtoHSB(3, (int) (short) 1, 0, floatArray37);
        try {
            float[] floatArray40 = color9.getComponents(colorSpace27, floatArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.lang.String str1 = color0.toString();
        int int2 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=128,b=0]" + "'", str1.equals("java.awt.Color[r=0,g=128,b=0]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        double double4 = blockContainer0.getWidth();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 0, (double) (byte) 1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement10);
        org.jfree.chart.block.Arrangement arrangement12 = blockContainer0.getArrangement();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = blockContainer0.arrange(graphics2D13);
        java.util.List list15 = blockContainer0.getBlocks();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(arrangement12);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        boolean boolean3 = standardPieSectionLabelGenerator0.equals((java.lang.Object) color2);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer3.getMargin();
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        double double7 = rectangleInsets4.trimHeight((double) 0.0f);
        double double8 = rectangleInsets4.getRight();
        double double10 = rectangleInsets4.calculateBottomInset(1.0E-5d);
        legendTitle1.setItemLabelPadding(rectangleInsets4);
        java.lang.Object obj12 = legendTitle1.clone();
        java.awt.Paint paint13 = legendTitle1.getItemPaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color15 = color14.darker();
        legendTitle1.setItemPaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.Plot plot10 = multiplePiePlot0.getParent();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (short) 1);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int8 = pieSectionEntity7.getPieIndex();
        org.jfree.data.general.PieDataset pieDataset9 = pieSectionEntity7.getDataset();
        int int10 = pieSectionEntity7.getPieIndex();
        pieSectionEntity7.setSectionIndex(8);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator13 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator14 = null;
        try {
            java.lang.String str15 = pieSectionEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator13, uRLTagFragmentGenerator14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        java.awt.Shape shape8 = pieSectionEntity7.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot7.getDataset();
        java.awt.Stroke stroke11 = piePlot7.getLabelLinkStroke();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        piePlot7.setMinimumArcAngleToDraw((-1.0d));
        java.awt.Paint paint15 = piePlot7.getShadowPaint();
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color5.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color3.getComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(colorSpace2, floatArray19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot22.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = multiplePiePlot22.getInsets();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets25);
        java.awt.Paint paint27 = lineBorder26.getPaint();
        org.jfree.chart.util.UnitType unitType28 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets(unitType28, (double) (short) 0, (double) (-1L), (double) (short) 1, (double) 1L);
        double double35 = rectangleInsets33.calculateLeftOutset((double) 0.0f);
        org.jfree.chart.util.UnitType unitType36 = rectangleInsets33.getUnitType();
        boolean boolean37 = lineBorder26.equals((java.lang.Object) unitType36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = lineBorder26.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(unitType28);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-1.0d) + "'", double35 == (-1.0d));
        org.junit.Assert.assertNotNull(unitType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleInsets38);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot1.getLegendLabelURLGenerator();
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10);
        piePlot1.setNoDataMessageFont(font10);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        double double4 = blockContainer0.getWidth();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 0, (double) (byte) 1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement10);
        blockContainer0.setPadding(0.0d, 0.0d, 0.0d, 1.0E-5d);
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block18 = null;
        columnArrangement17.add(block18, (java.lang.Object) 0L);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement17);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        textTitle22.setExpandToFitSpace(false);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = textTitle25.getHorizontalAlignment();
        java.lang.Object obj27 = textTitle25.clone();
        columnArrangement17.add((org.jfree.chart.block.Block) textTitle22, obj27);
        java.awt.Paint paint29 = textTitle22.getPaint();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        piePlot1.drawBackgroundImage(graphics2D10, rectangle2D11);
        boolean boolean13 = piePlot1.getIgnoreNullValues();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot14.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart17 = multiplePiePlot14.getPieChart();
        jFreeChart17.setNotify(true);
        java.awt.Stroke stroke20 = jFreeChart17.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener21 = null;
        jFreeChart17.removeProgressListener(chartProgressListener21);
        jFreeChart17.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle25 = jFreeChart17.getTitle();
        jFreeChart17.setBackgroundImageAlpha(1.0f);
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot29.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = multiplePiePlot29.getInsets();
        org.jfree.data.general.Dataset dataset33 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets32, dataset33);
        piePlot1.setLabelPadding(rectangleInsets32);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(jFreeChart17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(textTitle25);
        org.junit.Assert.assertNotNull(rectangleInsets32);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray2 = legendTitle1.getSources();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = legendTitle1.getBackgroundPaint();
        java.awt.Font font6 = legendTitle1.getItemFont();
        org.junit.Assert.assertNotNull(legendItemSourceArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "");
        java.lang.String str8 = chartEntity7.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo9 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image10 = projectInfo9.getLogo();
        java.awt.Image image11 = projectInfo9.getLogo();
        boolean boolean12 = chartEntity7.equals((java.lang.Object) image11);
        org.jfree.chart.ui.ProjectInfo projectInfo16 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "UnitType.ABSOLUTE", image11, "java.awt.Color[r=0,g=128,b=0]", "HorizontalAlignment.RIGHT", "ChartEntity: tooltip = ");
        projectInfo0.setLogo(image11);
        projectInfo0.setLicenceName("RectangleAnchor.LEFT");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-4,-4,4,4" + "'", str8.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo9);
        org.junit.Assert.assertNotNull(image10);
        org.junit.Assert.assertNotNull(image11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo11);
        jFreeChart3.fireChartChanged();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image15 = multiplePiePlot14.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset20 = piePlot17.getDataset();
        multiplePiePlot14.setParent((org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor22 = piePlot17.getLabelDistributor();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color23);
        java.awt.Color color25 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
        java.awt.Color color29 = color25.brighter();
        java.awt.Color color30 = java.awt.Color.green;
        float[] floatArray36 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
        float[] floatArray38 = color25.getRGBColorComponents(floatArray37);
        float[] floatArray39 = color23.getComponents(floatArray37);
        piePlot17.setLabelLinkPaint((java.awt.Paint) color23);
        jFreeChart3.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = jFreeChart3.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = legendTitle44.getLegendItemGraphicPadding();
        java.lang.Object obj46 = legendTitle44.clone();
        boolean boolean47 = jFreeChart3.equals(obj46);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNull(pieDataset20);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        java.awt.Paint paint10 = piePlot6.getLabelOutlinePaint();
        java.awt.Font font11 = piePlot6.getLabelFont();
        java.awt.Paint paint12 = piePlot6.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int8 = pieSectionEntity7.getPieIndex();
        org.jfree.data.general.PieDataset pieDataset9 = pieSectionEntity7.getDataset();
        java.awt.Shape shape10 = pieSectionEntity7.getArea();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity17 = new org.jfree.chart.entity.PieSectionEntity(shape10, pieDataset11, 100, 0, (java.lang.Comparable) 10, "java.awt.Color[r=255,g=0,b=255]", "");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        blockContainer0.setPadding((double) (-1.0f), (double) 15, (double) (short) 10, (double) 1.0f);
        blockContainer0.setPadding((double) 0.5f, (double) (-1), 8.0d, 0.025d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        jFreeChart7.setNotify(true);
        java.awt.Stroke stroke10 = jFreeChart7.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart7.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo15);
        float float17 = jFreeChart7.getBackgroundImageAlpha();
        chartChangeEvent1.setChart(jFreeChart7);
        jFreeChart7.setTitle("");
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color4);
        java.awt.Color color6 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color6, jFreeChart7, chartChangeEventType8);
        java.awt.Color color10 = color6.brighter();
        java.awt.Color color11 = java.awt.Color.green;
        float[] floatArray17 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray18 = color11.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color6.getRGBColorComponents(floatArray18);
        float[] floatArray20 = color4.getComponents(floatArray18);
        float[] floatArray21 = color1.getColorComponents(colorSpace3, floatArray20);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot23.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = multiplePiePlot23.getInsets();
        org.jfree.chart.block.LineBorder lineBorder27 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color1, stroke22, rectangleInsets26);
        piePlot0.setShadowPaint((java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        java.awt.Paint paint10 = piePlot6.getLabelOutlinePaint();
        java.awt.Font font11 = piePlot6.getLabelFont();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle14);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray16 = legendTitle14.getSources();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray19 = legendTitle18.getSources();
        legendTitle14.setSources(legendItemSourceArray19);
        java.awt.Font font21 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        legendTitle14.setItemFont(font21);
        java.awt.geom.Rectangle2D rectangle2D23 = legendTitle14.getBounds();
        piePlot6.drawBackgroundImage(graphics2D12, rectangle2D23);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(legendItemSourceArray16);
        org.junit.Assert.assertNotNull(legendItemSourceArray19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangle2D23);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot0.setOutlinePaint(paint3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font7);
        java.lang.String str9 = textTitle8.getText();
        double double10 = textTitle8.getHeight();
        textTitle8.setURLText("RectangleEdge.LEFT");
        textTitle8.setToolTipText("");
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getHorizontalAlignment();
        java.lang.Object obj17 = textTitle15.clone();
        java.awt.Paint paint18 = textTitle15.getBackgroundPaint();
        textTitle15.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        textTitle15.setURLText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle15.getHorizontalAlignment();
        textTitle8.setTextAlignment(horizontalAlignment23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.Font font28 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font28);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font28);
        java.awt.Paint paint31 = textTitle30.getPaint();
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle30.getBounds();
        java.awt.Font font34 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font34);
        java.lang.String str36 = textTitle35.getText();
        java.lang.Object obj37 = textTitle8.draw(graphics2D25, rectangle2D32, (java.lang.Object) textTitle35);
        multiplePiePlot0.drawBackgroundImage(graphics2D5, rectangle2D32);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str36.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNull(obj37);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot7.getDataset();
        java.awt.Stroke stroke11 = piePlot7.getLabelLinkStroke();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle14);
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockContainer16.getMargin();
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        double double20 = rectangleInsets17.trimHeight((double) 0.0f);
        double double21 = rectangleInsets17.getRight();
        double double23 = rectangleInsets17.calculateBottomInset(1.0E-5d);
        legendTitle14.setItemLabelPadding(rectangleInsets17);
        piePlot7.setInsets(rectangleInsets17);
        java.awt.Paint paint26 = piePlot7.getLabelOutlinePaint();
        double double27 = piePlot7.getInteriorGap();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator28 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library33 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "");
        boolean boolean34 = standardPieSectionLabelGenerator28.equals((java.lang.Object) "");
        piePlot7.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator28);
        java.lang.Object obj36 = null;
        boolean boolean37 = standardPieSectionLabelGenerator28.equals(obj36);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.08d + "'", double27 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) (short) 0, (double) (byte) 1);
        java.lang.String str6 = horizontalAlignment1.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "HorizontalAlignment.CENTER" + "'", str6.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (-16777216), (double) (-4145152), (-1.0d), 0.0d, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        piePlot1.setSectionPaint((java.lang.Comparable) "LGPL", (java.awt.Paint) color4);
        int int6 = color4.getRGB();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-12566273) + "'", int6 == (-12566273));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setLabelLinkMargin((double) (short) 100);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        java.awt.color.ColorSpace colorSpace12 = color10.getColorSpace();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = java.awt.Color.RGBtoHSB((-16777216), (int) (byte) 100, (int) (short) 100, floatArray23);
        float[] floatArray25 = color9.getColorComponents(colorSpace12, floatArray24);
        piePlot1.setShadowPaint((java.awt.Paint) color9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        strokeMap0.put((java.lang.Comparable) 1.0E-5d, stroke3);
        org.jfree.chart.PaintMap paintMap6 = new org.jfree.chart.PaintMap();
        java.awt.Font font8 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font8);
        textTitle9.setNotify(true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle9.setPaint((java.awt.Paint) color12);
        boolean boolean14 = paintMap6.equals((java.lang.Object) color12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot15.setOutlineStroke(stroke16);
        boolean boolean18 = paintMap6.equals((java.lang.Object) stroke16);
        strokeMap0.put((java.lang.Comparable) (-1.0d), stroke16);
        try {
            java.awt.Stroke stroke21 = strokeMap0.getStroke((java.lang.Comparable) "java.awt.Color[r=255,g=0,b=255]");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to java.lang.String");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        double double4 = blockContainer0.getWidth();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 0, (double) (byte) 1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement10);
        blockContainer0.setPadding(0.0d, 0.0d, 0.0d, 1.0E-5d);
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block18 = null;
        columnArrangement17.add(block18, (java.lang.Object) 0L);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement17);
        blockContainer0.clear();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle7.getHorizontalAlignment();
        java.lang.Object obj9 = textTitle7.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle7);
        jFreeChart3.titleChanged(titleChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = jFreeChart3.getPadding();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int8 = pieSectionEntity7.getPieIndex();
        org.jfree.data.general.PieDataset pieDataset9 = pieSectionEntity7.getDataset();
        java.lang.String str10 = pieSectionEntity7.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str10.equals("HorizontalAlignment.RIGHT"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.Plot plot10 = multiplePiePlot0.getParent();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape14, "");
        java.lang.String str17 = chartEntity16.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo18 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image19 = projectInfo18.getLogo();
        java.awt.Image image20 = projectInfo18.getLogo();
        boolean boolean21 = chartEntity16.equals((java.lang.Object) image20);
        org.jfree.chart.ui.ProjectInfo projectInfo25 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "UnitType.ABSOLUTE", image20, "java.awt.Color[r=0,g=128,b=0]", "HorizontalAlignment.RIGHT", "ChartEntity: tooltip = ");
        multiplePiePlot0.setBackgroundImage(image20);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.awt.Paint paint28 = legendTitle27.getBackgroundPaint();
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray31 = legendTitle30.getSources();
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray34 = legendTitle33.getSources();
        legendTitle30.setSources(legendItemSourceArray34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle30.setLegendItemGraphicLocation(rectangleAnchor36);
        legendTitle27.setLegendItemGraphicAnchor(rectangleAnchor36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = legendTitle27.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-4,-4,4,4" + "'", str17.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo18);
        org.junit.Assert.assertNotNull(image19);
        org.junit.Assert.assertNotNull(image20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(legendItemSourceArray31);
        org.junit.Assert.assertNotNull(legendItemSourceArray34);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj2 = textTitle0.clone();
        java.awt.Paint paint3 = textTitle0.getBackgroundPaint();
        textTitle0.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        textTitle0.setURLText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent12 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle11);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray13 = legendTitle11.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle11.getItemLabelPadding();
        boolean boolean15 = rectangleAnchor9.equals((java.lang.Object) legendTitle11);
        java.lang.Class<?> wildcardClass16 = legendTitle11.getClass();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle11.getItemContainer();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray20 = legendTitle19.getSources();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = legendTitle19.getLegendItemGraphicEdge();
        legendTitle11.setLegendItemGraphicEdge(rectangleEdge21);
        textTitle0.setPosition(rectangleEdge21);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(legendItemSourceArray13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(legendItemSourceArray20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (byte) 1);
        java.util.List list3 = defaultCategoryDataset0.getRowKeys();
        int int4 = defaultCategoryDataset0.getColumnCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot5.setLimit((double) '#');
        float float8 = multiplePiePlot5.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot5.addChangeListener(plotChangeListener9);
        java.awt.Image image11 = multiplePiePlot5.getBackgroundImage();
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj2 = textTitle0.clone();
        java.awt.Paint paint3 = textTitle0.getBackgroundPaint();
        textTitle0.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, (double) (short) 0, (double) (byte) 1);
        textTitle0.setVerticalAlignment(verticalAlignment8);
        java.lang.String str13 = textTitle0.getID();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = null;
        try {
            org.jfree.chart.util.Size2D size2D16 = textTitle0.arrange(graphics2D14, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.lang.Object obj5 = defaultKeyedValues2D1.clone();
        try {
            java.lang.Comparable comparable7 = defaultKeyedValues2D1.getColumnKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        boolean boolean3 = multiplePiePlot0.isSubplot();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (short) 0);
        java.lang.Comparable comparable6 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot0.getPieChart();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) 0 + "'", comparable6.equals((short) 0));
        org.junit.Assert.assertNotNull(jFreeChart7);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2);
        textTitle3.setNotify(true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle3.setPaint((java.awt.Paint) color6);
        boolean boolean8 = paintMap0.equals((java.lang.Object) color6);
        boolean boolean10 = paintMap0.containsKey((java.lang.Comparable) "rect");
        java.lang.Comparable comparable11 = null;
        try {
            java.awt.Paint paint12 = paintMap0.getPaint(comparable11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getInsets();
        java.awt.Paint paint6 = piePlot1.getNoDataMessagePaint();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) (short) 0, (double) (byte) 1);
        java.awt.Color color6 = java.awt.Color.WHITE;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        boolean boolean8 = verticalAlignment2.equals((java.lang.Object) blockBorder7);
        java.awt.Paint paint9 = blockBorder7.getPaint();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.plot.Plot plot7 = null;
        piePlot1.setParent(plot7);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        java.awt.Color color12 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Color color16 = color12.brighter();
        int int17 = color12.getRGB();
        multiplePiePlot9.setNoDataMessagePaint((java.awt.Paint) color12);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color12);
        piePlot1.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-16777216) + "'", int17 == (-16777216));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        java.awt.Paint paint10 = piePlot6.getLabelOutlinePaint();
        java.awt.Paint paint12 = piePlot6.getSectionOutlinePaint((java.lang.Comparable) 'a');
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setCircular(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color11 = color10.darker();
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment13);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        chartChangeEvent14.setType(chartChangeEventType15);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot17.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot17.getPieChart();
        jFreeChart20.setNotify(true);
        java.awt.Stroke stroke23 = jFreeChart20.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        java.awt.image.BufferedImage bufferedImage29 = jFreeChart20.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo28);
        float float30 = jFreeChart20.getBackgroundImageAlpha();
        chartChangeEvent14.setChart(jFreeChart20);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        java.lang.Object obj33 = jFreeChart20.getTextAntiAlias();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        try {
            jFreeChart20.handleClick((-32384), (int) (byte) 10, chartRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(bufferedImage29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNull(obj33);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        int int5 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100L);
        try {
            defaultCategoryDataset0.removeRow(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = projectInfo0.getLogo();
//        java.awt.Image image2 = projectInfo0.getLogo();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
//        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
//        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
//        basicProjectInfo3.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
//        java.lang.String str11 = projectInfo0.getLicenceText();
//        java.lang.String str12 = projectInfo0.getInfo();
//        java.lang.String str13 = projectInfo0.getCopyright();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(image1);
//        org.junit.Assert.assertNotNull(image2);
//        org.junit.Assert.assertNotNull(libraryArray6);
//        org.junit.Assert.assertNotNull(libraryArray7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnitType.ABSOLUTE" + "'", str11.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TableOrder.BY_ROW" + "'", str12.equals("TableOrder.BY_ROW"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str13.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer3.getMargin();
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        double double7 = rectangleInsets4.trimHeight((double) 0.0f);
        double double8 = rectangleInsets4.getRight();
        double double10 = rectangleInsets4.calculateBottomInset(1.0E-5d);
        legendTitle1.setItemLabelPadding(rectangleInsets4);
        double double13 = rectangleInsets4.calculateRightOutset(0.0d);
        double double15 = rectangleInsets4.extendHeight(1.0E-5d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-5d + "'", double15 == 1.0E-5d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent4);
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setCircular(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color11 = color10.darker();
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color10);
        java.awt.Font font13 = piePlot1.getLabelFont();
        java.awt.Paint paint14 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint14);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
//        multiplePiePlot0.setLimit((double) '#');
//        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
//        jFreeChart3.setNotify(true);
//        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
//        java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo11);
//        jFreeChart3.fireChartChanged();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
//        java.awt.Image image15 = multiplePiePlot14.getBackgroundImage();
//        org.jfree.data.general.PieDataset pieDataset16 = null;
//        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
//        piePlot17.setLabelLinksVisible(false);
//        org.jfree.data.general.PieDataset pieDataset20 = piePlot17.getDataset();
//        multiplePiePlot14.setParent((org.jfree.chart.plot.Plot) piePlot17);
//        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor22 = piePlot17.getLabelDistributor();
//        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_YELLOW;
//        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color23);
//        java.awt.Color color25 = java.awt.Color.black;
//        org.jfree.chart.JFreeChart jFreeChart26 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
//        java.awt.Color color29 = color25.brighter();
//        java.awt.Color color30 = java.awt.Color.green;
//        float[] floatArray36 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
//        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
//        float[] floatArray38 = color25.getRGBColorComponents(floatArray37);
//        float[] floatArray39 = color23.getComponents(floatArray37);
//        piePlot17.setLabelLinkPaint((java.awt.Paint) color23);
//        jFreeChart3.setBackgroundPaint((java.awt.Paint) color23);
//        jFreeChart3.setTitle("");
//        java.awt.Font font46 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
//        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font46);
//        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font46);
//        java.lang.String str49 = textTitle48.getToolTipText();
//        jFreeChart3.setTitle(textTitle48);
//        org.jfree.chart.ui.ProjectInfo projectInfo51 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image52 = projectInfo51.getLogo();
//        java.awt.Image image53 = projectInfo51.getLogo();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo54 = new org.jfree.chart.ui.BasicProjectInfo();
//        basicProjectInfo54.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        org.jfree.chart.ui.Library[] libraryArray57 = basicProjectInfo54.getOptionalLibraries();
//        org.jfree.chart.ui.Library[] libraryArray58 = basicProjectInfo54.getLibraries();
//        basicProjectInfo54.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        projectInfo51.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo54);
//        java.lang.String str62 = projectInfo51.getLicenceText();
//        java.awt.Image image63 = projectInfo51.getLogo();
//        jFreeChart3.setBackgroundImage(image63);
//        org.junit.Assert.assertNotNull(jFreeChart3);
//        org.junit.Assert.assertNotNull(stroke6);
//        org.junit.Assert.assertNotNull(bufferedImage12);
//        org.junit.Assert.assertNull(image15);
//        org.junit.Assert.assertNull(pieDataset20);
//        org.junit.Assert.assertNotNull(abstractPieLabelDistributor22);
//        org.junit.Assert.assertNotNull(color23);
//        org.junit.Assert.assertNotNull(color25);
//        org.junit.Assert.assertNotNull(color29);
//        org.junit.Assert.assertNotNull(color30);
//        org.junit.Assert.assertNotNull(floatArray36);
//        org.junit.Assert.assertNotNull(floatArray37);
//        org.junit.Assert.assertNotNull(floatArray38);
//        org.junit.Assert.assertNotNull(floatArray39);
//        org.junit.Assert.assertNotNull(font46);
//        org.junit.Assert.assertNull(str49);
//        org.junit.Assert.assertNotNull(projectInfo51);
//        org.junit.Assert.assertNotNull(image52);
//        org.junit.Assert.assertNotNull(image53);
//        org.junit.Assert.assertNotNull(libraryArray57);
//        org.junit.Assert.assertNotNull(libraryArray58);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "UnitType.ABSOLUTE" + "'", str62.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertNotNull(image63);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getLabelPadding();
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle6);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray8 = legendTitle6.getSources();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray11 = legendTitle10.getSources();
        legendTitle6.setSources(legendItemSourceArray11);
        java.awt.Font font13 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        legendTitle6.setItemFont(font13);
        java.awt.geom.Rectangle2D rectangle2D15 = legendTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D15, rectangleEdge16);
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets4.createInsetRectangle(rectangle2D15, true, true);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(legendItemSourceArray8);
        org.junit.Assert.assertNotNull(legendItemSourceArray11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot1.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot1.getPieChart();
        jFreeChart4.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle7.getHorizontalAlignment();
        java.lang.Object obj9 = textTitle7.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle7);
        jFreeChart4.titleChanged(titleChangeEvent10);
        java.awt.Stroke stroke12 = jFreeChart4.getBorderStroke();
        textTitle0.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart4);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(1.0d, 0.0d, (double) (byte) 10, (double) 0.0f);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "");
        boolean boolean6 = standardPieSectionLabelGenerator0.equals((java.lang.Object) "");
        org.jfree.data.general.PieDataset pieDataset7 = null;
        java.lang.String str9 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset7, (java.lang.Comparable) 0.0f);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle10 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        boolean boolean11 = standardPieSectionLabelGenerator0.equals((java.lang.Object) pieLabelLinkStyle10);
        java.text.NumberFormat numberFormat12 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.lang.Object obj13 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(numberFormat12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot0.setOutlinePaint(paint3);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockContainer5.getMargin();
        java.lang.String str7 = rectangleInsets6.toString();
        double double8 = rectangleInsets6.getRight();
        multiplePiePlot0.setInsets(rectangleInsets6, true);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image12 = multiplePiePlot11.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        piePlot14.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset17 = piePlot14.getDataset();
        multiplePiePlot11.setParent((org.jfree.chart.plot.Plot) piePlot14);
        java.awt.Shape shape19 = piePlot14.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot14);
        java.awt.Paint paint21 = piePlot14.getBackgroundPaint();
        piePlot14.setSimpleLabels(true);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        piePlot25.setLabelLinksVisible(false);
        piePlot25.setLabelLinksVisible(true);
        boolean boolean30 = piePlot25.getSectionOutlinesVisible();
        piePlot25.setCircular(false, false);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color35 = color34.darker();
        piePlot25.setLabelOutlinePaint((java.awt.Paint) color34);
        piePlot14.setLabelShadowPaint((java.awt.Paint) color34);
        int int38 = color34.getAlpha();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color34);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str7.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(image12);
        org.junit.Assert.assertNull(pieDataset17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 255 + "'", int38 == 255);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot0.setOutlinePaint(paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        multiplePiePlot0.setInsets(rectangleInsets5, false);
        double double9 = rectangleInsets5.extendWidth((double) (-16777216));
        java.lang.String str10 = rectangleInsets5.toString();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.6777216E7d) + "'", double9 == (-1.6777216E7d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str10.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("UnitType.ABSOLUTE", "rect");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UnitType.ABSOLUTE" + "'", str3.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.String str4 = chartEntity2.getToolTipText();
        java.lang.String str5 = chartEntity2.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rect" + "'", str3.equals("rect"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartEntity: tooltip = " + "'", str5.equals("ChartEntity: tooltip = "));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        java.awt.Color color11 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Color color15 = color11.brighter();
        int int16 = color11.getRGB();
        piePlot3.setLabelShadowPaint((java.awt.Paint) color11);
        piePlot3.setLabelLinkMargin(0.4d);
        java.awt.Font font20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        piePlot3.setNoDataMessageFont(font20);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-16777216) + "'", int16 == (-16777216));
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}");
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot7.getDataset();
        java.awt.Stroke stroke11 = piePlot7.getLabelLinkStroke();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle14);
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockContainer16.getMargin();
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        double double20 = rectangleInsets17.trimHeight((double) 0.0f);
        double double21 = rectangleInsets17.getRight();
        double double23 = rectangleInsets17.calculateBottomInset(1.0E-5d);
        legendTitle14.setItemLabelPadding(rectangleInsets17);
        piePlot7.setInsets(rectangleInsets17);
        java.awt.Paint paint26 = piePlot7.getLabelOutlinePaint();
        double double27 = piePlot7.getInteriorGap();
        double double28 = piePlot7.getMaximumExplodePercent();
        java.awt.Color color29 = java.awt.Color.black;
        piePlot7.setNoDataMessagePaint((java.awt.Paint) color29);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.08d + "'", double27 == 0.08d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.lang.Object obj5 = defaultKeyedValues2D1.clone();
        int int6 = defaultKeyedValues2D1.getColumnCount();
        java.util.List list7 = defaultKeyedValues2D1.getColumnKeys();
        java.lang.Object obj8 = null;
        boolean boolean9 = defaultKeyedValues2D1.equals(obj8);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list6 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list7 = defaultKeyedValues2D1.getRowKeys();
        java.lang.Number number8 = null;
        defaultKeyedValues2D1.setValue(number8, (java.lang.Comparable) 'a', (java.lang.Comparable) 128);
        java.lang.Comparable comparable13 = defaultKeyedValues2D1.getColumnKey((int) (byte) 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 128 + "'", comparable13.equals(128));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        java.lang.String str4 = textTitle0.getURLText();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener7 = null;
        textTitle6.addChangeListener(titleChangeListener7);
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font11);
        java.awt.Paint paint14 = textTitle13.getPaint();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle13.getBounds();
        textTitle6.setBounds(rectangle2D15);
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockContainer17.getMargin();
        org.jfree.chart.util.UnitType unitType19 = rectangleInsets18.getUnitType();
        java.lang.String str20 = rectangleInsets18.toString();
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets18.getUnitType();
        java.lang.Object obj22 = textTitle0.draw(graphics2D5, rectangle2D15, (java.lang.Object) rectangleInsets18);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str20.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertNull(obj22);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.jfree.chart.LegendItemSource legendItemSource0 = null;
//        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
//        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
//        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
//        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer3.getMargin();
//        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
//        double double7 = rectangleInsets4.trimHeight((double) 0.0f);
//        double double8 = rectangleInsets4.getRight();
//        double double10 = rectangleInsets4.calculateBottomInset(1.0E-5d);
//        legendTitle1.setItemLabelPadding(rectangleInsets4);
//        org.jfree.chart.util.UnitType unitType12 = rectangleInsets4.getUnitType();
//        org.jfree.chart.ui.ProjectInfo projectInfo13 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image14 = projectInfo13.getLogo();
//        java.awt.Image image15 = projectInfo13.getLogo();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo16 = new org.jfree.chart.ui.BasicProjectInfo();
//        basicProjectInfo16.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        org.jfree.chart.ui.Library[] libraryArray19 = basicProjectInfo16.getOptionalLibraries();
//        org.jfree.chart.ui.Library[] libraryArray20 = basicProjectInfo16.getLibraries();
//        basicProjectInfo16.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        projectInfo13.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo16);
//        java.lang.String str24 = projectInfo13.getLicenceText();
//        boolean boolean25 = unitType12.equals((java.lang.Object) str24);
//        org.junit.Assert.assertNotNull(rectangleInsets4);
//        org.junit.Assert.assertNotNull(unitType5);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//        org.junit.Assert.assertNotNull(unitType12);
//        org.junit.Assert.assertNotNull(projectInfo13);
//        org.junit.Assert.assertNotNull(image14);
//        org.junit.Assert.assertNotNull(image15);
//        org.junit.Assert.assertNotNull(libraryArray19);
//        org.junit.Assert.assertNotNull(libraryArray20);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnitType.ABSOLUTE" + "'", str24.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Color color7 = color3.brighter();
        int int8 = color3.getRGB();
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.Plot plot10 = multiplePiePlot0.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = null;
        try {
            multiplePiePlot0.setInsets(rectangleInsets11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16777216) + "'", int8 == (-16777216));
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D2.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        int int7 = defaultKeyedValues2D2.getColumnIndex((java.lang.Comparable) 1L);
        boolean boolean8 = rotation0.equals((java.lang.Object) defaultKeyedValues2D2);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        java.awt.Color color4 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color4, jFreeChart5, chartChangeEventType6);
        java.awt.Color color8 = color4.brighter();
        int int9 = color4.getRGB();
        multiplePiePlot1.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot1.getParent();
        try {
            org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("Other", plot11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16777216) + "'", int9 == (-16777216));
        org.junit.Assert.assertNull(plot11);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray7 = new java.awt.Stroke[] { stroke4, stroke5, stroke6 };
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke8, stroke9 };
        java.awt.Shape[] shapeArray11 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray3, strokeArray7, strokeArray10, shapeArray11);
        java.awt.Stroke stroke13 = defaultDrawingSupplier12.getNextOutlineStroke();
        boolean boolean14 = pieLabelLinkStyle0.equals((java.lang.Object) stroke13);
        java.lang.String str15 = pieLabelLinkStyle0.toString();
        boolean boolean17 = pieLabelLinkStyle0.equals((java.lang.Object) "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str1.equals("PieLabelLinkStyle.QUAD_CURVE"));
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(strokeArray7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(shapeArray11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str15.equals("PieLabelLinkStyle.QUAD_CURVE"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        java.awt.Paint paint10 = piePlot1.getOutlinePaint();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            piePlot1.drawOutline(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        pieSectionEntity7.setPieIndex((int) (byte) -1);
        java.lang.String str10 = pieSectionEntity7.getToolTipText();
        java.lang.String str11 = pieSectionEntity7.getShapeCoords();
        int int12 = pieSectionEntity7.getSectionIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str10.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-4,-4,4,4" + "'", str11.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "");
        boolean boolean6 = standardPieSectionLabelGenerator0.equals((java.lang.Object) "");
        org.jfree.data.general.PieDataset pieDataset7 = null;
        java.lang.String str9 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset7, (java.lang.Comparable) ' ');
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "");
        boolean boolean6 = standardPieSectionLabelGenerator0.equals((java.lang.Object) "");
        org.jfree.data.general.PieDataset pieDataset7 = null;
        java.lang.String str9 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset7, (java.lang.Comparable) 0.0f);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle10 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        boolean boolean11 = standardPieSectionLabelGenerator0.equals((java.lang.Object) pieLabelLinkStyle10);
        java.text.AttributedString attributedString13 = standardPieSectionLabelGenerator0.getAttributedLabel(15);
        java.lang.String str14 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(attributedString13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0}" + "'", str14.equals("{0}"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        int int3 = objectList0.indexOf((java.lang.Object) "");
        objectList0.clear();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) objectList0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.lang.Object obj5 = piePlot1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot1.getLabelPadding();
        double double7 = piePlot1.getMaximumExplodePercent();
        boolean boolean8 = piePlot1.getLabelLinksVisible();
        java.awt.Image image9 = piePlot1.getBackgroundImage();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(image9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image4 = multiplePiePlot3.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset9 = piePlot6.getDataset();
        multiplePiePlot3.setParent((org.jfree.chart.plot.Plot) piePlot6);
        java.awt.Shape shape11 = piePlot6.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        java.awt.Color color13 = java.awt.Color.green;
        java.awt.Color color14 = java.awt.Color.GRAY;
        boolean boolean15 = color13.equals((java.lang.Object) color14);
        piePlot6.setLabelShadowPaint((java.awt.Paint) color14);
        java.lang.Object obj17 = piePlot6.clone();
        boolean boolean18 = defaultKeyedValues2D1.equals((java.lang.Object) piePlot6);
        try {
            defaultKeyedValues2D1.removeColumn(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot1.setOutlinePaint(paint4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart6.addProgressListener(chartProgressListener7);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo11);
        jFreeChart3.fireChartChanged();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image15 = multiplePiePlot14.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset20 = piePlot17.getDataset();
        multiplePiePlot14.setParent((org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor22 = piePlot17.getLabelDistributor();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color23);
        java.awt.Color color25 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
        java.awt.Color color29 = color25.brighter();
        java.awt.Color color30 = java.awt.Color.green;
        float[] floatArray36 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
        float[] floatArray38 = color25.getRGBColorComponents(floatArray37);
        float[] floatArray39 = color23.getComponents(floatArray37);
        piePlot17.setLabelLinkPaint((java.awt.Paint) color23);
        jFreeChart3.setBackgroundPaint((java.awt.Paint) color23);
        jFreeChart3.setTitle("");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent44 = null;
        try {
            jFreeChart3.titleChanged(titleChangeEvent44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNull(pieDataset20);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getNoDataMessagePaint();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        piePlot2.setSectionPaint((java.lang.Comparable) "LGPL", (java.awt.Paint) color5);
        java.awt.Color color7 = java.awt.Color.GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        java.awt.Color color12 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Color color16 = color12.brighter();
        java.awt.Color color17 = java.awt.Color.green;
        float[] floatArray23 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray24 = color17.getRGBColorComponents(floatArray23);
        float[] floatArray25 = color12.getRGBColorComponents(floatArray24);
        float[] floatArray26 = color10.getComponents(floatArray24);
        float[] floatArray27 = color7.getColorComponents(colorSpace9, floatArray26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot29.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = multiplePiePlot29.getInsets();
        org.jfree.chart.block.LineBorder lineBorder33 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke28, rectangleInsets32);
        piePlot2.setBaseSectionOutlineStroke(stroke28);
        multiplePiePlot0.setOutlineStroke(stroke28);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets32);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.awt.Color color1 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2, chartChangeEventType3);
        java.awt.Color color5 = color1.brighter();
        java.awt.Color color6 = java.awt.Color.green;
        float[] floatArray12 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray13 = color6.getRGBColorComponents(floatArray12);
        float[] floatArray14 = color1.getRGBColorComponents(floatArray13);
        boolean boolean15 = tableOrder0.equals((java.lang.Object) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) '4', (double) (short) 1, (double) (byte) 10);
        double double22 = rectangleInsets20.calculateBottomInset((double) '#');
        double double24 = rectangleInsets20.trimWidth((double) 8);
        boolean boolean25 = tableOrder0.equals((java.lang.Object) double24);
        java.lang.String str26 = tableOrder0.toString();
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-54.0d) + "'", double24 == (-54.0d));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TableOrder.BY_ROW" + "'", str26.equals("TableOrder.BY_ROW"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        double double3 = rectangleInsets1.calculateRightOutset(0.0d);
        double double5 = rectangleInsets1.calculateLeftInset((double) 3);
        double double6 = rectangleInsets1.getTop();
        double double7 = rectangleInsets1.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        jFreeChart3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart3.getTitle();
        jFreeChart3.setBackgroundImageAlpha(1.0f);
        jFreeChart3.setNotify(false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot17.setOutlineStroke(stroke18);
        java.awt.Paint paint20 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot17.setOutlinePaint(paint20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot17);
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape23, "");
        java.lang.String str26 = chartEntity25.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo27 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image28 = projectInfo27.getLogo();
        java.awt.Image image29 = projectInfo27.getLogo();
        boolean boolean30 = chartEntity25.equals((java.lang.Object) image29);
        jFreeChart22.setBackgroundImage(image29);
        jFreeChart3.setBackgroundImage(image29);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "-4,-4,4,4" + "'", str26.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo27);
        org.junit.Assert.assertNotNull(image28);
        org.junit.Assert.assertNotNull(image29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        java.awt.Shape shape6 = piePlot1.getLegendItemShape();
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.awt.Stroke stroke8 = piePlot1.getOutlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        java.awt.Paint paint10 = piePlot1.getBaseSectionOutlinePaint();
        piePlot1.setStartAngle((double) 1);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        int int5 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100L);
        java.util.List list6 = defaultCategoryDataset0.getColumnKeys();
        try {
            java.lang.Comparable comparable8 = defaultCategoryDataset0.getColumnKey((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener1 = null;
        textTitle0.addChangeListener(titleChangeListener1);
        boolean boolean3 = textTitle0.getExpandToFitSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle0.getMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        piePlot3.setShadowXOffset((double) '4');
        float float13 = piePlot3.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot3.getURLGenerator();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNull(pieURLGenerator14);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinkMargin(0.08d);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        piePlot5.setLabelLinksVisible(false);
        piePlot5.setLabelLinksVisible(true);
        boolean boolean10 = piePlot5.getSectionOutlinesVisible();
        piePlot5.setCircular(false, false);
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot5);
        piePlot5.setNoDataMessage("RectangleEdge.LEFT");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font7);
        java.lang.String str9 = textTitle8.getText();
        double double10 = textTitle8.getHeight();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle8);
        java.awt.Stroke stroke12 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart3.removeProgressListener(chartProgressListener13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        try {
            java.awt.image.BufferedImage bufferedImage20 = jFreeChart3.createBufferedImage((-16777216), (int) 'a', (double) 100, 24.0d, chartRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-16777216) and height (97) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        double double7 = legendTitle2.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle2.getLegendItemGraphicEdge();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Color color15 = color11.brighter();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = color11.getRGBColorComponents(floatArray23);
        float[] floatArray25 = color9.getComponents(floatArray23);
        boolean boolean26 = legendTitle2.equals((java.lang.Object) floatArray25);
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = legendTitle28.getLegendItemGraphicEdge();
        boolean boolean30 = legendTitle2.equals((java.lang.Object) rectangleEdge29);
        java.awt.Font font31 = legendTitle2.getItemFont();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        int int5 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100L);
        org.jfree.data.general.DatasetGroup datasetGroup6 = defaultCategoryDataset0.getGroup();
        defaultCategoryDataset0.validateObject();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(datasetGroup6);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font7);
        java.lang.String str9 = textTitle8.getText();
        double double10 = textTitle8.getHeight();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle8);
        textTitle8.setURLText("PieLabelLinkStyle.CUBIC_CURVE");
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color2 = java.awt.Color.cyan;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getMargin();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle7.getHorizontalAlignment();
        java.lang.Object obj9 = textTitle7.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle7);
        jFreeChart3.titleChanged(titleChangeEvent10);
        jFreeChart3.removeLegend();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        try {
            jFreeChart3.handleClick(10, (-16777216), chartRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int8 = pieSectionEntity7.getPieIndex();
        org.jfree.data.general.PieDataset pieDataset9 = pieSectionEntity7.getDataset();
        pieSectionEntity7.setURLText("java.awt.Color[r=255,g=0,b=255]");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNull(pieDataset9);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.util.List list10 = jFreeChart9.getSubtitles();
        jFreeChart9.setNotify(true);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockContainer13.getMargin();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean16 = blockContainer13.equals((java.lang.Object) color15);
        boolean boolean17 = blockContainer13.isEmpty();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot18.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart21 = multiplePiePlot18.getPieChart();
        jFreeChart21.setNotify(true);
        java.awt.Stroke stroke24 = jFreeChart21.getBorderStroke();
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = textTitle25.getHorizontalAlignment();
        java.lang.Object obj27 = textTitle25.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent28 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle25);
        jFreeChart21.titleChanged(titleChangeEvent28);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D31 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D31.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.util.List list35 = defaultKeyedValues2D31.getRowKeys();
        java.util.List list36 = defaultKeyedValues2D31.getRowKeys();
        jFreeChart21.setSubtitles(list36);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font41 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("", font41);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font41);
        boolean boolean44 = chartChangeEventType38.equals((java.lang.Object) font41);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockContainer13, jFreeChart21, chartChangeEventType38);
        boolean boolean46 = jFreeChart9.equals((java.lang.Object) blockContainer13);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jFreeChart21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.awt.Stroke stroke8 = piePlot1.getOutlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        java.awt.Paint paint10 = piePlot1.getBaseSectionOutlinePaint();
        double double11 = piePlot1.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        java.awt.Paint paint10 = piePlot6.getLabelOutlinePaint();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "");
        piePlot6.setLegendItemShape(shape11);
        java.lang.Object obj15 = piePlot6.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        jFreeChart3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart3.getTitle();
        jFreeChart3.setBackgroundImageAlpha(1.0f);
        jFreeChart3.setNotify(false);
        jFreeChart3.setBorderVisible(false);
        try {
            org.jfree.chart.title.Title title19 = jFreeChart3.getSubtitle((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textTitle11);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        java.util.List list4 = defaultCategoryDataset0.getRowKeys();
        int int5 = defaultCategoryDataset0.getColumnCount();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.lang.Object obj5 = defaultKeyedValues2D1.clone();
        java.util.List list6 = defaultKeyedValues2D1.getColumnKeys();
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (short) -1, (java.lang.Comparable) true);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot3.getLabelDistributor();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Color color15 = color11.brighter();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = color11.getRGBColorComponents(floatArray23);
        float[] floatArray25 = color9.getComponents(floatArray23);
        piePlot3.setLabelLinkPaint((java.awt.Paint) color9);
        piePlot3.zoom((double) 100L);
        java.awt.Stroke stroke30 = piePlot3.getSectionOutlineStroke((java.lang.Comparable) "Rotation.CLOCKWISE");
        java.awt.Paint paint32 = piePlot3.getSectionPaint((java.lang.Comparable) 1.0E-5d);
        java.awt.Paint paint34 = piePlot3.getSectionPaint((java.lang.Comparable) (short) 1);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNull(stroke30);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNull(paint34);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.PaintMap paintMap1 = new org.jfree.chart.PaintMap();
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font3);
        textTitle4.setNotify(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle4.setPaint((java.awt.Paint) color7);
        boolean boolean9 = paintMap1.equals((java.lang.Object) color7);
        java.awt.Color color10 = java.awt.Color.getColor("TableOrder.BY_ROW", color7);
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockContainer13.getMargin();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean16 = blockContainer13.equals((java.lang.Object) color15);
        double double17 = blockContainer13.getWidth();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle18.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment19, verticalAlignment20, (double) (short) 0, (double) (byte) 1);
        blockContainer13.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement23);
        org.jfree.chart.block.BlockContainer blockContainer25 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockContainer25.getMargin();
        double double28 = rectangleInsets26.calculateRightOutset(0.0d);
        double double30 = rectangleInsets26.calculateBottomInset((double) (byte) 0);
        blockContainer13.setMargin(rectangleInsets26);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener33 = null;
        textTitle32.addChangeListener(titleChangeListener33);
        java.awt.Font font37 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font37);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font37);
        java.awt.Paint paint40 = textTitle39.getPaint();
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle39.getBounds();
        textTitle32.setBounds(rectangle2D41);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets26.createAdjustedRectangle(rectangle2D41, lengthAdjustmentType43, lengthAdjustmentType44);
        java.awt.geom.AffineTransform affineTransform46 = null;
        java.awt.Font font48 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font48);
        java.lang.String str50 = textTitle49.getText();
        double double51 = textTitle49.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = textTitle49.getPosition();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot53 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot53.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart56 = multiplePiePlot53.getPieChart();
        jFreeChart56.setNotify(true);
        java.awt.Stroke stroke59 = jFreeChart56.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo64 = null;
        java.awt.image.BufferedImage bufferedImage65 = jFreeChart56.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo64);
        jFreeChart56.fireChartChanged();
        java.awt.RenderingHints renderingHints67 = jFreeChart56.getRenderingHints();
        textTitle49.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart56);
        java.awt.Color color69 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color70 = color69.darker();
        java.awt.image.ColorModel colorModel71 = null;
        java.awt.Rectangle rectangle72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        java.awt.geom.AffineTransform affineTransform74 = null;
        java.awt.RenderingHints renderingHints75 = null;
        java.awt.PaintContext paintContext76 = color70.createContext(colorModel71, rectangle72, rectangle2D73, affineTransform74, renderingHints75);
        jFreeChart56.setBackgroundPaint((java.awt.Paint) color70);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot78 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot78.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart81 = multiplePiePlot78.getPieChart();
        jFreeChart81.setNotify(true);
        java.awt.Stroke stroke84 = jFreeChart81.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo89 = null;
        java.awt.image.BufferedImage bufferedImage90 = jFreeChart81.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo89);
        jFreeChart81.fireChartChanged();
        java.awt.RenderingHints renderingHints92 = jFreeChart81.getRenderingHints();
        jFreeChart56.setRenderingHints(renderingHints92);
        java.awt.PaintContext paintContext94 = color10.createContext(colorModel11, rectangle12, rectangle2D45, affineTransform46, renderingHints92);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str50.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(jFreeChart56);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(bufferedImage65);
        org.junit.Assert.assertNotNull(renderingHints67);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(paintContext76);
        org.junit.Assert.assertNotNull(jFreeChart81);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(bufferedImage90);
        org.junit.Assert.assertNotNull(renderingHints92);
        org.junit.Assert.assertNotNull(paintContext94);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        piePlot1.drawBackgroundImage(graphics2D10, rectangle2D11);
        boolean boolean13 = piePlot1.getIgnoreNullValues();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot14.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart17 = multiplePiePlot14.getPieChart();
        jFreeChart17.setNotify(true);
        java.awt.Stroke stroke20 = jFreeChart17.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener21 = null;
        jFreeChart17.removeProgressListener(chartProgressListener21);
        jFreeChart17.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle25 = jFreeChart17.getTitle();
        jFreeChart17.setBackgroundImageAlpha(1.0f);
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        java.lang.Comparable comparable29 = null;
        try {
            double double30 = piePlot1.getExplodePercent(comparable29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(jFreeChart17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(textTitle25);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font5);
        java.lang.String str7 = textTitle6.getText();
        double double8 = textTitle6.getHeight();
        java.awt.Color color9 = java.awt.Color.GREEN;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color14, jFreeChart15, chartChangeEventType16);
        java.awt.Color color18 = color14.brighter();
        java.awt.Color color19 = java.awt.Color.green;
        float[] floatArray25 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray26 = color19.getRGBColorComponents(floatArray25);
        float[] floatArray27 = color14.getRGBColorComponents(floatArray26);
        float[] floatArray28 = color12.getComponents(floatArray26);
        float[] floatArray29 = color9.getColorComponents(colorSpace11, floatArray28);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot31.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = multiplePiePlot31.getInsets();
        org.jfree.chart.block.LineBorder lineBorder35 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke30, rectangleInsets34);
        java.awt.Paint paint36 = lineBorder35.getPaint();
        java.awt.Stroke stroke37 = lineBorder35.getStroke();
        try {
            blockContainer0.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) stroke37);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.awt.BasicStroke cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str7.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray10 = legendTitle8.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle8.getItemLabelPadding();
        boolean boolean12 = rectangleAnchor6.equals((java.lang.Object) legendTitle8);
        double double13 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle8.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle16);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray18 = legendTitle16.getSources();
        legendTitle8.setSources(legendItemSourceArray18);
        jFreeChart3.addLegend(legendTitle8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot21.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart24 = multiplePiePlot21.getPieChart();
        jFreeChart24.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = textTitle27.getHorizontalAlignment();
        java.lang.Object obj29 = textTitle27.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent30 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle27);
        jFreeChart24.titleChanged(titleChangeEvent30);
        java.awt.Font font33 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font33);
        java.lang.String str35 = textTitle34.getText();
        jFreeChart24.setTitle(textTitle34);
        org.jfree.chart.title.LegendTitle legendTitle38 = jFreeChart24.getLegend((int) (short) 0);
        legendTitle8.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart24);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.Font font42 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font42);
        java.lang.String str44 = textTitle43.getText();
        double double45 = textTitle43.getHeight();
        textTitle43.setURLText("RectangleEdge.LEFT");
        textTitle43.setToolTipText("");
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment51 = textTitle50.getHorizontalAlignment();
        java.lang.Object obj52 = textTitle50.clone();
        java.awt.Paint paint53 = textTitle50.getBackgroundPaint();
        textTitle50.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        textTitle50.setURLText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment58 = textTitle50.getHorizontalAlignment();
        textTitle43.setTextAlignment(horizontalAlignment58);
        java.awt.Graphics2D graphics2D60 = null;
        java.awt.Font font63 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font63);
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font63);
        java.awt.Paint paint66 = textTitle65.getPaint();
        java.awt.geom.Rectangle2D rectangle2D67 = textTitle65.getBounds();
        java.awt.Font font69 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font69);
        java.lang.String str71 = textTitle70.getText();
        java.lang.Object obj72 = textTitle43.draw(graphics2D60, rectangle2D67, (java.lang.Object) textTitle70);
        try {
            legendTitle8.draw(graphics2D40, rectangle2D67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(legendItemSourceArray10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(legendItemSourceArray18);
        org.junit.Assert.assertNotNull(jFreeChart24);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str35.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNull(legendTitle38);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str44.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment51);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertNotNull(horizontalAlignment58);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str71.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNull(obj72);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        piePlot1.drawBackgroundImage(graphics2D10, rectangle2D11);
        boolean boolean13 = piePlot1.getIgnoreNullValues();
        piePlot1.setPieIndex(8);
        boolean boolean16 = piePlot1.isSubplot();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("Rotation.CLOCKWISE");
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        try {
            java.lang.String str5 = jFreeChartResources0.getString("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(15, (-16777216), 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        java.awt.Paint paint6 = piePlot1.getBaseSectionOutlinePaint();
        double double8 = piePlot1.getExplodePercent((java.lang.Comparable) (-1));
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor((int) (short) 10, 8, 0);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) chartColor14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent19 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle18);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray20 = legendTitle18.getSources();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray23 = legendTitle22.getSources();
        legendTitle18.setSources(legendItemSourceArray23);
        java.awt.Font font25 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        legendTitle18.setItemFont(font25);
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle18.getBounds();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets16.createOutsetRectangle(rectangle2D27, false, true);
        piePlot1.drawBackgroundImage(graphics2D10, rectangle2D30);
        piePlot1.setBackgroundImageAlpha(0.0f);
        piePlot1.setCircular(false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(legendItemSourceArray20);
        org.junit.Assert.assertNotNull(legendItemSourceArray23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        java.awt.Image image2 = projectInfo0.getLogo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
        basicProjectInfo3.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        org.jfree.chart.ui.ProjectInfo projectInfo11 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image12 = projectInfo11.getLogo();
        java.util.List list13 = projectInfo11.getContributors();
        projectInfo0.setContributors(list13);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(image2);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertNotNull(projectInfo11);
        org.junit.Assert.assertNotNull(image12);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape3, "");
        java.lang.String str6 = chartEntity5.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image8 = projectInfo7.getLogo();
        java.awt.Image image9 = projectInfo7.getLogo();
        boolean boolean10 = chartEntity5.equals((java.lang.Object) image9);
        org.jfree.chart.ui.ProjectInfo projectInfo14 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "UnitType.ABSOLUTE", image9, "java.awt.Color[r=0,g=128,b=0]", "HorizontalAlignment.RIGHT", "ChartEntity: tooltip = ");
        projectInfo14.setName("");
        projectInfo14.setName("java.awt.Color[r=255,g=0,b=255]");
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-4,-4,4,4" + "'", str6.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(image8);
        org.junit.Assert.assertNotNull(image9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int8 = pieSectionEntity7.getPieIndex();
        org.jfree.data.general.PieDataset pieDataset9 = pieSectionEntity7.getDataset();
        int int10 = pieSectionEntity7.getPieIndex();
        java.awt.Shape shape11 = pieSectionEntity7.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "Other");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleEdge.TOP", "PieLabelLinkStyle.CUBIC_CURVE", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleEdge.LEFT");
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        piePlot1.drawBackgroundImage(graphics2D10, rectangle2D11);
        boolean boolean13 = piePlot1.getIgnoreNullValues();
        double double14 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer1.getMargin();
        boolean boolean3 = columnArrangement0.equals((java.lang.Object) blockContainer1);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer1.getMargin();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent8 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle7);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray9 = legendTitle7.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle7.getItemLabelPadding();
        boolean boolean11 = rectangleAnchor5.equals((java.lang.Object) legendTitle7);
        java.lang.Class<?> wildcardClass12 = legendTitle7.getClass();
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle7.getItemContainer();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot14.setLimit((double) '#');
        float float17 = multiplePiePlot14.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        multiplePiePlot14.addChangeListener(plotChangeListener18);
        java.awt.Image image20 = multiplePiePlot14.getBackgroundImage();
        blockContainer1.add((org.jfree.chart.block.Block) blockContainer13, (java.lang.Object) image20);
        java.lang.Object obj22 = blockContainer1.clone();
        double double23 = blockContainer1.getWidth();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(legendItemSourceArray9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape0, "http://www.jfree.org/jfreechart/index.html");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = multiplePiePlot0.getInsets();
        double double5 = rectangleInsets3.trimHeight((double) 100.0f);
        double double6 = rectangleInsets3.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 92.0d + "'", double5 == 92.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str5 = chartChangeEventType4.toString();
        chartChangeEvent1.setType(chartChangeEventType4);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) chartChangeEventType4);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        chartChangeEvent7.setChart(jFreeChart8);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        java.lang.Object obj8 = textTitle6.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle6);
        jFreeChart3.titleChanged(titleChangeEvent9);
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font12);
        java.lang.String str14 = textTitle13.getText();
        jFreeChart3.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart3.getLegend((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart3.getLegend(8);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getHorizontalAlignment();
        java.lang.Object obj22 = textTitle20.clone();
        jFreeChart3.setTitle(textTitle20);
        java.awt.Color color24 = java.awt.Color.MAGENTA;
        java.lang.String str25 = color24.toString();
        jFreeChart3.setBackgroundPaint((java.awt.Paint) color24);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str14.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNull(legendTitle17);
        org.junit.Assert.assertNull(legendTitle19);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=255,g=0,b=255]" + "'", str25.equals("java.awt.Color[r=255,g=0,b=255]"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener11 = null;
        textTitle10.addChangeListener(titleChangeListener11);
        jFreeChart9.setTitle(textTitle10);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer1.getMargin();
        boolean boolean3 = columnArrangement0.equals((java.lang.Object) blockContainer1);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer1.getMargin();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent8 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle7);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray9 = legendTitle7.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle7.getItemLabelPadding();
        boolean boolean11 = rectangleAnchor5.equals((java.lang.Object) legendTitle7);
        java.lang.Class<?> wildcardClass12 = legendTitle7.getClass();
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle7.getItemContainer();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot14.setLimit((double) '#');
        float float17 = multiplePiePlot14.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        multiplePiePlot14.addChangeListener(plotChangeListener18);
        java.awt.Image image20 = multiplePiePlot14.getBackgroundImage();
        blockContainer1.add((org.jfree.chart.block.Block) blockContainer13, (java.lang.Object) image20);
        blockContainer1.clear();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(legendItemSourceArray9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNull(image20);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.awt.Color color0 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        textTitle3.addChangeListener(titleChangeListener4);
        boolean boolean6 = textTitle3.getExpandToFitSpace();
        textTitle3.setToolTipText("java.awt.Color[r=0,g=128,b=0]");
        textTitle3.setMargin((-1.6777216E7d), (-1.0d), (double) (byte) 10, 0.08d);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle16);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray18 = legendTitle16.getSources();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray21 = legendTitle20.getSources();
        legendTitle16.setSources(legendItemSourceArray21);
        java.awt.Font font23 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        legendTitle16.setItemFont(font23);
        java.awt.geom.Rectangle2D rectangle2D25 = legendTitle16.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D25, rectangleEdge26);
        textTitle3.draw(graphics2D14, rectangle2D25);
        try {
            blockBorder1.draw(graphics2D2, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray18);
        org.junit.Assert.assertNotNull(legendItemSourceArray21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot3.getLabelDistributor();
        double double9 = piePlot3.getLabelLinkMargin();
        double double10 = piePlot3.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Font font13 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font13);
        java.lang.String str15 = textTitle14.getText();
        double double16 = textTitle14.getHeight();
        textTitle14.setURLText("RectangleEdge.LEFT");
        textTitle14.setToolTipText("");
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textTitle21.getHorizontalAlignment();
        java.lang.Object obj23 = textTitle21.clone();
        java.awt.Paint paint24 = textTitle21.getBackgroundPaint();
        textTitle21.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        textTitle21.setURLText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = textTitle21.getHorizontalAlignment();
        textTitle14.setTextAlignment(horizontalAlignment29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.Font font34 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font34);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font34);
        java.awt.Paint paint37 = textTitle36.getPaint();
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle36.getBounds();
        java.awt.Font font40 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font40);
        java.lang.String str42 = textTitle41.getText();
        java.lang.Object obj43 = textTitle14.draw(graphics2D31, rectangle2D38, (java.lang.Object) textTitle41);
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot(pieDataset44);
        piePlot45.setLabelLinksVisible(false);
        piePlot45.setLabelLinksVisible(true);
        boolean boolean50 = piePlot45.getSectionOutlinesVisible();
        piePlot45.setCircular(false, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        org.jfree.chart.plot.PiePlotState piePlotState56 = piePlot3.initialise(graphics2D11, rectangle2D38, piePlot45, (java.lang.Integer) 8, plotRenderingInfo55);
        org.jfree.chart.util.ObjectList objectList57 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.ui.Contributor contributor60 = new org.jfree.chart.ui.Contributor("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        int int61 = objectList57.indexOf((java.lang.Object) "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.awt.Font font65 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("", font65);
        org.jfree.chart.title.TextTitle textTitle67 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font65);
        org.jfree.data.general.PieDataset pieDataset68 = null;
        org.jfree.chart.plot.PiePlot piePlot69 = new org.jfree.chart.plot.PiePlot(pieDataset68);
        piePlot69.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset72 = piePlot69.getDataset();
        java.awt.Font font73 = piePlot69.getLabelFont();
        piePlot69.setMinimumArcAngleToDraw(0.0d);
        boolean boolean76 = textTitle67.equals((java.lang.Object) 0.0d);
        java.awt.Font font77 = textTitle67.getFont();
        objectList57.set((int) (short) 10, (java.lang.Object) font77);
        boolean boolean79 = piePlot3.equals((java.lang.Object) objectList57);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str15.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str42.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNull(obj43);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(piePlotState56);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNull(pieDataset72);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        java.awt.Stroke stroke10 = piePlot6.getBaseSectionOutlineStroke();
        org.jfree.data.general.DatasetGroup datasetGroup11 = piePlot6.getDatasetGroup();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(datasetGroup11);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray11 = legendTitle9.getSources();
        legendTitle2.setSources(legendItemSourceArray11);
        org.jfree.chart.block.BlockFrame blockFrame13 = legendTitle2.getFrame();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(legendItemSourceArray11);
        org.junit.Assert.assertNotNull(blockFrame13);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image11 = multiplePiePlot10.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset16 = piePlot13.getDataset();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) piePlot13);
        java.awt.Shape shape18 = piePlot13.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = jFreeChart19.getPadding();
        java.lang.Object obj21 = jFreeChart19.getTextAntiAlias();
        java.util.List list22 = jFreeChart19.getSubtitles();
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        java.awt.Color color24 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart25 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color24, jFreeChart25, chartChangeEventType26);
        java.awt.Color color28 = color24.brighter();
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color24);
        java.awt.Color color30 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color30, jFreeChart31, chartChangeEventType32);
        java.awt.Color color34 = color30.brighter();
        java.awt.Color color35 = color30.brighter();
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNull(pieDataset16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paintContext41);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (-1.0f));
        java.util.List list8 = defaultKeyedValues2D1.getColumnKeys();
        defaultKeyedValues2D1.setValue((java.lang.Number) (-1.0f), (java.lang.Comparable) "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) 192);
        java.util.List list13 = defaultKeyedValues2D1.getRowKeys();
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle7.getHorizontalAlignment();
        java.lang.Object obj9 = textTitle7.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle7);
        jFreeChart3.titleChanged(titleChangeEvent10);
        java.awt.Font font13 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("", font13);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font17);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle19.setVerticalAlignment(verticalAlignment20);
        textTitle14.setVerticalAlignment(verticalAlignment20);
        jFreeChart3.addSubtitle((org.jfree.chart.title.Title) textTitle14);
        java.lang.Object obj24 = textTitle14.clone();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo11);
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart3.addProgressListener(chartProgressListener13);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(bufferedImage12);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot7.getDataset();
        java.awt.Stroke stroke11 = piePlot7.getLabelLinkStroke();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle14);
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockContainer16.getMargin();
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        double double20 = rectangleInsets17.trimHeight((double) 0.0f);
        double double21 = rectangleInsets17.getRight();
        double double23 = rectangleInsets17.calculateBottomInset(1.0E-5d);
        legendTitle14.setItemLabelPadding(rectangleInsets17);
        piePlot7.setInsets(rectangleInsets17);
        java.awt.Paint paint26 = piePlot7.getLabelOutlinePaint();
        double double27 = piePlot7.getInteriorGap();
        boolean boolean28 = piePlot7.getSimpleLabels();
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.08d + "'", double27 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("LGPL");
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.awt.Paint[] paintArray0 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke2, stroke3, stroke4 };
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke6, stroke7 };
        java.awt.Shape[] shapeArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray5, strokeArray8, shapeArray9);
        java.awt.Paint paint11 = defaultDrawingSupplier10.getNextFillPaint();
        java.awt.Stroke stroke12 = defaultDrawingSupplier10.getNextStroke();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(shapeArray9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.lang.Object obj5 = defaultCategoryDataset0.clone();
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot7.getDataset();
        java.awt.Stroke stroke11 = piePlot7.getLabelLinkStroke();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        org.jfree.data.general.DatasetGroup datasetGroup13 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot14.setOutlineStroke(stroke15);
        java.awt.Color color17 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color17, jFreeChart18, chartChangeEventType19);
        java.awt.Color color21 = color17.brighter();
        int int22 = color17.getRGB();
        multiplePiePlot14.setNoDataMessagePaint((java.awt.Paint) color17);
        multiplePiePlot14.setBackgroundImageAlpha((float) 0L);
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray31 = new java.awt.Stroke[] { stroke28, stroke29, stroke30 };
        java.awt.Stroke stroke32 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke32, stroke33 };
        java.awt.Shape[] shapeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray26, paintArray27, strokeArray31, strokeArray34, shapeArray35);
        java.awt.Paint paint37 = defaultDrawingSupplier36.getNextFillPaint();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font41 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("", font41);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font41);
        boolean boolean44 = chartChangeEventType38.equals((java.lang.Object) font41);
        boolean boolean45 = defaultDrawingSupplier36.equals((java.lang.Object) boolean44);
        java.awt.Stroke stroke46 = defaultDrawingSupplier36.getNextOutlineStroke();
        multiplePiePlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier36);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot14);
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer50 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = blockContainer50.getMargin();
        boolean boolean52 = columnArrangement49.equals((java.lang.Object) blockContainer50);
        org.jfree.chart.block.Arrangement arrangement53 = null;
        org.jfree.chart.title.LegendTitle legendTitle54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot14, (org.jfree.chart.block.Arrangement) columnArrangement49, arrangement53);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(datasetGroup13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16777216) + "'", int22 == (-16777216));
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(shapeArray35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        float float3 = multiplePiePlot0.getBackgroundImageAlpha();
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image5 = projectInfo4.getLogo();
        java.awt.Image image6 = projectInfo4.getLogo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo7.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray10 = basicProjectInfo7.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray11 = basicProjectInfo7.getLibraries();
        basicProjectInfo7.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        projectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo7);
        boolean boolean15 = multiplePiePlot0.equals((java.lang.Object) basicProjectInfo7);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset16.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16);
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertNotNull(image5);
        org.junit.Assert.assertNotNull(image6);
        org.junit.Assert.assertNotNull(libraryArray10);
        org.junit.Assert.assertNotNull(libraryArray11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray2 = legendTitle1.getSources();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = legendTitle4.getSources();
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle1.getPadding();
        org.junit.Assert.assertNotNull(legendItemSourceArray2);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle4.setVerticalAlignment(verticalAlignment5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        piePlot8.setLabelLinksVisible(false);
        java.awt.Stroke stroke12 = piePlot8.getSectionOutlineStroke((java.lang.Comparable) 'a');
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockContainer13.getMargin();
        double double16 = rectangleInsets14.calculateRightOutset(0.0d);
        piePlot8.setSimpleLabelOffset(rectangleInsets14);
        textTitle4.setPadding(rectangleInsets14);
        double double20 = rectangleInsets14.calculateRightInset((double) 3);
        org.jfree.chart.ChartColor chartColor24 = new org.jfree.chart.ChartColor((int) (short) 10, 8, 0);
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) chartColor24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockBorder25.getInsets();
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent29 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle28);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray30 = legendTitle28.getSources();
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray33 = legendTitle32.getSources();
        legendTitle28.setSources(legendItemSourceArray33);
        java.awt.Font font35 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        legendTitle28.setItemFont(font35);
        java.awt.geom.Rectangle2D rectangle2D37 = legendTitle28.getBounds();
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets26.createOutsetRectangle(rectangle2D37, false, true);
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets14.createOutsetRectangle(rectangle2D37);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(legendItemSourceArray30);
        org.junit.Assert.assertNotNull(legendItemSourceArray33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D41);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.lang.String str8 = piePlot1.getNoDataMessage();
        double double9 = piePlot1.getStartAngle();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 90.0d + "'", double9 == 90.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.lang.Object obj5 = piePlot1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot1.getLabelPadding();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator7);
        java.awt.Paint paint9 = piePlot1.getLabelOutlinePaint();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.awt.Color color0 = java.awt.Color.BLUE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        float[] floatArray10 = new float[] { '#', (-1), (byte) 100, (byte) 100, (byte) 1 };
        float[] floatArray11 = color4.getRGBComponents(floatArray10);
        float[] floatArray12 = java.awt.Color.RGBtoHSB(3, (int) (short) 1, 0, floatArray10);
        float[] floatArray13 = color0.getRGBComponents(floatArray10);
        java.awt.Font font16 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font16);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font16);
        java.awt.Paint paint19 = textTitle18.getPaint();
        boolean boolean20 = color0.equals((java.lang.Object) paint19);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.lang.Object obj5 = defaultKeyedValues2D1.clone();
        java.util.List list6 = defaultKeyedValues2D1.getRowKeys();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        textTitle7.draw(graphics2D8, rectangle2D9);
        textTitle7.setURLText("ChartEntity: tooltip = ");
        boolean boolean13 = defaultKeyedValues2D1.equals((java.lang.Object) "ChartEntity: tooltip = ");
        try {
            java.lang.Comparable comparable15 = defaultKeyedValues2D1.getColumnKey(192);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 192, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo11);
        jFreeChart3.fireChartChanged();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image15 = multiplePiePlot14.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset20 = piePlot17.getDataset();
        multiplePiePlot14.setParent((org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor22 = piePlot17.getLabelDistributor();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color23);
        java.awt.Color color25 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
        java.awt.Color color29 = color25.brighter();
        java.awt.Color color30 = java.awt.Color.green;
        float[] floatArray36 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
        float[] floatArray38 = color25.getRGBColorComponents(floatArray37);
        float[] floatArray39 = color23.getComponents(floatArray37);
        piePlot17.setLabelLinkPaint((java.awt.Paint) color23);
        jFreeChart3.setBackgroundPaint((java.awt.Paint) color23);
        jFreeChart3.setTitle("");
        org.jfree.chart.title.TextTitle textTitle44 = jFreeChart3.getTitle();
        java.lang.String str45 = textTitle44.getURLText();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNull(pieDataset20);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(textTitle44);
        org.junit.Assert.assertNull(str45);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test358");
//        java.awt.Paint[] paintArray0 = new java.awt.Paint[] {};
//        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
//        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
//        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
//        java.awt.Stroke stroke4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
//        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke2, stroke3, stroke4 };
//        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
//        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
//        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke6, stroke7 };
//        java.awt.Shape[] shapeArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray5, strokeArray8, shapeArray9);
//        java.awt.Paint paint11 = defaultDrawingSupplier10.getNextFillPaint();
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
//        java.awt.Font font15 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
//        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("", font15);
//        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font15);
//        boolean boolean18 = chartChangeEventType12.equals((java.lang.Object) font15);
//        boolean boolean19 = defaultDrawingSupplier10.equals((java.lang.Object) boolean18);
//        java.awt.Stroke stroke20 = defaultDrawingSupplier10.getNextStroke();
//        org.jfree.chart.ui.ProjectInfo projectInfo21 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image22 = projectInfo21.getLogo();
//        java.awt.Image image23 = projectInfo21.getLogo();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo24 = new org.jfree.chart.ui.BasicProjectInfo();
//        basicProjectInfo24.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        org.jfree.chart.ui.Library[] libraryArray27 = basicProjectInfo24.getOptionalLibraries();
//        org.jfree.chart.ui.Library[] libraryArray28 = basicProjectInfo24.getLibraries();
//        basicProjectInfo24.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        projectInfo21.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
//        java.lang.String str32 = projectInfo21.getLicenceText();
//        java.lang.String str33 = projectInfo21.getName();
//        boolean boolean34 = defaultDrawingSupplier10.equals((java.lang.Object) str33);
//        java.awt.Paint paint35 = defaultDrawingSupplier10.getNextFillPaint();
//        java.awt.Stroke stroke36 = defaultDrawingSupplier10.getNextOutlineStroke();
//        org.junit.Assert.assertNotNull(paintArray0);
//        org.junit.Assert.assertNotNull(paintArray1);
//        org.junit.Assert.assertNotNull(stroke2);
//        org.junit.Assert.assertNotNull(stroke3);
//        org.junit.Assert.assertNotNull(stroke4);
//        org.junit.Assert.assertNotNull(strokeArray5);
//        org.junit.Assert.assertNotNull(stroke6);
//        org.junit.Assert.assertNotNull(stroke7);
//        org.junit.Assert.assertNotNull(strokeArray8);
//        org.junit.Assert.assertNotNull(shapeArray9);
//        org.junit.Assert.assertNotNull(paint11);
//        org.junit.Assert.assertNotNull(chartChangeEventType12);
//        org.junit.Assert.assertNotNull(font15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(stroke20);
//        org.junit.Assert.assertNotNull(projectInfo21);
//        org.junit.Assert.assertNotNull(image22);
//        org.junit.Assert.assertNotNull(image23);
//        org.junit.Assert.assertNotNull(libraryArray27);
//        org.junit.Assert.assertNotNull(libraryArray28);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "UnitType.ABSOLUTE" + "'", str32.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str33.equals("http://www.jfree.org/jfreechart/index.html"));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(paint35);
//        org.junit.Assert.assertNotNull(stroke36);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.lang.Object obj5 = piePlot1.clone();
        java.awt.Paint paint6 = piePlot1.getLabelShadowPaint();
        piePlot1.setNoDataMessage("rect");
        java.awt.Paint paint9 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle11 = null;
        try {
            piePlot3.setLabelLinkStyle(pieLabelLinkStyle11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'style' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        piePlot1.setSectionPaint((java.lang.Comparable) "LGPL", (java.awt.Paint) color4);
        java.awt.Color color6 = java.awt.Color.GREEN;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Color color15 = color11.brighter();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = color11.getRGBColorComponents(floatArray23);
        float[] floatArray25 = color9.getComponents(floatArray23);
        float[] floatArray26 = color6.getColorComponents(colorSpace8, floatArray25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot28.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = multiplePiePlot28.getInsets();
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke27, rectangleInsets31);
        piePlot1.setBaseSectionOutlineStroke(stroke27);
        java.awt.Paint paint34 = piePlot1.getShadowPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinkMargin(0.08d);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        piePlot1.setMaximumLabelWidth(24.0d);
        piePlot1.setIgnoreNullValues(false);
        boolean boolean10 = piePlot1.getIgnoreZeroValues();
        java.lang.Comparable comparable11 = null;
        try {
            java.awt.Paint paint12 = piePlot1.getSectionPaint(comparable11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment2);
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, (double) 2, 35.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        jFreeChart3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.ChartChangeListener chartChangeListener11 = null;
        try {
            jFreeChart3.addChangeListener(chartChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        int int3 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        java.awt.Paint paint10 = piePlot6.getLabelOutlinePaint();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "");
        piePlot6.setLegendItemShape(shape11);
        java.awt.Paint paint15 = piePlot6.getOutlinePaint();
        piePlot6.setMinimumArcAngleToDraw((double) '4');
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setLabelLinkMargin((double) (short) 100);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        java.awt.color.ColorSpace colorSpace12 = color10.getColorSpace();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = java.awt.Color.RGBtoHSB((-16777216), (int) (byte) 100, (int) (short) 100, floatArray23);
        float[] floatArray25 = color9.getColorComponents(colorSpace12, floatArray24);
        piePlot1.setShadowPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot27.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart30 = multiplePiePlot27.getPieChart();
        jFreeChart30.setNotify(true);
        java.awt.Stroke stroke33 = jFreeChart30.getBorderStroke();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = blockContainer35.getMargin();
        boolean boolean37 = columnArrangement34.equals((java.lang.Object) blockContainer35);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = blockContainer35.getMargin();
        org.jfree.chart.block.LineBorder lineBorder39 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke33, rectangleInsets38);
        java.awt.Color color40 = color9.darker();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(jFreeChart30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(color40);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test368");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = projectInfo0.getLogo();
//        java.util.List list2 = projectInfo0.getContributors();
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image4 = projectInfo3.getLogo();
//        java.util.List list5 = projectInfo3.getContributors();
//        java.awt.Image image6 = projectInfo3.getLogo();
//        projectInfo0.setLogo(image6);
//        projectInfo0.addOptionalLibrary("UnitType.ABSOLUTE");
//        java.lang.String str10 = projectInfo0.toString();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(image1);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertNotNull(image4);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertNotNull(image6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "http://www.jfree.org/jfreechart/index.html version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:TableOrder.BY_ROW\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY http://www.jfree.org/jfreechart/index.html:None\nhttp://www.jfree.org/jfreechart/index.html LICENCE TERMS:\nUnitType.ABSOLUTE" + "'", str10.equals("http://www.jfree.org/jfreechart/index.html version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:TableOrder.BY_ROW\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY http://www.jfree.org/jfreechart/index.html:None\nhttp://www.jfree.org/jfreechart/index.html LICENCE TERMS:\nUnitType.ABSOLUTE"));
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = multiplePiePlot0.getInsets();
        java.awt.Paint paint4 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset9 = piePlot6.getDataset();
        java.awt.Font font10 = piePlot6.getLabelFont();
        piePlot6.setMinimumArcAngleToDraw(0.0d);
        java.awt.Stroke stroke13 = piePlot6.getOutlineStroke();
        multiplePiePlot0.setOutlineStroke(stroke13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = multiplePiePlot0.getDataset();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        multiplePiePlot0.setOutlinePaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(categoryDataset15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        java.awt.Stroke stroke10 = piePlot6.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image12 = multiplePiePlot11.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        piePlot14.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset17 = piePlot14.getDataset();
        multiplePiePlot11.setParent((org.jfree.chart.plot.Plot) piePlot14);
        java.awt.Shape shape19 = piePlot14.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot14);
        java.awt.Color color21 = java.awt.Color.green;
        java.awt.Color color22 = java.awt.Color.GRAY;
        boolean boolean23 = color21.equals((java.lang.Object) color22);
        piePlot14.setLabelShadowPaint((java.awt.Paint) color22);
        piePlot6.setLabelOutlinePaint((java.awt.Paint) color22);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(image12);
        org.junit.Assert.assertNull(pieDataset17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        double double10 = piePlot3.getStartAngle();
        java.awt.Paint paint11 = piePlot3.getOutlinePaint();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart9.clearSubtitles();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        piePlot12.setLabelLinksVisible(false);
        piePlot12.setLabelLinksVisible(true);
        boolean boolean17 = piePlot12.getSectionOutlinesVisible();
        piePlot12.setLabelLinkMargin((double) (short) 100);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace22 = color21.getColorSpace();
        java.awt.color.ColorSpace colorSpace23 = color21.getColorSpace();
        java.awt.Color color27 = java.awt.Color.green;
        float[] floatArray33 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray34 = color27.getRGBColorComponents(floatArray33);
        float[] floatArray35 = java.awt.Color.RGBtoHSB((-16777216), (int) (byte) 100, (int) (short) 100, floatArray34);
        float[] floatArray36 = color20.getColorComponents(colorSpace23, floatArray35);
        piePlot12.setShadowPaint((java.awt.Paint) color20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.plot.Plot plot39 = plotChangeEvent38.getPlot();
        jFreeChart9.plotChanged(plotChangeEvent38);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(colorSpace22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(plot39);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        textTitle2.setPadding((double) (byte) -1, (double) 10, (double) 10L, (double) 2);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image11 = projectInfo10.getLogo();
        java.util.List list12 = projectInfo10.getContributors();
        java.lang.Object obj13 = textTitle2.draw(graphics2D8, rectangle2D9, (java.lang.Object) projectInfo10);
        org.jfree.chart.ui.Library[] libraryArray14 = projectInfo10.getOptionalLibraries();
        java.util.List list15 = projectInfo10.getContributors();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(projectInfo10);
        org.junit.Assert.assertNotNull(image11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(libraryArray14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer3.getMargin();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean6 = blockContainer3.equals((java.lang.Object) color5);
        double double7 = blockContainer3.getWidth();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle8.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment10, (double) (short) 0, (double) (byte) 1);
        blockContainer3.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement13);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockContainer15.getMargin();
        double double18 = rectangleInsets16.calculateRightOutset(0.0d);
        double double20 = rectangleInsets16.calculateBottomInset((double) (byte) 0);
        blockContainer3.setMargin(rectangleInsets16);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener23 = null;
        textTitle22.addChangeListener(titleChangeListener23);
        java.awt.Font font27 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font27);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font27);
        java.awt.Paint paint30 = textTitle29.getPaint();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle29.getBounds();
        textTitle22.setBounds(rectangle2D31);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets16.createAdjustedRectangle(rectangle2D31, lengthAdjustmentType33, lengthAdjustmentType34);
        legendTitle1.setBounds(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.plot.Plot plot7 = null;
        piePlot1.setParent(plot7);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        java.awt.Color color12 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Color color16 = color12.brighter();
        int int17 = color12.getRGB();
        multiplePiePlot9.setNoDataMessagePaint((java.awt.Paint) color12);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color12);
        double double20 = piePlot1.getStartAngle();
        java.awt.Paint paint21 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.ChartColor chartColor25 = new org.jfree.chart.ChartColor((int) (short) 10, 8, 0);
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) chartColor25);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor25);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-16777216) + "'", int17 == (-16777216));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 90.0d + "'", double20 == 90.0d);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        try {
            piePlot3.setInteriorGap((double) (-4145152));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (-4145152.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 100, (float) 15, (float) (-4145152));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Rotation.CLOCKWISE", "TableOrder.BY_COLUMN");
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.plot.Plot plot7 = null;
        piePlot1.setParent(plot7);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        java.awt.Color color12 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Color color16 = color12.brighter();
        int int17 = color12.getRGB();
        multiplePiePlot9.setNoDataMessagePaint((java.awt.Paint) color12);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = piePlot1.getLegendLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-16777216) + "'", int17 == (-16777216));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator20);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.lang.String str9 = color8.toString();
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (short) 10, (java.awt.Paint) color8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=0,g=128,b=0]" + "'", str9.equals("java.awt.Color[r=0,g=128,b=0]"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 97, 10(100)" + "'", str8.equals("PieSection: 97, 10(100)"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.awt.Paint paint8 = piePlot1.getLabelLinkPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Color color15 = color11.brighter();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = color11.getRGBColorComponents(floatArray23);
        float[] floatArray25 = color9.getComponents(floatArray23);
        piePlot1.setLabelLinkPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str1 = horizontalAlignment0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = horizontalAlignment0.equals(obj2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment4, (-54.0d), 100.0d);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray11 = legendTitle9.getSources();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray14 = legendTitle13.getSources();
        legendTitle9.setSources(legendItemSourceArray14);
        java.awt.Font font16 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        legendTitle9.setItemFont(font16);
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle9.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D18, rectangleEdge19);
        boolean boolean21 = flowArrangement7.equals((java.lang.Object) double20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent25 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle24);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle24.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle24.getItemLabelPadding();
        boolean boolean28 = rectangleAnchor22.equals((java.lang.Object) legendTitle24);
        java.lang.Class<?> wildcardClass29 = legendTitle24.getClass();
        org.jfree.chart.block.BlockContainer blockContainer30 = legendTitle24.getItemContainer();
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent33 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle32);
        java.lang.Object obj34 = legendTitle32.clone();
        boolean boolean35 = blockContainer30.equals((java.lang.Object) legendTitle32);
        org.jfree.chart.block.ColumnArrangement columnArrangement36 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer37 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = blockContainer37.getMargin();
        boolean boolean39 = columnArrangement36.equals((java.lang.Object) blockContainer37);
        org.jfree.chart.block.ColumnArrangement columnArrangement40 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = blockContainer41.getMargin();
        boolean boolean43 = columnArrangement40.equals((java.lang.Object) blockContainer41);
        blockContainer37.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement40);
        columnArrangement40.clear();
        flowArrangement7.add((org.jfree.chart.block.Block) blockContainer30, (java.lang.Object) columnArrangement40);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str1.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray11);
        org.junit.Assert.assertNotNull(legendItemSourceArray14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(blockContainer30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot3.getDrawingSupplier();
        java.awt.Paint paint9 = piePlot3.getLabelOutlinePaint();
        piePlot3.setIgnoreNullValues(true);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener1 = null;
        textTitle0.addChangeListener(titleChangeListener1);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font5);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font5);
        java.awt.Paint paint8 = textTitle7.getPaint();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle7.getBounds();
        textTitle0.setBounds(rectangle2D9);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset11.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        org.jfree.data.general.DatasetGroup datasetGroup17 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle18.getHorizontalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        java.awt.Paint paint21 = textTitle18.getBackgroundPaint();
        textTitle18.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        boolean boolean24 = datasetGroup17.equals((java.lang.Object) textTitle18);
        defaultCategoryDataset11.setGroup(datasetGroup17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangle2D9, (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity8 = new org.jfree.chart.entity.PieSectionEntity(shape1, pieDataset2, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        java.lang.String str9 = pieSectionEntity8.toString();
        org.jfree.data.general.PieDataset pieDataset10 = pieSectionEntity8.getDataset();
        boolean boolean11 = color0.equals((java.lang.Object) pieDataset10);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PieSection: 97, 10(100)" + "'", str9.equals("PieSection: 97, 10(100)"));
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.util.List list10 = jFreeChart9.getSubtitles();
        jFreeChart9.setNotify(true);
        org.jfree.chart.event.ChartChangeListener chartChangeListener13 = null;
        try {
            jFreeChart9.removeChangeListener(chartChangeListener13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        int int5 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 100L);
        java.util.List list6 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.addValue((java.lang.Number) 35.0d, (java.lang.Comparable) 128, (java.lang.Comparable) (byte) -1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "");
        boolean boolean6 = standardPieSectionLabelGenerator0.equals((java.lang.Object) "");
        org.jfree.data.general.PieDataset pieDataset7 = null;
        java.lang.String str9 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset7, (java.lang.Comparable) 0.0f);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color13);
        java.awt.Color color15 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color15, jFreeChart16, chartChangeEventType17);
        java.awt.Color color19 = color15.brighter();
        java.awt.Color color20 = java.awt.Color.green;
        float[] floatArray26 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray27 = color20.getRGBColorComponents(floatArray26);
        float[] floatArray28 = color15.getRGBColorComponents(floatArray27);
        float[] floatArray29 = color13.getComponents(floatArray27);
        float[] floatArray30 = color10.getColorComponents(colorSpace12, floatArray29);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot32.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = multiplePiePlot32.getInsets();
        org.jfree.chart.block.LineBorder lineBorder36 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke31, rectangleInsets35);
        java.awt.Paint paint37 = lineBorder36.getPaint();
        java.awt.Paint paint38 = lineBorder36.getPaint();
        boolean boolean39 = standardPieSectionLabelGenerator0.equals((java.lang.Object) paint38);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        pieSectionEntity7.setPieIndex((int) (byte) -1);
        java.lang.String str10 = pieSectionEntity7.getToolTipText();
        java.lang.String str11 = pieSectionEntity7.getShapeCoords();
        java.lang.Comparable comparable12 = pieSectionEntity7.getSectionKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str10.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-4,-4,4,4" + "'", str11.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100L + "'", comparable12.equals(100L));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        pieLabelDistributor1.distributeLabels(8.0d, (double) (short) 0);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord6 = pieLabelDistributor1.getPieLabelRecord(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Paint paint10 = piePlot3.getBackgroundPaint();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle11.getHorizontalAlignment();
        java.lang.Object obj13 = textTitle11.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle11);
        java.lang.Object obj15 = textTitle11.clone();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = color16.darker();
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color17.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints22);
        boolean boolean24 = textTitle11.equals((java.lang.Object) color17);
        piePlot3.setBaseSectionPaint((java.awt.Paint) color17);
        int int26 = color17.getAlpha();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintContext23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 255 + "'", int26 == 255);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot3.getLabelDistributor();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Color color15 = color11.brighter();
        java.awt.Color color16 = java.awt.Color.green;
        float[] floatArray22 = new float[] { 1, 0.5f, (-1), (short) -1, (byte) 1 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = color11.getRGBColorComponents(floatArray23);
        float[] floatArray25 = color9.getComponents(floatArray23);
        piePlot3.setLabelLinkPaint((java.awt.Paint) color9);
        piePlot3.zoom((double) 100L);
        java.awt.Stroke stroke30 = piePlot3.getSectionOutlineStroke((java.lang.Comparable) "Rotation.CLOCKWISE");
        java.awt.Paint paint32 = piePlot3.getSectionPaint((java.lang.Comparable) 1.0E-5d);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot34 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot34.setLimit((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = multiplePiePlot34.getInsets();
        java.awt.Paint paint38 = multiplePiePlot34.getAggregatedItemsPaint();
        piePlot3.setSectionOutlinePaint((java.lang.Comparable) "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", paint38);
        double double40 = piePlot3.getMaximumLabelWidth();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNull(stroke30);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.14d + "'", double40 == 0.14d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) (short) 0, (double) (byte) 1);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockContainer6.getMargin();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean9 = blockContainer6.equals((java.lang.Object) color8);
        double double10 = blockContainer6.getWidth();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle11.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, (double) (short) 0, (double) (byte) 1);
        blockContainer6.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement16);
        java.lang.Object obj18 = blockContainer6.clone();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray21 = legendTitle20.getSources();
        boolean boolean22 = blockContainer6.equals((java.lang.Object) legendItemSourceArray21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = null;
        try {
            org.jfree.chart.util.Size2D size2D25 = flowArrangement5.arrange(blockContainer6, graphics2D23, rectangleConstraint24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(legendItemSourceArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray11 = legendTitle9.getSources();
        legendTitle2.setSources(legendItemSourceArray11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle2.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle2.getPadding();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(legendItemSourceArray11);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.ChartColor chartColor4 = new org.jfree.chart.ChartColor((int) (short) 10, 8, 0);
        boolean boolean5 = rectangleAnchor0.equals((java.lang.Object) chartColor4);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        java.awt.Font font6 = piePlot1.getLabelFont();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image9 = multiplePiePlot8.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset14 = piePlot11.getDataset();
        multiplePiePlot8.setParent((org.jfree.chart.plot.Plot) piePlot11);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextFillPaint();
        piePlot11.setSectionOutlinePaint((java.lang.Comparable) "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", paint18);
        piePlot1.setSectionPaint((java.lang.Comparable) "Other", paint18);
        java.awt.Paint paint21 = piePlot1.getOutlinePaint();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNull(pieDataset14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.String str3 = unknownKeyException1.toString();
        org.jfree.data.UnknownKeyException unknownKeyException5 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException5);
        java.lang.String str7 = unknownKeyException5.toString();
        java.lang.String str8 = unknownKeyException5.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str2.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str7.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str8.equals("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setExpandToFitSpace(false);
        textTitle0.setPadding((double) (byte) -1, (double) 1L, 0.0d, (double) 100.0f);
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (short) 10, 8, 0);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) chartColor11);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment13, verticalAlignment14, (double) (-16777216), (double) 10L);
        boolean boolean18 = blockBorder12.equals((java.lang.Object) verticalAlignment14);
        textTitle0.setVerticalAlignment(verticalAlignment14);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        piePlot21.setLabelLinksVisible(false);
        piePlot21.setLabelLinksVisible(true);
        boolean boolean26 = piePlot21.getSectionOutlinesVisible();
        org.jfree.chart.plot.Plot plot27 = null;
        piePlot21.setParent(plot27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot29.setOutlineStroke(stroke30);
        java.awt.Color color32 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart33 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color32, jFreeChart33, chartChangeEventType34);
        java.awt.Color color36 = color32.brighter();
        int int37 = color32.getRGB();
        multiplePiePlot29.setNoDataMessagePaint((java.awt.Paint) color32);
        piePlot21.setLabelBackgroundPaint((java.awt.Paint) color32);
        boolean boolean40 = verticalAlignment14.equals((java.lang.Object) color32);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-16777216) + "'", int37 == (-16777216));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.lang.Object obj2 = legendTitle1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot1.setOutlinePaint(paint4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        java.awt.Image image7 = multiplePiePlot1.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = multiplePiePlot1.getPieChart();
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = null;
        chartChangeEvent10.setType(chartChangeEventType11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot13.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot13.getPieChart();
        jFreeChart16.setNotify(true);
        java.awt.Stroke stroke19 = jFreeChart16.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        java.awt.image.BufferedImage bufferedImage25 = jFreeChart16.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo24);
        float float26 = jFreeChart16.getBackgroundImageAlpha();
        chartChangeEvent10.setChart(jFreeChart16);
        org.jfree.chart.ui.Contributor contributor30 = new org.jfree.chart.ui.Contributor("UnitType.ABSOLUTE", "rect");
        boolean boolean31 = jFreeChart16.equals((java.lang.Object) "UnitType.ABSOLUTE");
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle();
        textTitle32.setExpandToFitSpace(false);
        textTitle32.setPadding((double) (byte) -1, (double) 1L, 0.0d, (double) 100.0f);
        jFreeChart16.setTitle(textTitle32);
        jFreeChart8.setTitle(textTitle32);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(jFreeChart8);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(bufferedImage25);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block2 = null;
        columnArrangement1.add(block2, (java.lang.Object) 0L);
        columnArrangement1.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockContainer7.getMargin();
        boolean boolean9 = columnArrangement6.equals((java.lang.Object) blockContainer7);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement6);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        piePlot12.setLabelLinksVisible(false);
        piePlot12.setLabelLinksVisible(true);
        boolean boolean17 = piePlot12.getSectionOutlinesVisible();
        boolean boolean18 = columnArrangement6.equals((java.lang.Object) piePlot12);
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 10, (double) ' ');
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment5);
        java.lang.String str7 = verticalAlignment5.toString();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        float[] floatArray17 = new float[] { '#', (-1), (byte) 100, (byte) 100, (byte) 1 };
        float[] floatArray18 = color11.getRGBComponents(floatArray17);
        float[] floatArray19 = java.awt.Color.RGBtoHSB(3, (int) (short) 1, 0, floatArray17);
        boolean boolean20 = verticalAlignment5.equals((java.lang.Object) 3);
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment5, (double) (byte) 10, 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "VerticalAlignment.CENTER" + "'", str7.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getNumberFormat();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator0.getNumberFormat();
        java.text.NumberFormat numberFormat3 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        textTitle2.setNotify(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle2.setPaint((java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font10);
        java.awt.Paint paint13 = textTitle12.getPaint();
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle12.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray19 = legendTitle17.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle17.getItemLabelPadding();
        boolean boolean21 = rectangleAnchor15.equals((java.lang.Object) legendTitle17);
        boolean boolean23 = rectangleAnchor15.equals((java.lang.Object) ' ');
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D14, rectangleAnchor15);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset25.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset25);
        org.jfree.data.general.DatasetGroup datasetGroup30 = defaultCategoryDataset25.getGroup();
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        piePlot32.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset35 = piePlot32.getDataset();
        java.awt.Stroke stroke36 = piePlot32.getLabelLinkStroke();
        defaultCategoryDataset25.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot32);
        org.jfree.data.general.DatasetGroup datasetGroup38 = defaultCategoryDataset25.getGroup();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot39 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke40 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot39.setOutlineStroke(stroke40);
        java.awt.Color color42 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart43 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color42, jFreeChart43, chartChangeEventType44);
        java.awt.Color color46 = color42.brighter();
        int int47 = color42.getRGB();
        multiplePiePlot39.setNoDataMessagePaint((java.awt.Paint) color42);
        multiplePiePlot39.setBackgroundImageAlpha((float) 0L);
        java.awt.Paint[] paintArray51 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray52 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke55 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray56 = new java.awt.Stroke[] { stroke53, stroke54, stroke55 };
        java.awt.Stroke stroke57 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] { stroke57, stroke58 };
        java.awt.Shape[] shapeArray60 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray51, paintArray52, strokeArray56, strokeArray59, shapeArray60);
        java.awt.Paint paint62 = defaultDrawingSupplier61.getNextFillPaint();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType63 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font66 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle67 = new org.jfree.chart.title.TextTitle("", font66);
        org.jfree.chart.title.TextTitle textTitle68 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font66);
        boolean boolean69 = chartChangeEventType63.equals((java.lang.Object) font66);
        boolean boolean70 = defaultDrawingSupplier61.equals((java.lang.Object) boolean69);
        java.awt.Stroke stroke71 = defaultDrawingSupplier61.getNextOutlineStroke();
        multiplePiePlot39.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier61);
        defaultCategoryDataset25.addChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot39);
        java.lang.Object obj74 = textTitle2.draw(graphics2D7, rectangle2D14, (java.lang.Object) defaultCategoryDataset25);
        defaultCategoryDataset25.addValue(0.4d, (java.lang.Comparable) "RectangleEdge.LEFT", (java.lang.Comparable) 14.0d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(legendItemSourceArray19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(datasetGroup30);
        org.junit.Assert.assertNull(pieDataset35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(datasetGroup38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-16777216) + "'", int47 == (-16777216));
        org.junit.Assert.assertNotNull(paintArray51);
        org.junit.Assert.assertNotNull(paintArray52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(strokeArray56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(shapeArray60);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(chartChangeEventType63);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNull(obj74);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        double double8 = piePlot1.getLabelGap();
        java.lang.String str9 = piePlot1.getNoDataMessage();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        piePlot1.drawBackgroundImage(graphics2D10, rectangle2D11);
        boolean boolean13 = piePlot1.getIgnoreNullValues();
        piePlot1.setPieIndex(8);
        boolean boolean16 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setLabelLinksVisible(true);
        java.awt.Paint paint19 = piePlot1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        strokeMap0.clear();
        java.lang.Object obj3 = strokeMap0.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (-16777216), (double) 10L);
        columnArrangement4.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font7);
        java.lang.String str9 = textTitle8.getText();
        double double10 = textTitle8.getHeight();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle8);
        jFreeChart3.setBackgroundImageAlpha((float) 10L);
        java.awt.RenderingHints renderingHints14 = jFreeChart3.getRenderingHints();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot15.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart18 = multiplePiePlot15.getPieChart();
        jFreeChart18.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textTitle21.getHorizontalAlignment();
        java.lang.Object obj23 = textTitle21.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent24 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle21);
        jFreeChart18.titleChanged(titleChangeEvent24);
        jFreeChart3.titleChanged(titleChangeEvent24);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(jFreeChart18);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        jFreeChart7.setNotify(true);
        java.awt.Stroke stroke10 = jFreeChart7.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart7.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo15);
        float float17 = jFreeChart7.getBackgroundImageAlpha();
        chartChangeEvent1.setChart(jFreeChart7);
        java.awt.Paint paint19 = jFreeChart7.getBackgroundPaint();
        jFreeChart7.setTextAntiAlias(true);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        pieSectionEntity7.setPieIndex((int) (byte) -1);
        java.lang.String str10 = pieSectionEntity7.getShapeCoords();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        pieSectionEntity7.setDataset(pieDataset11);
        int int13 = pieSectionEntity7.getSectionIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-4,-4,4,4" + "'", str10.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        jFreeChart7.setNotify(true);
        java.awt.Stroke stroke10 = jFreeChart7.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart7.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo15);
        float float17 = jFreeChart7.getBackgroundImageAlpha();
        chartChangeEvent1.setChart(jFreeChart7);
        org.jfree.chart.ui.Contributor contributor21 = new org.jfree.chart.ui.Contributor("UnitType.ABSOLUTE", "rect");
        boolean boolean22 = jFreeChart7.equals((java.lang.Object) "UnitType.ABSOLUTE");
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle();
        textTitle23.setExpandToFitSpace(false);
        textTitle23.setPadding((double) (byte) -1, (double) 1L, 0.0d, (double) 100.0f);
        jFreeChart7.setTitle(textTitle23);
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity(shape35, "");
        java.lang.String str38 = chartEntity37.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo39 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image40 = projectInfo39.getLogo();
        java.awt.Image image41 = projectInfo39.getLogo();
        boolean boolean42 = chartEntity37.equals((java.lang.Object) image41);
        org.jfree.chart.ui.ProjectInfo projectInfo46 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "UnitType.ABSOLUTE", image41, "java.awt.Color[r=0,g=128,b=0]", "HorizontalAlignment.RIGHT", "ChartEntity: tooltip = ");
        jFreeChart7.setBackgroundImage(image41);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-4,-4,4,4" + "'", str38.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo39);
        org.junit.Assert.assertNotNull(image40);
        org.junit.Assert.assertNotNull(image41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        java.util.List list2 = projectInfo0.getContributors();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Paint paint5 = piePlot4.getNoDataMessagePaint();
        int int6 = piePlot4.getPieIndex();
        java.awt.Color color8 = java.awt.Color.magenta;
        piePlot4.setSectionPaint((java.lang.Comparable) "RectangleEdge.TOP", (java.awt.Paint) color8);
        boolean boolean10 = projectInfo0.equals((java.lang.Object) color8);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1.0f));
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list6 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list7 = defaultKeyedValues2D1.getRowKeys();
        java.lang.Number number8 = null;
        defaultKeyedValues2D1.setValue(number8, (java.lang.Comparable) 'a', (java.lang.Comparable) 128);
        java.lang.Object obj12 = defaultKeyedValues2D1.clone();
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) true);
        org.jfree.chart.util.ObjectList objectList4 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.ui.Contributor contributor7 = new org.jfree.chart.ui.Contributor("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        int int8 = objectList4.indexOf((java.lang.Object) "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        objectList4.clear();
        java.lang.Object obj10 = objectList4.clone();
        int int11 = objectList4.size();
        boolean boolean12 = standardPieSectionLabelGenerator0.equals((java.lang.Object) objectList4);
        objectList4.clear();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font7);
        java.lang.String str9 = textTitle8.getText();
        double double10 = textTitle8.getHeight();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle8);
        jFreeChart3.setBackgroundImageAlpha((float) 10L);
        java.awt.RenderingHints renderingHints14 = jFreeChart3.getRenderingHints();
        java.lang.Object obj15 = jFreeChart3.clone();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setLabelLinkMargin(0.08d);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = null;
        piePlot17.notifyListeners(plotChangeEvent20);
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke24, stroke25, stroke26 };
        java.awt.Stroke stroke28 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] { stroke28, stroke29 };
        java.awt.Shape[] shapeArray31 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray22, paintArray23, strokeArray27, strokeArray30, shapeArray31);
        java.awt.Stroke stroke33 = defaultDrawingSupplier32.getNextOutlineStroke();
        piePlot17.setLabelOutlineStroke(stroke33);
        jFreeChart3.setBorderStroke(stroke33);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(shapeArray31);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("HorizontalAlignment.RIGHT", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color2 = java.awt.Color.cyan;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle1.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test419");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = projectInfo0.getLogo();
//        java.awt.Image image2 = projectInfo0.getLogo();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
//        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
//        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
//        basicProjectInfo3.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
//        java.lang.String str11 = projectInfo0.getLicenceText();
//        projectInfo0.setName("http://www.jfree.org/jfreechart/index.html");
//        org.jfree.chart.ui.ProjectInfo projectInfo14 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image15 = projectInfo14.getLogo();
//        java.awt.Image image16 = projectInfo14.getLogo();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo17 = new org.jfree.chart.ui.BasicProjectInfo();
//        basicProjectInfo17.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        org.jfree.chart.ui.Library[] libraryArray20 = basicProjectInfo17.getOptionalLibraries();
//        org.jfree.chart.ui.Library[] libraryArray21 = basicProjectInfo17.getLibraries();
//        basicProjectInfo17.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//        projectInfo14.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo17);
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot26 = new org.jfree.chart.plot.MultiplePiePlot();
//        java.awt.Stroke stroke27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
//        multiplePiePlot26.setOutlineStroke(stroke27);
//        java.awt.Paint paint29 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
//        multiplePiePlot26.setOutlinePaint(paint29);
//        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot26);
//        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity(shape32, "");
//        java.lang.String str35 = chartEntity34.getShapeCoords();
//        org.jfree.chart.ui.ProjectInfo projectInfo36 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image37 = projectInfo36.getLogo();
//        java.awt.Image image38 = projectInfo36.getLogo();
//        boolean boolean39 = chartEntity34.equals((java.lang.Object) image38);
//        jFreeChart31.setBackgroundImage(image38);
//        projectInfo14.setLogo(image38);
//        projectInfo0.setLogo(image38);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(image1);
//        org.junit.Assert.assertNotNull(image2);
//        org.junit.Assert.assertNotNull(libraryArray6);
//        org.junit.Assert.assertNotNull(libraryArray7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnitType.ABSOLUTE" + "'", str11.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertNotNull(projectInfo14);
//        org.junit.Assert.assertNotNull(image15);
//        org.junit.Assert.assertNotNull(image16);
//        org.junit.Assert.assertNotNull(libraryArray20);
//        org.junit.Assert.assertNotNull(libraryArray21);
//        org.junit.Assert.assertNotNull(stroke27);
//        org.junit.Assert.assertNotNull(paint29);
//        org.junit.Assert.assertNotNull(shape32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-4,-4,4,4" + "'", str35.equals("-4,-4,4,4"));
//        org.junit.Assert.assertNotNull(projectInfo36);
//        org.junit.Assert.assertNotNull(image37);
//        org.junit.Assert.assertNotNull(image38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.awt.Paint paint8 = piePlot1.getLabelLinkPaint();
        piePlot1.setPieIndex((int) (byte) -1);
        piePlot1.setLabelLinksVisible(true);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setCircular(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color11 = color10.darker();
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment13);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        chartChangeEvent14.setType(chartChangeEventType15);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot17.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot17.getPieChart();
        jFreeChart20.setNotify(true);
        java.awt.Stroke stroke23 = jFreeChart20.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        java.awt.image.BufferedImage bufferedImage29 = jFreeChart20.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo28);
        float float30 = jFreeChart20.getBackgroundImageAlpha();
        chartChangeEvent14.setChart(jFreeChart20);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        int int33 = jFreeChart20.getSubtitleCount();
        jFreeChart20.setBorderVisible(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(bufferedImage29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = java.awt.Color.GRAY;
        boolean boolean12 = color10.equals((java.lang.Object) color11);
        piePlot3.setLabelShadowPaint((java.awt.Paint) color11);
        java.lang.Object obj14 = piePlot3.clone();
        java.awt.Stroke stroke15 = piePlot3.getLabelOutlineStroke();
        java.awt.Paint paint16 = piePlot3.getLabelBackgroundPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = null;
        piePlot3.setLegendLabelURLGenerator(pieURLGenerator17);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        piePlot21.setLabelLinksVisible(false);
        piePlot21.setLabelLinksVisible(true);
        boolean boolean26 = piePlot21.getSectionOutlinesVisible();
        piePlot21.setCircular(false, false);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color31 = color30.darker();
        piePlot21.setLabelOutlinePaint((java.awt.Paint) color30);
        java.awt.Font font33 = piePlot21.getLabelFont();
        java.awt.Stroke stroke34 = piePlot21.getLabelLinkStroke();
        piePlot3.setSectionOutlineStroke((java.lang.Comparable) "org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", stroke34);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator37 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("UnitType.ABSOLUTE");
        piePlot3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator37);
        piePlot3.setStartAngle((double) (-1L));
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelLinksVisible(true);
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setCircular(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color11 = color10.darker();
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = null;
        try {
            piePlot1.setLabelPadding(rectangleInsets13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        try {
            java.awt.Color color1 = java.awt.Color.decode("http://www.jfree.org/jfreechart/index.html");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"http://www.jfree.org/jfreechart/index.html\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        int int3 = objectList0.indexOf((java.lang.Object) "");
        objectList0.clear();
        int int5 = objectList0.size();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockContainer6.getMargin();
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets7.getUnitType();
        double double10 = rectangleInsets7.trimHeight((double) 0.0f);
        double double11 = rectangleInsets7.getRight();
        double double13 = rectangleInsets7.calculateBottomInset(1.0E-5d);
        double double15 = rectangleInsets7.calculateRightInset((double) 0.5f);
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets7.getUnitType();
        int int17 = objectList0.indexOf((java.lang.Object) rectangleInsets7);
        java.lang.Object obj19 = objectList0.get((-4145152));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(unitType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(obj19);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        piePlot1.setSectionPaint((java.lang.Comparable) "LGPL", (java.awt.Paint) color4);
        piePlot1.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        double double4 = blockContainer0.getWidth();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 0, (double) (byte) 1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement10);
        blockContainer0.clear();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Shape shape8 = piePlot3.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = java.awt.Color.GRAY;
        boolean boolean12 = color10.equals((java.lang.Object) color11);
        piePlot3.setLabelShadowPaint((java.awt.Paint) color11);
        java.lang.Object obj14 = piePlot3.clone();
        java.awt.Stroke stroke15 = piePlot3.getLabelOutlineStroke();
        java.awt.Paint paint16 = piePlot3.getLabelBackgroundPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = null;
        piePlot3.setLegendLabelURLGenerator(pieURLGenerator17);
        java.awt.Stroke stroke20 = piePlot3.getSectionOutlineStroke((java.lang.Comparable) "java.awt.Color[r=255,g=0,b=255]");
        boolean boolean21 = piePlot3.getIgnoreNullValues();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset22.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        int int27 = defaultCategoryDataset22.getColumnIndex((java.lang.Comparable) 100L);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot3, (org.jfree.data.general.Dataset) defaultCategoryDataset22);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot29.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart32 = multiplePiePlot29.getPieChart();
        jFreeChart32.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = textTitle35.getHorizontalAlignment();
        java.lang.Object obj37 = textTitle35.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent38 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle35);
        jFreeChart32.titleChanged(titleChangeEvent38);
        java.awt.Font font41 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font41);
        java.lang.String str43 = textTitle42.getText();
        jFreeChart32.setTitle(textTitle42);
        org.jfree.chart.title.LegendTitle legendTitle46 = jFreeChart32.getLegend((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle48 = jFreeChart32.getLegend(8);
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment50 = textTitle49.getHorizontalAlignment();
        java.lang.Object obj51 = textTitle49.clone();
        jFreeChart32.setTitle(textTitle49);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent53 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot3, jFreeChart32);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(jFreeChart32);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str43.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNull(legendTitle46);
        org.junit.Assert.assertNull(legendTitle48);
        org.junit.Assert.assertNotNull(horizontalAlignment50);
        org.junit.Assert.assertNotNull(obj51);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets1.getUnitType();
        java.lang.String str3 = rectangleInsets1.toString();
        double double5 = rectangleInsets1.trimWidth((double) 3);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.awt.Color color0 = java.awt.Color.blue;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image1 = multiplePiePlot0.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot3.getDataset();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot3.getLabelDistributor();
        double double9 = piePlot3.getLabelLinkMargin();
        double double10 = piePlot3.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Font font13 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font13);
        java.lang.String str15 = textTitle14.getText();
        double double16 = textTitle14.getHeight();
        textTitle14.setURLText("RectangleEdge.LEFT");
        textTitle14.setToolTipText("");
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textTitle21.getHorizontalAlignment();
        java.lang.Object obj23 = textTitle21.clone();
        java.awt.Paint paint24 = textTitle21.getBackgroundPaint();
        textTitle21.setToolTipText("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        textTitle21.setURLText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = textTitle21.getHorizontalAlignment();
        textTitle14.setTextAlignment(horizontalAlignment29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.Font font34 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font34);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font34);
        java.awt.Paint paint37 = textTitle36.getPaint();
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle36.getBounds();
        java.awt.Font font40 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font40);
        java.lang.String str42 = textTitle41.getText();
        java.lang.Object obj43 = textTitle14.draw(graphics2D31, rectangle2D38, (java.lang.Object) textTitle41);
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot(pieDataset44);
        piePlot45.setLabelLinksVisible(false);
        piePlot45.setLabelLinksVisible(true);
        boolean boolean50 = piePlot45.getSectionOutlinesVisible();
        piePlot45.setCircular(false, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        org.jfree.chart.plot.PiePlotState piePlotState56 = piePlot3.initialise(graphics2D11, rectangle2D38, piePlot45, (java.lang.Integer) 8, plotRenderingInfo55);
        piePlot3.setLabelGap(0.025d);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str15.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str42.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNull(obj43);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(piePlotState56);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color2 = java.awt.Color.cyan;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color2);
        legendTitle1.setMargin(24.0d, (double) '#', (double) ' ', 0.4d);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot10.setOutlineStroke(stroke11);
        java.awt.Paint paint13 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot10.setOutlinePaint(paint13);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot10);
        java.awt.Image image16 = multiplePiePlot10.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart17 = multiplePiePlot10.getPieChart();
        jFreeChart17.fireChartChanged();
        java.lang.Object obj19 = jFreeChart17.getTextAntiAlias();
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = legendTitle1.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(image16);
        org.junit.Assert.assertNotNull(jFreeChart17);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        java.awt.Stroke stroke6 = jFreeChart3.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        jFreeChart3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart3.getTitle();
        jFreeChart3.setBackgroundImageAlpha(1.0f);
        jFreeChart3.setNotify(false);
        java.awt.Color color16 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color16, jFreeChart17, chartChangeEventType18);
        java.awt.Color color20 = color16.brighter();
        jFreeChart3.setBackgroundPaint((java.awt.Paint) color20);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        java.awt.image.BufferedImage bufferedImage27 = jFreeChart3.createBufferedImage((int) (byte) 100, 255, (-1.2566281E7d), (double) 100.0f, chartRenderingInfo26);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(bufferedImage27);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Image image2 = multiplePiePlot1.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        piePlot4.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset7 = piePlot4.getDataset();
        multiplePiePlot1.setParent((org.jfree.chart.plot.Plot) piePlot4);
        java.awt.Shape shape9 = piePlot4.getLegendItemShape();
        boolean boolean10 = blockContainer0.equals((java.lang.Object) shape9);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNull(pieDataset7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getRowCount();
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) 10.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 10.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = piePlot1.initialise(graphics2D3, rectangle2D4, piePlot6, (java.lang.Integer) 2, plotRenderingInfo8);
        java.awt.Paint paint10 = piePlot6.getLabelOutlinePaint();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "");
        piePlot6.setLegendItemShape(shape11);
        java.awt.Paint paint15 = piePlot6.getOutlinePaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = piePlot6.getLabelGenerator();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator16);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        java.lang.Object obj8 = textTitle6.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle6);
        jFreeChart3.titleChanged(titleChangeEvent9);
        java.lang.Object obj11 = jFreeChart3.getTextAntiAlias();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle2.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle2.getItemLabelPadding();
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) legendTitle2);
        java.lang.Class<?> wildcardClass7 = legendTitle2.getClass();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot9.setOutlinePaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot9);
        legendTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        boolean boolean16 = jFreeChart14.isBorderVisible();
        jFreeChart14.setBackgroundImageAlignment(2);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer3.getMargin();
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        double double7 = rectangleInsets4.trimHeight((double) 0.0f);
        double double8 = rectangleInsets4.getRight();
        double double10 = rectangleInsets4.calculateBottomInset(1.0E-5d);
        legendTitle1.setItemLabelPadding(rectangleInsets4);
        java.awt.Paint paint12 = legendTitle1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray10 = legendTitle8.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle8.getItemLabelPadding();
        boolean boolean12 = rectangleAnchor6.equals((java.lang.Object) legendTitle8);
        double double13 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle8.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle16);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray18 = legendTitle16.getSources();
        legendTitle8.setSources(legendItemSourceArray18);
        jFreeChart3.addSubtitle((org.jfree.chart.title.Title) legendTitle8);
        float float21 = jFreeChart3.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(legendItemSourceArray10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(legendItemSourceArray18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (byte) 1);
        java.util.List list3 = defaultCategoryDataset0.getRowKeys();
        int int4 = defaultCategoryDataset0.getColumnCount();
        java.lang.Comparable comparable7 = null;
        try {
            defaultCategoryDataset0.incrementValue(0.0d, (java.lang.Comparable) 4.0d, comparable7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle4.setVerticalAlignment(verticalAlignment5);
        java.awt.Paint paint7 = textTitle4.getBackgroundPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, 8, 0);
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) chartColor3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double6 = rectangleInsets5.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) '#');
        multiplePiePlot0.setForegroundAlpha((float) (-1L));
        java.lang.Comparable comparable5 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder6 = org.jfree.chart.util.TableOrder.BY_ROW;
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString9 = null;
        standardPieSectionLabelGenerator7.setAttributedLabel(0, attributedString9);
        java.text.AttributedString attributedString12 = standardPieSectionLabelGenerator7.getAttributedLabel((int) (short) 1);
        boolean boolean13 = tableOrder6.equals((java.lang.Object) (short) 1);
        multiplePiePlot0.setDataExtractOrder(tableOrder6);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = multiplePiePlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder6);
        org.junit.Assert.assertNull(attributedString12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(legendItemCollection15);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        java.lang.String str2 = pieLabelDistributor1.toString();
        int int3 = pieLabelDistributor1.getItemCount();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord5 = pieLabelDistributor1.getPieLabelRecord((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.awt.Stroke stroke8 = piePlot1.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        piePlot10.setLabelLinksVisible(false);
        piePlot10.setLabelLinksVisible(true);
        boolean boolean15 = piePlot10.getSectionOutlinesVisible();
        piePlot10.setCircular(false, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color20 = color19.darker();
        piePlot10.setLabelOutlinePaint((java.awt.Paint) color19);
        java.awt.Font font22 = piePlot10.getLabelFont();
        java.awt.Font font23 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        piePlot10.setNoDataMessageFont(font23);
        piePlot1.setLabelFont(font23);
        try {
            piePlot1.setInteriorGap((-1.2566281E7d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (-1.2566281E7) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 10, (java.lang.Comparable) 100L, "HorizontalAlignment.RIGHT", "");
        int int8 = pieSectionEntity7.getPieIndex();
        org.jfree.data.general.PieDataset pieDataset9 = pieSectionEntity7.getDataset();
        int int10 = pieSectionEntity7.getPieIndex();
        java.awt.Shape shape11 = pieSectionEntity7.getArea();
        org.jfree.data.general.PieDataset pieDataset12 = pieSectionEntity7.getDataset();
        pieSectionEntity7.setPieIndex((-1));
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(pieDataset12);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        java.awt.Image image2 = projectInfo0.getLogo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo3.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo3.getLibraries();
        basicProjectInfo3.setVersion("org.jfree.data.UnknownKeyException: RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot12.setOutlineStroke(stroke13);
        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot12.setOutlinePaint(paint15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("-4,-4,4,4", (org.jfree.chart.plot.Plot) multiplePiePlot12);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape18, "");
        java.lang.String str21 = chartEntity20.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo22 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image23 = projectInfo22.getLogo();
        java.awt.Image image24 = projectInfo22.getLogo();
        boolean boolean25 = chartEntity20.equals((java.lang.Object) image24);
        jFreeChart17.setBackgroundImage(image24);
        projectInfo0.setLogo(image24);
        org.jfree.chart.ui.Library[] libraryArray28 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(image2);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-4,-4,4,4" + "'", str21.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo22);
        org.junit.Assert.assertNotNull(image23);
        org.junit.Assert.assertNotNull(image24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(libraryArray28);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 'a');
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockContainer6.getMargin();
        double double9 = rectangleInsets7.calculateRightOutset(0.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets7);
        double double11 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.14d + "'", double11 == 0.14d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape3, "");
        java.lang.String str6 = chartEntity5.getShapeCoords();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image8 = projectInfo7.getLogo();
        java.awt.Image image9 = projectInfo7.getLogo();
        boolean boolean10 = chartEntity5.equals((java.lang.Object) image9);
        org.jfree.chart.ui.ProjectInfo projectInfo14 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "UnitType.ABSOLUTE", image9, "java.awt.Color[r=0,g=128,b=0]", "HorizontalAlignment.RIGHT", "ChartEntity: tooltip = ");
        projectInfo14.setName("");
        projectInfo14.setName("rect");
        org.jfree.chart.ui.Library[] libraryArray19 = projectInfo14.getLibraries();
        java.lang.String str20 = projectInfo14.toString();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-4,-4,4,4" + "'", str6.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(image8);
        org.junit.Assert.assertNotNull(image9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(libraryArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect version VerticalAlignment.CENTER.\njava.awt.Color[r=0,g=128,b=0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:UnitType.ABSOLUTE\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY rect:None\nrect LICENCE TERMS:\nChartEntity: tooltip = " + "'", str20.equals("rect version VerticalAlignment.CENTER.\njava.awt.Color[r=0,g=128,b=0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:UnitType.ABSOLUTE\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY rect:None\nrect LICENCE TERMS:\nChartEntity: tooltip = "));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot7.getDataset();
        java.awt.Stroke stroke11 = piePlot7.getLabelLinkStroke();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        try {
            java.lang.Comparable comparable14 = defaultCategoryDataset0.getRowKey((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setLimit((double) '#');
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        jFreeChart7.setNotify(true);
        java.awt.Stroke stroke10 = jFreeChart7.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart7.createBufferedImage((int) '4', (int) '4', (double) 100, (double) 2, chartRenderingInfo15);
        float float17 = jFreeChart7.getBackgroundImageAlpha();
        chartChangeEvent1.setChart(jFreeChart7);
        java.awt.Paint paint19 = jFreeChart7.getBackgroundPaint();
        java.awt.RenderingHints renderingHints20 = jFreeChart7.getRenderingHints();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double23 = rectangleInsets21.calculateTopInset((double) 10L);
        jFreeChart7.setPadding(rectangleInsets21);
        org.jfree.chart.title.LegendTitle legendTitle25 = jFreeChart7.getLegend();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(renderingHints20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNull(legendTitle25);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 1, 3, 192);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Color color9 = color5.brighter();
        int int10 = color5.getRGB();
        boolean boolean11 = defaultCategoryDataset0.equals((java.lang.Object) int10);
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1);
        textTitle2.setNotify(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        textTitle2.setPaint((java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM", font10);
        java.awt.Paint paint13 = textTitle12.getPaint();
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle12.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray19 = legendTitle17.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle17.getItemLabelPadding();
        boolean boolean21 = rectangleAnchor15.equals((java.lang.Object) legendTitle17);
        boolean boolean23 = rectangleAnchor15.equals((java.lang.Object) ' ');
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D14, rectangleAnchor15);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset25.removeValue((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Comparable) "PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset25);
        org.jfree.data.general.DatasetGroup datasetGroup30 = defaultCategoryDataset25.getGroup();
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        piePlot32.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset35 = piePlot32.getDataset();
        java.awt.Stroke stroke36 = piePlot32.getLabelLinkStroke();
        defaultCategoryDataset25.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot32);
        org.jfree.data.general.DatasetGroup datasetGroup38 = defaultCategoryDataset25.getGroup();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot39 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Stroke stroke40 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        multiplePiePlot39.setOutlineStroke(stroke40);
        java.awt.Color color42 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart43 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color42, jFreeChart43, chartChangeEventType44);
        java.awt.Color color46 = color42.brighter();
        int int47 = color42.getRGB();
        multiplePiePlot39.setNoDataMessagePaint((java.awt.Paint) color42);
        multiplePiePlot39.setBackgroundImageAlpha((float) 0L);
        java.awt.Paint[] paintArray51 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray52 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke55 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray56 = new java.awt.Stroke[] { stroke53, stroke54, stroke55 };
        java.awt.Stroke stroke57 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] { stroke57, stroke58 };
        java.awt.Shape[] shapeArray60 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray51, paintArray52, strokeArray56, strokeArray59, shapeArray60);
        java.awt.Paint paint62 = defaultDrawingSupplier61.getNextFillPaint();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType63 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Font font66 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle67 = new org.jfree.chart.title.TextTitle("", font66);
        org.jfree.chart.title.TextTitle textTitle68 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font66);
        boolean boolean69 = chartChangeEventType63.equals((java.lang.Object) font66);
        boolean boolean70 = defaultDrawingSupplier61.equals((java.lang.Object) boolean69);
        java.awt.Stroke stroke71 = defaultDrawingSupplier61.getNextOutlineStroke();
        multiplePiePlot39.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier61);
        defaultCategoryDataset25.addChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot39);
        java.lang.Object obj74 = textTitle2.draw(graphics2D7, rectangle2D14, (java.lang.Object) defaultCategoryDataset25);
        defaultCategoryDataset25.clear();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(legendItemSourceArray19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(datasetGroup30);
        org.junit.Assert.assertNull(pieDataset35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(datasetGroup38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-16777216) + "'", int47 == (-16777216));
        org.junit.Assert.assertNotNull(paintArray51);
        org.junit.Assert.assertNotNull(paintArray52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(strokeArray56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(shapeArray60);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(chartChangeEventType63);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNull(obj74);
    }
}

