import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        long long20 = day9.getLastMillisecond();
        int int21 = day9.getMonth();
        int int22 = day9.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day9.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str7 = timePeriodValues1.getDescription();
        boolean boolean8 = timePeriodValues1.isEmpty();
        timePeriodValues1.setRangeDescription("");
        boolean boolean11 = timePeriodValues1.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str14 = timePeriodValues13.getDomainDescription();
        timePeriodValues13.setDomainDescription("Time");
        boolean boolean17 = timePeriodValues1.equals((java.lang.Object) timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        int int9 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=30-December-2019]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("");
        java.lang.Comparable comparable11 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues1.getDataItem(0);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        int int17 = year14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.next();
        java.lang.String str19 = year14.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, 1.0d);
        java.util.Date date22 = year14.getEnd();
        boolean boolean23 = timePeriodValue13.equals((java.lang.Object) date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) false);
        int int27 = year24.getYear();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) false);
        boolean boolean31 = year24.equals((java.lang.Object) year28);
        java.util.Date date32 = year24.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(date22, date32);
        java.util.Date date34 = simpleTimePeriod33.getEnd();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 0.0d + "'", comparable11.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriodValue13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        java.lang.Object obj13 = timePeriodValue11.clone();
        boolean boolean14 = timePeriodValues1.equals(obj13);
        java.lang.String str15 = timePeriodValues1.getDescription();
        try {
            timePeriodValues1.update(0, (java.lang.Number) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) false);
        int int4 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        boolean boolean8 = year1.equals((java.lang.Object) year5);
        java.util.Date date9 = year1.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        boolean boolean17 = year10.equals((java.lang.Object) year14);
        java.util.Date date18 = year10.getEnd();
        boolean boolean19 = year1.equals((java.lang.Object) date18);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str22 = timePeriodValues21.getDomainDescription();
        timePeriodValues21.setNotify(true);
        java.lang.Class<?> wildcardClass25 = timePeriodValues21.getClass();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        boolean boolean28 = year26.equals((java.lang.Object) false);
        int int29 = year26.getYear();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        boolean boolean32 = year30.equals((java.lang.Object) false);
        boolean boolean33 = year26.equals((java.lang.Object) year30);
        boolean boolean35 = year26.equals((java.lang.Object) false);
        java.util.Date date36 = year26.getStart();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        boolean boolean39 = year37.equals((java.lang.Object) false);
        int int40 = year37.getYear();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        boolean boolean43 = year41.equals((java.lang.Object) false);
        boolean boolean44 = year37.equals((java.lang.Object) year41);
        boolean boolean46 = year37.equals((java.lang.Object) false);
        java.util.Date date47 = year37.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        boolean boolean50 = year48.equals((java.lang.Object) false);
        int int51 = year48.getYear();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        boolean boolean54 = year52.equals((java.lang.Object) false);
        boolean boolean55 = year48.equals((java.lang.Object) year52);
        java.util.Date date56 = year48.getEnd();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        boolean boolean59 = year57.equals((java.lang.Object) false);
        int int60 = year57.getYear();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        boolean boolean63 = year61.equals((java.lang.Object) false);
        boolean boolean64 = year57.equals((java.lang.Object) year61);
        java.util.Date date65 = year57.getEnd();
        boolean boolean66 = year48.equals((java.lang.Object) date65);
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date65, timeZone67);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date47, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date36, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date18, timeZone67);
        org.jfree.data.time.TimePeriodValues timePeriodValues72 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
        java.beans.PropertyChangeListener propertyChangeListener73 = null;
        timePeriodValues72.removePropertyChangeListener(propertyChangeListener73);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNull(regularTimePeriod71);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) false);
        int int4 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        boolean boolean8 = year1.equals((java.lang.Object) year5);
        java.util.Date date9 = year1.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        boolean boolean17 = year10.equals((java.lang.Object) year14);
        java.util.Date date18 = year10.getEnd();
        boolean boolean19 = year1.equals((java.lang.Object) date18);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str22 = timePeriodValues21.getDomainDescription();
        timePeriodValues21.setNotify(true);
        java.lang.Class<?> wildcardClass25 = timePeriodValues21.getClass();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        boolean boolean28 = year26.equals((java.lang.Object) false);
        int int29 = year26.getYear();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        boolean boolean32 = year30.equals((java.lang.Object) false);
        boolean boolean33 = year26.equals((java.lang.Object) year30);
        boolean boolean35 = year26.equals((java.lang.Object) false);
        java.util.Date date36 = year26.getStart();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        boolean boolean39 = year37.equals((java.lang.Object) false);
        int int40 = year37.getYear();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        boolean boolean43 = year41.equals((java.lang.Object) false);
        boolean boolean44 = year37.equals((java.lang.Object) year41);
        boolean boolean46 = year37.equals((java.lang.Object) false);
        java.util.Date date47 = year37.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        boolean boolean50 = year48.equals((java.lang.Object) false);
        int int51 = year48.getYear();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        boolean boolean54 = year52.equals((java.lang.Object) false);
        boolean boolean55 = year48.equals((java.lang.Object) year52);
        java.util.Date date56 = year48.getEnd();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        boolean boolean59 = year57.equals((java.lang.Object) false);
        int int60 = year57.getYear();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        boolean boolean63 = year61.equals((java.lang.Object) false);
        boolean boolean64 = year57.equals((java.lang.Object) year61);
        java.util.Date date65 = year57.getEnd();
        boolean boolean66 = year48.equals((java.lang.Object) date65);
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date65, timeZone67);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date47, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date36, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date18, timeZone67);
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date18);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNull(regularTimePeriod71);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date10);
        java.lang.Class<?> wildcardClass17 = year16.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) false);
        int int21 = year18.getYear();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean24 = year22.equals((java.lang.Object) false);
        boolean boolean25 = year18.equals((java.lang.Object) year22);
        java.util.Date date26 = year18.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues28.setDescription("Time");
        int int31 = timePeriodValues28.getMinStartIndex();
        java.lang.String str32 = timePeriodValues28.getRangeDescription();
        int int33 = timePeriodValues28.getItemCount();
        int int34 = timePeriodValues28.getMinEndIndex();
        int int35 = year18.compareTo((java.lang.Object) timePeriodValues28);
        long long36 = year18.getSerialIndex();
        boolean boolean37 = year16.equals((java.lang.Object) year18);
        java.util.Calendar calendar38 = null;
        try {
            long long39 = year16.getMiddleMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Value" + "'", str32.equals("Value"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        java.lang.Object obj13 = timePeriodValue11.clone();
        boolean boolean14 = timePeriodValues1.equals(obj13);
        java.lang.String str15 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable16 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 0.0d + "'", comparable16.equals(0.0d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        long long8 = year4.getMiddleMillisecond();
        int int9 = year4.getYear();
        java.lang.Class<?> wildcardClass10 = year4.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str13 = timePeriodValues12.getDomainDescription();
        timePeriodValues12.setNotify(true);
        java.lang.Class<?> wildcardClass16 = timePeriodValues12.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) false);
        int int21 = year18.getYear();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean24 = year22.equals((java.lang.Object) false);
        boolean boolean25 = year18.equals((java.lang.Object) year22);
        java.util.Date date26 = year18.getEnd();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date26, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        boolean boolean32 = year30.equals((java.lang.Object) false);
        int int33 = year30.getYear();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) false);
        boolean boolean37 = year30.equals((java.lang.Object) year34);
        java.util.Date date38 = year30.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) false);
        int int42 = year39.getYear();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        boolean boolean45 = year43.equals((java.lang.Object) false);
        boolean boolean46 = year39.equals((java.lang.Object) year43);
        java.util.Date date47 = year39.getEnd();
        boolean boolean48 = year30.equals((java.lang.Object) date47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date47, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date26, timeZone49);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        boolean boolean54 = year52.equals((java.lang.Object) false);
        int int55 = year52.getYear();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        boolean boolean59 = year52.equals((java.lang.Object) year56);
        java.util.Date date60 = year52.getEnd();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        boolean boolean63 = day61.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException65 = new org.jfree.data.general.SeriesException("");
        java.lang.String str66 = seriesException65.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException68 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException65.addSuppressed((java.lang.Throwable) timePeriodFormatException68);
        boolean boolean70 = day61.equals((java.lang.Object) seriesException65);
        org.jfree.data.time.SerialDate serialDate71 = day61.getSerialDate();
        long long72 = day61.getLastMillisecond();
        int int73 = day61.getYear();
        java.lang.String str74 = day61.toString();
        java.util.Date date75 = day61.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod76 = new org.jfree.data.time.SimpleTimePeriod(date26, date75);
        long long77 = simpleTimePeriod76.getEndMillis();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str66.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1577865599999L + "'", long72 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "31-December-2019" + "'", str74.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1577865599999L + "'", long77 == 1577865599999L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.lang.Class class11 = null;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        java.util.Date date20 = year12.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) false);
        int int24 = year21.getYear();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) false);
        boolean boolean28 = year21.equals((java.lang.Object) year25);
        java.util.Date date29 = year21.getEnd();
        boolean boolean30 = year12.equals((java.lang.Object) date29);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str33 = timePeriodValues32.getDomainDescription();
        timePeriodValues32.setNotify(true);
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        boolean boolean39 = year37.equals((java.lang.Object) false);
        int int40 = year37.getYear();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        boolean boolean43 = year41.equals((java.lang.Object) false);
        boolean boolean44 = year37.equals((java.lang.Object) year41);
        boolean boolean46 = year37.equals((java.lang.Object) false);
        java.util.Date date47 = year37.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        boolean boolean50 = year48.equals((java.lang.Object) false);
        int int51 = year48.getYear();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        boolean boolean54 = year52.equals((java.lang.Object) false);
        boolean boolean55 = year48.equals((java.lang.Object) year52);
        boolean boolean57 = year48.equals((java.lang.Object) false);
        java.util.Date date58 = year48.getStart();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        boolean boolean61 = year59.equals((java.lang.Object) false);
        int int62 = year59.getYear();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        boolean boolean65 = year63.equals((java.lang.Object) false);
        boolean boolean66 = year59.equals((java.lang.Object) year63);
        java.util.Date date67 = year59.getEnd();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        boolean boolean70 = year68.equals((java.lang.Object) false);
        int int71 = year68.getYear();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        boolean boolean74 = year72.equals((java.lang.Object) false);
        boolean boolean75 = year68.equals((java.lang.Object) year72);
        java.util.Date date76 = year68.getEnd();
        boolean boolean77 = year59.equals((java.lang.Object) date76);
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date76, timeZone78);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date58, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date47, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date29, timeZone78);
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year();
        boolean boolean85 = year83.equals((java.lang.Object) false);
        int int86 = year83.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = year83.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = year83.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = year83.next();
        java.util.Date date90 = regularTimePeriod89.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod91 = new org.jfree.data.time.SimpleTimePeriod(date29, date90);
        int int92 = day9.compareTo((java.lang.Object) simpleTimePeriod91);
        java.util.Date date93 = simpleTimePeriod91.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Time" + "'", str33.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2019 + "'", int71 == 2019);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 2019 + "'", int86 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
        org.junit.Assert.assertNotNull(regularTimePeriod89);
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNotNull(date93);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        boolean boolean8 = timePeriodValues1.getNotify();
        int int9 = timePeriodValues1.getMinEndIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues1.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        int int9 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str16 = timePeriodValues15.getDomainDescription();
        timePeriodValues15.setDomainDescription("Time");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year19, (double) (-1L));
        long long22 = year19.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.next();
        long long24 = year19.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year19.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 9);
        timePeriodValue27.setValue((java.lang.Number) 1577865599999L);
        timePeriodValues1.add(timePeriodValue27);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.fireSeriesChanged();
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str23 = timePeriodValues22.getDomainDescription();
        timePeriodValues22.setNotify(true);
        java.lang.String str26 = timePeriodValues22.getRangeDescription();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        java.lang.String str28 = timePeriodValues22.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) false);
        int int34 = year31.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        boolean boolean38 = year31.equals((java.lang.Object) year35);
        java.util.Date date39 = year31.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        boolean boolean42 = day40.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        java.lang.String str45 = seriesException44.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException44.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        boolean boolean49 = day40.equals((java.lang.Object) seriesException44);
        org.jfree.data.time.SerialDate serialDate50 = day40.getSerialDate();
        long long51 = day40.getLastMillisecond();
        int int52 = day40.getYear();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day40, (double) 0L);
        int int55 = year20.compareTo((java.lang.Object) day40);
        long long56 = year20.getMiddleMillisecond();
        long long57 = year20.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0d + "'", comparable27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str45.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1562097599999L + "'", long56 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1546329600000L + "'", long57 == 1546329600000L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues10.setDescription("Time");
        int int13 = timePeriodValues10.getMinStartIndex();
        java.lang.String str14 = timePeriodValues10.getRangeDescription();
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMinEndIndex();
        int int17 = year0.compareTo((java.lang.Object) timePeriodValues10);
        long long18 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        boolean boolean27 = day18.equals((java.lang.Object) seriesException22);
        org.jfree.data.time.SerialDate serialDate28 = day18.getSerialDate();
        timePeriodValues1.setKey((java.lang.Comparable) day18);
        java.lang.Object obj30 = null;
        boolean boolean31 = day18.equals(obj30);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "", "hi!");
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        boolean boolean45 = year36.equals((java.lang.Object) false);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) year36, (java.lang.Number) 2);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        boolean boolean50 = year48.equals((java.lang.Object) false);
        int int51 = year48.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year48.next();
        java.lang.String str53 = year48.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue55 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, 1.0d);
        long long56 = year48.getLastMillisecond();
        boolean boolean57 = year36.equals((java.lang.Object) long56);
        boolean boolean58 = day18.equals((java.lang.Object) year36);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019" + "'", str53.equals("2019"));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1577865599999L + "'", long56 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        boolean boolean27 = day18.equals((java.lang.Object) seriesException22);
        org.jfree.data.time.SerialDate serialDate28 = day18.getSerialDate();
        timePeriodValues1.setKey((java.lang.Comparable) day18);
        java.lang.String str30 = day18.toString();
        long long31 = day18.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, 100.0d);
        org.jfree.data.time.TimePeriod timePeriod34 = timePeriodValue33.getPeriod();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriod34);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43830L + "'", long31 == 43830L);
        org.junit.Assert.assertNotNull(timePeriod34);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        int int16 = year13.getYear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        boolean boolean20 = year13.equals((java.lang.Object) year17);
        java.util.Date date21 = year13.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        boolean boolean24 = day22.equals((java.lang.Object) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day22.previous();
        boolean boolean26 = day9.equals((java.lang.Object) day22);
        long long27 = day9.getFirstMillisecond();
        java.util.Calendar calendar28 = null;
        try {
            long long29 = day9.getFirstMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577779200000L + "'", long27 == 1577779200000L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue10.getPeriod();
        timePeriodValue10.setValue((java.lang.Number) 100);
        timePeriodValue10.setValue((java.lang.Number) 2019L);
        timePeriodValues1.add(timePeriodValue10);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        long long20 = year17.getLastMillisecond();
        java.lang.String str21 = year17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 1546329600000L);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str27 = timePeriodValues26.getDomainDescription();
        timePeriodValues26.setNotify(true);
        int int30 = timePeriodValues26.getMinMiddleIndex();
        int int31 = timePeriodValues26.getItemCount();
        timePeriodValues26.setKey((java.lang.Comparable) 100.0d);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year34, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod37 = timePeriodValue36.getPeriod();
        timePeriodValue36.setValue((java.lang.Number) 100);
        java.lang.String str40 = timePeriodValue36.toString();
        boolean boolean42 = timePeriodValue36.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        boolean boolean45 = year43.equals((java.lang.Object) false);
        int int46 = year43.getYear();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        boolean boolean49 = year47.equals((java.lang.Object) false);
        boolean boolean50 = year43.equals((java.lang.Object) year47);
        java.util.Date date51 = year43.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year43.previous();
        boolean boolean53 = timePeriodValue36.equals((java.lang.Object) regularTimePeriod52);
        java.lang.Number number54 = null;
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) regularTimePeriod52, number54);
        boolean boolean56 = year17.equals((java.lang.Object) timePeriodValues26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(timePeriod11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(timePeriod37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "TimePeriodValue[2019,100]" + "'", str40.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue10.getPeriod();
        timePeriodValue10.setValue((java.lang.Number) 100);
        timePeriodValue10.setValue((java.lang.Number) 2019L);
        timePeriodValues1.add(timePeriodValue10);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        long long20 = year17.getLastMillisecond();
        java.lang.String str21 = year17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 1546329600000L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(timePeriod11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
        try {
            java.lang.Number number11 = timePeriodValues9.getValue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year10.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        int int10 = year0.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues20.setDescription("Time");
        int int23 = timePeriodValues20.getMinStartIndex();
        java.lang.String str24 = timePeriodValues20.getRangeDescription();
        java.lang.Object obj25 = timePeriodValues20.clone();
        java.lang.String str26 = timePeriodValues20.getDescription();
        int int27 = timePeriodValues20.getMinStartIndex();
        boolean boolean28 = day9.equals((java.lang.Object) timePeriodValues20);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod32 = timePeriodValue31.getPeriod();
        timePeriodValues20.add(timePeriodValue31);
        int int34 = timePeriodValues20.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timePeriod32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(2019L, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0d);
        timePeriodValues1.fireSeriesChanged();
        boolean boolean3 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        boolean boolean27 = day18.equals((java.lang.Object) seriesException22);
        org.jfree.data.time.SerialDate serialDate28 = day18.getSerialDate();
        timePeriodValues1.setKey((java.lang.Comparable) day18);
        java.lang.String str30 = day18.toString();
        int int31 = day18.getYear();
        long long32 = day18.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43830L + "'", long32 == 43830L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("");
        java.lang.Comparable comparable11 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues1.getDataItem(0);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        int int17 = year14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.next();
        java.lang.String str19 = year14.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, 1.0d);
        java.util.Date date22 = year14.getEnd();
        boolean boolean23 = timePeriodValue13.equals((java.lang.Object) date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) false);
        int int27 = year24.getYear();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) false);
        boolean boolean31 = year24.equals((java.lang.Object) year28);
        java.util.Date date32 = year24.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(date22, date32);
        long long34 = simpleTimePeriod33.getEndMillis();
        java.util.Date date35 = simpleTimePeriod33.getStart();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 0.0d + "'", comparable11.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriodValue13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertNotNull(date35);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str23 = timePeriodValues22.getDomainDescription();
        timePeriodValues22.setNotify(true);
        java.lang.String str26 = timePeriodValues22.getRangeDescription();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        java.lang.String str28 = timePeriodValues22.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) false);
        int int34 = year31.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        boolean boolean38 = year31.equals((java.lang.Object) year35);
        java.util.Date date39 = year31.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        boolean boolean42 = day40.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        java.lang.String str45 = seriesException44.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException44.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        boolean boolean49 = day40.equals((java.lang.Object) seriesException44);
        org.jfree.data.time.SerialDate serialDate50 = day40.getSerialDate();
        long long51 = day40.getLastMillisecond();
        int int52 = day40.getYear();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day40, (double) 0L);
        int int55 = year20.compareTo((java.lang.Object) day40);
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day40);
        long long57 = day40.getLastMillisecond();
        int int58 = day40.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue60 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day40, (double) '#');
        java.util.Date date61 = day40.getStart();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0d + "'", comparable27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str45.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577865599999L + "'", long57 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
        org.junit.Assert.assertNotNull(date61);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        int int11 = year8.getYear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        boolean boolean15 = year8.equals((java.lang.Object) year12);
        java.util.Date date16 = year8.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        boolean boolean19 = day17.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("");
        java.lang.String str22 = seriesException21.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        boolean boolean26 = day17.equals((java.lang.Object) seriesException21);
        org.jfree.data.time.SerialDate serialDate27 = day17.getSerialDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate27);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 8);
        int int32 = timePeriodValues1.getMinEndIndex();
        int int33 = timePeriodValues1.getMinEndIndex();
        boolean boolean34 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str37 = timePeriodValues36.getDomainDescription();
        timePeriodValues36.setDomainDescription("Time");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        timePeriodValues36.add((org.jfree.data.time.TimePeriod) year40, (double) (-1L));
        long long43 = year40.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year40.next();
        long long45 = year40.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year40.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue48 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (double) 9);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        int int54 = timePeriodValues50.getMinMiddleIndex();
        boolean boolean55 = timePeriodValue48.equals((java.lang.Object) int54);
        org.jfree.data.time.TimePeriod timePeriod56 = timePeriodValue48.getPeriod();
        timePeriodValues1.add(timePeriod56, (double) (short) -1);
        int int59 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        int int63 = year60.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year60.next();
        java.lang.String str65 = year60.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year60, 1.0d);
        java.util.Date date68 = year60.getEnd();
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date68);
        int int70 = day69.getYear();
        timePeriodValues1.setKey((java.lang.Comparable) day69);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str22.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Time" + "'", str37.equals("Time"));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(timePeriod56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2019 + "'", int63 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "2019" + "'", str65.equals("2019"));
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ", "TimePeriodValue[2019,100]", "2019");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        java.lang.Number number3 = timePeriodValue2.getValue();
        java.lang.Object obj4 = timePeriodValue2.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str7 = timePeriodValues6.getDomainDescription();
        timePeriodValues6.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        boolean boolean17 = year10.equals((java.lang.Object) year14);
        java.util.Date date18 = year10.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        boolean boolean21 = day19.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("");
        java.lang.String str24 = seriesException23.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException23.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        boolean boolean28 = day19.equals((java.lang.Object) seriesException23);
        java.lang.String str29 = day19.toString();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day19, (double) (byte) -1);
        java.lang.Object obj32 = timePeriodValues6.clone();
        boolean boolean33 = timePeriodValue2.equals(obj32);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str24.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "31-December-2019" + "'", str29.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        java.lang.Object obj9 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 0.0d + "'", comparable8.equals(0.0d));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setRangeDescription("Time");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        boolean boolean17 = year10.equals((java.lang.Object) year14);
        java.util.Date date18 = year10.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        int int20 = day19.getMonth();
        long long21 = day19.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) (byte) 100);
        java.util.Date date24 = day19.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) false);
        int int28 = year25.getYear();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        boolean boolean31 = year29.equals((java.lang.Object) false);
        boolean boolean32 = year25.equals((java.lang.Object) year29);
        java.util.Date date33 = year25.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) false);
        int int37 = year34.getYear();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        boolean boolean40 = year38.equals((java.lang.Object) false);
        boolean boolean41 = year34.equals((java.lang.Object) year38);
        java.util.Date date42 = year34.getEnd();
        boolean boolean43 = year25.equals((java.lang.Object) date42);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(date24, date42);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577779200000L + "'", long21 == 1577779200000L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a', "hi!", "Time");
        boolean boolean39 = year27.equals((java.lang.Object) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate13 = day9.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,100]");
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0f);
        timePeriodValues1.setDomainDescription("org.jfree.data.general.SeriesException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=30-December-2019]");
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.general.SeriesChangeEvent[source=Value]", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues11.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues15.setDescription("Time");
        int int18 = timePeriodValues15.getMinStartIndex();
        java.lang.String str19 = timePeriodValues15.getRangeDescription();
        int int20 = timePeriodValues15.getItemCount();
        timePeriodValues15.setDescription("2019");
        int int23 = timePeriodValues15.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener24);
        timePeriodValues15.setDomainDescription("org.jfree.data.general.SeriesException: ");
        int int28 = timePeriodValues15.getMinStartIndex();
        boolean boolean29 = timePeriodValues11.equals((java.lang.Object) timePeriodValues15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timePeriodValues11.addChangeListener(seriesChangeListener30);
        timePeriodValues11.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) false);
        int int4 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        boolean boolean8 = year1.equals((java.lang.Object) year5);
        boolean boolean10 = year1.equals((java.lang.Object) false);
        java.util.Date date11 = year1.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        java.util.Date date20 = year12.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) false);
        int int24 = year21.getYear();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) false);
        boolean boolean28 = year21.equals((java.lang.Object) year25);
        java.util.Date date29 = year21.getEnd();
        boolean boolean30 = year12.equals((java.lang.Object) date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        boolean boolean35 = year33.equals((java.lang.Object) false);
        int int36 = year33.getYear();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        boolean boolean39 = year37.equals((java.lang.Object) false);
        boolean boolean40 = year33.equals((java.lang.Object) year37);
        java.util.Date date41 = year33.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        java.lang.String str43 = day42.toString();
        java.util.Date date44 = day42.getStart();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        boolean boolean47 = year45.equals((java.lang.Object) false);
        int int48 = year45.getYear();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        boolean boolean51 = year49.equals((java.lang.Object) false);
        boolean boolean52 = year45.equals((java.lang.Object) year49);
        boolean boolean54 = year45.equals((java.lang.Object) false);
        java.util.Date date55 = year45.getStart();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        int int59 = year56.getYear();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        boolean boolean63 = year56.equals((java.lang.Object) year60);
        java.util.Date date64 = year56.getEnd();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        boolean boolean67 = year65.equals((java.lang.Object) false);
        int int68 = year65.getYear();
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        boolean boolean71 = year69.equals((java.lang.Object) false);
        boolean boolean72 = year65.equals((java.lang.Object) year69);
        java.util.Date date73 = year65.getEnd();
        boolean boolean74 = year56.equals((java.lang.Object) date73);
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date73, timeZone75);
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date55, timeZone75);
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date44, timeZone75);
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date29, timeZone75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date11, timeZone75);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "31-December-2019" + "'", str43.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2019 + "'", int68 == 2019);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNull(regularTimePeriod80);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        int int16 = year13.getYear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        boolean boolean20 = year13.equals((java.lang.Object) year17);
        java.util.Date date21 = year13.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        boolean boolean24 = day22.equals((java.lang.Object) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day22.previous();
        boolean boolean26 = day9.equals((java.lang.Object) day22);
        long long27 = day9.getFirstMillisecond();
        java.util.Calendar calendar28 = null;
        try {
            long long29 = day9.getLastMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577779200000L + "'", long27 == 1577779200000L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        long long20 = day9.getLastMillisecond();
        int int21 = day9.getYear();
        java.lang.String str22 = day9.toString();
        java.util.Date date23 = day9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (double) 1546329600000L);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = day9.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        int int10 = day9.getDayOfMonth();
        java.lang.String str11 = day9.toString();
        long long12 = day9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("Value");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        timePeriodValue9.setValue((java.lang.Number) 100);
        timePeriodValues3.add(timePeriodValue9);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        int int17 = year14.getYear();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) false);
        boolean boolean21 = year14.equals((java.lang.Object) year18);
        java.util.Date date22 = year14.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        int int24 = day23.getMonth();
        long long25 = day23.getFirstMillisecond();
        boolean boolean26 = timePeriodValue9.equals((java.lang.Object) day23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues28.setDescription("Time");
        int int31 = timePeriodValues28.getMinStartIndex();
        java.lang.String str32 = timePeriodValues28.getRangeDescription();
        java.lang.Object obj33 = timePeriodValues28.clone();
        java.lang.String str34 = timePeriodValues28.getRangeDescription();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        int int38 = year35.getYear();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) false);
        boolean boolean42 = year35.equals((java.lang.Object) year39);
        java.util.Date date43 = year35.getEnd();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        boolean boolean46 = day44.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException48 = new org.jfree.data.general.SeriesException("");
        java.lang.String str49 = seriesException48.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException48.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        boolean boolean53 = day44.equals((java.lang.Object) seriesException48);
        org.jfree.data.time.SerialDate serialDate54 = day44.getSerialDate();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(serialDate54);
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day56, (java.lang.Number) 8);
        int int59 = timePeriodValues28.getMinEndIndex();
        int int60 = timePeriodValues28.getMinEndIndex();
        boolean boolean61 = timePeriodValues28.isEmpty();
        boolean boolean62 = day23.equals((java.lang.Object) timePeriodValues28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577779200000L + "'", long25 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Value" + "'", str32.equals("Value"));
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Value" + "'", str34.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str49.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        boolean boolean10 = year5.equals((java.lang.Object) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timePeriodValues30.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date11, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        java.lang.Class<?> wildcardClass54 = timePeriodValues50.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        int int59 = year56.getYear();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        boolean boolean63 = year56.equals((java.lang.Object) year60);
        java.util.Date date64 = year56.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date64, timeZone66);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date11, date64);
        long long69 = simpleTimePeriod68.getEndMillis();
        long long70 = simpleTimePeriod68.getEndMillis();
        java.util.Date date71 = simpleTimePeriod68.getStart();
        org.jfree.data.general.SeriesException seriesException73 = new org.jfree.data.general.SeriesException("1-January-2019");
        boolean boolean74 = simpleTimePeriod68.equals((java.lang.Object) seriesException73);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1577865599999L + "'", long70 == 1577865599999L);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMinEndIndex();
        int int8 = timePeriodValues1.getMinMiddleIndex();
        try {
            timePeriodValues1.delete((-1), 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.lang.String str8 = year0.toString();
        int int9 = year0.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        int int26 = year23.getYear();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        boolean boolean30 = year23.equals((java.lang.Object) year27);
        java.util.Date date31 = year23.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        boolean boolean34 = year32.equals((java.lang.Object) false);
        int int35 = year32.getYear();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        boolean boolean39 = year32.equals((java.lang.Object) year36);
        java.util.Date date40 = year32.getEnd();
        boolean boolean41 = year23.equals((java.lang.Object) date40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date40, timeZone42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date22, timeZone42);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date11, timeZone42);
        java.util.Date date46 = day45.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day45);
        timePeriodValues47.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(date46);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        long long10 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.previous();
        java.lang.Object obj12 = null;
        int int13 = year5.compareTo(obj12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        long long8 = year4.getMiddleMillisecond();
        int int9 = year4.getYear();
        java.lang.Class<?> wildcardClass10 = year4.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str13 = timePeriodValues12.getDomainDescription();
        timePeriodValues12.setNotify(true);
        java.lang.Class<?> wildcardClass16 = timePeriodValues12.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) false);
        int int21 = year18.getYear();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean24 = year22.equals((java.lang.Object) false);
        boolean boolean25 = year18.equals((java.lang.Object) year22);
        java.util.Date date26 = year18.getEnd();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date26, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        boolean boolean32 = year30.equals((java.lang.Object) false);
        int int33 = year30.getYear();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) false);
        boolean boolean37 = year30.equals((java.lang.Object) year34);
        java.util.Date date38 = year30.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) false);
        int int42 = year39.getYear();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        boolean boolean45 = year43.equals((java.lang.Object) false);
        boolean boolean46 = year39.equals((java.lang.Object) year43);
        java.util.Date date47 = year39.getEnd();
        boolean boolean48 = year30.equals((java.lang.Object) date47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date47, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date26, timeZone49);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date26);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("");
        java.lang.Comparable comparable11 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues1.getDataItem(0);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        int int17 = year14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.next();
        java.lang.String str19 = year14.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, 1.0d);
        java.util.Date date22 = year14.getEnd();
        boolean boolean23 = timePeriodValue13.equals((java.lang.Object) date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) false);
        int int27 = year24.getYear();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) false);
        boolean boolean31 = year24.equals((java.lang.Object) year28);
        java.util.Date date32 = year24.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(date22, date32);
        long long34 = simpleTimePeriod33.getStartMillis();
        java.util.Date date35 = simpleTimePeriod33.getEnd();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 0.0d + "'", comparable11.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriodValue13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertNotNull(date35);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        int int16 = year13.getYear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        boolean boolean20 = year13.equals((java.lang.Object) year17);
        java.util.Date date21 = year13.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        boolean boolean24 = day22.equals((java.lang.Object) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day22.previous();
        boolean boolean26 = day9.equals((java.lang.Object) day22);
        long long27 = day9.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate28 = day9.getSerialDate();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str33 = timePeriodValues32.getDomainDescription();
        timePeriodValues32.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        boolean boolean47 = day45.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException49 = new org.jfree.data.general.SeriesException("");
        java.lang.String str50 = seriesException49.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException49.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
        boolean boolean54 = day45.equals((java.lang.Object) seriesException49);
        java.lang.String str55 = day45.toString();
        timePeriodValues32.add((org.jfree.data.time.TimePeriod) day45, (double) (byte) -1);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        boolean boolean60 = year58.equals((java.lang.Object) false);
        int int61 = year58.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year58.next();
        java.util.Date date63 = year58.getEnd();
        timePeriodValues32.add((org.jfree.data.time.TimePeriod) year58, (double) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues69 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "", "hi!");
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        boolean boolean72 = year70.equals((java.lang.Object) false);
        int int73 = year70.getYear();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
        boolean boolean76 = year74.equals((java.lang.Object) false);
        boolean boolean77 = year70.equals((java.lang.Object) year74);
        boolean boolean79 = year70.equals((java.lang.Object) false);
        timePeriodValues69.add((org.jfree.data.time.TimePeriod) year70, (java.lang.Number) 2);
        long long82 = year70.getSerialIndex();
        int int83 = year58.compareTo((java.lang.Object) year70);
        int int84 = year70.getYear();
        long long85 = year70.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = year70.previous();
        boolean boolean87 = day29.equals((java.lang.Object) regularTimePeriod86);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577779200000L + "'", long27 == 1577779200000L);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Time" + "'", str33.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str50.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "31-December-2019" + "'", str55.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 2019L + "'", long82 == 2019L);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 2019 + "'", int84 == 2019);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1546329600000L + "'", long85 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.String str6 = timePeriodValues1.getDescription();
        boolean boolean7 = timePeriodValues1.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy((-1), 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        java.lang.Object obj13 = timePeriodValue11.clone();
        boolean boolean14 = timePeriodValues1.equals(obj13);
        java.lang.String str15 = timePeriodValues1.getDescription();
        int int16 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date10);
        java.lang.Class<?> wildcardClass17 = year16.getClass();
        int int18 = year16.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        int int23 = year20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year20.next();
        java.lang.String str25 = year20.toString();
        int int26 = day9.compareTo((java.lang.Object) str25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day9.next();
        org.jfree.data.time.SerialDate serialDate28 = day9.getSerialDate();
        java.util.Date date29 = day9.getStart();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.String str12 = day11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        long long14 = day11.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1-January-2019" + "'", str12.equals("1-January-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546415999999L + "'", long14 == 1546415999999L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues10.setDescription("Time");
        int int13 = timePeriodValues10.getMinStartIndex();
        java.lang.String str14 = timePeriodValues10.getRangeDescription();
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMinEndIndex();
        int int17 = year0.compareTo((java.lang.Object) timePeriodValues10);
        timePeriodValues10.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        boolean boolean8 = timePeriodValues1.getNotify();
        int int9 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) -1, (-1));
        int int13 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        long long20 = day9.getLastMillisecond();
        int int21 = day9.getYear();
        java.lang.String str22 = day9.toString();
        long long23 = day9.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day9, "org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: ]", "org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: ]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43830L + "'", long23 == 43830L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("");
        java.lang.Comparable comparable11 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues1.getDataItem(0);
        int int14 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) false);
        int int18 = year15.getYear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) false);
        boolean boolean22 = year15.equals((java.lang.Object) year19);
        boolean boolean24 = year15.equals((java.lang.Object) false);
        java.util.Date date25 = year15.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.lang.String str27 = day26.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str30 = timePeriodValues29.getDomainDescription();
        timePeriodValues29.setNotify(true);
        int int33 = timePeriodValues29.getMinMiddleIndex();
        int int34 = timePeriodValues29.getItemCount();
        timePeriodValues29.setKey((java.lang.Comparable) 100.0d);
        int int37 = day26.compareTo((java.lang.Object) 100.0d);
        timePeriodValues1.setKey((java.lang.Comparable) day26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 0.0d + "'", comparable11.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriodValue13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1-January-2019" + "'", str27.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Time" + "'", str30.equals("Time"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues9.addChangeListener(seriesChangeListener10);
        java.lang.Object obj12 = timePeriodValues9.clone();
        timePeriodValues9.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        int int12 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timePeriodValues30.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date11, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        java.lang.Class<?> wildcardClass54 = timePeriodValues50.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        int int59 = year56.getYear();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        boolean boolean63 = year56.equals((java.lang.Object) year60);
        java.util.Date date64 = year56.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date64, timeZone66);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date11, date64);
        long long69 = simpleTimePeriod68.getEndMillis();
        java.util.Date date70 = simpleTimePeriod68.getEnd();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        boolean boolean73 = year71.equals((java.lang.Object) false);
        int int74 = year71.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = year71.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year71.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue78 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year71, (double) 0);
        java.util.Date date79 = year71.getEnd();
        long long80 = year71.getLastMillisecond();
        java.lang.String str81 = year71.toString();
        boolean boolean82 = simpleTimePeriod68.equals((java.lang.Object) year71);
        java.util.Date date83 = simpleTimePeriod68.getStart();
        java.util.Date date84 = simpleTimePeriod68.getStart();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2019 + "'", int74 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1577865599999L + "'", long80 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "2019" + "'", str81.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(date84);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        int int7 = year4.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        boolean boolean11 = year4.equals((java.lang.Object) year8);
        boolean boolean13 = year4.equals((java.lang.Object) false);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 2);
        java.lang.String str16 = timePeriodValues3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener17);
        timePeriodValues3.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        java.util.Date date20 = year12.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        java.lang.String str22 = day21.toString();
        int int24 = day21.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) false);
        int int28 = year25.getYear();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        boolean boolean31 = year29.equals((java.lang.Object) false);
        boolean boolean32 = year25.equals((java.lang.Object) year29);
        java.util.Date date33 = year25.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        boolean boolean36 = day34.equals((java.lang.Object) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day34.previous();
        boolean boolean38 = day21.equals((java.lang.Object) day34);
        int int39 = day34.getDayOfMonth();
        int int40 = day9.compareTo((java.lang.Object) day34);
        int int41 = day9.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 31 + "'", int39 == 31);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener35);
        java.lang.Comparable comparable37 = timePeriodValues1.getKey();
        int int38 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 0.0d + "'", comparable37.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) false);
        int int9 = year6.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        boolean boolean13 = year6.equals((java.lang.Object) year10);
        boolean boolean15 = year6.equals((java.lang.Object) false);
        java.util.Date date16 = year6.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        int int20 = year17.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) false);
        boolean boolean24 = year17.equals((java.lang.Object) year21);
        java.util.Date date25 = year17.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        boolean boolean28 = year26.equals((java.lang.Object) false);
        int int29 = year26.getYear();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        boolean boolean32 = year30.equals((java.lang.Object) false);
        boolean boolean33 = year26.equals((java.lang.Object) year30);
        java.util.Date date34 = year26.getEnd();
        boolean boolean35 = year17.equals((java.lang.Object) date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date34, timeZone36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date16, timeZone36);
        java.util.Date date39 = year38.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        int int43 = year40.getYear();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        boolean boolean46 = year44.equals((java.lang.Object) false);
        boolean boolean47 = year40.equals((java.lang.Object) year44);
        boolean boolean49 = year40.equals((java.lang.Object) false);
        java.util.Date date50 = year40.getStart();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date50, timeZone52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date39, timeZone52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date39);
        int int57 = day56.getYear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        int int9 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        try {
            java.lang.Number number15 = timePeriodValues1.getValue(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0f));
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        int int7 = year4.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        boolean boolean11 = year4.equals((java.lang.Object) year8);
        long long12 = year8.getMiddleMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year8.previous();
        long long17 = year8.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str3 = timePeriodValues2.getDomainDescription();
        timePeriodValues2.setNotify(true);
        java.lang.Class<?> wildcardClass6 = timePeriodValues2.getClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) false);
        int int10 = year7.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        boolean boolean14 = year7.equals((java.lang.Object) year11);
        boolean boolean16 = year7.equals((java.lang.Object) false);
        java.util.Date date17 = year7.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) false);
        int int21 = year18.getYear();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean24 = year22.equals((java.lang.Object) false);
        boolean boolean25 = year18.equals((java.lang.Object) year22);
        java.util.Date date26 = year18.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) false);
        boolean boolean34 = year27.equals((java.lang.Object) year31);
        java.util.Date date35 = year27.getEnd();
        boolean boolean36 = year18.equals((java.lang.Object) date35);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date35, timeZone37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date17, timeZone37);
        java.util.Date date40 = year39.getStart();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        boolean boolean43 = year41.equals((java.lang.Object) false);
        int int44 = year41.getYear();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        boolean boolean47 = year45.equals((java.lang.Object) false);
        boolean boolean48 = year41.equals((java.lang.Object) year45);
        boolean boolean50 = year41.equals((java.lang.Object) false);
        java.util.Date date51 = year41.getStart();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date51, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date40, timeZone53);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date40);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(date0, date40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod55);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        java.util.Date date5 = year0.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timePeriodValues30.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date11, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        java.lang.Class<?> wildcardClass54 = timePeriodValues50.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        int int59 = year56.getYear();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        boolean boolean63 = year56.equals((java.lang.Object) year60);
        java.util.Date date64 = year56.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date64, timeZone66);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date11, date64);
        long long69 = simpleTimePeriod68.getEndMillis();
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        boolean boolean72 = year70.equals((java.lang.Object) false);
        int int73 = year70.getYear();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
        boolean boolean76 = year74.equals((java.lang.Object) false);
        boolean boolean77 = year70.equals((java.lang.Object) year74);
        java.util.Date date78 = year70.getEnd();
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date78);
        java.lang.String str80 = day79.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = day79.next();
        boolean boolean82 = simpleTimePeriod68.equals((java.lang.Object) regularTimePeriod81);
        long long83 = simpleTimePeriod68.getStartMillis();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "31-December-2019" + "'", str80.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1577779200000L + "'", long83 == 1577779200000L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.delete((int) (byte) 100, (int) ' ');
        int int6 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        long long20 = day9.getLastMillisecond();
        int int21 = day9.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day9, "", "org.jfree.data.general.SeriesChangeEvent[source=Value]");
        java.lang.Class<?> wildcardClass25 = timePeriodValues24.getClass();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        boolean boolean28 = year26.equals((java.lang.Object) false);
        int int29 = year26.getYear();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        boolean boolean32 = year30.equals((java.lang.Object) false);
        boolean boolean33 = year26.equals((java.lang.Object) year30);
        java.util.Date date34 = year26.getEnd();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        int int38 = year35.getYear();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) false);
        boolean boolean42 = year35.equals((java.lang.Object) year39);
        java.util.Date date43 = year35.getEnd();
        boolean boolean44 = year26.equals((java.lang.Object) date43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        boolean boolean47 = year45.equals((java.lang.Object) false);
        int int48 = year45.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year45.next();
        java.util.Date date50 = year45.getEnd();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        boolean boolean53 = year51.equals((java.lang.Object) false);
        int int54 = year51.getYear();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        boolean boolean57 = year55.equals((java.lang.Object) false);
        boolean boolean58 = year51.equals((java.lang.Object) year55);
        java.util.Date date59 = year51.getEnd();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        java.lang.String str61 = day60.toString();
        java.util.Date date62 = day60.getStart();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        boolean boolean65 = year63.equals((java.lang.Object) false);
        int int66 = year63.getYear();
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
        boolean boolean69 = year67.equals((java.lang.Object) false);
        boolean boolean70 = year63.equals((java.lang.Object) year67);
        boolean boolean72 = year63.equals((java.lang.Object) false);
        java.util.Date date73 = year63.getStart();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
        boolean boolean76 = year74.equals((java.lang.Object) false);
        int int77 = year74.getYear();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        boolean boolean80 = year78.equals((java.lang.Object) false);
        boolean boolean81 = year74.equals((java.lang.Object) year78);
        java.util.Date date82 = year74.getEnd();
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year();
        boolean boolean85 = year83.equals((java.lang.Object) false);
        int int86 = year83.getYear();
        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year();
        boolean boolean89 = year87.equals((java.lang.Object) false);
        boolean boolean90 = year83.equals((java.lang.Object) year87);
        java.util.Date date91 = year83.getEnd();
        boolean boolean92 = year74.equals((java.lang.Object) date91);
        java.util.TimeZone timeZone93 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year94 = new org.jfree.data.time.Year(date91, timeZone93);
        org.jfree.data.time.Year year95 = new org.jfree.data.time.Year(date73, timeZone93);
        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(date62, timeZone93);
        org.jfree.data.time.Day day97 = new org.jfree.data.time.Day(date50, timeZone93);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date43, timeZone93);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "31-December-2019" + "'", str61.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2019 + "'", int77 == 2019);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 2019 + "'", int86 == 2019);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(timeZone93);
        org.junit.Assert.assertNull(regularTimePeriod98);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        int int9 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(3, 5);
        timePeriodValues12.fireSeriesChanged();
        boolean boolean14 = timePeriodValues12.getNotify();
        java.lang.String str15 = timePeriodValues12.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues12.removeChangeListener(seriesChangeListener16);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        int int11 = year8.getYear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        boolean boolean15 = year8.equals((java.lang.Object) year12);
        java.util.Date date16 = year8.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        boolean boolean19 = day17.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("");
        java.lang.String str22 = seriesException21.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        boolean boolean26 = day17.equals((java.lang.Object) seriesException21);
        org.jfree.data.time.SerialDate serialDate27 = day17.getSerialDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate27);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 8);
        int int32 = timePeriodValues1.getMinEndIndex();
        int int33 = timePeriodValues1.getMinEndIndex();
        boolean boolean34 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str37 = timePeriodValues36.getDomainDescription();
        timePeriodValues36.setDomainDescription("Time");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        timePeriodValues36.add((org.jfree.data.time.TimePeriod) year40, (double) (-1L));
        long long43 = year40.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year40.next();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        boolean boolean47 = year45.equals((java.lang.Object) false);
        int int48 = year45.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year45.next();
        boolean boolean50 = year40.equals((java.lang.Object) year45);
        timePeriodValues1.setKey((java.lang.Comparable) year40);
        int int52 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str22.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Time" + "'", str37.equals("Time"));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setKey((java.lang.Comparable) 100.0d);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        int int11 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        java.util.Date date20 = year12.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        java.lang.String str22 = day21.toString();
        int int24 = day21.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) false);
        int int28 = year25.getYear();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        boolean boolean31 = year29.equals((java.lang.Object) false);
        boolean boolean32 = year25.equals((java.lang.Object) year29);
        java.util.Date date33 = year25.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        boolean boolean36 = day34.equals((java.lang.Object) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day34.previous();
        boolean boolean38 = day21.equals((java.lang.Object) day34);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, 0.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, (double) 5);
        timePeriodValues1.add(timePeriodValue42);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getMinStartIndex();
        boolean boolean7 = timePeriodValues1.getNotify();
        try {
            timePeriodValues1.delete(8, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        int int16 = year13.getYear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        boolean boolean20 = year13.equals((java.lang.Object) year17);
        java.util.Date date21 = year13.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        boolean boolean24 = day22.equals((java.lang.Object) 2019);
        long long25 = day22.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day22.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day22, (double) 1577779200000L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577779200000L + "'", long25 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        int int7 = timePeriodValues1.getMaxStartIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues1.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getItemCount();
        java.lang.String str6 = timePeriodValues3.getDescription();
        boolean boolean7 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year5.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        int int14 = year11.getYear();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) false);
        boolean boolean18 = year11.equals((java.lang.Object) year15);
        java.util.Date date19 = year11.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        int int23 = year20.getYear();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) false);
        boolean boolean27 = year20.equals((java.lang.Object) year24);
        java.util.Date date28 = year20.getEnd();
        boolean boolean29 = year11.equals((java.lang.Object) date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date28, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date10, timeZone30);
        java.util.Date date33 = year32.getStart();
        long long34 = year32.getFirstMillisecond();
        java.lang.Class<?> wildcardClass35 = year32.getClass();
        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(class36);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        boolean boolean17 = year10.equals((java.lang.Object) year14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year10.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (java.lang.Number) (-1.0f));
        int int21 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setKey((java.lang.Comparable) 100.0d);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        timePeriodValue11.setValue((java.lang.Number) 100);
        java.lang.String str15 = timePeriodValue11.toString();
        boolean boolean17 = timePeriodValue11.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) false);
        int int21 = year18.getYear();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean24 = year22.equals((java.lang.Object) false);
        boolean boolean25 = year18.equals((java.lang.Object) year22);
        java.util.Date date26 = year18.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year18.previous();
        boolean boolean28 = timePeriodValue11.equals((java.lang.Object) regularTimePeriod27);
        java.lang.Number number29 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod27, number29);
        int int31 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[2019,100]" + "'", str15.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 9, 100L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        int int7 = year4.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        boolean boolean11 = year4.equals((java.lang.Object) year8);
        java.util.Date date12 = year4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year4.previous();
        boolean boolean14 = simpleTimePeriod2.equals((java.lang.Object) regularTimePeriod13);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        int int9 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener10);
        timePeriodValues1.setDomainDescription("org.jfree.data.general.SeriesException: ");
        int int14 = timePeriodValues1.getMinStartIndex();
        boolean boolean15 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        int int9 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Value");
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + "Value" + "'", obj3.equals("Value"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("Value");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        timePeriodValue9.setValue((java.lang.Number) 100);
        timePeriodValues3.add(timePeriodValue9);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        int int17 = year14.getYear();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) false);
        boolean boolean21 = year14.equals((java.lang.Object) year18);
        java.util.Date date22 = year14.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        int int24 = day23.getMonth();
        long long25 = day23.getFirstMillisecond();
        boolean boolean26 = timePeriodValue9.equals((java.lang.Object) day23);
        java.lang.Class<?> wildcardClass27 = day23.getClass();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577779200000L + "'", long25 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str23 = timePeriodValues22.getDomainDescription();
        timePeriodValues22.setNotify(true);
        java.lang.String str26 = timePeriodValues22.getRangeDescription();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        java.lang.String str28 = timePeriodValues22.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) false);
        int int34 = year31.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        boolean boolean38 = year31.equals((java.lang.Object) year35);
        java.util.Date date39 = year31.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        boolean boolean42 = day40.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        java.lang.String str45 = seriesException44.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException44.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        boolean boolean49 = day40.equals((java.lang.Object) seriesException44);
        org.jfree.data.time.SerialDate serialDate50 = day40.getSerialDate();
        long long51 = day40.getLastMillisecond();
        int int52 = day40.getYear();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day40, (double) 0L);
        int int55 = year20.compareTo((java.lang.Object) day40);
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day40);
        long long57 = day40.getLastMillisecond();
        int int58 = day40.getYear();
        long long59 = day40.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0d + "'", comparable27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str45.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577865599999L + "'", long57 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 43830L + "'", long59 == 43830L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.String str6 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue9.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue(timePeriod11, (double) 1);
        timePeriodValues1.add(timePeriodValue13);
        java.lang.Object obj15 = timePeriodValue13.clone();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValue18.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValue18.getPeriod();
        boolean boolean21 = timePeriodValue13.equals((java.lang.Object) timePeriod20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertNotNull(timePeriod11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(timePeriod19);
        org.junit.Assert.assertNotNull(timePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setKey((java.lang.Comparable) 100.0d);
        timePeriodValues1.setRangeDescription("1-January-2019");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 9, 100L);
        timePeriodValues1.setKey((java.lang.Comparable) 9);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        int int7 = year4.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        boolean boolean11 = year4.equals((java.lang.Object) year8);
        boolean boolean13 = year4.equals((java.lang.Object) false);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 2);
        java.lang.Class<?> wildcardClass16 = timePeriodValues3.getClass();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
        long long20 = year19.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.previous();
        org.jfree.data.time.SerialDate serialDate14 = day9.getSerialDate();
        long long15 = day9.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577779200000L + "'", long15 == 1577779200000L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
        java.lang.String str14 = day9.toString();
        java.lang.Class<?> wildcardClass15 = day9.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        int int38 = year35.getYear();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) false);
        boolean boolean42 = year35.equals((java.lang.Object) year39);
        boolean boolean44 = year35.equals((java.lang.Object) false);
        java.util.Date date45 = year35.getStart();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        java.lang.String str47 = day46.toString();
        int int48 = year27.compareTo((java.lang.Object) day46);
        java.lang.String str49 = day46.toString();
        long long50 = day46.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1-January-2019" + "'", str47.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1-January-2019" + "'", str49.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 43466L + "'", long50 == 43466L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("Value");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) false);
        int int10 = year7.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        boolean boolean14 = year7.equals((java.lang.Object) year11);
        java.util.Date date15 = year7.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        int int19 = year16.getYear();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        boolean boolean23 = year16.equals((java.lang.Object) year20);
        java.util.Date date24 = year16.getEnd();
        boolean boolean25 = year7.equals((java.lang.Object) date24);
        timePeriodValues3.setKey((java.lang.Comparable) year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year7.previous();
        long long28 = regularTimePeriod27.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1530561599999L + "'", long28 == 1530561599999L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "", "hi!");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) false);
        int int42 = year39.getYear();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        boolean boolean45 = year43.equals((java.lang.Object) false);
        boolean boolean46 = year39.equals((java.lang.Object) year43);
        boolean boolean48 = year39.equals((java.lang.Object) false);
        timePeriodValues38.add((org.jfree.data.time.TimePeriod) year39, (java.lang.Number) 2);
        long long51 = year39.getSerialIndex();
        int int52 = year27.compareTo((java.lang.Object) year39);
        int int53 = year39.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str56 = timePeriodValues55.getDomainDescription();
        timePeriodValues55.setDomainDescription("Time");
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year59, (double) (-1L));
        int int62 = timePeriodValues55.getItemCount();
        timePeriodValues55.setDomainDescription("");
        java.lang.Comparable comparable65 = timePeriodValues55.getKey();
        org.jfree.data.time.TimePeriodValue timePeriodValue67 = timePeriodValues55.getDataItem(0);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        boolean boolean70 = year68.equals((java.lang.Object) false);
        int int71 = year68.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year68.next();
        java.lang.String str73 = year68.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue75 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year68, 1.0d);
        java.util.Date date76 = year68.getEnd();
        boolean boolean77 = timePeriodValue67.equals((java.lang.Object) date76);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        boolean boolean80 = year78.equals((java.lang.Object) false);
        int int81 = year78.getYear();
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year();
        boolean boolean84 = year82.equals((java.lang.Object) false);
        boolean boolean85 = year78.equals((java.lang.Object) year82);
        java.util.Date date86 = year78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod87 = new org.jfree.data.time.SimpleTimePeriod(date76, date86);
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date86);
        int int89 = year39.compareTo((java.lang.Object) date86);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Time" + "'", str56.equals("Time"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + comparable65 + "' != '" + 0.0d + "'", comparable65.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriodValue67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2019 + "'", int71 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "2019" + "'", str73.equals("2019"));
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 2019 + "'", int81 == 2019);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        int int11 = year8.getYear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        boolean boolean15 = year8.equals((java.lang.Object) year12);
        java.util.Date date16 = year8.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        boolean boolean19 = day17.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("");
        java.lang.String str22 = seriesException21.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        boolean boolean26 = day17.equals((java.lang.Object) seriesException21);
        org.jfree.data.time.SerialDate serialDate27 = day17.getSerialDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate27);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 8);
        int int32 = timePeriodValues1.getMinEndIndex();
        int int33 = timePeriodValues1.getMinEndIndex();
        boolean boolean34 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str37 = timePeriodValues36.getDomainDescription();
        timePeriodValues36.setDomainDescription("Time");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        timePeriodValues36.add((org.jfree.data.time.TimePeriod) year40, (double) (-1L));
        long long43 = year40.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year40.next();
        long long45 = year40.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year40.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue48 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (double) 9);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        int int54 = timePeriodValues50.getMinMiddleIndex();
        boolean boolean55 = timePeriodValue48.equals((java.lang.Object) int54);
        org.jfree.data.time.TimePeriod timePeriod56 = timePeriodValue48.getPeriod();
        timePeriodValues1.add(timePeriod56, (double) (short) -1);
        int int59 = timePeriodValues1.getMinEndIndex();
        int int60 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str22.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Time" + "'", str37.equals("Time"));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(timePeriod56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        java.util.Date date12 = regularTimePeriod11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str15 = timePeriodValues14.getDomainDescription();
        timePeriodValues14.setNotify(true);
        java.lang.Class<?> wildcardClass18 = timePeriodValues14.getClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) false);
        int int22 = year19.getYear();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        boolean boolean26 = year19.equals((java.lang.Object) year23);
        boolean boolean28 = year19.equals((java.lang.Object) false);
        java.util.Date date29 = year19.getStart();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        boolean boolean32 = year30.equals((java.lang.Object) false);
        int int33 = year30.getYear();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) false);
        boolean boolean37 = year30.equals((java.lang.Object) year34);
        java.util.Date date38 = year30.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) false);
        int int42 = year39.getYear();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        boolean boolean45 = year43.equals((java.lang.Object) false);
        boolean boolean46 = year39.equals((java.lang.Object) year43);
        java.util.Date date47 = year39.getEnd();
        boolean boolean48 = year30.equals((java.lang.Object) date47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date47, timeZone49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date29, timeZone49);
        java.util.Date date52 = year51.getStart();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        boolean boolean55 = year53.equals((java.lang.Object) false);
        int int56 = year53.getYear();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        boolean boolean59 = year57.equals((java.lang.Object) false);
        boolean boolean60 = year53.equals((java.lang.Object) year57);
        boolean boolean62 = year53.equals((java.lang.Object) false);
        java.util.Date date63 = year53.getStart();
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date63);
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date63, timeZone65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date52, timeZone65);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date12, timeZone65);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod67);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day19);
        long long21 = day19.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        boolean boolean8 = timePeriodValues1.getNotify();
        int int9 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) -1, (-1));
        java.lang.Comparable comparable13 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0d + "'", comparable13.equals(0.0d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        int int26 = year21.compareTo((java.lang.Object) year23);
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (double) (short) 10);
        java.lang.Object obj29 = timePeriodValue28.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        boolean boolean8 = timePeriodValues1.getNotify();
        java.lang.String str9 = timePeriodValues1.getRangeDescription();
        int int10 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.general.SeriesChangeEvent[source=Value]", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        timePeriodValues11.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year27.previous();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timePeriodValues30.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date11, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        java.lang.Class<?> wildcardClass54 = timePeriodValues50.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        int int59 = year56.getYear();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        boolean boolean63 = year56.equals((java.lang.Object) year60);
        java.util.Date date64 = year56.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date64, timeZone66);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date11, date64);
        long long69 = simpleTimePeriod68.getEndMillis();
        java.util.Date date70 = simpleTimePeriod68.getEnd();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        boolean boolean73 = year71.equals((java.lang.Object) false);
        int int74 = year71.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = year71.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year71.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue78 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year71, (double) 0);
        java.util.Date date79 = year71.getEnd();
        long long80 = year71.getLastMillisecond();
        java.lang.String str81 = year71.toString();
        boolean boolean82 = simpleTimePeriod68.equals((java.lang.Object) year71);
        java.util.Date date83 = simpleTimePeriod68.getEnd();
        java.util.Date date84 = simpleTimePeriod68.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2019 + "'", int74 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1577865599999L + "'", long80 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "2019" + "'", str81.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(date84);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        long long20 = day9.getLastMillisecond();
        int int21 = day9.getMonth();
        org.jfree.data.time.SerialDate serialDate22 = day9.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        long long35 = year27.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year27.next();
        java.util.Calendar calendar37 = null;
        try {
            year27.peg(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        boolean boolean27 = day18.equals((java.lang.Object) seriesException22);
        org.jfree.data.time.SerialDate serialDate28 = day18.getSerialDate();
        timePeriodValues1.setKey((java.lang.Comparable) day18);
        java.lang.String str30 = day18.toString();
        int int31 = day18.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int31);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        int int16 = year13.getYear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        boolean boolean20 = year13.equals((java.lang.Object) year17);
        java.util.Date date21 = year13.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        boolean boolean24 = day22.equals((java.lang.Object) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day22.previous();
        boolean boolean26 = day9.equals((java.lang.Object) day22);
        long long27 = day9.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate28 = day9.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day9, "Time", "Time");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577779200000L + "'", long27 == 1577779200000L);
        org.junit.Assert.assertNotNull(serialDate28);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timePeriodValues30.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date11, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        java.lang.Class<?> wildcardClass54 = timePeriodValues50.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        int int59 = year56.getYear();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        boolean boolean63 = year56.equals((java.lang.Object) year60);
        java.util.Date date64 = year56.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date64, timeZone66);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date11, date64);
        long long69 = simpleTimePeriod68.getEndMillis();
        long long70 = simpleTimePeriod68.getEndMillis();
        java.util.Date date71 = simpleTimePeriod68.getStart();
        long long72 = simpleTimePeriod68.getStartMillis();
        java.util.Date date73 = simpleTimePeriod68.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1577865599999L + "'", long70 == 1577865599999L);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1577779200000L + "'", long72 == 1577779200000L);
        org.junit.Assert.assertNotNull(date73);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        int int38 = year35.getYear();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) false);
        boolean boolean42 = year35.equals((java.lang.Object) year39);
        boolean boolean44 = year35.equals((java.lang.Object) false);
        java.util.Date date45 = year35.getStart();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        java.lang.String str47 = day46.toString();
        int int48 = year27.compareTo((java.lang.Object) day46);
        java.lang.String str49 = day46.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day46, (java.lang.Number) 0.0f);
        java.lang.Number number52 = timePeriodValue51.getValue();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1-January-2019" + "'", str47.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1-January-2019" + "'", str49.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 0.0f + "'", number52.equals(0.0f));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        int int23 = year20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year20.next();
        java.lang.String str25 = year20.toString();
        int int26 = day9.compareTo((java.lang.Object) str25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day9.next();
        org.jfree.data.time.SerialDate serialDate28 = day9.getSerialDate();
        long long29 = day9.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43830L + "'", long29 == 43830L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        int int11 = year8.getYear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        boolean boolean15 = year8.equals((java.lang.Object) year12);
        java.util.Date date16 = year8.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        boolean boolean19 = day17.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("");
        java.lang.String str22 = seriesException21.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        boolean boolean26 = day17.equals((java.lang.Object) seriesException21);
        org.jfree.data.time.SerialDate serialDate27 = day17.getSerialDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate27);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 8);
        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str22.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate32);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        int int14 = year11.getYear();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) false);
        boolean boolean18 = year11.equals((java.lang.Object) year15);
        java.util.Date date19 = year11.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        int int23 = year20.getYear();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) false);
        boolean boolean27 = year20.equals((java.lang.Object) year24);
        java.util.Date date28 = year20.getEnd();
        boolean boolean29 = year11.equals((java.lang.Object) date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date28, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date10, timeZone30);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date10);
        long long34 = year33.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1562097599999L + "'", long34 == 1562097599999L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        int int9 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str10 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues1.getTimePeriod(0);
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("Value");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        timePeriodValue9.setValue((java.lang.Number) 100);
        timePeriodValues3.add(timePeriodValue9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener14);
        java.lang.String str16 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        int int17 = year14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.next();
        java.lang.String str19 = year14.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, 1.0d);
        java.util.Date date22 = year14.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year14, "org.jfree.data.general.SeriesChangeEvent[source=Value]", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        int int26 = day9.compareTo((java.lang.Object) "org.jfree.data.general.SeriesChangeEvent[source=Value]");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day9.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.delete((int) (byte) 100, (int) ' ');
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        java.lang.String str20 = day9.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31-December-2019" + "'", str20.equals("31-December-2019"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        int int4 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str9 = timePeriodValues8.getDomainDescription();
        timePeriodValues8.setRangeDescription("Value");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
        timePeriodValue14.setValue((java.lang.Number) 100);
        timePeriodValues8.add(timePeriodValue14);
        timePeriodValues1.add(timePeriodValue14);
        boolean boolean20 = timePeriodValues1.isEmpty();
        try {
            java.lang.Number number22 = timePeriodValues1.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day9);
        int int21 = day9.getDayOfMonth();
        long long22 = day9.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577822399999L + "'", long22 == 1577822399999L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timePeriodValues30.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date11, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        java.lang.Class<?> wildcardClass54 = timePeriodValues50.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        int int59 = year56.getYear();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        boolean boolean63 = year56.equals((java.lang.Object) year60);
        java.util.Date date64 = year56.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date64, timeZone66);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date11, date64);
        long long69 = simpleTimePeriod68.getEndMillis();
        java.util.Date date70 = simpleTimePeriod68.getEnd();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        boolean boolean73 = year71.equals((java.lang.Object) false);
        int int74 = year71.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = year71.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year71.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue78 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year71, (double) 0);
        java.util.Date date79 = year71.getEnd();
        long long80 = year71.getLastMillisecond();
        java.lang.String str81 = year71.toString();
        boolean boolean82 = simpleTimePeriod68.equals((java.lang.Object) year71);
        long long83 = simpleTimePeriod68.getStartMillis();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2019 + "'", int74 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1577865599999L + "'", long80 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "2019" + "'", str81.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1577779200000L + "'", long83 == 1577779200000L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean24 = year22.equals((java.lang.Object) false);
        int int25 = year22.getYear();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        boolean boolean28 = year26.equals((java.lang.Object) false);
        boolean boolean29 = year22.equals((java.lang.Object) year26);
        boolean boolean31 = year22.equals((java.lang.Object) false);
        java.util.Date date32 = year22.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        boolean boolean35 = year33.equals((java.lang.Object) false);
        int int36 = year33.getYear();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        boolean boolean39 = year37.equals((java.lang.Object) false);
        boolean boolean40 = year33.equals((java.lang.Object) year37);
        java.util.Date date41 = year33.getEnd();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        boolean boolean44 = year42.equals((java.lang.Object) false);
        int int45 = year42.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        boolean boolean48 = year46.equals((java.lang.Object) false);
        boolean boolean49 = year42.equals((java.lang.Object) year46);
        java.util.Date date50 = year42.getEnd();
        boolean boolean51 = year33.equals((java.lang.Object) date50);
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date50, timeZone52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date32, timeZone52);
        boolean boolean55 = year20.equals((java.lang.Object) timeZone52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        int int38 = year35.getYear();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) false);
        boolean boolean42 = year35.equals((java.lang.Object) year39);
        long long43 = year39.getMiddleMillisecond();
        int int44 = year39.getYear();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year39, (double) 'a');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year39.previous();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1562097599999L + "'", long43 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        timePeriodValues3.setDescription("TimePeriodValue[2019,100]");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean8 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 9, 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "TimePeriodValue[2019,-1.0]", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("");
        java.lang.Comparable comparable11 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues1.getDataItem(0);
        int int14 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.delete(11, 4);
        int int18 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 0.0d + "'", comparable11.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriodValue13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0f, "org.jfree.data.general.SeriesChangeEvent[source=Value]", "Value");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0f));
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        int int7 = year4.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        boolean boolean11 = year4.equals((java.lang.Object) year8);
        long long12 = year8.getMiddleMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        int int4 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str9 = timePeriodValues8.getDomainDescription();
        timePeriodValues8.setRangeDescription("Value");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
        timePeriodValue14.setValue((java.lang.Number) 100);
        timePeriodValues8.add(timePeriodValue14);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.String str20 = timePeriodValue14.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[2019,100]" + "'", str20.equals("TimePeriodValue[2019,100]"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        int int9 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener10);
        timePeriodValues1.setDomainDescription("org.jfree.data.general.SeriesException: ");
        int int14 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setRangeDescription("Time");
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener19);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day9);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) false);
        int int24 = year21.getYear();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) false);
        boolean boolean28 = year21.equals((java.lang.Object) year25);
        java.util.Date date29 = year21.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        java.lang.String str31 = day30.toString();
        int int33 = day30.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate34 = day30.getSerialDate();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate34);
        java.util.Date date36 = day35.getEnd();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        boolean boolean39 = year37.equals((java.lang.Object) false);
        int int40 = year37.getYear();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        boolean boolean43 = year41.equals((java.lang.Object) false);
        boolean boolean44 = year37.equals((java.lang.Object) year41);
        long long45 = year41.getMiddleMillisecond();
        int int46 = year41.getYear();
        java.lang.Class<?> wildcardClass47 = year41.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str50 = timePeriodValues49.getDomainDescription();
        timePeriodValues49.setNotify(true);
        java.lang.Class<?> wildcardClass53 = timePeriodValues49.getClass();
        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass53);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        boolean boolean57 = year55.equals((java.lang.Object) false);
        int int58 = year55.getYear();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        boolean boolean61 = year59.equals((java.lang.Object) false);
        boolean boolean62 = year55.equals((java.lang.Object) year59);
        java.util.Date date63 = year55.getEnd();
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date63);
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date63, timeZone65);
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
        boolean boolean69 = year67.equals((java.lang.Object) false);
        int int70 = year67.getYear();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        boolean boolean73 = year71.equals((java.lang.Object) false);
        boolean boolean74 = year67.equals((java.lang.Object) year71);
        java.util.Date date75 = year67.getEnd();
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year();
        boolean boolean78 = year76.equals((java.lang.Object) false);
        int int79 = year76.getYear();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year();
        boolean boolean82 = year80.equals((java.lang.Object) false);
        boolean boolean83 = year76.equals((java.lang.Object) year80);
        java.util.Date date84 = year76.getEnd();
        boolean boolean85 = year67.equals((java.lang.Object) date84);
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date84, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date63, timeZone86);
        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year(date36, timeZone86);
        int int90 = day9.compareTo((java.lang.Object) timeZone86);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-2019" + "'", str31.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1562097599999L + "'", long45 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Time" + "'", str50.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(class54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2019 + "'", int79 == 2019);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 1 + "'", int90 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "Time", "org.jfree.data.general.SeriesChangeEvent[source=30-December-2019]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getItemCount();
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        boolean boolean5 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMinEndIndex();
        int int8 = timePeriodValues1.getMinMiddleIndex();
        boolean boolean9 = timePeriodValues1.isEmpty();
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        timePeriodValues1.setNotify(false);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        int int16 = year13.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) (-1.0d));
        long long19 = year13.getMiddleMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) 0L);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0d + "'", comparable10.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1562097599999L + "'", long19 == 1562097599999L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        int int9 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(3, 5);
        timePeriodValues12.fireSeriesChanged();
        boolean boolean14 = timePeriodValues12.getNotify();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue16 = timePeriodValues12.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues1.getTimePeriod(0);
        boolean boolean11 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        java.lang.Object obj13 = timePeriodValue11.clone();
        boolean boolean14 = timePeriodValues1.equals(obj13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener15);
        timePeriodValues1.setNotify(true);
        int int19 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        long long23 = year20.getLastMillisecond();
        long long24 = year20.getLastMillisecond();
        java.util.Date date25 = year20.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year20, (java.lang.Number) 2);
        java.util.Date date28 = year20.getStart();
        long long29 = year20.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        java.lang.Object obj12 = null;
        boolean boolean13 = day9.equals(obj12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues15.getMinEndIndex();
        int int19 = day9.compareTo((java.lang.Object) timePeriodValues15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues15.addChangeListener(seriesChangeListener20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0f));
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: Time");
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ", "TimePeriodValue[2019,100]", "2019");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        try {
            timePeriodValues3.delete((int) (short) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,100]" + "'", str4.equals("TimePeriodValue[2019,100]"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        int int16 = year13.getYear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        boolean boolean20 = year13.equals((java.lang.Object) year17);
        java.util.Date date21 = year13.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        boolean boolean24 = day22.equals((java.lang.Object) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day22.previous();
        boolean boolean26 = day9.equals((java.lang.Object) day22);
        int int27 = day22.getDayOfMonth();
        java.util.Calendar calendar28 = null;
        try {
            long long29 = day22.getLastMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        int int6 = year0.getYear();
        java.util.Date date7 = year0.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        int int11 = year8.getYear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        boolean boolean15 = year8.equals((java.lang.Object) year12);
        boolean boolean17 = year8.equals((java.lang.Object) false);
        java.util.Date date18 = year8.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) false);
        int int22 = year19.getYear();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        boolean boolean26 = year19.equals((java.lang.Object) year23);
        java.util.Date date27 = year19.getEnd();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) false);
        int int31 = year28.getYear();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        boolean boolean34 = year32.equals((java.lang.Object) false);
        boolean boolean35 = year28.equals((java.lang.Object) year32);
        java.util.Date date36 = year28.getEnd();
        boolean boolean37 = year19.equals((java.lang.Object) date36);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date36, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date18, timeZone38);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date7, timeZone38);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeZone38);
    }
}

