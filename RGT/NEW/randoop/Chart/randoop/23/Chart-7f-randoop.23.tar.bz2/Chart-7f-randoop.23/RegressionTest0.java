import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimePeriod timePeriod2 = null;
        try {
            timePeriodValues1.add(timePeriod2, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = null;
        try {
            timePeriodValues1.add(timePeriodValue5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        try {
            org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValues1.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        int int7 = timePeriodValues1.getMaxStartIndex();
        try {
            timePeriodValues1.delete((int) '#', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        org.jfree.data.time.TimePeriod timePeriod8 = null;
        try {
            timePeriodValues1.add(timePeriod8, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues1.getDataItem(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        try {
            timePeriodValues1.update((int) (short) 0, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValues1.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        int int8 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = year0.getEnd();
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        timePeriodValues1.add(timePeriodValue9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriod10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        try {
            org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValues1.getTimePeriod((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.delete((int) (byte) 100, (int) ' ');
        int int6 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 9, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) str5, "", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day9.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable throwable2 = null;
        try {
            seriesException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.util.Calendar calendar10 = null;
        try {
            day9.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year4.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = null;
        try {
            timePeriodValues3.add(timePeriodValue4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        timePeriodValue2.setValue((java.lang.Number) 100);
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue2.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue2.getPeriod();
        org.junit.Assert.assertNotNull(timePeriod3);
        org.junit.Assert.assertNotNull(timePeriod6);
        org.junit.Assert.assertNotNull(timePeriod7);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        try {
            timePeriodValues1.update(5, (java.lang.Number) 2019L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriod7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = year0.getEnd();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        int int12 = year0.compareTo((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        timePeriodValues1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNotNull(timePeriod7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day9.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        java.util.TimeZone timeZone11 = null;
        try {
            org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10, timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        try {
            timePeriodValues1.delete(0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) -1, 6, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues1.getTimePeriod((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("31-December-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day9.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        int int6 = year0.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(timePeriod8);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        int int6 = timePeriodValues1.getMaxEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues1.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year4.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 0);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(timePeriod8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.TimePeriod timePeriod6 = null;
        try {
            timePeriodValues1.add(timePeriod6, (java.lang.Number) 1562097599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day9.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Value");
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        timePeriodValue2.setValue((java.lang.Number) 100);
        java.lang.String str6 = timePeriodValue2.toString();
        boolean boolean8 = timePeriodValue2.equals((java.lang.Object) (byte) 1);
        java.lang.String str9 = timePeriodValue2.toString();
        java.lang.Number number10 = timePeriodValue2.getValue();
        org.junit.Assert.assertNotNull(timePeriod3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[2019,100]" + "'", str6.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,100]" + "'", str9.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100 + "'", number10.equals(100));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable9 = null;
        try {
            timePeriodValues1.setKey(comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (-1.0d));
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        timePeriodValues7.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        int int10 = timePeriodValues7.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("Value");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        timePeriodValue9.setValue((java.lang.Number) 100);
        timePeriodValues3.add(timePeriodValue9);
        java.lang.Object obj14 = timePeriodValue9.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        int int7 = year4.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        boolean boolean11 = year4.equals((java.lang.Object) year8);
        boolean boolean13 = year4.equals((java.lang.Object) false);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 2);
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        try {
            timePeriodValues1.update((-1), (java.lang.Number) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        java.lang.Comparable comparable8 = timePeriodValues7.getKey();
        java.lang.Comparable comparable9 = timePeriodValues7.getKey();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 0.0d + "'", comparable8.equals(0.0d));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0d + "'", comparable9.equals(0.0d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(10L, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        long long8 = year0.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year0.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        java.lang.Comparable comparable27 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0d + "'", comparable27.equals(0.0d));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("31-December-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, (int) 'a', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setDomainDescription("Value");
        try {
            java.lang.Number number9 = timePeriodValues1.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        try {
            timePeriodValues1.update((int) (short) 1, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        int int7 = timePeriodValues1.getMaxStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues1.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        try {
            timePeriodValues1.update((int) ' ', (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1, (int) (byte) -1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException4.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue4 = timePeriodValues1.getDataItem(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
        java.util.Calendar calendar14 = null;
        try {
            day9.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        timePeriodValues1.delete((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        int int7 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        try {
            timePeriodValues1.delete((int) (short) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) false);
        int int4 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        boolean boolean8 = year1.equals((java.lang.Object) year5);
        boolean boolean10 = year1.equals((java.lang.Object) false);
        java.util.Date date11 = year1.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        java.util.Date date20 = year12.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) false);
        int int24 = year21.getYear();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) false);
        boolean boolean28 = year21.equals((java.lang.Object) year25);
        java.util.Date date29 = year21.getEnd();
        boolean boolean30 = year12.equals((java.lang.Object) date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date11, timeZone31);
        try {
            org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date0, timeZone31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeZone31);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues10.setDescription("Time");
        int int13 = timePeriodValues10.getMinStartIndex();
        java.lang.String str14 = timePeriodValues10.getRangeDescription();
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMinEndIndex();
        int int17 = year0.compareTo((java.lang.Object) timePeriodValues10);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year0.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setKey((java.lang.Comparable) 100.0d);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues1.createCopy(4, 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener6);
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("Value");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.util.Calendar calendar10 = null;
        try {
            day9.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ", "TimePeriodValue[2019,100]", "2019");
        try {
            timePeriodValues3.update(12, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        timePeriodValue2.setValue((java.lang.Number) 100);
        java.lang.String str6 = timePeriodValue2.toString();
        boolean boolean8 = timePeriodValue2.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year9.previous();
        boolean boolean19 = timePeriodValue2.equals((java.lang.Object) regularTimePeriod18);
        java.lang.Number number20 = timePeriodValue2.getValue();
        org.junit.Assert.assertNotNull(timePeriod3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[2019,100]" + "'", str6.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 100 + "'", number20.equals(100));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        timePeriodValues3.setDescription("TimePeriodValue[2019,100]");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues3.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day9.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day9.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-1), 8, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        int int4 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener5);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues1.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate13 = day9.getSerialDate();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day14.getMiddleMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        boolean boolean9 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener10);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str12 = timePeriodValues11.getDomainDescription();
        timePeriodValues11.setDomainDescription("Time");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) year15, (double) (-1L));
        int int18 = timePeriodValues11.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues11.getDataItem(0);
        boolean boolean21 = day9.equals((java.lang.Object) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(timePeriodValue20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues1.getDataItem(0);
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues1.getTimePeriod(0);
        try {
            timePeriodValues1.update(10, (java.lang.Number) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timePeriodValue10);
        org.junit.Assert.assertNotNull(timePeriod12);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getMinEndIndex();
        int int7 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Value");
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        java.lang.Object obj6 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + "Value" + "'", obj4.equals("Value"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + "Value" + "'", obj5.equals("Value"));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + "Value" + "'", obj6.equals("Value"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0f));
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=Value]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Value");
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.String str5 = seriesChangeEvent1.toString();
        java.lang.String str6 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + "Value" + "'", obj4.equals("Value"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0d);
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        timePeriodValues1.setDomainDescription("31-December-2019");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        java.lang.String str7 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues1.getDataItem(0);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str13 = timePeriodValues12.getDomainDescription();
        timePeriodValues12.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        int int19 = year16.getYear();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        boolean boolean23 = year16.equals((java.lang.Object) year20);
        java.util.Date date24 = year16.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        boolean boolean27 = day25.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("");
        java.lang.String str30 = seriesException29.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException29.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        boolean boolean34 = day25.equals((java.lang.Object) seriesException29);
        java.lang.String str35 = day25.toString();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) day25, (double) (byte) -1);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        boolean boolean40 = year38.equals((java.lang.Object) false);
        int int41 = year38.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year38.next();
        java.util.Date date43 = year38.getEnd();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) year38, (double) (-1L));
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        boolean boolean48 = year46.equals((java.lang.Object) false);
        int int49 = year46.getYear();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        boolean boolean52 = year50.equals((java.lang.Object) false);
        boolean boolean53 = year46.equals((java.lang.Object) year50);
        boolean boolean55 = year46.equals((java.lang.Object) false);
        java.util.Date date56 = year46.getStart();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
        java.lang.String str58 = day57.toString();
        int int59 = year38.compareTo((java.lang.Object) day57);
        boolean boolean60 = timePeriodValue10.equals((java.lang.Object) int59);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timePeriodValue10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str30.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "31-December-2019" + "'", str35.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1-January-2019" + "'", str58.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = day14.getLastMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone14);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day15.getMiddleMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0d);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) '#', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        int int14 = year11.getYear();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) false);
        boolean boolean18 = year11.equals((java.lang.Object) year15);
        java.util.Date date19 = year11.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        int int23 = year20.getYear();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) false);
        boolean boolean27 = year20.equals((java.lang.Object) year24);
        java.util.Date date28 = year20.getEnd();
        boolean boolean29 = year11.equals((java.lang.Object) date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date28, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date10, timeZone30);
        java.util.Calendar calendar33 = null;
        try {
            year32.peg(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeZone30);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue10.getPeriod();
        timePeriodValue10.setValue((java.lang.Number) 100);
        timePeriodValue10.setValue((java.lang.Number) 2019L);
        timePeriodValues1.add(timePeriodValue10);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues1.createCopy(4, (int) (byte) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues19.createCopy((int) (byte) -1, 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(timePeriod11);
        org.junit.Assert.assertNotNull(timePeriodValues19);
        org.junit.Assert.assertNotNull(timePeriodValues22);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        long long8 = year4.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            year4.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getMinEndIndex();
        int int7 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        boolean boolean17 = year10.equals((java.lang.Object) year14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year10.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (java.lang.Number) (-1.0f));
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        java.lang.Object obj3 = null;
        int int4 = year0.compareTo(obj3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Value");
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.String str5 = seriesChangeEvent1.toString();
        java.lang.Object obj6 = seriesChangeEvent1.getSource();
        java.lang.Object obj7 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + "Value" + "'", obj4.equals("Value"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + "Value" + "'", obj6.equals("Value"));
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + "Value" + "'", obj7.equals("Value"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.next();
        boolean boolean15 = year5.equals((java.lang.Object) year10);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 4);
        java.util.Date date18 = year10.getStart();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (-1.0d));
        long long6 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        long long8 = year4.getMiddleMillisecond();
        int int9 = year4.getYear();
        java.lang.Class<?> wildcardClass10 = year4.getClass();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year4.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, (int) '4', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) false);
        int int10 = year7.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        boolean boolean14 = year7.equals((java.lang.Object) year11);
        java.util.Date date15 = year7.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str19 = timePeriodValues18.getDomainDescription();
        timePeriodValues18.setNotify(true);
        java.lang.Class<?> wildcardClass22 = timePeriodValues18.getClass();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        int int26 = year23.getYear();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        boolean boolean30 = year23.equals((java.lang.Object) year27);
        boolean boolean32 = year23.equals((java.lang.Object) false);
        java.util.Date date33 = year23.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) false);
        int int37 = year34.getYear();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        boolean boolean40 = year38.equals((java.lang.Object) false);
        boolean boolean41 = year34.equals((java.lang.Object) year38);
        boolean boolean43 = year34.equals((java.lang.Object) false);
        java.util.Date date44 = year34.getStart();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        boolean boolean47 = year45.equals((java.lang.Object) false);
        int int48 = year45.getYear();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        boolean boolean51 = year49.equals((java.lang.Object) false);
        boolean boolean52 = year45.equals((java.lang.Object) year49);
        java.util.Date date53 = year45.getEnd();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        boolean boolean56 = year54.equals((java.lang.Object) false);
        int int57 = year54.getYear();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        boolean boolean60 = year58.equals((java.lang.Object) false);
        boolean boolean61 = year54.equals((java.lang.Object) year58);
        java.util.Date date62 = year54.getEnd();
        boolean boolean63 = year45.equals((java.lang.Object) date62);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date62, timeZone64);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date44, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date33, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date15, timeZone64);
        java.lang.Class class69 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(class69);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        timePeriodValues3.setDescription("TimePeriodValue[2019,100]");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        int int6 = timePeriodValues1.getItemCount();
        java.lang.String str7 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        timePeriodValues3.setDescription("TimePeriodValue[2019,100]");
        java.lang.Object obj6 = null;
        boolean boolean7 = timePeriodValues3.equals(obj6);
        try {
            timePeriodValues3.delete(3, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
        java.lang.String str14 = day9.toString();
        long long15 = day9.getSerialIndex();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day9.getMiddleMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43830L + "'", long15 == 43830L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (11) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue10.getPeriod();
        timePeriodValue10.setValue((java.lang.Number) 100);
        timePeriodValue10.setValue((java.lang.Number) 2019L);
        timePeriodValues1.add(timePeriodValue10);
        java.lang.Object obj17 = timePeriodValue10.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(timePeriod11);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.String str6 = timePeriodValues1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 0);
        java.util.Date date8 = year0.getEnd();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.next();
        boolean boolean15 = year5.equals((java.lang.Object) year10);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 4);
        java.lang.String str18 = year10.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=Value]");
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setKey((java.lang.Comparable) 100.0d);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        boolean boolean8 = timePeriodValues1.getNotify();
        int int9 = timePeriodValues1.getMinStartIndex();
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues1.getMaxStartIndex();
        java.lang.Object obj9 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate13 = day9.getSerialDate();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
        java.util.Date date15 = day14.getEnd();
        java.lang.Object obj16 = new java.lang.Object();
        boolean boolean17 = day14.equals(obj16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (-1.0d));
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue5.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(timePeriod6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        java.util.Calendar calendar35 = null;
        try {
            long long36 = year27.getFirstMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        boolean boolean17 = year10.equals((java.lang.Object) year14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year10.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (java.lang.Number) (-1.0f));
        java.util.Calendar calendar21 = null;
        try {
            long long22 = regularTimePeriod18.getMiddleMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day20.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        int int23 = year20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year20.next();
        java.lang.String str25 = year20.toString();
        int int26 = day9.compareTo((java.lang.Object) str25);
        long long27 = day9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43830L + "'", long27 == 43830L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        int int10 = day9.getMonth();
        long long11 = day9.getFirstMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day9.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577779200000L + "'", long11 == 1577779200000L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.next();
        boolean boolean15 = year5.equals((java.lang.Object) year10);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 4);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) false);
        int int21 = year18.getYear();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean24 = year22.equals((java.lang.Object) false);
        boolean boolean25 = year18.equals((java.lang.Object) year22);
        java.util.Date date26 = year18.getEnd();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        boolean boolean29 = day27.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("");
        java.lang.String str32 = seriesException31.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException31.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        boolean boolean36 = day27.equals((java.lang.Object) seriesException31);
        java.lang.String str37 = day27.toString();
        boolean boolean38 = timePeriodValue17.equals((java.lang.Object) str37);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str32.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "31-December-2019" + "'", str37.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setKey((java.lang.Comparable) 100.0d);
        timePeriodValues1.setRangeDescription("1-January-2019");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        int int11 = year8.getYear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        boolean boolean15 = year8.equals((java.lang.Object) year12);
        java.util.Date date16 = year8.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        boolean boolean19 = day17.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("");
        java.lang.String str22 = seriesException21.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        boolean boolean26 = day17.equals((java.lang.Object) seriesException21);
        org.jfree.data.time.SerialDate serialDate27 = day17.getSerialDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate27);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 8);
        int int32 = timePeriodValues1.getMinEndIndex();
        int int33 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str22.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        int int4 = timePeriodValues1.getMinEndIndex();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        try {
            java.lang.Number number7 = timePeriodValues1.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0d + "'", comparable5.equals(0.0d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        int int9 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) int9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("2019");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
        long long14 = day9.getFirstMillisecond();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod18 = timePeriodValue17.getPeriod();
        timePeriodValue17.setValue((java.lang.Number) 100);
        timePeriodValue17.setValue((java.lang.Number) 2019L);
        int int23 = day9.compareTo((java.lang.Object) 2019L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577779200000L + "'", long14 == 1577779200000L);
        org.junit.Assert.assertNotNull(timePeriod18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        java.lang.Comparable comparable8 = null;
        try {
            timePeriodValues1.setKey(comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod11);
        java.lang.Object obj13 = seriesChangeEvent12.getSource();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(31, (int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        java.lang.String str8 = timePeriodValues7.getDescription();
        int int9 = timePeriodValues7.getMaxMiddleIndex();
        try {
            java.lang.Number number11 = timePeriodValues7.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
        java.lang.String str14 = day9.toString();
        long long15 = day9.getSerialIndex();
        java.util.Calendar calendar16 = null;
        try {
            day9.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43830L + "'", long15 == 43830L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        java.util.Calendar calendar20 = null;
        try {
            day19.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
        long long14 = day9.getFirstMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day9.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577779200000L + "'", long14 == 1577779200000L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int11 = day9.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
        java.lang.String str14 = day9.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day9, "org.jfree.data.general.SeriesException: ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        boolean boolean27 = day18.equals((java.lang.Object) seriesException22);
        org.jfree.data.time.SerialDate serialDate28 = day18.getSerialDate();
        timePeriodValues1.setKey((java.lang.Comparable) day18);
        boolean boolean30 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,100]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        int int35 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        int int26 = year21.compareTo((java.lang.Object) year23);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = year23.getFirstMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        boolean boolean27 = day18.equals((java.lang.Object) seriesException22);
        org.jfree.data.time.SerialDate serialDate28 = day18.getSerialDate();
        timePeriodValues1.setKey((java.lang.Comparable) day18);
        java.lang.String str30 = day18.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (java.lang.Number) 100L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        int int6 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.delete(10, 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue2.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue(timePeriod4, (double) 1);
        timePeriodValue6.setValue((java.lang.Number) (-1.0d));
        org.junit.Assert.assertNotNull(timePeriod3);
        org.junit.Assert.assertNotNull(timePeriod4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "31-December-2019", "Value");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        int int7 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        java.lang.Number number9 = timePeriodValue6.getValue();
        timePeriodValue6.setValue((java.lang.Number) 11);
        timePeriodValue6.setValue((java.lang.Number) 0.0d);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        timePeriodValues3.setDescription("TimePeriodValue[2019,100]");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str8 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[2019,100]" + "'", str8.equals("TimePeriodValue[2019,100]"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.previous();
        java.util.Calendar calendar14 = null;
        try {
            day9.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.String str6 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue9.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue(timePeriod11, (double) 1);
        timePeriodValues1.add(timePeriodValue13);
        try {
            java.lang.Number number16 = timePeriodValues1.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertNotNull(timePeriod11);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) false);
        int int10 = year7.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        boolean boolean14 = year7.equals((java.lang.Object) year11);
        java.util.Date date15 = year7.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str19 = timePeriodValues18.getDomainDescription();
        timePeriodValues18.setNotify(true);
        java.lang.Class<?> wildcardClass22 = timePeriodValues18.getClass();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        int int26 = year23.getYear();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        boolean boolean30 = year23.equals((java.lang.Object) year27);
        boolean boolean32 = year23.equals((java.lang.Object) false);
        java.util.Date date33 = year23.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) false);
        int int37 = year34.getYear();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        boolean boolean40 = year38.equals((java.lang.Object) false);
        boolean boolean41 = year34.equals((java.lang.Object) year38);
        boolean boolean43 = year34.equals((java.lang.Object) false);
        java.util.Date date44 = year34.getStart();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        boolean boolean47 = year45.equals((java.lang.Object) false);
        int int48 = year45.getYear();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        boolean boolean51 = year49.equals((java.lang.Object) false);
        boolean boolean52 = year45.equals((java.lang.Object) year49);
        java.util.Date date53 = year45.getEnd();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        boolean boolean56 = year54.equals((java.lang.Object) false);
        int int57 = year54.getYear();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        boolean boolean60 = year58.equals((java.lang.Object) false);
        boolean boolean61 = year54.equals((java.lang.Object) year58);
        java.util.Date date62 = year54.getEnd();
        boolean boolean63 = year45.equals((java.lang.Object) date62);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date62, timeZone64);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date44, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date33, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date15, timeZone64);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        boolean boolean71 = year69.equals((java.lang.Object) false);
        int int72 = year69.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year69.next();
        java.util.Date date74 = year69.getEnd();
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
        boolean boolean77 = year75.equals((java.lang.Object) false);
        int int78 = year75.getYear();
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year();
        boolean boolean81 = year79.equals((java.lang.Object) false);
        boolean boolean82 = year75.equals((java.lang.Object) year79);
        boolean boolean84 = year75.equals((java.lang.Object) false);
        java.util.Date date85 = year75.getStart();
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date85);
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date85, timeZone87);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date85, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date74, timeZone89);
        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day(date74);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2019 + "'", int72 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2019 + "'", int78 == 2019);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNotNull(regularTimePeriod91);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "", "hi!");
        try {
            org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValues3.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        java.lang.String str4 = timePeriodValue2.toString();
        org.junit.Assert.assertNotNull(timePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str4.equals("TimePeriodValue[2019,-1.0]"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0f));
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener4);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues3.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        int int23 = year20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year20.next();
        java.lang.String str25 = year20.toString();
        int int26 = day9.compareTo((java.lang.Object) str25);
        long long27 = day9.getFirstMillisecond();
        java.util.Calendar calendar28 = null;
        try {
            long long29 = day9.getFirstMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577779200000L + "'", long27 == 1577779200000L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,-1.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) 8);
        java.util.Date date11 = regularTimePeriod8.getStart();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0f, "org.jfree.data.general.SeriesChangeEvent[source=Value]", "Value");
        int int4 = timePeriodValues3.getItemCount();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year5.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        boolean boolean2 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        int int4 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener5);
        try {
            timePeriodValues1.delete((int) (byte) 1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        int int10 = day9.getMonth();
        long long11 = day9.getFirstMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day9.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577779200000L + "'", long11 == 1577779200000L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str23 = timePeriodValues22.getDomainDescription();
        timePeriodValues22.setNotify(true);
        java.lang.String str26 = timePeriodValues22.getRangeDescription();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        java.lang.String str28 = timePeriodValues22.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) false);
        int int34 = year31.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        boolean boolean38 = year31.equals((java.lang.Object) year35);
        java.util.Date date39 = year31.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        boolean boolean42 = day40.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        java.lang.String str45 = seriesException44.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException44.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        boolean boolean49 = day40.equals((java.lang.Object) seriesException44);
        org.jfree.data.time.SerialDate serialDate50 = day40.getSerialDate();
        long long51 = day40.getLastMillisecond();
        int int52 = day40.getYear();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day40, (double) 0L);
        int int55 = year20.compareTo((java.lang.Object) day40);
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day40);
        try {
            timePeriodValues56.delete(6, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0d + "'", comparable27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str45.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener35);
        int int37 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setKey((java.lang.Comparable) 10.0d);
        timePeriodValues1.setNotify(false);
        timePeriodValues1.delete(2019, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        java.lang.String str5 = seriesException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        java.lang.String str13 = timePeriodFormatException7.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException7.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodFormatException7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.lang.Class<?> wildcardClass8 = timePeriodValues1.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        java.lang.Object obj13 = timePeriodValue11.clone();
        boolean boolean14 = timePeriodValues1.equals(obj13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener15);
        timePeriodValues1.setNotify(true);
        int int19 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("TimePeriodValue[2019,100]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        long long20 = day9.getLastMillisecond();
        int int21 = day9.getMonth();
        int int22 = day9.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate23 = day9.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
        org.junit.Assert.assertNotNull(serialDate23);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1562097599999L, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) false);
        int int10 = year7.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        boolean boolean14 = year7.equals((java.lang.Object) year11);
        java.util.Date date15 = year7.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str19 = timePeriodValues18.getDomainDescription();
        timePeriodValues18.setNotify(true);
        java.lang.Class<?> wildcardClass22 = timePeriodValues18.getClass();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        int int26 = year23.getYear();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        boolean boolean30 = year23.equals((java.lang.Object) year27);
        boolean boolean32 = year23.equals((java.lang.Object) false);
        java.util.Date date33 = year23.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) false);
        int int37 = year34.getYear();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        boolean boolean40 = year38.equals((java.lang.Object) false);
        boolean boolean41 = year34.equals((java.lang.Object) year38);
        boolean boolean43 = year34.equals((java.lang.Object) false);
        java.util.Date date44 = year34.getStart();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        boolean boolean47 = year45.equals((java.lang.Object) false);
        int int48 = year45.getYear();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        boolean boolean51 = year49.equals((java.lang.Object) false);
        boolean boolean52 = year45.equals((java.lang.Object) year49);
        java.util.Date date53 = year45.getEnd();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        boolean boolean56 = year54.equals((java.lang.Object) false);
        int int57 = year54.getYear();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        boolean boolean60 = year58.equals((java.lang.Object) false);
        boolean boolean61 = year54.equals((java.lang.Object) year58);
        java.util.Date date62 = year54.getEnd();
        boolean boolean63 = year45.equals((java.lang.Object) date62);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date62, timeZone64);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date44, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date33, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date15, timeZone64);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        boolean boolean71 = year69.equals((java.lang.Object) false);
        int int72 = year69.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year69.next();
        java.util.Date date74 = year69.getEnd();
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
        boolean boolean77 = year75.equals((java.lang.Object) false);
        int int78 = year75.getYear();
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year();
        boolean boolean81 = year79.equals((java.lang.Object) false);
        boolean boolean82 = year75.equals((java.lang.Object) year79);
        boolean boolean84 = year75.equals((java.lang.Object) false);
        java.util.Date date85 = year75.getStart();
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date85);
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date85, timeZone87);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date85, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date74, timeZone89);
        java.lang.Class class92 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2019 + "'", int72 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2019 + "'", int78 == 2019);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNotNull(regularTimePeriod91);
        org.junit.Assert.assertNotNull(class92);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        long long5 = year0.getFirstMillisecond();
        long long6 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.next();
        boolean boolean15 = year5.equals((java.lang.Object) year10);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 4);
        timePeriodValue17.setValue((java.lang.Number) 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=Value]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        boolean boolean9 = timePeriodValues1.getNotify();
        timePeriodValues1.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, 1562097599999L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue10.getPeriod();
        timePeriodValue10.setValue((java.lang.Number) 100);
        timePeriodValue10.setValue((java.lang.Number) 2019L);
        timePeriodValues1.add(timePeriodValue10);
        try {
            timePeriodValues1.delete(6, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(timePeriod11);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day19);
        long long21 = day19.getLastMillisecond();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = day19.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues10.setDescription("Time");
        int int13 = timePeriodValues10.getMinStartIndex();
        java.lang.String str14 = timePeriodValues10.getRangeDescription();
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMinEndIndex();
        int int17 = year0.compareTo((java.lang.Object) timePeriodValues10);
        long long18 = year0.getSerialIndex();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year0.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        long long8 = year4.getMiddleMillisecond();
        int int9 = year4.getYear();
        java.lang.Class<?> wildcardClass10 = year4.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues13.setDescription("Time");
        int int16 = timePeriodValues13.getMinStartIndex();
        java.lang.String str17 = timePeriodValues13.getRangeDescription();
        java.lang.Object obj18 = timePeriodValues13.clone();
        java.lang.String str19 = timePeriodValues13.getRangeDescription();
        timePeriodValues13.setRangeDescription("Time");
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean24 = year22.equals((java.lang.Object) false);
        int int25 = year22.getYear();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        boolean boolean28 = year26.equals((java.lang.Object) false);
        boolean boolean29 = year22.equals((java.lang.Object) year26);
        java.util.Date date30 = year22.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        int int32 = day31.getMonth();
        long long33 = day31.getFirstMillisecond();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) (byte) 100);
        java.util.Date date36 = day31.getEnd();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        boolean boolean39 = year37.equals((java.lang.Object) false);
        int int40 = year37.getYear();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        boolean boolean43 = year41.equals((java.lang.Object) false);
        boolean boolean44 = year37.equals((java.lang.Object) year41);
        java.util.Date date45 = year37.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        java.lang.String str47 = day46.toString();
        java.util.Date date48 = day46.getStart();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        boolean boolean51 = year49.equals((java.lang.Object) false);
        int int52 = year49.getYear();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        boolean boolean55 = year53.equals((java.lang.Object) false);
        boolean boolean56 = year49.equals((java.lang.Object) year53);
        boolean boolean58 = year49.equals((java.lang.Object) false);
        java.util.Date date59 = year49.getStart();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date59, timeZone61);
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date59, timeZone63);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date48, timeZone63);
        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str68 = timePeriodValues67.getDomainDescription();
        timePeriodValues67.setNotify(true);
        java.lang.Class<?> wildcardClass71 = timePeriodValues67.getClass();
        java.lang.Class class72 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass71);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
        boolean boolean75 = year73.equals((java.lang.Object) false);
        int int76 = year73.getYear();
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
        boolean boolean79 = year77.equals((java.lang.Object) false);
        boolean boolean80 = year73.equals((java.lang.Object) year77);
        java.util.Date date81 = year73.getEnd();
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date81);
        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass71, date81, timeZone83);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date48, timeZone83);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date36, timeZone83);
        java.lang.Class class87 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577779200000L + "'", long33 == 1577779200000L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "31-December-2019" + "'", str47.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Time" + "'", str68.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(class72);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2019 + "'", int76 == 2019);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(timeZone83);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(class87);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        timePeriodValues7.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        int int10 = timePeriodValues7.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean24 = year22.equals((java.lang.Object) false);
        int int25 = year22.getYear();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        boolean boolean28 = year26.equals((java.lang.Object) false);
        boolean boolean29 = year22.equals((java.lang.Object) year26);
        boolean boolean31 = year22.equals((java.lang.Object) false);
        java.util.Date date32 = year22.getStart();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(date17, date32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (-1.0d));
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) false);
        int int9 = year6.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        boolean boolean13 = year6.equals((java.lang.Object) year10);
        long long14 = year10.getMiddleMillisecond();
        int int15 = year10.getYear();
        int int16 = year0.compareTo((java.lang.Object) int15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        boolean boolean9 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        java.lang.Number number3 = timePeriodValue2.getValue();
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue2.getPeriod();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriod4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.next();
        boolean boolean15 = year5.equals((java.lang.Object) year10);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 4);
        long long18 = year10.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 0);
        int int8 = year0.getYear();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str23 = timePeriodValues22.getDomainDescription();
        timePeriodValues22.setNotify(true);
        java.lang.Class<?> wildcardClass26 = timePeriodValues22.getClass();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) false);
        boolean boolean34 = year27.equals((java.lang.Object) year31);
        boolean boolean36 = year27.equals((java.lang.Object) false);
        java.util.Date date37 = year27.getStart();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        boolean boolean40 = year38.equals((java.lang.Object) false);
        int int41 = year38.getYear();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        boolean boolean44 = year42.equals((java.lang.Object) false);
        boolean boolean45 = year38.equals((java.lang.Object) year42);
        java.util.Date date46 = year38.getEnd();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        boolean boolean49 = year47.equals((java.lang.Object) false);
        int int50 = year47.getYear();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        boolean boolean53 = year51.equals((java.lang.Object) false);
        boolean boolean54 = year47.equals((java.lang.Object) year51);
        java.util.Date date55 = year47.getEnd();
        boolean boolean56 = year38.equals((java.lang.Object) date55);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date55, timeZone57);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date37, timeZone57);
        java.util.Date date60 = year59.getStart();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        boolean boolean63 = year61.equals((java.lang.Object) false);
        int int64 = year61.getYear();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        boolean boolean67 = year65.equals((java.lang.Object) false);
        boolean boolean68 = year61.equals((java.lang.Object) year65);
        boolean boolean70 = year61.equals((java.lang.Object) false);
        java.util.Date date71 = year61.getStart();
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date71);
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date71, timeZone73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date60, timeZone73);
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date17, timeZone73);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNull(regularTimePeriod75);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        boolean boolean27 = day18.equals((java.lang.Object) seriesException22);
        org.jfree.data.time.SerialDate serialDate28 = day18.getSerialDate();
        timePeriodValues1.setKey((java.lang.Comparable) day18);
        java.lang.String str30 = day18.toString();
        long long31 = day18.getSerialIndex();
        int int32 = day18.getDayOfMonth();
        java.lang.Number number33 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, number33);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43830L + "'", long31 == 43830L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 31 + "'", int32 == 31);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        int int38 = year35.getYear();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) false);
        boolean boolean42 = year35.equals((java.lang.Object) year39);
        boolean boolean44 = year35.equals((java.lang.Object) false);
        java.util.Date date45 = year35.getStart();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        java.lang.String str47 = day46.toString();
        int int48 = year27.compareTo((java.lang.Object) day46);
        int int49 = year27.getYear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1-January-2019" + "'", str47.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMinEndIndex();
        int int8 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=Value]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        int int7 = year4.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        boolean boolean11 = year4.equals((java.lang.Object) year8);
        long long12 = year8.getMiddleMillisecond();
        int int13 = year8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod14, (java.lang.Number) 10.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        java.lang.String str8 = timePeriodValues7.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        java.lang.String str5 = seriesException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        java.lang.String str13 = timePeriodFormatException7.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str15 = seriesException1.toString();
        java.lang.String str16 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str15.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str16.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day9.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        long long3 = year0.getLastMillisecond();
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1.0f));
        java.lang.Number number10 = timePeriodValue9.getValue();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue13.getPeriod();
        java.lang.Object obj15 = timePeriodValue13.clone();
        boolean boolean16 = timePeriodValue9.equals(obj15);
        int int17 = year0.compareTo((java.lang.Object) timePeriodValue9);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-1.0d) + "'", number10.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriod14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        long long8 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.next();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str23 = timePeriodValues22.getDomainDescription();
        timePeriodValues22.setNotify(true);
        java.lang.String str26 = timePeriodValues22.getRangeDescription();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        java.lang.String str28 = timePeriodValues22.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) false);
        int int34 = year31.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        boolean boolean38 = year31.equals((java.lang.Object) year35);
        java.util.Date date39 = year31.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        boolean boolean42 = day40.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        java.lang.String str45 = seriesException44.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException44.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        boolean boolean49 = day40.equals((java.lang.Object) seriesException44);
        org.jfree.data.time.SerialDate serialDate50 = day40.getSerialDate();
        long long51 = day40.getLastMillisecond();
        int int52 = day40.getYear();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day40, (double) 0L);
        int int55 = year20.compareTo((java.lang.Object) day40);
        java.util.Calendar calendar56 = null;
        try {
            long long57 = year20.getFirstMillisecond(calendar56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0d + "'", comparable27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str45.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.Calendar calendar19 = null;
        try {
            year0.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("Value");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) false);
        int int10 = year7.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        boolean boolean14 = year7.equals((java.lang.Object) year11);
        java.util.Date date15 = year7.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        int int19 = year16.getYear();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        boolean boolean23 = year16.equals((java.lang.Object) year20);
        java.util.Date date24 = year16.getEnd();
        boolean boolean25 = year7.equals((java.lang.Object) date24);
        timePeriodValues3.setKey((java.lang.Comparable) year7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener27);
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMaxStartIndex();
        try {
            timePeriodValues1.update((int) (byte) 1, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        try {
            java.lang.Number number9 = timePeriodValues1.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        int int7 = year4.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        boolean boolean11 = year4.equals((java.lang.Object) year8);
        boolean boolean13 = year4.equals((java.lang.Object) false);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 2);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        int int19 = year16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year16.next();
        java.lang.String str21 = year16.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, 1.0d);
        long long24 = year16.getLastMillisecond();
        boolean boolean25 = year4.equals((java.lang.Object) long24);
        long long26 = year4.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1562097599999L + "'", long26 == 1562097599999L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone14);
        int int16 = day15.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, 1.0d);
        int int19 = day15.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        int int9 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(3, 5);
        timePeriodValues12.fireSeriesChanged();
        boolean boolean14 = timePeriodValues12.getNotify();
        timePeriodValues12.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(8, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable throwable6 = null;
        try {
            seriesException1.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        java.lang.Object obj13 = timePeriodValue11.clone();
        boolean boolean14 = timePeriodValues1.equals(obj13);
        java.lang.String str15 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        try {
            timePeriodValues1.update((int) (short) -1, (java.lang.Number) 2019L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriod7);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (double) (-1L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        long long10 = year5.getSerialIndex();
        boolean boolean12 = year5.equals((java.lang.Object) (-1));
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        java.lang.String str4 = seriesException3.toString();
        java.lang.String str5 = seriesException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str4.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timePeriodValues30.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date11, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        java.lang.Class<?> wildcardClass54 = timePeriodValues50.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        int int59 = year56.getYear();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        boolean boolean63 = year56.equals((java.lang.Object) year60);
        java.util.Date date64 = year56.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date64, timeZone66);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date11, date64);
        long long69 = simpleTimePeriod68.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str72 = timePeriodValues71.getDomainDescription();
        timePeriodValues71.setDomainDescription("Time");
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year75, (double) (-1L));
        long long78 = year75.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year75.next();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year();
        boolean boolean82 = year80.equals((java.lang.Object) false);
        int int83 = year80.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = year80.next();
        boolean boolean85 = year75.equals((java.lang.Object) year80);
        long long86 = year75.getSerialIndex();
        try {
            int int87 = simpleTimePeriod68.compareTo((java.lang.Object) long86);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "Time" + "'", str72.equals("Time"));
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 2019L + "'", long78 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 2019 + "'", int83 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 2019L + "'", long86 == 2019L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        long long8 = year4.getMiddleMillisecond();
        int int9 = year4.getYear();
        java.util.Calendar calendar10 = null;
        try {
            year4.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone12);
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue10.getPeriod();
        timePeriodValue10.setValue((java.lang.Number) 100);
        timePeriodValue10.setValue((java.lang.Number) 2019L);
        timePeriodValues1.add(timePeriodValue10);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues1.createCopy(4, (int) (byte) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str22 = timePeriodValues21.getDomainDescription();
        timePeriodValues21.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) false);
        int int28 = year25.getYear();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        boolean boolean31 = year29.equals((java.lang.Object) false);
        boolean boolean32 = year25.equals((java.lang.Object) year29);
        java.util.Date date33 = year25.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        boolean boolean36 = day34.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException38 = new org.jfree.data.general.SeriesException("");
        java.lang.String str39 = seriesException38.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException38.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        boolean boolean43 = day34.equals((java.lang.Object) seriesException38);
        java.lang.String str44 = day34.toString();
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day34, (double) (byte) -1);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        boolean boolean49 = year47.equals((java.lang.Object) false);
        int int50 = year47.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year47.next();
        java.util.Date date52 = year47.getEnd();
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) year47, (double) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "", "hi!");
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        boolean boolean61 = year59.equals((java.lang.Object) false);
        int int62 = year59.getYear();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        boolean boolean65 = year63.equals((java.lang.Object) false);
        boolean boolean66 = year59.equals((java.lang.Object) year63);
        boolean boolean68 = year59.equals((java.lang.Object) false);
        timePeriodValues58.add((org.jfree.data.time.TimePeriod) year59, (java.lang.Number) 2);
        long long71 = year59.getSerialIndex();
        int int72 = year47.compareTo((java.lang.Object) year59);
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year59, 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(timePeriod11);
        org.junit.Assert.assertNotNull(timePeriodValues19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str39.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31-December-2019" + "'", str44.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 2019L + "'", long71 == 2019L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        int int9 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener11);
        java.lang.Object obj13 = timePeriodValues1.clone();
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        int int14 = year11.getYear();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) false);
        boolean boolean18 = year11.equals((java.lang.Object) year15);
        java.util.Date date19 = year11.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        int int23 = year20.getYear();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) false);
        boolean boolean27 = year20.equals((java.lang.Object) year24);
        java.util.Date date28 = year20.getEnd();
        boolean boolean29 = year11.equals((java.lang.Object) date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date28, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date10, timeZone30);
        java.util.Date date33 = year32.getStart();
        java.util.Date date34 = year32.getStart();
        long long35 = year32.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        boolean boolean27 = day18.equals((java.lang.Object) seriesException22);
        org.jfree.data.time.SerialDate serialDate28 = day18.getSerialDate();
        timePeriodValues1.setKey((java.lang.Comparable) day18);
        java.lang.String str30 = day18.toString();
        int int31 = day18.getYear();
        java.lang.String str32 = day18.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "31-December-2019" + "'", str32.equals("31-December-2019"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate13 = day9.getSerialDate();
        java.util.Date date14 = day9.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day9.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        boolean boolean27 = day18.equals((java.lang.Object) seriesException22);
        org.jfree.data.time.SerialDate serialDate28 = day18.getSerialDate();
        timePeriodValues1.setKey((java.lang.Comparable) day18);
        java.lang.String str30 = day18.toString();
        long long31 = day18.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, 100.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setDescription("Time");
        int int38 = timePeriodValues35.getMinStartIndex();
        java.lang.String str39 = timePeriodValues35.getRangeDescription();
        int int40 = timePeriodValues35.getItemCount();
        timePeriodValues35.setDescription("2019");
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year43, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod46 = timePeriodValue45.getPeriod();
        java.lang.Object obj47 = timePeriodValue45.clone();
        boolean boolean48 = timePeriodValues35.equals(obj47);
        int int49 = day18.compareTo((java.lang.Object) boolean48);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43830L + "'", long31 == 43830L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Value" + "'", str39.equals("Value"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(timePeriod46);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        boolean boolean27 = day18.equals((java.lang.Object) seriesException22);
        org.jfree.data.time.SerialDate serialDate28 = day18.getSerialDate();
        timePeriodValues1.setKey((java.lang.Comparable) day18);
        java.lang.String str30 = day18.toString();
        long long31 = day18.getSerialIndex();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        boolean boolean34 = year32.equals((java.lang.Object) false);
        int int35 = year32.getYear();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        boolean boolean39 = year32.equals((java.lang.Object) year36);
        java.util.Date date40 = year32.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        boolean boolean43 = day41.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException45 = new org.jfree.data.general.SeriesException("");
        java.lang.String str46 = seriesException45.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException45.addSuppressed((java.lang.Throwable) timePeriodFormatException48);
        boolean boolean50 = day41.equals((java.lang.Object) seriesException45);
        org.jfree.data.time.SerialDate serialDate51 = day41.getSerialDate();
        long long52 = day41.getLastMillisecond();
        int int53 = day41.getYear();
        java.lang.String str54 = day41.toString();
        java.util.Date date55 = day41.getEnd();
        int int56 = day18.compareTo((java.lang.Object) day41);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43830L + "'", long31 == 43830L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str46.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1577865599999L + "'", long52 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "31-December-2019" + "'", str54.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str23 = timePeriodValues22.getDomainDescription();
        timePeriodValues22.setNotify(true);
        java.lang.String str26 = timePeriodValues22.getRangeDescription();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        java.lang.String str28 = timePeriodValues22.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) false);
        int int34 = year31.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        boolean boolean38 = year31.equals((java.lang.Object) year35);
        java.util.Date date39 = year31.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        boolean boolean42 = day40.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        java.lang.String str45 = seriesException44.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException44.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        boolean boolean49 = day40.equals((java.lang.Object) seriesException44);
        org.jfree.data.time.SerialDate serialDate50 = day40.getSerialDate();
        long long51 = day40.getLastMillisecond();
        int int52 = day40.getYear();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day40, (double) 0L);
        int int55 = year20.compareTo((java.lang.Object) day40);
        org.jfree.data.time.SerialDate serialDate56 = day40.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0d + "'", comparable27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str45.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(serialDate56);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate13 = day9.getSerialDate();
        java.util.Calendar calendar14 = null;
        try {
            day9.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        int int7 = year4.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        boolean boolean11 = year4.equals((java.lang.Object) year8);
        boolean boolean13 = year4.equals((java.lang.Object) false);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 2);
        int int16 = year4.getYear();
        long long17 = year4.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        long long20 = day9.getLastMillisecond();
        int int21 = day9.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day9, "", "org.jfree.data.general.SeriesChangeEvent[source=Value]");
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues24.createCopy(100, (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(timePeriodValues27);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        java.lang.Object obj13 = timePeriodValue11.clone();
        boolean boolean14 = timePeriodValues1.equals(obj13);
        java.lang.String str15 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriod timePeriod18 = null;
        try {
            timePeriodValues1.add(timePeriod18, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        int int14 = year11.getYear();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) false);
        boolean boolean18 = year11.equals((java.lang.Object) year15);
        java.util.Date date19 = year11.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        int int23 = year20.getYear();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) false);
        boolean boolean27 = year20.equals((java.lang.Object) year24);
        java.util.Date date28 = year20.getEnd();
        boolean boolean29 = year11.equals((java.lang.Object) date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date28, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date10, timeZone30);
        java.util.Date date33 = year32.getStart();
        long long34 = year32.getFirstMillisecond();
        java.lang.String str35 = year32.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,-1.0]");
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        int int23 = year20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year20.next();
        java.lang.String str25 = year20.toString();
        int int26 = day9.compareTo((java.lang.Object) str25);
        long long27 = day9.getFirstMillisecond();
        java.util.Calendar calendar28 = null;
        try {
            long long29 = day9.getMiddleMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577779200000L + "'", long27 == 1577779200000L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        timePeriodValues7.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        java.lang.Object obj10 = timePeriodValues7.clone();
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues7.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        int int7 = year4.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        boolean boolean11 = year4.equals((java.lang.Object) year8);
        boolean boolean13 = year4.equals((java.lang.Object) false);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 2);
        long long16 = year4.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        int int9 = timePeriodValues1.getMaxEndIndex();
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues1.getDataItem(0);
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timePeriodValue10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        java.lang.String str5 = seriesException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        java.lang.String str13 = timePeriodFormatException7.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException7.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        int int19 = year16.getYear();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        boolean boolean23 = year16.equals((java.lang.Object) year20);
        java.util.Date date24 = year16.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.lang.String str26 = day25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day25.next();
        java.util.Date date28 = regularTimePeriod27.getStart();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        boolean boolean31 = year29.equals((java.lang.Object) false);
        int int32 = year29.getYear();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        boolean boolean35 = year33.equals((java.lang.Object) false);
        boolean boolean36 = year29.equals((java.lang.Object) year33);
        boolean boolean38 = year29.equals((java.lang.Object) false);
        java.util.Date date39 = year29.getStart();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date39, timeZone41);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date39, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date28, timeZone43);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "31-December-2019" + "'", str26.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod45);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 0);
        int int8 = year0.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.lang.String str19 = day18.toString();
        java.util.Date date20 = day18.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) false);
        int int24 = year21.getYear();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) false);
        boolean boolean28 = year21.equals((java.lang.Object) year25);
        boolean boolean30 = year21.equals((java.lang.Object) false);
        java.util.Date date31 = year21.getStart();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date31, timeZone33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date31, timeZone35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date20, timeZone35);
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str40 = timePeriodValues39.getDomainDescription();
        timePeriodValues39.setNotify(true);
        java.lang.Class<?> wildcardClass43 = timePeriodValues39.getClass();
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        boolean boolean47 = year45.equals((java.lang.Object) false);
        int int48 = year45.getYear();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        boolean boolean51 = year49.equals((java.lang.Object) false);
        boolean boolean52 = year45.equals((java.lang.Object) year49);
        java.util.Date date53 = year45.getEnd();
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date53);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date53, timeZone55);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date20, timeZone55);
        boolean boolean58 = year0.equals((java.lang.Object) date20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-2019" + "'", str19.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Time" + "'", str40.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.String str6 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
        long long14 = day9.getFirstMillisecond();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) false);
        int int18 = year15.getYear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) false);
        boolean boolean22 = year15.equals((java.lang.Object) year19);
        long long23 = year19.getMiddleMillisecond();
        int int24 = year19.getYear();
        java.lang.Class<?> wildcardClass25 = year19.getClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        boolean boolean27 = day9.equals((java.lang.Object) class26);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577779200000L + "'", long14 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1562097599999L + "'", long23 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        int int38 = year35.getYear();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) false);
        boolean boolean42 = year35.equals((java.lang.Object) year39);
        long long43 = year39.getMiddleMillisecond();
        int int44 = year39.getYear();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year39, (double) 'a');
        java.util.Calendar calendar47 = null;
        try {
            long long48 = year39.getFirstMillisecond(calendar47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1562097599999L + "'", long43 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues1.getDataItem(0);
        java.lang.String str11 = timePeriodValue10.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timePeriodValue10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str11.equals("TimePeriodValue[2019,-1.0]"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) false);
        int int4 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        boolean boolean8 = year1.equals((java.lang.Object) year5);
        long long9 = year5.getMiddleMillisecond();
        int int10 = year5.getYear();
        java.lang.Class<?> wildcardClass11 = year5.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues14.setDescription("Time");
        int int17 = timePeriodValues14.getMinStartIndex();
        java.lang.String str18 = timePeriodValues14.getRangeDescription();
        java.lang.Object obj19 = timePeriodValues14.clone();
        java.lang.String str20 = timePeriodValues14.getRangeDescription();
        timePeriodValues14.setRangeDescription("Time");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        int int26 = year23.getYear();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        boolean boolean30 = year23.equals((java.lang.Object) year27);
        java.util.Date date31 = year23.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        int int33 = day32.getMonth();
        long long34 = day32.getFirstMillisecond();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day32, (java.lang.Number) (byte) 100);
        java.util.Date date37 = day32.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        boolean boolean40 = year38.equals((java.lang.Object) false);
        int int41 = year38.getYear();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        boolean boolean44 = year42.equals((java.lang.Object) false);
        boolean boolean45 = year38.equals((java.lang.Object) year42);
        java.util.Date date46 = year38.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        java.lang.String str48 = day47.toString();
        java.util.Date date49 = day47.getStart();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        boolean boolean52 = year50.equals((java.lang.Object) false);
        int int53 = year50.getYear();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        boolean boolean56 = year54.equals((java.lang.Object) false);
        boolean boolean57 = year50.equals((java.lang.Object) year54);
        boolean boolean59 = year50.equals((java.lang.Object) false);
        java.util.Date date60 = year50.getStart();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date60, timeZone62);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date60, timeZone64);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date49, timeZone64);
        org.jfree.data.time.TimePeriodValues timePeriodValues68 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str69 = timePeriodValues68.getDomainDescription();
        timePeriodValues68.setNotify(true);
        java.lang.Class<?> wildcardClass72 = timePeriodValues68.getClass();
        java.lang.Class class73 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass72);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
        boolean boolean76 = year74.equals((java.lang.Object) false);
        int int77 = year74.getYear();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        boolean boolean80 = year78.equals((java.lang.Object) false);
        boolean boolean81 = year74.equals((java.lang.Object) year78);
        java.util.Date date82 = year74.getEnd();
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date82);
        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date82, timeZone84);
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date49, timeZone84);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date37, timeZone84);
        try {
            org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date0, timeZone84);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577779200000L + "'", long34 == 1577779200000L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "31-December-2019" + "'", str48.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Time" + "'", str69.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(class73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2019 + "'", int77 == 2019);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(timeZone84);
        org.junit.Assert.assertNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.previous();
        int int14 = day9.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        int int23 = year20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year20.next();
        java.lang.String str25 = year20.toString();
        int int26 = day9.compareTo((java.lang.Object) str25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day9.next();
        java.util.Calendar calendar28 = null;
        try {
            long long29 = day9.getLastMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone14);
        int int16 = day15.getMonth();
        java.lang.Object obj17 = null;
        int int18 = day15.compareTo(obj17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) int18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        timePeriodValues3.setDescription("TimePeriodValue[2019,100]");
        boolean boolean6 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener35);
        int int37 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        boolean boolean40 = year38.equals((java.lang.Object) false);
        boolean boolean41 = timePeriodValues1.equals((java.lang.Object) false);
        java.lang.String str42 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str42.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        java.lang.Object obj13 = timePeriodValue11.clone();
        boolean boolean14 = timePeriodValues1.equals(obj13);
        try {
            timePeriodValues1.update(0, (java.lang.Number) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        java.lang.String str8 = timePeriodValues7.getDescription();
        int int9 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriod timePeriod10 = null;
        try {
            timePeriodValues7.add(timePeriod10, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        timePeriodValues7.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        java.lang.Object obj10 = timePeriodValues7.clone();
        java.lang.Comparable comparable11 = timePeriodValues7.getKey();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 0.0d + "'", comparable11.equals(0.0d));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener6);
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        java.lang.Number number9 = timePeriodValue6.getValue();
        timePeriodValue6.setValue((java.lang.Number) 11);
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue6.getPeriod();
        timePeriodValue6.setValue((java.lang.Number) 11);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriod12);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        boolean boolean9 = timePeriodValues1.getNotify();
        timePeriodValues1.setNotify(true);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setKey((java.lang.Comparable) 100.0d);
        timePeriodValues1.setRangeDescription("1-January-2019");
        try {
            timePeriodValues1.update(2, (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        java.lang.Object obj13 = timePeriodValue11.clone();
        boolean boolean14 = timePeriodValues1.equals(obj13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener15);
        timePeriodValues1.setNotify(true);
        int int19 = timePeriodValues1.getMaxMiddleIndex();
        int int20 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.next();
        boolean boolean15 = year5.equals((java.lang.Object) year10);
        java.util.Calendar calendar16 = null;
        try {
            year10.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        java.lang.Object obj12 = null;
        boolean boolean13 = day9.equals(obj12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day9.next();
        java.util.Calendar calendar15 = null;
        try {
            day9.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.next();
        boolean boolean15 = year5.equals((java.lang.Object) year10);
        long long16 = year5.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        int int9 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener10);
        timePeriodValues1.setDomainDescription("org.jfree.data.general.SeriesException: ");
        int int14 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        java.lang.Object obj13 = timePeriodValue11.clone();
        boolean boolean14 = timePeriodValues1.equals(obj13);
        java.lang.Comparable comparable15 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 0.0d + "'", comparable15.equals(0.0d));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timePeriodValues30.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date11, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        java.lang.Class<?> wildcardClass54 = timePeriodValues50.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        int int59 = year56.getYear();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        boolean boolean63 = year56.equals((java.lang.Object) year60);
        java.util.Date date64 = year56.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date64, timeZone66);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date11, date64);
        org.jfree.data.time.TimePeriodValues timePeriodValues70 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues70.setRangeDescription("");
        int int73 = timePeriodValues70.getMinEndIndex();
        java.lang.Comparable comparable74 = timePeriodValues70.getKey();
        try {
            int int75 = simpleTimePeriod68.compareTo((java.lang.Object) comparable74);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + comparable74 + "' != '" + 0.0d + "'", comparable74.equals(0.0d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        long long20 = day9.getLastMillisecond();
        int int21 = day9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day9.previous();
        long long23 = day9.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesException1);
        java.lang.Object obj7 = seriesChangeEvent6.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("1-January-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        long long8 = year4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        timePeriodValue2.setValue((java.lang.Number) 100);
        java.lang.String str6 = timePeriodValue2.toString();
        boolean boolean8 = timePeriodValue2.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year9.previous();
        boolean boolean19 = timePeriodValue2.equals((java.lang.Object) regularTimePeriod18);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues21.setRangeDescription("");
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValue26.getPeriod();
        timePeriodValues21.add(timePeriodValue26);
        int int29 = timePeriodValues21.getMaxStartIndex();
        timePeriodValues21.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener31);
        boolean boolean33 = timePeriodValue2.equals((java.lang.Object) timePeriodValues21);
        org.junit.Assert.assertNotNull(timePeriod3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[2019,100]" + "'", str6.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        java.lang.Object obj13 = timePeriodValue11.clone();
        boolean boolean14 = timePeriodValues1.equals(obj13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) false);
        int int18 = year15.getYear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) false);
        boolean boolean22 = year15.equals((java.lang.Object) year19);
        boolean boolean24 = year15.equals((java.lang.Object) false);
        java.util.Date date25 = year15.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25, timeZone27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date25, timeZone29);
        int int31 = day30.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day30, 1.0d);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day30, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        int int8 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues10.setDescription("Time");
        int int13 = timePeriodValues10.getMinStartIndex();
        java.lang.String str14 = timePeriodValues10.getRangeDescription();
        java.lang.Object obj15 = timePeriodValues10.clone();
        java.lang.String str16 = timePeriodValues10.getDescription();
        int int17 = timePeriodValues10.getMinStartIndex();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) false);
        int int21 = year18.getYear();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean24 = year22.equals((java.lang.Object) false);
        boolean boolean25 = year18.equals((java.lang.Object) year22);
        java.util.Date date26 = year18.getEnd();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        boolean boolean29 = day27.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("");
        java.lang.String str32 = seriesException31.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException31.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        boolean boolean36 = day27.equals((java.lang.Object) seriesException31);
        org.jfree.data.time.SerialDate serialDate37 = day27.getSerialDate();
        timePeriodValues10.setKey((java.lang.Comparable) day27);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year39, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod42 = timePeriodValue41.getPeriod();
        timePeriodValue41.setValue((java.lang.Number) 100);
        boolean boolean45 = day27.equals((java.lang.Object) 100);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str32.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(timePeriod42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        timePeriodValues3.setDescription("TimePeriodValue[2019,100]");
        timePeriodValues3.setDomainDescription("1-January-2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str10 = timePeriodValues9.getDomainDescription();
        timePeriodValues9.setDomainDescription("Time");
        boolean boolean13 = timePeriodValues3.equals((java.lang.Object) "Time");
        java.lang.String str14 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 2019);
        int int10 = year5.compareTo((java.lang.Object) 2019);
        long long11 = year5.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        int int7 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        boolean boolean10 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
        timePeriodValues1.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        try {
            java.lang.Number number7 = timePeriodValues1.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue10.getPeriod();
        timePeriodValue10.setValue((java.lang.Number) 100);
        timePeriodValue10.setValue((java.lang.Number) 2019L);
        timePeriodValues1.add(timePeriodValue10);
        java.lang.Object obj17 = null;
        boolean boolean18 = timePeriodValue10.equals(obj17);
        boolean boolean20 = timePeriodValue10.equals((java.lang.Object) (byte) 1);
        timePeriodValue10.setValue((java.lang.Number) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(timePeriod11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate13 = day9.getSerialDate();
        java.util.Date date14 = day9.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) false);
        int int18 = year15.getYear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) false);
        boolean boolean22 = year15.equals((java.lang.Object) year19);
        boolean boolean24 = year15.equals((java.lang.Object) false);
        java.util.Date date25 = year15.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date14, timeZone27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone27);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setDomainDescription("TimePeriodValue[2019,1.0]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        java.lang.Object obj12 = null;
        boolean boolean13 = day9.equals(obj12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues15.getMinEndIndex();
        int int19 = day9.compareTo((java.lang.Object) timePeriodValues15);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        java.lang.String str4 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str3.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str4.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        int int7 = year4.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        boolean boolean11 = year4.equals((java.lang.Object) year8);
        boolean boolean13 = year4.equals((java.lang.Object) false);
        java.util.Date date14 = year4.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) false);
        int int18 = year15.getYear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) false);
        boolean boolean22 = year15.equals((java.lang.Object) year19);
        java.util.Date date23 = year15.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) false);
        int int27 = year24.getYear();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) false);
        boolean boolean31 = year24.equals((java.lang.Object) year28);
        java.util.Date date32 = year24.getEnd();
        boolean boolean33 = year15.equals((java.lang.Object) date32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date14, timeZone34);
        boolean boolean37 = timePeriodValues1.equals((java.lang.Object) timeZone34);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("Value");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) false);
        int int10 = year7.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        boolean boolean14 = year7.equals((java.lang.Object) year11);
        java.util.Date date15 = year7.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        int int19 = year16.getYear();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        boolean boolean23 = year16.equals((java.lang.Object) year20);
        java.util.Date date24 = year16.getEnd();
        boolean boolean25 = year7.equals((java.lang.Object) date24);
        timePeriodValues3.setKey((java.lang.Comparable) year7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        timePeriodValues3.setDescription("TimePeriodValue[2019,100]");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date10);
        java.lang.Class<?> wildcardClass17 = year16.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) false);
        int int21 = year18.getYear();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean24 = year22.equals((java.lang.Object) false);
        boolean boolean25 = year18.equals((java.lang.Object) year22);
        java.util.Date date26 = year18.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues28.setDescription("Time");
        int int31 = timePeriodValues28.getMinStartIndex();
        java.lang.String str32 = timePeriodValues28.getRangeDescription();
        int int33 = timePeriodValues28.getItemCount();
        int int34 = timePeriodValues28.getMinEndIndex();
        int int35 = year18.compareTo((java.lang.Object) timePeriodValues28);
        long long36 = year18.getSerialIndex();
        boolean boolean37 = year16.equals((java.lang.Object) year18);
        long long38 = year16.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Value" + "'", str32.equals("Value"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        java.lang.Comparable comparable4 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 0.0d + "'", comparable4.equals(0.0d));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        int int9 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(3, 5);
        timePeriodValues12.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        long long3 = year0.getLastMillisecond();
        java.lang.String str4 = year0.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 2019);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timePeriodValues30.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date11, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        java.lang.Class<?> wildcardClass54 = timePeriodValues50.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        int int59 = year56.getYear();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        boolean boolean63 = year56.equals((java.lang.Object) year60);
        java.util.Date date64 = year56.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date64, timeZone66);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date11, date64);
        long long69 = simpleTimePeriod68.getEndMillis();
        java.util.Date date70 = simpleTimePeriod68.getEnd();
        java.util.Date date71 = simpleTimePeriod68.getEnd();
        java.lang.Object obj72 = null;
        try {
            int int73 = simpleTimePeriod68.compareTo(obj72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(date71);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        boolean boolean12 = timePeriodValues1.isEmpty();
        int int13 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        int int16 = year13.getYear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        boolean boolean20 = year13.equals((java.lang.Object) year17);
        java.util.Date date21 = year13.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        boolean boolean24 = day22.equals((java.lang.Object) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day22.previous();
        boolean boolean26 = day9.equals((java.lang.Object) day22);
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, 0.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (double) 5);
        int int31 = day9.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 31 + "'", int31 == 31);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.delete((int) (byte) 100, (int) ' ');
        timePeriodValues1.setRangeDescription("1-January-2019");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Value");
        java.lang.String str10 = seriesChangeEvent9.toString();
        java.lang.String str11 = seriesChangeEvent9.toString();
        java.lang.Object obj12 = seriesChangeEvent9.getSource();
        java.lang.Object obj13 = seriesChangeEvent9.getSource();
        java.lang.String str14 = seriesChangeEvent9.toString();
        boolean boolean15 = timePeriodValues1.equals((java.lang.Object) seriesChangeEvent9);
        int int16 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + obj12 + "' != '" + "Value" + "'", obj12.equals("Value"));
        org.junit.Assert.assertTrue("'" + obj13 + "' != '" + "Value" + "'", obj13.equals("Value"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Value]" + "'", str14.equals("org.jfree.data.general.SeriesChangeEvent[source=Value]"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        java.util.Calendar calendar22 = null;
        try {
            year20.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.general.SeriesChangeEvent[source=Value]", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues11.removeChangeListener(seriesChangeListener12);
        timePeriodValues11.setRangeDescription("TimePeriodValue[2019,100]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue2.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue(timePeriod4, (double) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue(timePeriod4, (java.lang.Number) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue(timePeriod4, (double) (short) 100);
        org.junit.Assert.assertNotNull(timePeriod3);
        org.junit.Assert.assertNotNull(timePeriod4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        boolean boolean27 = day18.equals((java.lang.Object) seriesException22);
        org.jfree.data.time.SerialDate serialDate28 = day18.getSerialDate();
        timePeriodValues1.setKey((java.lang.Comparable) day18);
        java.lang.String str30 = day18.toString();
        int int31 = day18.getYear();
        java.lang.Number number32 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, number32);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        java.lang.Object obj12 = null;
        boolean boolean13 = day9.equals(obj12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues15.getMinEndIndex();
        int int19 = day9.compareTo((java.lang.Object) timePeriodValues15);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = day9.getFirstMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        java.lang.String str4 = seriesException3.toString();
        java.lang.String str5 = seriesException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Class<?> wildcardClass7 = seriesException3.getClass();
        java.lang.Throwable[] throwableArray8 = seriesException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str4.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate13 = day9.getSerialDate();
        java.util.Date date14 = day9.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) false);
        int int18 = year15.getYear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) false);
        boolean boolean22 = year15.equals((java.lang.Object) year19);
        boolean boolean24 = year15.equals((java.lang.Object) false);
        java.util.Date date25 = year15.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date14, timeZone27);
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone27);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        java.lang.Object obj9 = timePeriodValue6.clone();
        java.lang.String str10 = timePeriodValue6.toString();
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str10.equals("TimePeriodValue[2019,-1.0]"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        timePeriodValues1.fireSeriesChanged();
        int int8 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Value");
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + "Value" + "'", obj2.equals("Value"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("31-December-2019");
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) false);
        boolean boolean17 = year10.equals((java.lang.Object) year14);
        java.util.Date date18 = year10.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        boolean boolean21 = day19.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("");
        java.lang.String str24 = seriesException23.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException23.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        boolean boolean28 = day19.equals((java.lang.Object) seriesException23);
        org.jfree.data.time.SerialDate serialDate29 = day19.getSerialDate();
        long long30 = day19.getLastMillisecond();
        int int31 = day19.getYear();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day19, (double) 0L);
        int int34 = day19.getYear();
        java.util.Date date35 = day19.getStart();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str24.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertNotNull(date35);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timePeriodValues30.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date11, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        java.lang.Class<?> wildcardClass54 = timePeriodValues50.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        int int59 = year56.getYear();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        boolean boolean63 = year56.equals((java.lang.Object) year60);
        java.util.Date date64 = year56.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date64, timeZone66);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date11, date64);
        long long69 = simpleTimePeriod68.getEndMillis();
        java.util.Date date70 = simpleTimePeriod68.getEnd();
        java.util.Date date71 = simpleTimePeriod68.getEnd();
        java.util.Date date72 = simpleTimePeriod68.getStart();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(date72);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        boolean boolean27 = day18.equals((java.lang.Object) seriesException22);
        org.jfree.data.time.SerialDate serialDate28 = day18.getSerialDate();
        timePeriodValues1.setKey((java.lang.Comparable) day18);
        int int30 = day18.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("Value");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) false);
        int int10 = year7.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        boolean boolean14 = year7.equals((java.lang.Object) year11);
        java.util.Date date15 = year7.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        int int19 = year16.getYear();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        boolean boolean23 = year16.equals((java.lang.Object) year20);
        java.util.Date date24 = year16.getEnd();
        boolean boolean25 = year7.equals((java.lang.Object) date24);
        timePeriodValues3.setKey((java.lang.Comparable) year7);
        java.lang.Class<?> wildcardClass27 = year7.getClass();
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str32 = timePeriodValues31.getDomainDescription();
        timePeriodValues31.setDomainDescription("Time");
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        timePeriodValues31.add((org.jfree.data.time.TimePeriod) year35, (double) (-1L));
        int int38 = timePeriodValues31.getItemCount();
        timePeriodValues31.setDomainDescription("");
        java.lang.Comparable comparable41 = timePeriodValues31.getKey();
        org.jfree.data.time.TimePeriodValue timePeriodValue43 = timePeriodValues31.getDataItem(0);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        boolean boolean46 = year44.equals((java.lang.Object) false);
        int int47 = year44.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year44.next();
        java.lang.String str49 = year44.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year44, 1.0d);
        java.util.Date date52 = year44.getEnd();
        boolean boolean53 = timePeriodValue43.equals((java.lang.Object) date52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        boolean boolean56 = year54.equals((java.lang.Object) false);
        int int57 = year54.getYear();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        boolean boolean60 = year58.equals((java.lang.Object) false);
        boolean boolean61 = year54.equals((java.lang.Object) year58);
        java.util.Date date62 = year54.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod(date52, date62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        boolean boolean66 = year64.equals((java.lang.Object) false);
        int int67 = year64.getYear();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        boolean boolean70 = year68.equals((java.lang.Object) false);
        boolean boolean71 = year64.equals((java.lang.Object) year68);
        boolean boolean73 = year64.equals((java.lang.Object) false);
        java.util.Date date74 = year64.getStart();
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date74);
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date74, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date62, timeZone76);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 0.0d + "'", comparable41.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriodValue43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019" + "'", str49.equals("2019"));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2019 + "'", int67 == 2019);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy(2, (int) (short) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues10.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        java.lang.Comparable comparable35 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + 0.0d + "'", comparable35.equals(0.0d));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) (byte) 10);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day9.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        int int38 = year35.getYear();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) false);
        boolean boolean42 = year35.equals((java.lang.Object) year39);
        boolean boolean44 = year35.equals((java.lang.Object) false);
        java.util.Date date45 = year35.getStart();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        java.lang.String str47 = day46.toString();
        int int48 = year27.compareTo((java.lang.Object) day46);
        int int49 = day46.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day46.next();
        java.util.Calendar calendar51 = null;
        try {
            day46.peg(calendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1-January-2019" + "'", str47.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) false);
        int int10 = year7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 0);
        int int15 = year0.compareTo((java.lang.Object) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue11.getPeriod();
        java.lang.Object obj13 = timePeriodValue11.clone();
        boolean boolean14 = timePeriodValues1.equals(obj13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener15);
        timePeriodValues1.setNotify(true);
        int int19 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        long long23 = year20.getLastMillisecond();
        long long24 = year20.getLastMillisecond();
        java.util.Date date25 = year20.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year20, (java.lang.Number) 2);
        timePeriodValues1.setDomainDescription("hi!");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(31, 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        int int16 = year13.getYear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        boolean boolean20 = year13.equals((java.lang.Object) year17);
        java.util.Date date21 = year13.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        boolean boolean24 = day22.equals((java.lang.Object) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day22.previous();
        boolean boolean26 = day9.equals((java.lang.Object) day22);
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, 0.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (double) 5);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = day9.getLastMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        java.lang.String str8 = timePeriodValues7.getDescription();
        int int9 = timePeriodValues7.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue11 = timePeriodValues7.getDataItem(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        int int26 = year23.getYear();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        boolean boolean30 = year23.equals((java.lang.Object) year27);
        java.util.Date date31 = year23.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        boolean boolean34 = year32.equals((java.lang.Object) false);
        int int35 = year32.getYear();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        boolean boolean39 = year32.equals((java.lang.Object) year36);
        java.util.Date date40 = year32.getEnd();
        boolean boolean41 = year23.equals((java.lang.Object) date40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date40, timeZone42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date22, timeZone42);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date11, timeZone42);
        java.util.Date date46 = day45.getStart();
        int int47 = day45.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate48 = day45.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 31 + "'", int47 == 31);
        org.junit.Assert.assertNotNull(serialDate48);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        int int4 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str9 = timePeriodValues8.getDomainDescription();
        timePeriodValues8.setRangeDescription("Value");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
        timePeriodValue14.setValue((java.lang.Number) 100);
        timePeriodValues8.add(timePeriodValue14);
        timePeriodValues1.add(timePeriodValue14);
        boolean boolean20 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriod timePeriod21 = null;
        try {
            timePeriodValues1.add(timePeriod21, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        int int9 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValues1.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate13 = day9.getSerialDate();
        java.util.Date date14 = day9.getEnd();
        long long15 = day9.getLastMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day9.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone14);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues17.setDescription("Time");
        int int20 = timePeriodValues17.getMinStartIndex();
        java.lang.String str21 = timePeriodValues17.getRangeDescription();
        java.lang.String str22 = timePeriodValues17.getDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod26 = timePeriodValue25.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValue25.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue(timePeriod27, (double) 1);
        timePeriodValues17.add(timePeriodValue29);
        java.lang.Object obj31 = timePeriodValue29.clone();
        java.lang.String str32 = timePeriodValue29.toString();
        java.lang.Object obj33 = timePeriodValue29.clone();
        boolean boolean34 = day15.equals(obj33);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriod26);
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str32.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        java.lang.String str8 = seriesException7.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str8.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.lang.String str8 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.next();
        boolean boolean15 = year0.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "TimePeriodValue[2019,100]", "TimePeriodValue[2019,-1.0]");
        try {
            timePeriodValues18.delete(8, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timePeriodValues30.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date11, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        java.lang.Class<?> wildcardClass54 = timePeriodValues50.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        int int59 = year56.getYear();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        boolean boolean63 = year56.equals((java.lang.Object) year60);
        java.util.Date date64 = year56.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date64, timeZone66);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date11, date64);
        java.util.Date date69 = simpleTimePeriod68.getEnd();
        java.util.Date date70 = simpleTimePeriod68.getEnd();
        long long71 = simpleTimePeriod68.getStartMillis();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1577779200000L + "'", long71 == 1577779200000L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) false);
        int int4 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        boolean boolean8 = year1.equals((java.lang.Object) year5);
        boolean boolean10 = year1.equals((java.lang.Object) false);
        java.util.Date date11 = year1.getStart();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date0, date11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        java.lang.String str12 = seriesException11.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str12.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timePeriodValues30.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date11, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        timePeriodValues50.setNotify(true);
        java.lang.Class<?> wildcardClass54 = timePeriodValues50.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        int int59 = year56.getYear();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        boolean boolean62 = year60.equals((java.lang.Object) false);
        boolean boolean63 = year56.equals((java.lang.Object) year60);
        java.util.Date date64 = year56.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date64, timeZone66);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date11, date64);
        long long69 = simpleTimePeriod68.getEndMillis();
        long long70 = simpleTimePeriod68.getEndMillis();
        java.util.Date date71 = simpleTimePeriod68.getStart();
        long long72 = simpleTimePeriod68.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str75 = timePeriodValues74.getDomainDescription();
        timePeriodValues74.setNotify(true);
        java.lang.String str78 = timePeriodValues74.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener79 = null;
        timePeriodValues74.removeChangeListener(seriesChangeListener79);
        boolean boolean81 = simpleTimePeriod68.equals((java.lang.Object) seriesChangeListener79);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1577865599999L + "'", long70 == 1577865599999L);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1577779200000L + "'", long72 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "Time" + "'", str75.equals("Time"));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "Time" + "'", str78.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (9) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("31-December-2019");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        java.util.Date date20 = year12.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        java.lang.String str22 = day21.toString();
        int int24 = day21.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) false);
        int int28 = year25.getYear();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        boolean boolean31 = year29.equals((java.lang.Object) false);
        boolean boolean32 = year25.equals((java.lang.Object) year29);
        java.util.Date date33 = year25.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        boolean boolean36 = day34.equals((java.lang.Object) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day34.previous();
        boolean boolean38 = day21.equals((java.lang.Object) day34);
        int int39 = day34.getDayOfMonth();
        int int40 = day9.compareTo((java.lang.Object) day34);
        java.util.Calendar calendar41 = null;
        try {
            day9.peg(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 31 + "'", int39 == 31);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.setRangeDescription("Time");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        int int9 = timePeriodValues1.getMaxEndIndex();
        int int10 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        boolean boolean8 = timePeriodValues1.getNotify();
        int int9 = timePeriodValues1.getMinStartIndex();
        java.lang.Object obj10 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        long long21 = year20.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str21 = timePeriodValues20.getDomainDescription();
        timePeriodValues20.setNotify(true);
        java.lang.Class<?> wildcardClass24 = timePeriodValues20.getClass();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) false);
        int int28 = year25.getYear();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        boolean boolean31 = year29.equals((java.lang.Object) false);
        boolean boolean32 = year25.equals((java.lang.Object) year29);
        boolean boolean34 = year25.equals((java.lang.Object) false);
        java.util.Date date35 = year25.getStart();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        boolean boolean47 = year45.equals((java.lang.Object) false);
        int int48 = year45.getYear();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        boolean boolean51 = year49.equals((java.lang.Object) false);
        boolean boolean52 = year45.equals((java.lang.Object) year49);
        java.util.Date date53 = year45.getEnd();
        boolean boolean54 = year36.equals((java.lang.Object) date53);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date53, timeZone55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date35, timeZone55);
        java.util.Date date58 = year57.getStart();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        boolean boolean61 = year59.equals((java.lang.Object) false);
        int int62 = year59.getYear();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        boolean boolean65 = year63.equals((java.lang.Object) false);
        boolean boolean66 = year59.equals((java.lang.Object) year63);
        boolean boolean68 = year59.equals((java.lang.Object) false);
        java.util.Date date69 = year59.getStart();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date69);
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date69, timeZone71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date58, timeZone71);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date17, timeZone71);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod73);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.String str6 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue9.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue(timePeriod11, (double) 1);
        timePeriodValues1.add(timePeriodValue13);
        java.lang.Number number15 = timePeriodValue13.getValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertNotNull(timePeriod11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        int int8 = timePeriodValues1.getItemCount();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues1.getDataItem(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        int int26 = year21.compareTo((java.lang.Object) year23);
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (double) (short) 10);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        boolean boolean31 = year29.equals((java.lang.Object) false);
        int int32 = year29.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year29.previous();
        java.util.Date date35 = regularTimePeriod34.getEnd();
        boolean boolean36 = year21.equals((java.lang.Object) date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35);
        int int38 = day37.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        timePeriodValues3.setDescription("TimePeriodValue[2019,100]");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues9.setRangeDescription("");
        int int12 = timePeriodValues9.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str17 = timePeriodValues16.getDomainDescription();
        timePeriodValues16.setRangeDescription("Value");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod23 = timePeriodValue22.getPeriod();
        timePeriodValue22.setValue((java.lang.Number) 100);
        timePeriodValues16.add(timePeriodValue22);
        timePeriodValues9.add(timePeriodValue22);
        timePeriodValues3.add(timePeriodValue22);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = timePeriodValues30.createCopy(2, (int) (byte) 100);
        boolean boolean37 = timePeriodValues30.getNotify();
        boolean boolean38 = timePeriodValue22.equals((java.lang.Object) boolean37);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriod23);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        int int11 = year8.getYear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        boolean boolean15 = year8.equals((java.lang.Object) year12);
        java.util.Date date16 = year8.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        boolean boolean19 = day17.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("");
        java.lang.String str22 = seriesException21.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        boolean boolean26 = day17.equals((java.lang.Object) seriesException21);
        org.jfree.data.time.SerialDate serialDate27 = day17.getSerialDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate27);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 8);
        java.lang.String str32 = timePeriodValues1.getDomainDescription();
        int int33 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str22.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        long long8 = year4.getMiddleMillisecond();
        int int9 = year4.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) (short) 0);
        long long12 = year4.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        boolean boolean8 = timePeriodValues1.getNotify();
        int int9 = timePeriodValues1.getMinStartIndex();
        try {
            java.lang.Number number11 = timePeriodValues1.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=Value]");
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        int int4 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener5);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        int int9 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue13.getPeriod();
        timePeriodValue13.setValue((java.lang.Number) 100);
        java.lang.String str17 = timePeriodValue13.toString();
        java.lang.Number number18 = timePeriodValue13.getValue();
        timePeriodValues1.add(timePeriodValue13);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(timePeriod14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TimePeriodValue[2019,100]" + "'", str17.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 100 + "'", number18.equals(100));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        int int26 = year23.getYear();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        boolean boolean30 = year23.equals((java.lang.Object) year27);
        java.util.Date date31 = year23.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        boolean boolean34 = year32.equals((java.lang.Object) false);
        int int35 = year32.getYear();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        boolean boolean39 = year32.equals((java.lang.Object) year36);
        java.util.Date date40 = year32.getEnd();
        boolean boolean41 = year23.equals((java.lang.Object) date40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date40, timeZone42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date22, timeZone42);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date11, timeZone42);
        java.util.Date date46 = day45.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day45);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day45, "", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(date46);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        timePeriodValues30.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timePeriodValues30.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) false);
        int int39 = year36.getYear();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) false);
        boolean boolean43 = year36.equals((java.lang.Object) year40);
        java.util.Date date44 = year36.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date44, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date11, timeZone46);
        java.util.Calendar calendar49 = null;
        try {
            day48.peg(calendar49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        timePeriodValues1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        java.lang.Class<?> wildcardClass9 = year0.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        long long10 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.next();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
        int int4 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        long long10 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 9);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str16 = timePeriodValues15.getDomainDescription();
        timePeriodValues15.setNotify(true);
        int int19 = timePeriodValues15.getMinMiddleIndex();
        boolean boolean20 = timePeriodValue13.equals((java.lang.Object) int19);
        java.lang.Number number21 = timePeriodValue13.getValue();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 9.0d + "'", number21.equals(9.0d));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        int int14 = year11.getYear();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) false);
        boolean boolean18 = year11.equals((java.lang.Object) year15);
        java.util.Date date19 = year11.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        int int23 = year20.getYear();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) false);
        boolean boolean27 = year20.equals((java.lang.Object) year24);
        java.util.Date date28 = year20.getEnd();
        boolean boolean29 = year11.equals((java.lang.Object) date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date28, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date10, timeZone30);
        java.util.Date date33 = year32.getStart();
        java.util.Date date34 = year32.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year32.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 0);
        java.util.Date date8 = year0.getEnd();
        java.util.Calendar calendar9 = null;
        try {
            year0.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        java.lang.String str4 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str4.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 100);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.lang.Object obj5 = null;
        try {
            int int6 = simpleTimePeriod2.compareTo(obj5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) false);
        int int4 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        boolean boolean8 = year1.equals((java.lang.Object) year5);
        long long9 = year5.getMiddleMillisecond();
        int int10 = year5.getYear();
        java.lang.Class<?> wildcardClass11 = year5.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues14.setDescription("Time");
        int int17 = timePeriodValues14.getMinStartIndex();
        java.lang.String str18 = timePeriodValues14.getRangeDescription();
        java.lang.Object obj19 = timePeriodValues14.clone();
        java.lang.String str20 = timePeriodValues14.getRangeDescription();
        timePeriodValues14.setRangeDescription("Time");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        int int26 = year23.getYear();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        boolean boolean30 = year23.equals((java.lang.Object) year27);
        java.util.Date date31 = year23.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        int int33 = day32.getMonth();
        long long34 = day32.getFirstMillisecond();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day32, (java.lang.Number) (byte) 100);
        java.util.Date date37 = day32.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        boolean boolean40 = year38.equals((java.lang.Object) false);
        int int41 = year38.getYear();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        boolean boolean44 = year42.equals((java.lang.Object) false);
        boolean boolean45 = year38.equals((java.lang.Object) year42);
        java.util.Date date46 = year38.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        java.lang.String str48 = day47.toString();
        java.util.Date date49 = day47.getStart();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        boolean boolean52 = year50.equals((java.lang.Object) false);
        int int53 = year50.getYear();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        boolean boolean56 = year54.equals((java.lang.Object) false);
        boolean boolean57 = year50.equals((java.lang.Object) year54);
        boolean boolean59 = year50.equals((java.lang.Object) false);
        java.util.Date date60 = year50.getStart();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date60, timeZone62);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date60, timeZone64);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date49, timeZone64);
        org.jfree.data.time.TimePeriodValues timePeriodValues68 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str69 = timePeriodValues68.getDomainDescription();
        timePeriodValues68.setNotify(true);
        java.lang.Class<?> wildcardClass72 = timePeriodValues68.getClass();
        java.lang.Class class73 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass72);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
        boolean boolean76 = year74.equals((java.lang.Object) false);
        int int77 = year74.getYear();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        boolean boolean80 = year78.equals((java.lang.Object) false);
        boolean boolean81 = year74.equals((java.lang.Object) year78);
        java.util.Date date82 = year74.getEnd();
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date82);
        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date82, timeZone84);
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date49, timeZone84);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date37, timeZone84);
        try {
            org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date0, timeZone84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577779200000L + "'", long34 == 1577779200000L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "31-December-2019" + "'", str48.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Time" + "'", str69.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(class73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2019 + "'", int77 == 2019);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(timeZone84);
        org.junit.Assert.assertNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue10.getPeriod();
        timePeriodValue10.setValue((java.lang.Number) 100);
        timePeriodValue10.setValue((java.lang.Number) 2019L);
        timePeriodValues1.add(timePeriodValue10);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        long long20 = year17.getLastMillisecond();
        java.lang.String str21 = year17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 1546329600000L);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) false);
        int int28 = year25.getYear();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        boolean boolean31 = year29.equals((java.lang.Object) false);
        boolean boolean32 = year25.equals((java.lang.Object) year29);
        java.util.Date date33 = year25.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        boolean boolean36 = day34.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException38 = new org.jfree.data.general.SeriesException("");
        java.lang.String str39 = seriesException38.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException38.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        boolean boolean43 = day34.equals((java.lang.Object) seriesException38);
        org.jfree.data.time.SerialDate serialDate44 = day34.getSerialDate();
        long long45 = day34.getLastMillisecond();
        int int46 = day34.getYear();
        java.lang.String str47 = day34.toString();
        java.util.Date date48 = day34.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue50 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day34, (double) 1546329600000L);
        java.lang.Number number51 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day34, number51);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(timePeriod11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str39.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "31-December-2019" + "'", str47.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date48);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, 12, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesException1);
        java.lang.String str7 = seriesChangeEvent6.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: ]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: ]"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        int int13 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        java.util.Date date29 = year28.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        java.util.Date date35 = year27.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year27.next();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str39 = timePeriodValues38.getDomainDescription();
        timePeriodValues38.setDomainDescription("Time");
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        timePeriodValues38.add((org.jfree.data.time.TimePeriod) year42, (double) (-1L));
        long long45 = year42.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year42.next();
        long long47 = year42.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year42.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year42, (java.lang.Number) (byte) 10);
        timePeriodValues1.setRangeDescription("TimePeriodValue[2019,1.0]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Time" + "'", str39.equals("Time"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        java.util.Date date35 = year27.getStart();
        int int36 = year27.getYear();
        long long37 = year27.getMiddleMillisecond();
        java.util.Calendar calendar38 = null;
        try {
            year27.peg(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1562097599999L + "'", long37 == 1562097599999L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str39 = timePeriodValues38.getDomainDescription();
        timePeriodValues38.setDomainDescription("Time");
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        timePeriodValues38.add((org.jfree.data.time.TimePeriod) year42, (double) (-1L));
        long long45 = year42.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year42.next();
        long long47 = year42.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year42.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year42, (java.lang.Number) (byte) 10);
        long long51 = year42.getSerialIndex();
        long long52 = year42.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Time" + "'", str39.equals("Time"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1577865599999L + "'", long52 == 1577865599999L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day19);
        long long21 = day19.getLastMillisecond();
        long long22 = day19.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577822399999L + "'", long22 == 1577822399999L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.next();
        boolean boolean15 = year5.equals((java.lang.Object) year10);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 4);
        timePeriodValue17.setValue((java.lang.Number) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str23 = timePeriodValues22.getDomainDescription();
        timePeriodValues22.setNotify(true);
        java.lang.String str26 = timePeriodValues22.getRangeDescription();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        java.lang.String str28 = timePeriodValues22.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) false);
        int int34 = year31.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        boolean boolean38 = year31.equals((java.lang.Object) year35);
        java.util.Date date39 = year31.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        boolean boolean42 = day40.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        java.lang.String str45 = seriesException44.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException44.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        boolean boolean49 = day40.equals((java.lang.Object) seriesException44);
        org.jfree.data.time.SerialDate serialDate50 = day40.getSerialDate();
        long long51 = day40.getLastMillisecond();
        int int52 = day40.getYear();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day40, (double) 0L);
        int int55 = year20.compareTo((java.lang.Object) day40);
        long long56 = year20.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year20.next();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue60 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year58, (double) (-1.0f));
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        boolean boolean63 = year61.equals((java.lang.Object) false);
        long long64 = year61.getLastMillisecond();
        java.lang.String str65 = year61.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year61.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent67 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year61);
        java.lang.Object obj68 = seriesChangeEvent67.getSource();
        boolean boolean69 = timePeriodValue60.equals((java.lang.Object) seriesChangeEvent67);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent70 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue60);
        int int71 = year20.compareTo((java.lang.Object) timePeriodValue60);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0d + "'", comparable27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str45.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1562097599999L + "'", long56 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1577865599999L + "'", long64 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "2019" + "'", str65.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        int int13 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.next();
        boolean boolean15 = year0.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "TimePeriodValue[2019,100]", "TimePeriodValue[2019,-1.0]");
        java.lang.Object obj19 = timePeriodValues18.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        int int11 = year8.getYear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        boolean boolean15 = year8.equals((java.lang.Object) year12);
        boolean boolean17 = year8.equals((java.lang.Object) false);
        java.util.Date date18 = year8.getStart();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date18, timeZone20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date18, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date18);
        java.lang.Class<?> wildcardClass25 = year24.getClass();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year24, (double) '4');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) false);
        int int9 = year6.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) false);
        boolean boolean13 = year6.equals((java.lang.Object) year10);
        boolean boolean15 = year6.equals((java.lang.Object) false);
        java.util.Date date16 = year6.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        int int20 = year17.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) false);
        boolean boolean24 = year17.equals((java.lang.Object) year21);
        boolean boolean26 = year17.equals((java.lang.Object) false);
        java.util.Date date27 = year17.getStart();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) false);
        int int31 = year28.getYear();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        boolean boolean34 = year32.equals((java.lang.Object) false);
        boolean boolean35 = year28.equals((java.lang.Object) year32);
        java.util.Date date36 = year28.getEnd();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        boolean boolean39 = year37.equals((java.lang.Object) false);
        int int40 = year37.getYear();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        boolean boolean43 = year41.equals((java.lang.Object) false);
        boolean boolean44 = year37.equals((java.lang.Object) year41);
        java.util.Date date45 = year37.getEnd();
        boolean boolean46 = year28.equals((java.lang.Object) date45);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date45, timeZone47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date27, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date16, timeZone47);
        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(class51);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        java.util.Date date20 = year12.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        java.lang.String str22 = day21.toString();
        int int24 = day21.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) false);
        int int28 = year25.getYear();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        boolean boolean31 = year29.equals((java.lang.Object) false);
        boolean boolean32 = year25.equals((java.lang.Object) year29);
        java.util.Date date33 = year25.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        boolean boolean36 = day34.equals((java.lang.Object) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day34.previous();
        boolean boolean38 = day21.equals((java.lang.Object) day34);
        int int39 = day34.getDayOfMonth();
        int int40 = day9.compareTo((java.lang.Object) day34);
        org.jfree.data.time.SerialDate serialDate41 = day34.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 31 + "'", int39 == 31);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(serialDate41);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str23 = timePeriodValues22.getDomainDescription();
        timePeriodValues22.setNotify(true);
        java.lang.String str26 = timePeriodValues22.getRangeDescription();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        java.lang.String str28 = timePeriodValues22.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) false);
        int int34 = year31.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        boolean boolean38 = year31.equals((java.lang.Object) year35);
        java.util.Date date39 = year31.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        boolean boolean42 = day40.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        java.lang.String str45 = seriesException44.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException44.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        boolean boolean49 = day40.equals((java.lang.Object) seriesException44);
        org.jfree.data.time.SerialDate serialDate50 = day40.getSerialDate();
        long long51 = day40.getLastMillisecond();
        int int52 = day40.getYear();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day40, (double) 0L);
        int int55 = year20.compareTo((java.lang.Object) day40);
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day40);
        boolean boolean57 = timePeriodValues56.getNotify();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0d + "'", comparable27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str45.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        long long19 = day9.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        int int8 = timePeriodValues1.getItemCount();
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues1.getTimePeriod((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str10 = timePeriodValues9.getDomainDescription();
        timePeriodValues9.setNotify(true);
        java.lang.String str13 = timePeriodValues9.getRangeDescription();
        java.lang.Comparable comparable14 = timePeriodValues9.getKey();
        java.lang.String str15 = timePeriodValues9.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues9.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) false);
        int int21 = year18.getYear();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean24 = year22.equals((java.lang.Object) false);
        boolean boolean25 = year18.equals((java.lang.Object) year22);
        java.util.Date date26 = year18.getEnd();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        boolean boolean29 = day27.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("");
        java.lang.String str32 = seriesException31.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException31.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        boolean boolean36 = day27.equals((java.lang.Object) seriesException31);
        org.jfree.data.time.SerialDate serialDate37 = day27.getSerialDate();
        long long38 = day27.getLastMillisecond();
        int int39 = day27.getYear();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day27, (double) 0L);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day27, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 0.0d + "'", comparable14.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str32.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        int int10 = day9.getMonth();
        int int11 = day9.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod11);
        java.lang.String str13 = seriesChangeEvent12.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=30-December-2019]" + "'", str13.equals("org.jfree.data.general.SeriesChangeEvent[source=30-December-2019]"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        int int14 = year11.getYear();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) false);
        boolean boolean18 = year11.equals((java.lang.Object) year15);
        java.util.Date date19 = year11.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) false);
        int int23 = year20.getYear();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) false);
        boolean boolean27 = year20.equals((java.lang.Object) year24);
        java.util.Date date28 = year20.getEnd();
        boolean boolean29 = year11.equals((java.lang.Object) date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date28, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date10, timeZone30);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        boolean boolean35 = year33.equals((java.lang.Object) false);
        int int36 = year33.getYear();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        boolean boolean39 = year37.equals((java.lang.Object) false);
        boolean boolean40 = year33.equals((java.lang.Object) year37);
        java.util.Date date41 = year33.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        boolean boolean44 = day42.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException46 = new org.jfree.data.general.SeriesException("");
        java.lang.String str47 = seriesException46.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException46.addSuppressed((java.lang.Throwable) timePeriodFormatException49);
        boolean boolean51 = day42.equals((java.lang.Object) seriesException46);
        org.jfree.data.time.SerialDate serialDate52 = day42.getSerialDate();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(serialDate52);
        int int54 = year32.compareTo((java.lang.Object) day53);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str47.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        boolean boolean6 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        int int12 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        boolean boolean16 = year9.equals((java.lang.Object) year13);
        java.util.Date date17 = year9.getEnd();
        boolean boolean18 = year0.equals((java.lang.Object) date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str23 = timePeriodValues22.getDomainDescription();
        timePeriodValues22.setNotify(true);
        java.lang.String str26 = timePeriodValues22.getRangeDescription();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        java.lang.String str28 = timePeriodValues22.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) false);
        int int34 = year31.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        boolean boolean38 = year31.equals((java.lang.Object) year35);
        java.util.Date date39 = year31.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        boolean boolean42 = day40.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        java.lang.String str45 = seriesException44.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException44.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        boolean boolean49 = day40.equals((java.lang.Object) seriesException44);
        org.jfree.data.time.SerialDate serialDate50 = day40.getSerialDate();
        long long51 = day40.getLastMillisecond();
        int int52 = day40.getYear();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day40, (double) 0L);
        int int55 = year20.compareTo((java.lang.Object) day40);
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day40);
        long long57 = day40.getLastMillisecond();
        int int58 = day40.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue60 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day40, (double) '#');
        int int61 = day40.getMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0d + "'", comparable27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str45.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577865599999L + "'", long57 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 12 + "'", int61 == 12);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        long long20 = day9.getLastMillisecond();
        long long21 = day9.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577822399999L + "'", long21 == 1577822399999L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValues1.add(timePeriodValue6);
        timePeriodValue6.setValue((java.lang.Number) (short) 1);
        org.junit.Assert.assertNotNull(timePeriod7);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) false);
        int int16 = year13.getYear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        boolean boolean20 = year13.equals((java.lang.Object) year17);
        java.util.Date date21 = year13.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        boolean boolean24 = day22.equals((java.lang.Object) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day22.previous();
        boolean boolean26 = day9.equals((java.lang.Object) day22);
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, 0.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (double) 5);
        java.lang.Number number31 = timePeriodValue30.getValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 5.0d + "'", number31.equals(5.0d));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        boolean boolean9 = year0.equals((java.lang.Object) false);
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.String str12 = day11.toString();
        long long13 = day11.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1-January-2019" + "'", str12.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: ]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        java.lang.String str7 = timePeriodValues1.getDescription();
        boolean boolean8 = timePeriodValues1.getNotify();
        int int9 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str12 = timePeriodValues11.getDomainDescription();
        timePeriodValues11.setNotify(true);
        java.lang.String str15 = timePeriodValues11.getDomainDescription();
        int int16 = timePeriodValues11.getMaxEndIndex();
        boolean boolean17 = timePeriodValues11.getNotify();
        boolean boolean18 = timePeriodValues1.equals((java.lang.Object) timePeriodValues11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int12 = day9.compareTo((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate13 = day9.getSerialDate();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues1.getTimePeriod(0);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue(timePeriod10, 5.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timePeriod10);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        java.util.Date date7 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date6, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Time" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Time"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        int int7 = year4.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) false);
        boolean boolean11 = year4.equals((java.lang.Object) year8);
        java.util.Date date12 = year4.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.lang.String str14 = day13.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) false);
        int int8 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) false);
        boolean boolean12 = year5.equals((java.lang.Object) year9);
        java.util.Date date13 = year5.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        boolean boolean16 = day14.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean23 = day14.equals((java.lang.Object) seriesException18);
        java.lang.String str24 = day14.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (double) (byte) -1);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) false);
        int int30 = year27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.next();
        java.util.Date date32 = year27.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        int int38 = year35.getYear();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) false);
        boolean boolean42 = year35.equals((java.lang.Object) year39);
        boolean boolean44 = year35.equals((java.lang.Object) false);
        java.util.Date date45 = year35.getStart();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        java.lang.String str47 = day46.toString();
        int int48 = year27.compareTo((java.lang.Object) day46);
        java.lang.String str49 = day46.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day46, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        boolean boolean54 = year52.equals((java.lang.Object) false);
        int int55 = year52.getYear();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) false);
        boolean boolean59 = year52.equals((java.lang.Object) year56);
        long long60 = year56.getMiddleMillisecond();
        int int61 = year56.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue63 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year56, (java.lang.Number) (short) 0);
        boolean boolean64 = day46.equals((java.lang.Object) year56);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1-January-2019" + "'", str47.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1-January-2019" + "'", str49.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1562097599999L + "'", long60 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 1.0d);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
        timePeriodValues9.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        int int10 = day9.getMonth();
        long long11 = day9.getFirstMillisecond();
        long long12 = day9.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577779200000L + "'", long11 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577822399999L + "'", long12 == 1577822399999L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setRangeDescription("");
        int int4 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "Value", "org.jfree.data.general.SeriesException: ");
        java.lang.String str9 = timePeriodValues8.getDomainDescription();
        timePeriodValues8.setRangeDescription("Value");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
        timePeriodValue14.setValue((java.lang.Number) 100);
        timePeriodValues8.add(timePeriodValue14);
        timePeriodValues1.add(timePeriodValue14);
        org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValue14.getPeriod();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertNotNull(timePeriod20);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str10 = timePeriodValues9.getDomainDescription();
        timePeriodValues9.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues9.createCopy(2, (int) (byte) 100);
        int int16 = year5.compareTo((java.lang.Object) 2);
        long long17 = year5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        java.lang.Throwable[] throwableArray19 = seriesException13.getSuppressed();
        java.lang.String str20 = seriesException13.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str20.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long8 = year5.getSerialIndex();
        long long9 = year5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) false);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) false);
        boolean boolean19 = year12.equals((java.lang.Object) year16);
        boolean boolean21 = year12.equals((java.lang.Object) false);
        java.util.Date date22 = year12.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11, timeZone26);
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ", "TimePeriodValue[2019,100]", "2019");
        java.lang.String str35 = timePeriodValues34.getDomainDescription();
        int int36 = year28.compareTo((java.lang.Object) timePeriodValues34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "TimePeriodValue[2019,100]" + "'", str35.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        int int6 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener7);
        try {
            java.lang.Number number10 = timePeriodValues1.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue2.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue(timePeriod4, (double) 1);
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        java.lang.String str8 = timePeriodValue6.toString();
        org.junit.Assert.assertNotNull(timePeriod3);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str8.equals("TimePeriodValue[2019,1.0]"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDomainDescription("Time");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        int int8 = timePeriodValues1.getItemCount();
        timePeriodValues1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) (-1.0f));
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0f));
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) false);
        int int20 = year17.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) false);
        boolean boolean24 = year17.equals((java.lang.Object) year21);
        long long25 = year21.getMiddleMillisecond();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year21.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1562097599999L + "'", long25 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) (byte) 100);
        java.lang.Comparable comparable8 = timePeriodValues7.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues7.getItemCount();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 0.0d + "'", comparable8.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        int int9 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener10);
        timePeriodValues1.setDomainDescription("org.jfree.data.general.SeriesException: ");
        boolean boolean14 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setDescription("Time");
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        int int9 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(3, 5);
        timePeriodValues12.fireSeriesChanged();
        boolean boolean14 = timePeriodValues12.getNotify();
        java.lang.String str15 = timePeriodValues12.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) false);
        int int10 = year7.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) false);
        boolean boolean14 = year7.equals((java.lang.Object) year11);
        java.util.Date date15 = year7.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date15, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) false);
        int int22 = year19.getYear();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) false);
        boolean boolean26 = year19.equals((java.lang.Object) year23);
        java.util.Date date27 = year19.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        java.lang.String str29 = day28.toString();
        java.util.Date date30 = day28.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) false);
        int int34 = year31.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) false);
        boolean boolean38 = year31.equals((java.lang.Object) year35);
        boolean boolean40 = year31.equals((java.lang.Object) false);
        java.util.Date date41 = year31.getStart();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        boolean boolean44 = year42.equals((java.lang.Object) false);
        int int45 = year42.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        boolean boolean48 = year46.equals((java.lang.Object) false);
        boolean boolean49 = year42.equals((java.lang.Object) year46);
        java.util.Date date50 = year42.getEnd();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        boolean boolean53 = year51.equals((java.lang.Object) false);
        int int54 = year51.getYear();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        boolean boolean57 = year55.equals((java.lang.Object) false);
        boolean boolean58 = year51.equals((java.lang.Object) year55);
        java.util.Date date59 = year51.getEnd();
        boolean boolean60 = year42.equals((java.lang.Object) date59);
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date59, timeZone61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date41, timeZone61);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date30, timeZone61);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date15, timeZone61);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "31-December-2019" + "'", str29.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(timeZone61);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
        int int14 = day9.getDayOfMonth();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day9.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) false);
        int int3 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) false);
        boolean boolean7 = year0.equals((java.lang.Object) year4);
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 2019);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean18 = day9.equals((java.lang.Object) seriesException13);
        org.jfree.data.time.SerialDate serialDate19 = day9.getSerialDate();
        long long20 = day9.getLastMillisecond();
        int int21 = day9.getYear();
        org.jfree.data.time.SerialDate serialDate22 = day9.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(serialDate22);
    }
}

