import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(8, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = null;
        try {
            timeSeries1.add(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0, "", "", class3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = null;
        try {
            timeSeries4.add(timeSeriesDataItem5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) 100L);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year6, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.setDescription("hi!");
        try {
            timeSeries1.delete((int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + (byte) 10 + "'", comparable2.equals((byte) 10));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = null;
        try {
            timeSeries1.add(timeSeriesDataItem3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + (byte) 10 + "'", comparable2.equals((byte) 10));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            month0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.clear();
        try {
            timeSeries1.delete(4, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 10, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) '4');
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries4 = timeSeries2.addAndOrUpdate(timeSeries3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries11.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries15.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries11.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = null;
        try {
            timeSeries20.add(timeSeriesDataItem21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries11.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries15.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries11.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries11);
        try {
            java.lang.Number number22 = timeSeries11.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.util.List list2 = timeSeries1.getItems();
        int int3 = timeSeries1.getItemCount();
        try {
            timeSeries1.update(4, (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries10.addAndOrUpdate(timeSeries14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(4, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = null;
        try {
            timeSeries5.add(timeSeriesDataItem10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = null;
        try {
            timeSeries1.add(timeSeriesDataItem10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.util.List list2 = timeSeries1.getItems();
        int int3 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        java.lang.String str9 = timeSeries5.getDomainDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries16.removeAgedItems((long) (-1), false);
        java.lang.String str20 = timeSeries16.getDomainDescription();
        timeSeries16.removeAgedItems((long) (short) -1, true);
        int int24 = year10.compareTo((java.lang.Object) true);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 30, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        timeSeries1.removeAgedItems((long) (short) 10, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = null;
        try {
            timeSeries1.add(timeSeriesDataItem8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, 8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(9, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 100L);
        int int4 = year0.compareTo((java.lang.Object) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries4.removeAgedItems((long) (-1), false);
        java.lang.String str8 = timeSeries4.getDomainDescription();
        timeSeries4.removeAgedItems((long) (short) -1, true);
        java.util.Collection collection12 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(4, 0);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month15, (double) 1L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, (int) (byte) 0, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(1900);
        long long16 = year15.getSerialIndex();
        java.lang.Number number17 = null;
        try {
            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year15, number17);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1900L + "'", long16 == 1900L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        int int3 = day0.getDayOfMonth();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', (int) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        long long2 = timeSeries1.getMaximumItemAge();
        timeSeries1.setRangeDescription("Value");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.util.Date date0 = null;
        java.lang.Class class1 = null;
        java.util.Date date2 = null;
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date2, timeZone3);
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date0, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(1900);
        long long16 = year15.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year15);
        java.lang.Number number18 = null;
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year15, number18, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1900L + "'", long16 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100, (int) ' ', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        int int17 = month15.getYearValue();
        java.lang.Number number18 = null;
        try {
            timeSeries10.update((org.jfree.data.time.RegularTimePeriod) month15, number18);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(1900);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) year4);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1900L + "'", long5 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        boolean boolean4 = day0.equals((java.lang.Object) 1560150000000L);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        try {
            timeSeries9.update(3, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries9);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560192427209L + "'", long4 == 1560192427209L);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2958465");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        int int2 = year0.getYear();
        java.lang.String str3 = year0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        boolean boolean4 = day0.equals((java.lang.Object) 100L);
//        long long5 = day0.getMiddleMillisecond();
//        int int6 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193199999L + "'", long5 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        timeSeries1.delete(regularTimePeriod7);
        timeSeries1.setRangeDescription("Time");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) -1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate3.getEndOfCurrentMonth(serialDate6);
//        try {
//            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 100, serialDate3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.util.List list2 = timeSeries1.getItems();
        int int3 = timeSeries1.getItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean10 = timeSeries9.getNotify();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean15 = day13.equals((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
        try {
            org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate3 = null;
//        try {
//            org.jfree.data.time.SerialDate serialDate4 = serialDate2.getEndOfCurrentMonth(serialDate3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate3);
//        try {
//            org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(1900);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        timeSeries1.setMaximumItemAge(0L);
        try {
            java.lang.Number number13 = timeSeries1.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(1900);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) year4);
        boolean boolean7 = timeSeries2.getNotify();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1900L + "'", long5 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        int int3 = day0.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        try {
            timeSeries1.delete((int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries10.getDescription();
        timeSeries10.removeAgedItems(1900L, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
        try {
            timeSeries10.update(regularTimePeriod17, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(1900);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) year4);
        timeSeries2.setKey((java.lang.Comparable) 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1900L + "'", long5 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long14 = year7.getSerialIndex();
        java.util.Calendar calendar15 = null;
        try {
            year7.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date2, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate3);
//        java.lang.String str7 = serialDate3.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) '4');
        java.lang.String str3 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "August 52" + "'", str3.equals("August 52"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        java.lang.String str2 = year1.toString();
        java.lang.String str3 = year1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1900" + "'", str2.equals("1900"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1900" + "'", str3.equals("1900"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 0);
        java.util.Calendar calendar3 = null;
        try {
            month2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, 3, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) '4');
        long long3 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-60507964800000L) + "'", long3 == (-60507964800000L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean5 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate15 = serialDate9.getEndOfCurrentMonth(serialDate12);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate15);
//        boolean boolean17 = spreadsheetDate2.isOn(serialDate15);
//        try {
//            org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(9, serialDate15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getPreviousDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate3.getEndOfCurrentMonth(serialDate6);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate9);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "", "Time", class13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        boolean boolean17 = year15.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 2958465);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries21.removeAgedItems((long) (-1), false);
//        int int25 = timeSeriesDataItem19.compareTo((java.lang.Object) timeSeries21);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate35 = serialDate29.getEndOfCurrentMonth(serialDate32);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate35);
//        serialDate36.setDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
//        int int39 = timeSeriesDataItem19.compareTo((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: 2019");
//        java.lang.Object obj40 = timeSeriesDataItem19.clone();
//        try {
//            timeSeries14.add(timeSeriesDataItem19, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(obj40);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.time.TimePeriodFormatException: 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        timeSeries1.removeAgedItems((long) (short) 10, false);
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        try {
            java.util.Collection collection9 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Value");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate4);
//        try {
//            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
//        try {
//            timeSeries10.add(regularTimePeriod20, (java.lang.Number) 24229L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192431353L + "'", long16 == 1560192431353L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.setDescription("hi!");
        timeSeries1.setDomainDescription("1900");
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("August 52");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) 'a', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date2, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = timeSeries1.getMaximumItemAge();
        java.lang.Comparable comparable12 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 2958465);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries16.removeAgedItems((long) (-1), false);
        int int20 = timeSeriesDataItem14.compareTo((java.lang.Object) timeSeries16);
        java.util.Collection collection21 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        long long22 = timeSeries16.getMaximumItemAge();
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries10.getDescription();
        timeSeries10.setKey((java.lang.Comparable) (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(9, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "September" + "'", str2.equals("September"));
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate2.getEndOfCurrentMonth(serialDate5);
//        java.lang.String str9 = serialDate8.getDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate8);
//        long long11 = day10.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43646L + "'", long11 == 43646L);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        int int3 = day0.getDayOfMonth();
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(0, serialDate4);
//        java.lang.String str8 = serialDate7.getDescription();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(0, serialDate7);
//        try {
//            org.jfree.data.time.SerialDate serialDate11 = serialDate7.getFollowingDayOfWeek((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(30);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-452) + "'", int1 == (-452));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean10 = timeSeries9.getNotify();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean15 = day13.equals((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
        int int19 = day13.getYear();
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) str3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "2019", "hi!", "", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        int int7 = timeSeries4.getMaximumItemCount();
        boolean boolean8 = timeSeries4.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries11.removeAgedItems((long) (-1), false);
        java.lang.String str15 = timeSeries11.getDomainDescription();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year18);
        long long21 = year16.getSerialIndex();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, year16);
        long long23 = month22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month22, regularTimePeriod24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1549007999999L + "'", long23 == 1549007999999L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getMonth();
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) str7);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "December" + "'", str1.equals("December"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2147483647, 0, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(3, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 5);
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean2, class3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries6.removeAgedItems((long) (-1), false);
        java.lang.String str10 = timeSeries6.getDomainDescription();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        java.lang.Number number18 = timeSeries15.getValue(regularTimePeriod17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod17, (java.lang.Number) 6);
        int int22 = timeSeriesDataItem20.compareTo((java.lang.Object) 1560192429018L);
        try {
            timeSeries4.add(timeSeriesDataItem20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 6);
//        java.lang.Object obj20 = null;
//        int int21 = fixedMillisecond14.compareTo(obj20);
//        java.lang.Object obj22 = null;
//        int int23 = fixedMillisecond14.compareTo(obj22);
//        java.lang.Object obj24 = null;
//        boolean boolean25 = fixedMillisecond14.equals(obj24);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192433842L + "'", long16 == 1560192433842L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getSerialIndex();
//        int int5 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2958465);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (short) 10);
//        long long3 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        boolean boolean10 = timeSeries5.getNotify();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        boolean boolean13 = day11.equals((java.lang.Object) 5);
//        long long14 = day11.getLastMillisecond();
//        int int15 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10, (int) (byte) 1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1.0d);
//        int int7 = day2.getDayOfMonth();
//        java.util.Calendar calendar8 = null;
//        try {
//            day2.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean5 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        java.lang.String str15 = serialDate14.getDescription();
//        boolean boolean16 = spreadsheetDate4.isBefore(serialDate14);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate22 = serialDate20.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate20);
//        boolean boolean24 = spreadsheetDate4.isOn(serialDate20);
//        try {
//            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) "2019");
//        java.lang.Object obj5 = null;
//        int int6 = fixedMillisecond0.compareTo(obj5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
//        long long8 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192434835L + "'", long2 == 1560192434835L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560192434835L + "'", long8 == 1560192434835L);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries4.removeAgedItems((long) (-1), false);
        java.lang.String str8 = timeSeries4.getDomainDescription();
        timeSeries4.removeAgedItems((long) (short) -1, true);
        java.util.Collection collection12 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        try {
            timeSeries4.update(regularTimePeriod14, (java.lang.Number) 1560192427209L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        try {
            timeSeries1.update(30, (java.lang.Number) 1560192432446L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 30, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        int int5 = timeSeries1.getMaximumItemCount();
        int int6 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = null;
        try {
            timeSeries1.add(timeSeriesDataItem7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean15 = day13.equals((java.lang.Object) 5);
//        int int16 = day13.getDayOfMonth();
//        java.lang.String str17 = day13.toString();
//        long long18 = day13.getLastMillisecond();
//        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 10.0f);
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries10.removePropertyChangeListener(propertyChangeListener21);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 100L);
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 2958465);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries6.removeAgedItems((long) (-1), false);
        int int10 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries6);
        try {
            java.lang.Number number12 = timeSeries6.getValue((-43620));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "2019", "hi!", "", class3);
        try {
            timeSeries4.delete((int) (byte) 1, (-452));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        timeSeries1.delete(regularTimePeriod7);
        try {
            timeSeries1.delete(13, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long14 = year7.getSerialIndex();
        int int15 = year7.getYear();
        long long16 = year7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        java.lang.Comparable comparable12 = timeSeries1.getKey();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate18.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate15.getEndOfCurrentMonth(serialDate18);
//        java.lang.String str22 = serialDate21.getDescription();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(1900);
//        java.lang.String str26 = year25.toString();
//        long long27 = year25.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
//        java.util.Date date31 = fixedMillisecond29.getTime();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date31, timeZone32);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date31);
//        try {
//            timeSeries28.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 1560192428424L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1900" + "'", str26.equals("1900"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2208960000000L) + "'", long27 == (-2208960000000L));
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getMonth();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        long long3 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(4, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries1.getTimePeriod((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        boolean boolean15 = spreadsheetDate3.isBefore(serialDate13);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate19.getEndOfCurrentMonth(serialDate22);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate25);
//        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate3.getEndOfCurrentMonth(serialDate25);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries31.removeAgedItems((long) (-1), false);
//        java.lang.String str35 = timeSeries31.getDomainDescription();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.previous();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.previous();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) year36, (org.jfree.data.time.RegularTimePeriod) year38);
//        long long41 = year38.getSerialIndex();
//        long long42 = year38.getMiddleMillisecond();
//        try {
//            int int43 = spreadsheetDate3.compareTo((java.lang.Object) long42);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1562097599999L + "'", long42 == 1562097599999L);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 0);
        long long3 = month2.getLastMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) "September");
        long long6 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62125372800001L) + "'", long3 == (-62125372800001L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62159500800000L) + "'", long6 == (-62159500800000L));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 2958465);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries6.removeAgedItems((long) (-1), false);
        int int10 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries6);
        java.lang.Number number11 = timeSeriesDataItem4.getValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2958465 + "'", number11.equals(2958465));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.clear();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        try {
            java.lang.Number number5 = timeSeries1.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        timeSeries10.setDescription("");
//        timeSeries10.setMaximumItemAge((long) (byte) 100);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries16.removeAgedItems((long) (-1), false);
//        java.lang.String str20 = timeSeries16.getDomainDescription();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year23);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
//        java.lang.Number number28 = timeSeries25.getValue(regularTimePeriod27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond29.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) 6);
//        java.lang.Object obj35 = null;
//        int int36 = fixedMillisecond29.compareTo(obj35);
//        long long37 = fixedMillisecond29.getMiddleMillisecond();
//        try {
//            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 4);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560192436725L + "'", long31 == 1560192436725L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560192436725L + "'", long37 == 1560192436725L);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (13) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year6.getSerialIndex();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year6.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(0, serialDate3);
//        java.lang.String str7 = serialDate6.getDescription();
//        java.lang.String str8 = serialDate6.getDescription();
//        try {
//            org.jfree.data.time.SerialDate serialDate10 = serialDate6.getPreviousDayOfWeek(9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertNull(str8);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str2.equals("org.jfree.data.general.SeriesException: Value"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(6, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        boolean boolean15 = spreadsheetDate3.isBefore(serialDate13);
//        int int16 = spreadsheetDate3.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        long long19 = timeSeries18.getMaximumItemAge();
//        try {
//            int int20 = spreadsheetDate3.compareTo((java.lang.Object) long19);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) '4');
        long long3 = month2.getMiddleMillisecond();
        int int4 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-60506625600001L) + "'", long3 == (-60506625600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year6.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        java.lang.Class class3 = null;
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date2, timeZone5);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "2019", "hi!", "", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timeSeries4.getDescription();
        org.junit.Assert.assertNull(str7);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries4.removeAgedItems((long) (-1), false);
//        java.lang.String str8 = timeSeries4.getDomainDescription();
//        timeSeries4.removeAgedItems((long) (short) -1, true);
//        java.util.Collection collection12 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries4);
//        timeSeries2.setRangeDescription("hi!");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean17 = day15.equals((java.lang.Object) 5);
//        long long18 = day15.getLastMillisecond();
//        java.lang.Number number19 = null;
//        try {
//            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day15, number19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.util.Date date0 = null;
        java.lang.Class class1 = null;
        java.util.Date date2 = null;
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date2, timeZone3);
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date0, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems(false);
//        java.util.Collection collection8 = timeSeries5.getTimePeriods();
//        int int9 = day0.compareTo((java.lang.Object) timeSeries5);
//        try {
//            timeSeries5.update(30, (java.lang.Number) 0.0d);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 30, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        boolean boolean15 = spreadsheetDate3.isBefore(serialDate13);
//        int int16 = spreadsheetDate3.getMonth();
//        try {
//            org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate3.getNearestDayOfWeek((int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 0);
        long long3 = month2.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62125372800001L) + "'", long3 == (-62125372800001L));
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean5 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate15 = serialDate9.getEndOfCurrentMonth(serialDate12);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate15);
//        boolean boolean17 = spreadsheetDate2.isOn(serialDate15);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(serialDate18);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        java.lang.Class class3 = null;
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date2, timeZone5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.previous();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date2, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        int int4 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "2019", "hi!", "", class3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            timeSeries4.add(regularTimePeriod5, (java.lang.Number) (-1), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1.0d);
//        int int7 = day2.getDayOfMonth();
//        java.lang.String str8 = day2.toString();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.Object obj5 = null;
        try {
            int int6 = spreadsheetDate3.compareTo(obj5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate10 = serialDate4.getEndOfCurrentMonth(serialDate7);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate18.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate15.getEndOfCurrentMonth(serialDate18);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate21);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate11.getEndOfCurrentMonth(serialDate24);
//        try {
//            org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears(2958465, serialDate24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries11.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries15.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries11.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries22.removeAgedItems((long) (-1), false);
        java.lang.String str26 = timeSeries22.getDomainDescription();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
        java.lang.Number number34 = timeSeries31.getValue(regularTimePeriod33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod33, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem36.getPeriod();
        try {
            timeSeries20.add(timeSeriesDataItem36, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.lang.String str6 = seriesChangeEvent5.toString();
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "January" + "'", str2.equals("January"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        int int3 = year1.getYear();
        java.lang.Object obj4 = null;
        int int5 = year1.compareTo(obj4);
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1900, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.clear();
        java.util.Collection collection3 = timeSeries1.getTimePeriods();
        java.lang.Number number5 = null;
        try {
            timeSeries1.update((int) (short) 100, number5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(13, serialDate10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate17);
//        org.jfree.data.time.SerialDate serialDate19 = serialDate11.getEndOfCurrentMonth(serialDate17);
//        boolean boolean20 = spreadsheetDate1.isOn(serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean25 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate35 = serialDate29.getEndOfCurrentMonth(serialDate32);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate35);
//        boolean boolean37 = spreadsheetDate22.isOn(serialDate35);
//        boolean boolean38 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.jfree.data.time.SerialDate serialDate39 = null;
//        try {
//            boolean boolean40 = spreadsheetDate1.isAfter(serialDate39);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(13, serialDate6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate13);
//        try {
//            org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2147483647, serialDate15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: Value");
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1900, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1900");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate3.getEndOfCurrentMonth(serialDate6);
//        try {
//            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears(2147483647, serialDate3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) true);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        try {
            timeSeries1.delete((-43620), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -43620");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1900);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        java.util.Date date5 = fixedMillisecond3.getTime();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date2, timeZone6);
        java.lang.String str9 = month8.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long14 = year7.getSerialIndex();
        int int15 = year7.getYear();
        java.util.Date date16 = year7.getEnd();
        java.util.Calendar calendar17 = null;
        try {
            year7.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(date16);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        int int4 = timeSeries1.getItemCount();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        boolean boolean7 = day5.equals((java.lang.Object) 5);
//        long long8 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) '4');
//        int int11 = day5.getYear();
//        int int12 = day5.getYear();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year7.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.next();
//        long long4 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192440684L + "'", long2 == 1560192440684L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560192440684L + "'", long4 == 1560192440684L);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod12, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem15.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem15.getPeriod();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        boolean boolean15 = spreadsheetDate3.isBefore(serialDate13);
//        int int16 = spreadsheetDate3.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean19 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        int int20 = spreadsheetDate3.getDayOfWeek();
//        try {
//            int int22 = spreadsheetDate3.compareTo((java.lang.Object) 1560150000000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year7.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) '4');
        long long3 = month2.getSerialIndex();
        int int4 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 632L + "'", long3 == 632L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "2019", "hi!", "", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries9.removeAgedItems((long) (-1), false);
        java.lang.String str13 = timeSeries9.getDomainDescription();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year14, (org.jfree.data.time.RegularTimePeriod) year16);
        long long19 = year14.getSerialIndex();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, year14);
        long long21 = year14.getSerialIndex();
        int int22 = year14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year14.next();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year8.getSerialIndex();
        long long12 = year8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries16.fireSeriesChanged();
        boolean boolean18 = timeSeriesDataItem14.equals((java.lang.Object) timeSeries16);
        java.lang.Number number19 = timeSeriesDataItem14.getValue();
        java.lang.Object obj20 = timeSeriesDataItem14.clone();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 5 + "'", number19.equals(5));
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesException: Value");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str13 = spreadsheetDate12.toString();
        java.util.Date date14 = spreadsheetDate12.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.previous();
        java.util.Date date17 = fixedMillisecond15.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date14, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries22.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries26.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries22.addAndOrUpdate(timeSeries26);
        java.lang.Class class31 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str34 = spreadsheetDate33.toString();
        java.util.Date date35 = spreadsheetDate33.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond36.previous();
        java.util.Date date38 = fixedMillisecond36.getTime();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date38, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date35, timeZone39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        boolean boolean44 = year42.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (java.lang.Number) 2958465);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = timeSeriesDataItem46.getPeriod();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean49 = timeSeriesDataItem46.equals((java.lang.Object) timeZone48);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date35, timeZone48);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries52.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries56.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries52.addAndOrUpdate(timeSeries56);
        java.lang.Class class61 = timeSeries56.getTimePeriodClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str64 = spreadsheetDate63.toString();
        java.util.Date date65 = spreadsheetDate63.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = fixedMillisecond66.previous();
        java.util.Date date68 = fixedMillisecond66.getTime();
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date68, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class61, date65, timeZone69);
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        boolean boolean74 = year72.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year72, (java.lang.Number) 2958465);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = timeSeriesDataItem76.getPeriod();
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean79 = timeSeriesDataItem76.equals((java.lang.Object) timeZone78);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date65, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date35, timeZone78);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "5-January-1900" + "'", str13.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "5-January-1900" + "'", str34.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertNotNull(class61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "5-January-1900" + "'", str64.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        boolean boolean15 = spreadsheetDate3.isBefore(serialDate13);
//        org.jfree.data.time.SerialDate serialDate16 = null;
//        try {
//            org.jfree.data.time.SerialDate serialDate17 = serialDate13.getEndOfCurrentMonth(serialDate16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        timeSeries1.removeAgedItems((long) (short) 10, false);
        timeSeries1.setDomainDescription("Time");
        java.util.Collection collection10 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(collection10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("December");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate3.getEndOfCurrentMonth(serialDate6);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears(3, serialDate6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year6.getSerialIndex();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year6.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (double) (byte) 10);
//        java.lang.Number number7 = timeSeriesDataItem6.getValue();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries9.removeAgedItems((long) (-1), false);
//        timeSeries9.removeAgedItems((long) (short) 10, false);
//        timeSeries9.setDomainDescription("Time");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries9.addChangeListener(seriesChangeListener18);
//        boolean boolean20 = timeSeriesDataItem6.equals((java.lang.Object) seriesChangeListener18);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0d + "'", number7.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) '#', 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        timeSeries10.setDescription("");
        timeSeries10.setMaximumItemAge((long) (byte) 100);
        timeSeries10.setMaximumItemAge((long) 'a');
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries10.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(1900);
        java.lang.String str3 = year2.toString();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year2);
        long long5 = year2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1900" + "'", str3.equals("1900"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1900L + "'", long5 == 1900L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2958465);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560192445763L + "'", long1 == 1560192445763L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192445763L + "'", long3 == 1560192445763L);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems(false);
        java.util.Collection collection8 = timeSeries5.getTimePeriods();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        timeSeries5.delete(regularTimePeriod10);
        try {
            timeSeries1.update(regularTimePeriod10, (java.lang.Number) 1560192428424L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        boolean boolean6 = timeSeries1.getNotify();
        try {
            timeSeries1.update(0, (java.lang.Number) 1560192430718L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate14);
//        boolean boolean16 = spreadsheetDate1.isOn(serialDate14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate19.getEndOfCurrentMonth(serialDate22);
//        int int26 = spreadsheetDate1.compare(serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean29 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        int int30 = spreadsheetDate1.getYYYY();
//        try {
//            org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate1.getFollowingDayOfWeek((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-43620) + "'", int26 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getMonth();
        org.jfree.data.time.Year year3 = month0.getYear();
        int int4 = year3.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year8.getSerialIndex();
        long long12 = year8.getMiddleMillisecond();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year8.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((-452), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean4 = day2.equals((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1.0d);
        int int7 = day2.getYear();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean5 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths(13, serialDate11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate16.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate18);
//        org.jfree.data.time.SerialDate serialDate20 = serialDate12.getEndOfCurrentMonth(serialDate18);
//        boolean boolean21 = spreadsheetDate2.isOn(serialDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean26 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate30 = day28.getSerialDate();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate33 = day31.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate35 = serialDate33.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate36 = serialDate30.getEndOfCurrentMonth(serialDate33);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate36);
//        boolean boolean38 = spreadsheetDate23.isOn(serialDate36);
//        boolean boolean39 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        try {
//            org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-452), (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(1900);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) year4);
        long long7 = timeSeries2.getMaximumItemAge();
        int int8 = timeSeries2.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1900L + "'", long5 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timeSeries10.getDescription();
//        java.lang.String str14 = timeSeries10.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries16.removeAgedItems((long) (-1), false);
//        java.lang.String str20 = timeSeries16.getDomainDescription();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year23);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries27.removeAgedItems((long) (-1), false);
//        java.lang.String str31 = timeSeries27.getDomainDescription();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) year34);
//        int int37 = year23.compareTo((java.lang.Object) year32);
//        java.lang.String str38 = year32.toString();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        boolean boolean41 = day39.equals((java.lang.Object) 5);
//        int int42 = day39.getDayOfMonth();
//        java.lang.String str43 = day39.toString();
//        long long44 = day39.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) day39);
//        java.util.Calendar calendar46 = null;
//        try {
//            day39.peg(calendar46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries45);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean10 = timeSeries9.getNotify();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean15 = day13.equals((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries20.removeAgedItems((long) (-1), false);
        java.lang.String str24 = timeSeries20.getDomainDescription();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) year27);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        java.lang.Number number32 = timeSeries29.getValue(regularTimePeriod31);
        try {
            timeSeries9.add(regularTimePeriod31, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Time" + "'", str24.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNull(number32);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 2958465);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries16.removeAgedItems((long) (-1), false);
        int int20 = timeSeriesDataItem14.compareTo((java.lang.Object) timeSeries16);
        java.util.Collection collection21 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        timeSeries16.setMaximumItemCount(4);
        java.lang.Class class24 = timeSeries16.getTimePeriodClass();
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(class24);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(3, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "March" + "'", str2.equals("March"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year4 = month3.getYear();
        long long5 = month3.getFirstMillisecond();
        long long6 = month3.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        java.util.Date date5 = fixedMillisecond3.getTime();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date2, timeZone6);
        long long9 = month8.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24234L + "'", long9 == 24234L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries11.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries15.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries11.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries20.setRangeDescription("2019");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries20.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long14 = month13.getLastMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            month13.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1549007999999L + "'", long14 == 1549007999999L);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean11 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(13, serialDate17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate24);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate18.getEndOfCurrentMonth(serialDate24);
//        boolean boolean27 = spreadsheetDate8.isOn(serialDate26);
//        boolean boolean28 = day6.equals((java.lang.Object) serialDate26);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        spreadsheetDate1.setDescription("September");
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (7) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-43620));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 2958465);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries6.removeAgedItems((long) (-1), false);
        int int10 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries6);
        timeSeries6.setNotify(false);
        try {
            java.lang.Number number14 = timeSeries6.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        boolean boolean15 = spreadsheetDate3.isBefore(serialDate13);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate19.getEndOfCurrentMonth(serialDate22);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate25);
//        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate3.getEndOfCurrentMonth(serialDate25);
//        int int30 = spreadsheetDate3.getYYYY();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.next();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192448249L + "'", long2 == 1560192448249L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560192448249L + "'", long5 == 1560192448249L);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean4 = day2.equals((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1.0d);
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        timeSeries1.setDescription("March");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(1900);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) year4);
        long long7 = timeSeries2.getMaximumItemAge();
        timeSeries2.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1900L + "'", long5 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries6.removeAgedItems((long) (-1), false);
        java.lang.String str10 = timeSeries6.getDomainDescription();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year13);
        long long16 = year11.getSerialIndex();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        long long18 = year11.getSerialIndex();
        int int19 = year11.getYear();
        java.util.Date date20 = year11.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
        java.lang.Class class22 = null;
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date20, timeZone24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNull(regularTimePeriod26);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener13);
        try {
            timeSeries10.update((int) (short) 0, (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(0, serialDate8);
//        java.lang.String str12 = serialDate11.getDescription();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate4.getEndOfCurrentMonth(serialDate11);
//        java.lang.String str14 = serialDate13.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "30-June-2019" + "'", str14.equals("30-June-2019"));
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("December");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate5.getEndOfCurrentMonth(serialDate8);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate22 = serialDate16.getEndOfCurrentMonth(serialDate19);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate22);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate22.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate12.getEndOfCurrentMonth(serialDate25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate25);
//        boolean boolean28 = spreadsheetDate1.isOnOrBefore(serialDate25);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate33 = day31.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate35 = serialDate33.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addDays(0, serialDate33);
//        java.lang.String str37 = serialDate36.getDescription();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(0, serialDate36);
//        try {
//            int int39 = spreadsheetDate1.compareTo((java.lang.Object) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNull(str37);
//        org.junit.Assert.assertNotNull(serialDate38);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries11.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries15.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries11.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries22.removeAgedItems((long) (-1), false);
        java.lang.String str26 = timeSeries22.getDomainDescription();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.previous();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod32, class33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries1.getDataItem(regularTimePeriod32);
        long long36 = timeSeries1.getMaximumItemAge();
        timeSeries1.setDomainDescription("hi!");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getPreviousDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) "2019");
//        java.lang.Object obj5 = null;
//        int int6 = fixedMillisecond0.compareTo(obj5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getLastMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192449430L + "'", long2 == 1560192449430L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560192449430L + "'", long8 == 1560192449430L);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = serialDate2.getPreviousDayOfWeek(3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate2);
//        long long6 = day5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
//        boolean boolean16 = spreadsheetDate1.isOnOrBefore(serialDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean21 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate25 = day23.getSerialDate();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate28 = day26.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate30 = serialDate28.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate25.getEndOfCurrentMonth(serialDate28);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate31);
//        boolean boolean33 = spreadsheetDate18.isOn(serialDate31);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int38 = day37.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate42 = serialDate36.getEndOfCurrentMonth(serialDate39);
//        int int43 = spreadsheetDate18.compare(serialDate36);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate36.getPreviousDayOfWeek(6);
//        boolean boolean46 = spreadsheetDate1.isOnOrBefore(serialDate45);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries48.removeAgedItems(false);
//        timeSeries48.clear();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent52 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries48);
//        try {
//            int int53 = spreadsheetDate1.compareTo((java.lang.Object) seriesChangeEvent52);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.general.SeriesChangeEvent cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-43620) + "'", int43 == (-43620));
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=1560192426750]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("December");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10, (-452), 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
//        java.lang.Object obj8 = timeSeriesDataItem6.clone();
//        java.lang.Object obj9 = timeSeriesDataItem6.clone();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(obj9);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Feb" + "'", str2.equals("Feb"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate5 = null;
        try {
            boolean boolean6 = spreadsheetDate1.isOnOrBefore(serialDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries3.removeAgedItems((long) (-1), false);
        java.lang.String str7 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        long long13 = year8.getSerialIndex();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year8);
        try {
            org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) '4', year8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, 6, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getMonth();
        int int3 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        timeSeries1.setMaximumItemAge(0L);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries13.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries17.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries13.addAndOrUpdate(timeSeries17);
//        int int22 = timeSeries21.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
//        int int27 = fixedMillisecond23.compareTo((java.lang.Object) "2019");
//        java.lang.Object obj28 = null;
//        int int29 = fixedMillisecond23.compareTo(obj28);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond23.getFirstMillisecond(calendar31);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 100L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560192450829L + "'", long25 == 1560192450829L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560192450829L + "'", long32 == 1560192450829L);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        long long11 = timeSeries1.getMaximumItemAge();
//        java.lang.String str12 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getLastMillisecond();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int20 = day19.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate18.getEndOfCurrentMonth(serialDate21);
//        java.lang.String str25 = serialDate24.getDescription();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears(6, serialDate24);
//        int int27 = fixedMillisecond13.compareTo((java.lang.Object) 6);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond13.getMiddleMillisecond(calendar28);
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond13.peg(calendar30);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 7, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560192450844L + "'", long14 == 1560192450844L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560192450844L + "'", long29 == 1560192450844L);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(13);
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getSerialIndex();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
//        boolean boolean16 = day0.equals((java.lang.Object) serialDate13);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        java.util.Date date5 = fixedMillisecond3.getTime();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date2, timeZone6);
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date2, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries12.removeAgedItems((long) (-1), false);
        java.lang.String str16 = timeSeries12.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
        int int22 = year8.compareTo((java.lang.Object) year17);
        long long23 = year8.getFirstMillisecond();
        long long24 = year8.getFirstMillisecond();
        java.lang.String str25 = year8.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.util.List list7 = timeSeries6.getItems();
        int int8 = timeSeries6.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries10.removeAgedItems((long) (-1), false);
        java.lang.String str14 = timeSeries10.getDomainDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year17);
        long long20 = year17.getSerialIndex();
        long long21 = year17.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, (double) 1560192426750L);
        long long27 = year17.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1562097599999L + "'", long21 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1562097599999L + "'", long27 == 1562097599999L);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate3.getEndOfCurrentMonth(serialDate6);
//        java.lang.String str10 = serialDate9.getDescription();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(3, serialDate9);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNotNull(serialDate12);
//    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        java.lang.Comparable comparable12 = timeSeries1.getKey();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate18.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate15.getEndOfCurrentMonth(serialDate18);
//        java.lang.String str22 = serialDate21.getDescription();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(1900);
//        java.lang.String str26 = year25.toString();
//        long long27 = year25.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year25);
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener29);
//        timeSeries1.clear();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1900" + "'", str26.equals("1900"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2208960000000L) + "'", long27 == (-2208960000000L));
//        org.junit.Assert.assertNotNull(timeSeries28);
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
//        boolean boolean16 = spreadsheetDate1.isOnOrBefore(serialDate13);
//        int int17 = spreadsheetDate1.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("5-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        boolean boolean2 = year0.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 2958465);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries6.removeAgedItems((long) (-1), false);
//        int int10 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries6);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate14 = day12.getSerialDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate19 = serialDate17.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate20 = serialDate14.getEndOfCurrentMonth(serialDate17);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate20);
//        serialDate21.setDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
//        int int24 = timeSeriesDataItem4.compareTo((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: 2019");
//        java.lang.Number number25 = null;
//        timeSeriesDataItem4.setValue(number25);
//        timeSeriesDataItem4.setValue((java.lang.Number) 0.0d);
//        boolean boolean30 = timeSeriesDataItem4.equals((java.lang.Object) 1560192436656L);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean10 = timeSeries9.getNotify();
        java.lang.String str11 = timeSeries9.getDescription();
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(3, (int) ' ', 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean10 = timeSeries5.getNotify();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries5.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate10 = serialDate4.getEndOfCurrentMonth(serialDate7);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate18.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate15.getEndOfCurrentMonth(serialDate18);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate21);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate11.getEndOfCurrentMonth(serialDate24);
//        try {
//            org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(11, serialDate11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(10, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "October" + "'", str2.equals("October"));
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        java.util.List list2 = timeSeries1.getItems();
//        int int3 = timeSeries1.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems((long) (-1), false);
//        java.lang.String str9 = timeSeries5.getDomainDescription();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year12);
//        long long15 = year12.getSerialIndex();
//        long long16 = year12.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year12);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries21.removeAgedItems((long) (-1), false);
//        java.lang.String str25 = timeSeries21.getDomainDescription();
//        timeSeries21.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable29 = timeSeries21.getKey();
//        timeSeries21.clear();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        boolean boolean33 = day31.equals((java.lang.Object) 5);
//        boolean boolean35 = day31.equals((java.lang.Object) 100L);
//        long long36 = day31.getMiddleMillisecond();
//        long long37 = day31.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day31, (double) (-62159500800000L));
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 1577865599999L, false);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1562097599999L + "'", long16 == 1562097599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + (byte) 10 + "'", comparable29.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560193199999L + "'", long36 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 43626L + "'", long37 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year6.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries14.removeAgedItems((long) (-1), false);
        java.lang.String str18 = timeSeries14.getDomainDescription();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) year19, (org.jfree.data.time.RegularTimePeriod) year21);
        long long24 = year19.getSerialIndex();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, year19);
        long long26 = year19.getSerialIndex();
        int int27 = year19.getYear();
        java.util.Date date28 = year19.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond30.previous();
        java.util.Date date32 = fixedMillisecond30.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond33.previous();
        java.util.Date date35 = fixedMillisecond33.getTime();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35, timeZone36);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date32, timeZone36);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date28, timeZone36);
        int int40 = year6.compareTo((java.lang.Object) year39);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        boolean boolean12 = year10.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 2958465);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries16.removeAgedItems((long) (-1), false);
//        int int20 = timeSeriesDataItem14.compareTo((java.lang.Object) timeSeries16);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate24 = day22.getSerialDate();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        int int26 = day25.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate27 = day25.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate30 = serialDate24.getEndOfCurrentMonth(serialDate27);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate30);
//        serialDate31.setDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
//        int int34 = timeSeriesDataItem14.compareTo((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: 2019");
//        java.lang.Number number35 = null;
//        timeSeriesDataItem14.setValue(number35);
//        timeSeriesDataItem14.setValue((java.lang.Number) 0.0d);
//        java.lang.Number number39 = timeSeriesDataItem14.getValue();
//        try {
//            timeSeries1.add(timeSeriesDataItem14, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 0.0d + "'", number39.equals(0.0d));
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        timeSeries1.removeAgedItems((long) (short) 10, false);
        timeSeries1.setDomainDescription("Time");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.addChangeListener(seriesChangeListener10);
        try {
            timeSeries1.delete(1900, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries11.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries15.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries11.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries22.removeAgedItems((long) (-1), false);
        java.lang.String str26 = timeSeries22.getDomainDescription();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.previous();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod32, class33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries1.getDataItem(regularTimePeriod32);
        java.util.Collection collection36 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(collection36);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate5.getEndOfCurrentMonth(serialDate8);
//        java.lang.String str12 = serialDate11.getDescription();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(6, serialDate11);
//        int int14 = fixedMillisecond0.compareTo((java.lang.Object) 6);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond0.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560192453111L + "'", long1 == 1560192453111L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192453111L + "'", long16 == 1560192453111L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        boolean boolean15 = spreadsheetDate3.isBefore(serialDate13);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate19);
//        boolean boolean23 = spreadsheetDate3.isOn(serialDate19);
//        try {
//            org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate3.getFollowingDayOfWeek((-452));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getLastMillisecond();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
//        java.util.Date date9 = fixedMillisecond7.getTime();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.Year year11 = month10.getYear();
//        long long12 = month10.getLastMillisecond();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month10, (double) 1560192433842L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560192453178L + "'", long5 == 1560192453178L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        long long3 = month0.getSerialIndex();
        int int4 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
//        java.lang.Number number8 = timeSeriesDataItem6.getValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10.0d + "'", number8.equals(10.0d));
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(31);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2147483647, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long14 = year7.getSerialIndex();
        int int15 = year7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year7.next();
        java.lang.Object obj17 = null;
        int int18 = year7.compareTo(obj17);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-43620));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        int int3 = day0.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("December");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("1900");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        int int11 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries13.removeAgedItems((long) (-1), false);
        java.lang.String str17 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) year20);
        long long23 = year20.getSerialIndex();
        long long24 = year20.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 5);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries28.fireSeriesChanged();
        boolean boolean30 = timeSeriesDataItem26.equals((java.lang.Object) timeSeries28);
        java.lang.Number number31 = timeSeriesDataItem26.getValue();
        try {
            timeSeries1.add(timeSeriesDataItem26);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1562097599999L + "'", long24 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 5 + "'", number31.equals(5));
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        java.lang.Comparable comparable12 = timeSeries1.getKey();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate18.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate15.getEndOfCurrentMonth(serialDate18);
//        java.lang.String str22 = serialDate21.getDescription();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(1900);
//        java.lang.String str26 = year25.toString();
//        long long27 = year25.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year25);
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener29);
//        try {
//            timeSeries1.update((-1), (java.lang.Number) 1560192436656L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1900" + "'", str26.equals("1900"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2208960000000L) + "'", long27 == (-2208960000000L));
//        org.junit.Assert.assertNotNull(timeSeries28);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(30, 11, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(0, serialDate4);
//        java.lang.String str8 = serialDate7.getDescription();
//        java.lang.String str9 = serialDate7.getDescription();
//        try {
//            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2958465, serialDate7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNull(str9);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate2.getEndOfCurrentMonth(serialDate5);
//        java.lang.String str9 = serialDate8.getDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate8);
//        try {
//            org.jfree.data.time.SerialDate serialDate12 = serialDate8.getNearestDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNull(str9);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("June 2019");
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 5);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        java.lang.Class class3 = null;
//        java.util.Date date4 = null;
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date2, timeZone5);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(0, serialDate11);
//        java.lang.String str15 = serialDate14.getDescription();
//        boolean boolean16 = day7.equals((java.lang.Object) str15);
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = day7.getLastMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1900, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        int int2 = spreadsheetDate1.getDayOfWeek();
//        int int3 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate4 = null;
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate16 = serialDate10.getEndOfCurrentMonth(serialDate13);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate16);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int20 = day19.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate24 = day22.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate26 = serialDate24.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate27 = serialDate21.getEndOfCurrentMonth(serialDate24);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate27);
//        org.jfree.data.time.SerialDate serialDate30 = serialDate27.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate17.getEndOfCurrentMonth(serialDate30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate30);
//        boolean boolean33 = spreadsheetDate6.isOnOrBefore(serialDate30);
//        try {
//            boolean boolean34 = spreadsheetDate1.isInRange(serialDate4, (org.jfree.data.time.SerialDate) spreadsheetDate6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2958465) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 2958465);
        long long5 = year0.getSerialIndex();
        java.lang.Class<?> wildcardClass6 = year0.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192454901L + "'", long2 == 1560192454901L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560192454901L + "'", long4 == 1560192454901L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "2019", "hi!", "", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        int int7 = timeSeries4.getMaximumItemCount();
        boolean boolean8 = timeSeries4.isEmpty();
        int int9 = timeSeries4.getItemCount();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate5.getEndOfCurrentMonth(serialDate8);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(31, serialDate12);
//        try {
//            org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(100, serialDate12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = timeSeries1.getMaximumItemAge();
        boolean boolean12 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        long long2 = timeSeries1.getMaximumItemAge();
//        java.lang.String str3 = timeSeries1.getRangeDescription();
//        timeSeries1.setDescription("");
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        boolean boolean8 = year6.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 2958465);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries12.removeAgedItems((long) (-1), false);
//        int int16 = timeSeriesDataItem10.compareTo((java.lang.Object) timeSeries12);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate23 = day21.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate20.getEndOfCurrentMonth(serialDate23);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate26);
//        serialDate27.setDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
//        int int30 = timeSeriesDataItem10.compareTo((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: 2019");
//        java.lang.Object obj31 = timeSeriesDataItem10.clone();
//        try {
//            timeSeries1.add(timeSeriesDataItem10);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(obj31);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year8.getSerialIndex();
        long long12 = year8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries16.fireSeriesChanged();
        boolean boolean18 = timeSeriesDataItem14.equals((java.lang.Object) timeSeries16);
        java.lang.Object obj19 = timeSeriesDataItem14.clone();
        timeSeriesDataItem14.setValue((java.lang.Number) 1560192448683L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        int int4 = timeSeries1.getItemCount();
        try {
            timeSeries1.delete(12, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        boolean boolean4 = day0.equals((java.lang.Object) 100L);
//        long long5 = day0.getMiddleMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "10-June-2019", class8);
//        java.lang.String str10 = timeSeries9.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries9.removePropertyChangeListener(propertyChangeListener11);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193199999L + "'", long5 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        java.lang.String str7 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0, "", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        int int7 = month5.getYearValue();
        int int8 = month5.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month5.previous();
        try {
            timeSeries4.add(regularTimePeriod9, (double) 1560192427209L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 6);
//        java.lang.Object obj20 = null;
//        int int21 = fixedMillisecond14.compareTo(obj20);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries23.removeAgedItems(false);
//        timeSeries23.clear();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries23);
//        boolean boolean28 = fixedMillisecond14.equals((java.lang.Object) seriesChangeEvent27);
//        java.lang.String str29 = seriesChangeEvent27.toString();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192455785L + "'", long16 == 1560192455785L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod12, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem15.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean23 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        int int25 = day24.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate26 = day24.getSerialDate();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate32 = serialDate26.getEndOfCurrentMonth(serialDate29);
//        java.lang.String str33 = serialDate32.getDescription();
//        boolean boolean34 = spreadsheetDate22.isBefore(serialDate32);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        int int37 = day36.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate38 = day36.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate40 = serialDate38.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate38);
//        boolean boolean42 = spreadsheetDate22.isOn(serialDate38);
//        int int43 = spreadsheetDate18.compare(serialDate38);
//        boolean boolean44 = timeSeriesDataItem15.equals((java.lang.Object) int43);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-43623) + "'", int43 == (-43623));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year4 = month3.getYear();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year4);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries1.fireSeriesChanged();
        timeSeries1.setDescription("Feb");
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 6);
//        java.lang.Object obj20 = null;
//        int int21 = fixedMillisecond14.compareTo(obj20);
//        java.util.Date date22 = fixedMillisecond14.getEnd();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192456307L + "'", long16 == 1560192456307L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate14);
//        boolean boolean16 = spreadsheetDate1.isOn(serialDate14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate19.getEndOfCurrentMonth(serialDate22);
//        int int26 = spreadsheetDate1.compare(serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean31 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate37 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = serialDate37.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate34.getEndOfCurrentMonth(serialDate37);
//        java.lang.String str41 = serialDate40.getDescription();
//        boolean boolean42 = spreadsheetDate30.isBefore(serialDate40);
//        int int43 = spreadsheetDate30.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean46 = spreadsheetDate30.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        boolean boolean47 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate50 = day48.getSerialDate();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(serialDate50);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        int int54 = day53.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate55 = day53.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate57 = serialDate55.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate55);
//        boolean boolean60 = spreadsheetDate1.isInRange(serialDate50, serialDate55, 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-43620) + "'", int26 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 10 + "'", int54 == 10);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        boolean boolean3 = day1.equals((java.lang.Object) 5);
//        int int4 = day1.getDayOfMonth();
//        java.lang.String str5 = day1.toString();
//        boolean boolean6 = month0.equals((java.lang.Object) str5);
//        int int7 = month0.getMonth();
//        int int8 = month0.getYearValue();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        timeSeries1.delete(regularTimePeriod7);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(4, 0);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        boolean boolean14 = timeSeries1.equals((java.lang.Object) regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62159500800000L) + "'", long12 == (-62159500800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str14 = timePeriodFormatException13.toString();
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException13.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Time", "1900", "Time", class16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5, "", "org.jfree.data.general.SeriesException: Value", class16);
        int int20 = year5.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("September");
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = day0.equals(obj3);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.setMaximumItemCount(1900);
        int int4 = timeSeries1.getItemCount();
        boolean boolean5 = timeSeries1.isEmpty();
        try {
            timeSeries1.delete(11, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("30-June-2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (double) (byte) 10);
//        java.lang.Number number7 = timeSeriesDataItem6.getValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem6.getPeriod();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0d + "'", number7.equals(10.0d));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean5 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        java.lang.String str15 = serialDate14.getDescription();
//        boolean boolean16 = spreadsheetDate4.isBefore(serialDate14);
//        int int17 = spreadsheetDate4.getMonth();
//        try {
//            org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        timeSeries1.removeAgedItems((long) (short) 10, false);
        timeSeries1.setDomainDescription("Time");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(1900);
        java.lang.String str14 = year13.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1900" + "'", str14.equals("1900"));
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        java.lang.String str4 = month0.toString();
        long long5 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.clear();
        try {
            timeSeries1.update((-43623), (java.lang.Number) 43646L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        int int14 = year7.getYear();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560192438814L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192438814L + "'", long3 == 1560192438814L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems(false);
//        java.util.Collection collection8 = timeSeries5.getTimePeriods();
//        int int9 = day0.compareTo((java.lang.Object) timeSeries5);
//        int int10 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1560192438128L);
        long long7 = month3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) "2019");
//        java.lang.Object obj5 = null;
//        int int6 = fixedMillisecond0.compareTo(obj5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192462382L + "'", long2 == 1560192462382L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        boolean boolean7 = fixedMillisecond0.equals((java.lang.Object) 1560192445763L);
//        java.util.Date date8 = fixedMillisecond0.getTime();
//        java.lang.Class class9 = null;
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8, timeZone11);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192462403L + "'", long3 == 1560192462403L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560192462403L + "'", long5 == 1560192462403L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        int int10 = timeSeries9.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
//        int int15 = fixedMillisecond11.compareTo((java.lang.Object) "2019");
//        java.lang.Object obj16 = null;
//        int int17 = fixedMillisecond11.compareTo(obj16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        long long19 = fixedMillisecond11.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560192462449L + "'", long13 == 1560192462449L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560192462449L + "'", long19 == 1560192462449L);
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = serialDate2.getPreviousDayOfWeek(3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate2);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day5.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timeSeries10.getDescription();
//        java.lang.String str14 = timeSeries10.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries16.removeAgedItems((long) (-1), false);
//        java.lang.String str20 = timeSeries16.getDomainDescription();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year23);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries27.removeAgedItems((long) (-1), false);
//        java.lang.String str31 = timeSeries27.getDomainDescription();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) year34);
//        int int37 = year23.compareTo((java.lang.Object) year32);
//        java.lang.String str38 = year32.toString();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        boolean boolean41 = day39.equals((java.lang.Object) 5);
//        int int42 = day39.getDayOfMonth();
//        java.lang.String str43 = day39.toString();
//        long long44 = day39.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) day39);
//        int int46 = day39.getMonth();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries3.removeAgedItems((long) (-1), false);
//        java.lang.String str7 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
//        java.lang.Number number15 = timeSeries12.getValue(regularTimePeriod14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 6);
//        java.lang.Object obj22 = null;
//        int int23 = fixedMillisecond16.compareTo(obj22);
//        java.lang.Object obj24 = null;
//        int int25 = fixedMillisecond16.compareTo(obj24);
//        int int26 = month0.compareTo((java.lang.Object) fixedMillisecond16);
//        java.util.Calendar calendar27 = null;
//        try {
//            long long28 = month0.getLastMillisecond(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560192462687L + "'", long18 == 1560192462687L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("September");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        java.util.Calendar calendar3 = null;
        fixedMillisecond0.peg(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560192456307L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
//        boolean boolean16 = spreadsheetDate1.isOnOrBefore(serialDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean21 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate25 = day23.getSerialDate();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate28 = day26.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate30 = serialDate28.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate25.getEndOfCurrentMonth(serialDate28);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate31);
//        boolean boolean33 = spreadsheetDate18.isOn(serialDate31);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int38 = day37.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate42 = serialDate36.getEndOfCurrentMonth(serialDate39);
//        int int43 = spreadsheetDate18.compare(serialDate36);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate36.getPreviousDayOfWeek(6);
//        boolean boolean46 = spreadsheetDate1.isOnOrBefore(serialDate45);
//        java.lang.Class<?> wildcardClass47 = serialDate45.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond48.previous();
//        java.util.Date date50 = fixedMillisecond48.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = fixedMillisecond51.previous();
//        java.util.Date date53 = fixedMillisecond51.getTime();
//        java.lang.Class class54 = null;
//        java.util.Date date55 = null;
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date55, timeZone56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date53, timeZone56);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date50, timeZone56);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = fixedMillisecond60.previous();
//        java.util.Date date62 = fixedMillisecond60.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond63.previous();
//        java.util.Date date65 = fixedMillisecond63.getTime();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date65, timeZone66);
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date62, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date50, timeZone66);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-43620) + "'", int43 == (-43620));
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean10 = timeSeries9.getNotify();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean15 = day13.equals((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = day13.getMiddleMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Time", "1900", "Time", class10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "August 52", "Value", "Value", class10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries13.removeAgedItems((long) (-1), false);
        java.lang.String str17 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        java.lang.Number number25 = timeSeries22.getValue(regularTimePeriod24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod24, (java.lang.Number) 6);
        int int29 = timeSeriesDataItem27.compareTo((java.lang.Object) 1560192429018L);
        try {
            timeSeries1.add(timeSeriesDataItem27);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate3);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
//        try {
//            org.jfree.data.time.SerialDate serialDate9 = serialDate3.getFollowingDayOfWeek(13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        java.lang.String str4 = month0.toString();
        long long5 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (short) 10);
        java.util.Date date3 = day0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
        java.util.Date date6 = fixedMillisecond4.getTime();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries13.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries17.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries13.addAndOrUpdate(timeSeries17);
        java.lang.Class class22 = timeSeries17.getTimePeriodClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str25 = spreadsheetDate24.toString();
        java.util.Date date26 = spreadsheetDate24.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.previous();
        java.util.Date date29 = fixedMillisecond27.getTime();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date29, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date26, timeZone30);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date6, timeZone30);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date3, timeZone30);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "5-January-1900" + "'", str25.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries4.removeAgedItems((long) (-1), false);
        java.lang.String str8 = timeSeries4.getDomainDescription();
        timeSeries4.removeAgedItems((long) (short) -1, true);
        java.util.Collection collection12 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        java.lang.Comparable comparable13 = timeSeries2.getKey();
        long long14 = timeSeries2.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 1L + "'", comparable13.equals(1L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9999);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1964 + "'", int1 == 1964);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        int int10 = timeSeries9.getMaximumItemCount();
        java.lang.String str11 = timeSeries9.getRangeDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) 100L);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(8, year13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month16);
        int int18 = month16.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) (byte) -1);
        timeSeriesDataItem20.setValue((java.lang.Number) 1560192445763L);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        boolean boolean4 = day0.equals((java.lang.Object) 100L);
//        long long5 = day0.getMiddleMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "10-June-2019", class8);
//        java.util.List list10 = timeSeries9.getItems();
//        java.lang.Class class11 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1560193199999L);
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = year12.getLastMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193199999L + "'", long5 == 1560193199999L);
//        org.junit.Assert.assertNotNull(list10);
//        org.junit.Assert.assertNull(class11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate3.getEndOfCurrentMonth(serialDate6);
//        java.lang.String str10 = serialDate9.getDescription();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(6, serialDate9);
//        serialDate9.setDescription("Value");
//        try {
//            org.jfree.data.time.SerialDate serialDate15 = serialDate9.getNearestDayOfWeek(9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-43626));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (double) (byte) 10);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries8.removeAgedItems((long) (-1), false);
//        java.lang.String str12 = timeSeries8.getDomainDescription();
//        timeSeries8.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable16 = timeSeries8.getKey();
//        java.lang.Object obj17 = timeSeries8.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.previous();
//        long long20 = fixedMillisecond18.getMiddleMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getMiddleMillisecond(calendar21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1560192430017L);
//        boolean boolean25 = timeSeriesDataItem6.equals((java.lang.Object) timeSeries8);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries27.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries31.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries27.addAndOrUpdate(timeSeries31);
//        int int36 = timeSeries35.getMaximumItemCount();
//        java.lang.String str37 = timeSeries35.getRangeDescription();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        boolean boolean41 = year39.equals((java.lang.Object) 100L);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(8, year39);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) month42);
//        int int44 = month42.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) (byte) -1);
//        try {
//            timeSeries8.add(timeSeriesDataItem46, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (byte) 10 + "'", comparable16.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560192466341L + "'", long20 == 1560192466341L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560192466341L + "'", long22 == 1560192466341L);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2147483647 + "'", int36 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Value" + "'", str37.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 8 + "'", int44 == 8);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str2 = spreadsheetDate1.toString();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5-January-1900" + "'", str2.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(6, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str7 = timePeriodFormatException4.toString();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        timeSeries1.delete(regularTimePeriod6);
        timeSeries1.setMaximumItemAge(1560150000000L);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timeSeries10.getDescription();
//        java.lang.String str14 = timeSeries10.getDescription();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        boolean boolean17 = year15.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 2958465);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries21.removeAgedItems((long) (-1), false);
//        int int25 = timeSeriesDataItem19.compareTo((java.lang.Object) timeSeries21);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate35 = serialDate29.getEndOfCurrentMonth(serialDate32);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate35);
//        serialDate36.setDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
//        int int39 = timeSeriesDataItem19.compareTo((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: 2019");
//        java.lang.Object obj40 = timeSeriesDataItem19.clone();
//        java.lang.Object obj41 = timeSeriesDataItem19.clone();
//        try {
//            timeSeries10.add(timeSeriesDataItem19, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(obj40);
//        org.junit.Assert.assertNotNull(obj41);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
        java.util.Date date6 = fixedMillisecond4.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        java.util.Date date9 = fixedMillisecond7.getTime();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9, timeZone10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date6, timeZone10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day13);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day13.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate15 = serialDate9.getEndOfCurrentMonth(serialDate12);
//        java.lang.String str16 = serialDate15.getDescription();
//        boolean boolean17 = spreadsheetDate5.isBefore(serialDate15);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int20 = day19.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate21);
//        boolean boolean25 = spreadsheetDate5.isOn(serialDate21);
//        int int26 = spreadsheetDate1.compare(serialDate21);
//        int int27 = spreadsheetDate1.toSerial();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-43623) + "'", int26 == (-43623));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str2 = spreadsheetDate1.toString();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5-January-1900" + "'", str2.equals("5-January-1900"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str7 = spreadsheetDate6.toString();
        java.util.Date date8 = spreadsheetDate6.toDate();
        java.util.Date date9 = spreadsheetDate6.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries14.removeAgedItems((long) (-1), false);
        java.lang.String str18 = timeSeries14.getDomainDescription();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) year19, (org.jfree.data.time.RegularTimePeriod) year21);
        long long24 = year19.getSerialIndex();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, year19);
        long long26 = year19.getSerialIndex();
        int int27 = year19.getYear();
        java.util.Date date28 = year19.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond30.previous();
        java.util.Date date32 = fixedMillisecond30.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond33.previous();
        java.util.Date date35 = fixedMillisecond33.getTime();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35, timeZone36);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date32, timeZone36);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date28, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "5-January-1900" + "'", str7.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod40);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries10.getDescription();
        timeSeries10.removeAgedItems(1900L, true);
        boolean boolean17 = timeSeries10.getNotify();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long14 = year7.getSerialIndex();
        int int15 = year7.getYear();
        java.util.Date date16 = year7.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.previous();
        java.util.Date date20 = fixedMillisecond18.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.previous();
        java.util.Date date23 = fixedMillisecond21.getTime();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23, timeZone24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date20, timeZone24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date16, timeZone24);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date16);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        long long6 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192469181L + "'", long3 == 1560192469181L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560192469181L + "'", long5 == 1560192469181L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560192469181L + "'", long6 == 1560192469181L);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year8.getSerialIndex();
        long long12 = year8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries16.fireSeriesChanged();
        boolean boolean18 = timeSeriesDataItem14.equals((java.lang.Object) timeSeries16);
        java.lang.Number number19 = timeSeriesDataItem14.getValue();
        java.lang.Object obj20 = null;
        int int21 = timeSeriesDataItem14.compareTo(obj20);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 5 + "'", number19.equals(5));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(13, serialDate10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate17);
//        org.jfree.data.time.SerialDate serialDate19 = serialDate11.getEndOfCurrentMonth(serialDate17);
//        boolean boolean20 = spreadsheetDate1.isOn(serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean25 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate35 = serialDate29.getEndOfCurrentMonth(serialDate32);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate35);
//        boolean boolean37 = spreadsheetDate22.isOn(serialDate35);
//        boolean boolean38 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.jfree.data.time.SerialDate serialDate39 = null;
//        try {
//            int int40 = spreadsheetDate22.compare(serialDate39);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timeSeries10.getDescription();
//        java.lang.String str14 = timeSeries10.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries16.removeAgedItems((long) (-1), false);
//        java.lang.String str20 = timeSeries16.getDomainDescription();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year23);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries27.removeAgedItems((long) (-1), false);
//        java.lang.String str31 = timeSeries27.getDomainDescription();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) year34);
//        int int37 = year23.compareTo((java.lang.Object) year32);
//        java.lang.String str38 = year32.toString();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        boolean boolean41 = day39.equals((java.lang.Object) 5);
//        int int42 = day39.getDayOfMonth();
//        java.lang.String str43 = day39.toString();
//        long long44 = day39.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) day39);
//        java.lang.String str46 = timeSeries45.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Time" + "'", str46.equals("Time"));
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (byte) -1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long14 = month13.getSerialIndex();
        java.lang.Class<?> wildcardClass15 = month13.getClass();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24229L + "'", long14 == 24229L);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.setMaximumItemCount(1900);
        int int4 = timeSeries1.getItemCount();
        boolean boolean5 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("January");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate3);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries9.removeAgedItems((long) (-1), false);
//        java.lang.String str13 = timeSeries9.getDomainDescription();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year14, (org.jfree.data.time.RegularTimePeriod) year16);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries20.removeAgedItems((long) (-1), false);
//        java.lang.String str24 = timeSeries20.getDomainDescription();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) year27);
//        int int30 = year16.compareTo((java.lang.Object) year25);
//        long long31 = year16.getFirstMillisecond();
//        long long32 = year16.getFirstMillisecond();
//        int int33 = day7.compareTo((java.lang.Object) long32);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Time" + "'", str24.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        java.lang.Comparable comparable12 = timeSeries1.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.previous();
//        java.util.Date date17 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date17);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries24.removeAgedItems(false);
//        int int27 = timeSeries24.getItemCount();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 5);
//        long long31 = day28.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (double) '4');
//        long long34 = day28.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) day28);
//        java.util.Date date36 = day28.getEnd();
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560236399999L + "'", long31 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560150000000L + "'", long34 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertNotNull(date36);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        timeSeries10.setDescription("");
        timeSeries10.setMaximumItemAge((long) (byte) 100);
        int int15 = timeSeries10.getItemCount();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
//        boolean boolean16 = spreadsheetDate1.isOnOrBefore(serialDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean21 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate25 = day23.getSerialDate();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate28 = day26.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate30 = serialDate28.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate25.getEndOfCurrentMonth(serialDate28);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate31);
//        boolean boolean33 = spreadsheetDate18.isOn(serialDate31);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int38 = day37.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate42 = serialDate36.getEndOfCurrentMonth(serialDate39);
//        int int43 = spreadsheetDate18.compare(serialDate36);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate36.getPreviousDayOfWeek(6);
//        boolean boolean46 = spreadsheetDate1.isOnOrBefore(serialDate45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        boolean boolean49 = day47.equals((java.lang.Object) 5);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean54 = spreadsheetDate51.isOn((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        int int57 = day56.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate58 = day56.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate60 = serialDate58.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addMonths(13, serialDate60);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        int int64 = day63.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate65 = day63.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate67 = serialDate65.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate67);
//        org.jfree.data.time.SerialDate serialDate69 = serialDate61.getEndOfCurrentMonth(serialDate67);
//        boolean boolean70 = spreadsheetDate51.isOn(serialDate69);
//        int int71 = day47.compareTo((java.lang.Object) spreadsheetDate51);
//        int int72 = spreadsheetDate51.getYYYY();
//        boolean boolean73 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-43620) + "'", int43 == (-43620));
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 10 + "'", int64 == 10);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1900 + "'", int72 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("October");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        int int4 = timeSeries1.getItemCount();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        boolean boolean7 = day5.equals((java.lang.Object) 5);
//        long long8 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) '4');
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries12.removeAgedItems((long) (-1), false);
//        java.lang.String str16 = timeSeries12.getDomainDescription();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries23.removeAgedItems((long) (-1), false);
//        java.lang.String str27 = timeSeries23.getDomainDescription();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) year30);
//        int int33 = year19.compareTo((java.lang.Object) year28);
//        long long34 = year19.getLastMillisecond();
//        boolean boolean35 = day5.equals((java.lang.Object) year19);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries37.removeAgedItems((long) (-1), false);
//        java.lang.String str41 = timeSeries37.getDomainDescription();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year42.previous();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) year42, (org.jfree.data.time.RegularTimePeriod) year44);
//        long long47 = year44.getSerialIndex();
//        java.lang.String str48 = year44.toString();
//        boolean boolean49 = day5.equals((java.lang.Object) str48);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2019" + "'", str48.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.clear();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        long long4 = timeSeries1.getMaximumItemAge();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.util.List list2 = timeSeries1.getItems();
        int int3 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        java.lang.String str9 = timeSeries5.getDomainDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year12);
        long long15 = year12.getSerialIndex();
        long long16 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year12);
        java.lang.String str20 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1562097599999L + "'", long16 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        java.lang.Comparable comparable12 = timeSeries1.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.previous();
//        java.util.Date date17 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date17);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries24.removeAgedItems(false);
//        int int27 = timeSeries24.getItemCount();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 5);
//        long long31 = day28.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (double) '4');
//        long long34 = day28.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) day28);
//        java.util.Date date36 = day28.getEnd();
//        int int37 = day28.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day28.next();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560236399999L + "'", long31 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560150000000L + "'", long34 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Value");
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(0, serialDate3);
//        try {
//            org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek((-43620));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
//        boolean boolean7 = day5.equals((java.lang.Object) 1560236399999L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        int int9 = day5.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        boolean boolean5 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-3));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.next();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 100, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.previous();
//        long long13 = fixedMillisecond11.getMiddleMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond11.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1560192430017L);
//        java.lang.Number number19 = null;
//        timeSeries1.update(0, number19);
//        java.lang.Comparable comparable21 = timeSeries1.getKey();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560192473164L + "'", long13 == 1560192473164L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192473164L + "'", long15 == 1560192473164L);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (byte) 10 + "'", comparable21.equals((byte) 10));
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560192426750L);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1560192426750]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=1560192426750]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1560192426750]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=1560192426750]"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-43620), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        boolean boolean3 = day1.equals((java.lang.Object) 5);
//        int int4 = day1.getDayOfMonth();
//        java.lang.String str5 = day1.toString();
//        boolean boolean6 = month0.equals((java.lang.Object) str5);
//        int int7 = month0.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getLastMillisecond();
//        int int10 = month0.compareTo((java.lang.Object) fixedMillisecond8);
//        java.lang.String str11 = month0.toString();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560192473866L + "'", long9 == 1560192473866L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.previous();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, class12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries15.removeAgedItems((long) (-1), false);
        java.lang.String str19 = timeSeries15.getDomainDescription();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str29 = timePeriodFormatException28.toString();
        java.lang.Class<?> wildcardClass30 = timePeriodFormatException28.getClass();
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year22, (java.lang.Class) wildcardClass30);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries37.removeAgedItems((long) (-1), false);
        java.lang.String str41 = timeSeries37.getDomainDescription();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year42.previous();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.previous();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) year42, (org.jfree.data.time.RegularTimePeriod) year44);
        long long47 = year42.getSerialIndex();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month((int) (byte) 1, year42);
        long long49 = year42.getSerialIndex();
        int int50 = year42.getYear();
        java.util.Date date51 = year42.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = fixedMillisecond53.previous();
        java.util.Date date55 = fixedMillisecond53.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond56.previous();
        java.util.Date date58 = fixedMillisecond56.getTime();
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date58, timeZone59);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(date55, timeZone59);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date51, timeZone59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond(date51);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries65.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries69.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries65.addAndOrUpdate(timeSeries69);
        java.lang.Class class74 = timeSeries69.getTimePeriodClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str77 = spreadsheetDate76.toString();
        java.util.Date date78 = spreadsheetDate76.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = fixedMillisecond79.previous();
        java.util.Date date81 = fixedMillisecond79.getTime();
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date81, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance(class74, date78, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date51, timeZone82);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 2019L + "'", long49 == 2019L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNotNull(timeSeries73);
        org.junit.Assert.assertNotNull(class74);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "5-January-1900" + "'", str77.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.clear();
        timeSeries1.removeAgedItems(true);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(1900);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 100, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }
}

