import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) "2019");
//        java.lang.Object obj5 = null;
//        int int6 = fixedMillisecond0.compareTo(obj5);
//        long long7 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192476838L + "'", long2 == 1560192476838L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560192476838L + "'", long7 == 1560192476838L);
//    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        boolean boolean4 = day0.equals((java.lang.Object) 100L);
//        long long5 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries7.clear();
//        java.util.Collection collection9 = timeSeries7.getTimePeriods();
//        boolean boolean10 = day0.equals((java.lang.Object) timeSeries7);
//        timeSeries7.clear();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193199999L + "'", long5 == 1560193199999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(1900);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) year4);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year4.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1900L + "'", long5 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries12.removeAgedItems((long) (-1), false);
        java.lang.String str16 = timeSeries12.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
        int int22 = year8.compareTo((java.lang.Object) year17);
        long long23 = year8.getLastMillisecond();
        long long24 = year8.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) "2019");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 6);
//        java.lang.Object obj7 = timeSeriesDataItem6.clone();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192477171L + "'", long2 == 1560192477171L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(obj7);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560192438814L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192438814L + "'", long3 == 1560192438814L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560192438814L + "'", long4 == 1560192438814L);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1.0d);
//        int int7 = day2.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getLastMillisecond();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate16.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate19 = serialDate13.getEndOfCurrentMonth(serialDate16);
//        java.lang.String str20 = serialDate19.getDescription();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(6, serialDate19);
//        int int22 = fixedMillisecond8.compareTo((java.lang.Object) 6);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond8.getMiddleMillisecond(calendar23);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond8.getMiddleMillisecond(calendar25);
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond8.getMiddleMillisecond(calendar27);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond8.getMiddleMillisecond(calendar29);
//        int int31 = day2.compareTo((java.lang.Object) calendar29);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560192477214L + "'", long9 == 1560192477214L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560192477214L + "'", long24 == 1560192477214L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560192477214L + "'", long26 == 1560192477214L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560192477214L + "'", long28 == 1560192477214L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560192477214L + "'", long30 == 1560192477214L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getMiddleMillisecond(calendar6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192477261L + "'", long3 == 1560192477261L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560192477261L + "'", long5 == 1560192477261L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560192477261L + "'", long7 == 1560192477261L);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        java.util.Collection collection4 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries6.setMaximumItemCount(1900);
//        int int9 = timeSeries6.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.previous();
//        java.util.Date date13 = fixedMillisecond11.getTime();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date13);
//        long long16 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 24234L);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192477281L + "'", long16 == 1560192477281L);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        int int3 = month0.getMonth();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.clear();
        boolean boolean7 = month0.equals((java.lang.Object) timeSeries5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "February" + "'", str1.equals("February"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560192438814L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192438814L + "'", long3 == 1560192438814L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year6.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        boolean boolean15 = spreadsheetDate3.isBefore(serialDate13);
//        int int16 = spreadsheetDate3.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean19 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        int int22 = spreadsheetDate21.getDayOfWeek();
//        int int23 = spreadsheetDate21.getDayOfWeek();
//        try {
//            int int24 = spreadsheetDate3.compareTo((java.lang.Object) int23);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean5 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        java.lang.String str15 = serialDate14.getDescription();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate14);
//        boolean boolean17 = spreadsheetDate2.isOnOrBefore(serialDate14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean22 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        int int25 = day24.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate26 = day24.getSerialDate();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate32 = serialDate26.getEndOfCurrentMonth(serialDate29);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate32);
//        boolean boolean34 = spreadsheetDate19.isOn(serialDate32);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        int int37 = day36.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate38 = day36.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate40 = serialDate38.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate38);
//        boolean boolean43 = spreadsheetDate2.isInRange(serialDate32, serialDate41, 11);
//        try {
//            org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate5);
//        int int9 = spreadsheetDate1.compare(serialDate8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = null;
//        try {
//            boolean boolean14 = spreadsheetDate1.isInRange(serialDate12, serialDate13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-43626) + "'", int9 == (-43626));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.util.List list11 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list11);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
//        java.lang.String str3 = timeSeries2.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
//        boolean boolean7 = timeSeries2.equals((java.lang.Object) fixedMillisecond4);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560192478655L + "'", long6 == 1560192478655L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries8.removeAgedItems((long) (-1), false);
//        java.lang.String str12 = timeSeries8.getDomainDescription();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) year13, (org.jfree.data.time.RegularTimePeriod) year15);
//        int int18 = timeSeries8.getItemCount();
//        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.next();
//        int int24 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        try {
//            java.lang.Number number26 = timeSeries1.getValue(13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560192478669L + "'", long22 == 1560192478669L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean10 = timeSeries5.getNotify();
        timeSeries5.removeAgedItems((long) 13, false);
        try {
            timeSeries5.update((int) '4', (java.lang.Number) 1560192452817L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year8.next();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year8.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1.0d);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day2.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (double) 1560192445731L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.lang.String str2 = spreadsheetDate1.toString();
//        java.util.Date date3 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean8 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate18 = serialDate12.getEndOfCurrentMonth(serialDate15);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate18);
//        boolean boolean20 = spreadsheetDate5.isOn(serialDate18);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate23 = day21.getSerialDate();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        int int25 = day24.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate26 = day24.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate28 = serialDate26.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate29 = serialDate23.getEndOfCurrentMonth(serialDate26);
//        int int30 = spreadsheetDate5.compare(serialDate23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean35 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        int int37 = day36.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate38 = day36.getSerialDate();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        int int40 = day39.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate41 = day39.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate44 = serialDate38.getEndOfCurrentMonth(serialDate41);
//        java.lang.String str45 = serialDate44.getDescription();
//        boolean boolean46 = spreadsheetDate34.isBefore(serialDate44);
//        int int47 = spreadsheetDate34.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean50 = spreadsheetDate34.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        boolean boolean51 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        int int54 = day53.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate55 = day53.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate57 = serialDate55.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addMonths(13, serialDate57);
//        boolean boolean59 = spreadsheetDate34.isOnOrBefore(serialDate58);
//        boolean boolean60 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
//        int int62 = month61.getMonth();
//        int int63 = month61.getYearValue();
//        int int64 = month61.getMonth();
//        int int65 = month61.getMonth();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        int int67 = day66.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate68 = day66.getSerialDate();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        int int70 = day69.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate71 = day69.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate73 = serialDate71.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate74 = serialDate68.getEndOfCurrentMonth(serialDate71);
//        boolean boolean75 = month61.equals((java.lang.Object) serialDate68);
//        boolean boolean76 = spreadsheetDate34.isBefore(serialDate68);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5-January-1900" + "'", str2.equals("5-January-1900"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-43620) + "'", int30 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNull(str45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 10 + "'", int54 == 10);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2019 + "'", int63 == 2019);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 10 + "'", int67 == 10);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 10 + "'", int70 == 10);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        java.lang.Object obj10 = timeSeries1.clone();
        timeSeries1.setMaximumItemAge((long) (short) 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertNotNull(obj10);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
//        boolean boolean16 = spreadsheetDate1.isOnOrBefore(serialDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean21 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate25 = day23.getSerialDate();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate28 = day26.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate30 = serialDate28.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate25.getEndOfCurrentMonth(serialDate28);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate31);
//        boolean boolean33 = spreadsheetDate18.isOn(serialDate31);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate37 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = serialDate37.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate37);
//        boolean boolean42 = spreadsheetDate1.isInRange(serialDate31, serialDate40, 11);
//        try {
//            org.jfree.data.time.SerialDate serialDate44 = serialDate40.getFollowingDayOfWeek((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        long long11 = year8.getSerialIndex();
//        long long12 = year8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 5);
//        java.lang.Number number15 = timeSeriesDataItem14.getValue();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) 5);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean23 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        int int26 = day25.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate27 = day25.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(13, serialDate29);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate30.getEndOfCurrentMonth(serialDate36);
//        boolean boolean39 = spreadsheetDate20.isOn(serialDate38);
//        int int40 = day16.compareTo((java.lang.Object) spreadsheetDate20);
//        int int41 = day16.getMonth();
//        boolean boolean42 = timeSeriesDataItem14.equals((java.lang.Object) day16);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 5 + "'", number15.equals(5));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate6);
//        try {
//            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 6);
//        java.lang.Object obj20 = null;
//        int int21 = fixedMillisecond14.compareTo(obj20);
//        java.lang.Object obj22 = null;
//        int int23 = fixedMillisecond14.compareTo(obj22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond14.next();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192480173L + "'", long16 == 1560192480173L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year8.getSerialIndex();
        long long12 = year8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries16.fireSeriesChanged();
        boolean boolean18 = timeSeriesDataItem14.equals((java.lang.Object) timeSeries16);
        java.lang.Object obj19 = timeSeriesDataItem14.clone();
        java.lang.Object obj20 = timeSeriesDataItem14.clone();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) 'a', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4', 2147483647, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str2 = spreadsheetDate1.toString();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        boolean boolean6 = spreadsheetDate1.isOn(serialDate5);
        int int7 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5-January-1900" + "'", str2.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod12, (java.lang.Number) 6);
        int int17 = timeSeriesDataItem15.compareTo((java.lang.Object) 1560192429018L);
        timeSeriesDataItem15.setValue((java.lang.Number) 1.0d);
        java.lang.Number number20 = timeSeriesDataItem15.getValue();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.0d + "'", number20.equals(1.0d));
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 6);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond14.getLastMillisecond(calendar20);
//        long long22 = fixedMillisecond14.getFirstMillisecond();
//        long long23 = fixedMillisecond14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) (short) 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192481441L + "'", long16 == 1560192481441L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560192481441L + "'", long21 == 1560192481441L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560192481441L + "'", long22 == 1560192481441L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560192481441L + "'", long23 == 1560192481441L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.String str6 = serialDate5.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) ' ', serialDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate14);
//        boolean boolean16 = spreadsheetDate1.isOn(serialDate14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate19.getEndOfCurrentMonth(serialDate22);
//        int int26 = spreadsheetDate1.compare(serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean31 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate37 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = serialDate37.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate34.getEndOfCurrentMonth(serialDate37);
//        java.lang.String str41 = serialDate40.getDescription();
//        boolean boolean42 = spreadsheetDate30.isBefore(serialDate40);
//        int int43 = spreadsheetDate30.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean46 = spreadsheetDate30.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        boolean boolean47 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        int int48 = spreadsheetDate30.getYYYY();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-43620) + "'", int26 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1900 + "'", int48 == 1900);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean5 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate15 = serialDate9.getEndOfCurrentMonth(serialDate12);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate15);
//        boolean boolean17 = spreadsheetDate2.isOn(serialDate15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate23 = day21.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate20.getEndOfCurrentMonth(serialDate23);
//        int int27 = spreadsheetDate2.compare(serialDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean30 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addDays(7, (org.jfree.data.time.SerialDate) spreadsheetDate29);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-43620) + "'", int27 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(serialDate31);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = timeSeries1.getMaximumItemAge();
        timeSeries1.setNotify(false);
        try {
            org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        int int4 = month2.getYearValue();
        int int5 = month2.getMonth();
        int int6 = month2.getMonth();
        timeSeries1.setKey((java.lang.Comparable) month2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "2019", "hi!", "", class3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries4.removeChangeListener(seriesChangeListener5);
//        int int7 = timeSeries4.getMaximumItemCount();
//        boolean boolean8 = timeSeries4.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries10.removeAgedItems(false);
//        int int13 = timeSeries10.getItemCount();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        boolean boolean16 = day14.equals((java.lang.Object) 5);
//        long long17 = day14.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (double) '4');
//        boolean boolean20 = timeSeries4.equals((java.lang.Object) timeSeries10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.previous();
//        java.util.Date date23 = fixedMillisecond21.getTime();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date23);
//        try {
//            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year26, (double) '4');
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560236399999L + "'", long17 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(serialDate25);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        fixedMillisecond0.peg(calendar5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getMiddleMillisecond(calendar7);
//        long long9 = fixedMillisecond0.getFirstMillisecond();
//        long long10 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192481978L + "'", long2 == 1560192481978L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192481978L + "'", long3 == 1560192481978L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560192481978L + "'", long4 == 1560192481978L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560192481978L + "'", long8 == 1560192481978L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560192481978L + "'", long9 == 1560192481978L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560192481978L + "'", long10 == 1560192481978L);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (short) 10);
//        java.util.Date date3 = day0.getStart();
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (short) 0);
        try {
            org.jfree.data.time.Year year3 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        long long3 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.lang.String str3 = spreadsheetDate2.toString();
//        java.util.Date date4 = spreadsheetDate2.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean9 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate16.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate19 = serialDate13.getEndOfCurrentMonth(serialDate16);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate19);
//        boolean boolean21 = spreadsheetDate6.isOn(serialDate19);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate24 = day22.getSerialDate();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        int int26 = day25.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate27 = day25.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate30 = serialDate24.getEndOfCurrentMonth(serialDate27);
//        int int31 = spreadsheetDate6.compare(serialDate24);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean36 = spreadsheetDate33.isOn((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int38 = day37.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        int int41 = day40.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate44 = serialDate42.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate39.getEndOfCurrentMonth(serialDate42);
//        java.lang.String str46 = serialDate45.getDescription();
//        boolean boolean47 = spreadsheetDate35.isBefore(serialDate45);
//        int int48 = spreadsheetDate35.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean51 = spreadsheetDate35.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        boolean boolean52 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        int int55 = day54.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate56 = day54.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate58 = serialDate56.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths(13, serialDate58);
//        boolean boolean60 = spreadsheetDate35.isOnOrBefore(serialDate59);
//        boolean boolean61 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addDays((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate35);
//        int int63 = spreadsheetDate35.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5-January-1900" + "'", str3.equals("5-January-1900"));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-43620) + "'", int31 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNull(str46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 6 + "'", int63 == 6);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries12.removeAgedItems((long) (-1), false);
        java.lang.String str16 = timeSeries12.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
        int int22 = year8.compareTo((java.lang.Object) year17);
        java.lang.String str23 = year17.toString();
        boolean boolean25 = year17.equals((java.lang.Object) 2958465);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries27.removeAgedItems((long) (-1), false);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries27.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries34.removeAgedItems((long) (-1), false);
        java.lang.String str38 = timeSeries34.getDomainDescription();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year41.previous();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) year39, (org.jfree.data.time.RegularTimePeriod) year41);
        int int44 = timeSeries34.getItemCount();
        java.util.Collection collection45 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        boolean boolean46 = year17.equals((java.lang.Object) timeSeries27);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        int int4 = timeSeries1.getItemCount();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        boolean boolean7 = day5.equals((java.lang.Object) 5);
//        long long8 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) '4');
//        int int11 = day5.getYear();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) int11);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        timeSeries1.delete(regularTimePeriod7);
        timeSeries1.setDescription("September");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        int int3 = day0.getDayOfMonth();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
//        java.util.Date date7 = fixedMillisecond5.getTime();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(0, serialDate13);
//        java.lang.String str17 = serialDate16.getDescription();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate9.getEndOfCurrentMonth(serialDate16);
//        boolean boolean19 = day0.equals((java.lang.Object) serialDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.lang.String str22 = spreadsheetDate21.toString();
//        java.util.Date date23 = spreadsheetDate21.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean28 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate35 = day33.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate37 = serialDate35.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate32.getEndOfCurrentMonth(serialDate35);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate38);
//        boolean boolean40 = spreadsheetDate25.isOn(serialDate38);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        int int42 = day41.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = day41.getSerialDate();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        int int45 = day44.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate46 = day44.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate49 = serialDate43.getEndOfCurrentMonth(serialDate46);
//        int int50 = spreadsheetDate25.compare(serialDate43);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean55 = spreadsheetDate52.isOn((org.jfree.data.time.SerialDate) spreadsheetDate54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        int int57 = day56.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate58 = day56.getSerialDate();
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        int int60 = day59.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate61 = day59.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate63 = serialDate61.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate64 = serialDate58.getEndOfCurrentMonth(serialDate61);
//        java.lang.String str65 = serialDate64.getDescription();
//        boolean boolean66 = spreadsheetDate54.isBefore(serialDate64);
//        int int67 = spreadsheetDate54.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean70 = spreadsheetDate54.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        boolean boolean71 = spreadsheetDate25.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate54);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        int int74 = day73.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate75 = day73.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate77 = serialDate75.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addMonths(13, serialDate77);
//        boolean boolean79 = spreadsheetDate54.isOnOrBefore(serialDate78);
//        boolean boolean80 = spreadsheetDate21.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate54);
//        org.jfree.data.time.SerialDate serialDate81 = serialDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "5-January-1900" + "'", str22.equals("5-January-1900"));
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-43620) + "'", int50 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNull(str65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 10 + "'", int74 == 10);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(serialDate81);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 2958465);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries16.removeAgedItems((long) (-1), false);
        int int20 = timeSeriesDataItem14.compareTo((java.lang.Object) timeSeries16);
        java.util.Collection collection21 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        timeSeries16.setMaximumItemCount(4);
        long long24 = timeSeries16.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries16.createCopy(0, 1900);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener28);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries27);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (short) 0);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries4.removeAgedItems((long) (-1), false);
        java.lang.String str8 = timeSeries4.getDomainDescription();
        timeSeries4.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable12 = timeSeries4.getKey();
        java.lang.Object obj13 = timeSeries4.clone();
        java.lang.Comparable comparable14 = timeSeries4.getKey();
        boolean boolean15 = month2.equals((java.lang.Object) timeSeries4);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries4.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 10 + "'", comparable14.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        boolean boolean10 = timeSeries9.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean15 = day13.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 1.0d);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
//        long long19 = day13.getSerialIndex();
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43626L + "'", long19 == 43626L);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
//        java.lang.String str2 = timePeriodFormatException1.toString();
//        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean10 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate16.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate19 = serialDate13.getEndOfCurrentMonth(serialDate16);
//        java.lang.String str20 = serialDate19.getDescription();
//        boolean boolean21 = spreadsheetDate9.isBefore(serialDate19);
//        int int22 = spreadsheetDate9.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean25 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean30 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate33 = day31.getSerialDate();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate38 = serialDate36.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate39 = serialDate33.getEndOfCurrentMonth(serialDate36);
//        java.lang.String str40 = serialDate39.getDescription();
//        boolean boolean41 = spreadsheetDate29.isBefore(serialDate39);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate45 = day43.getSerialDate();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int47 = day46.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate48 = day46.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate50 = serialDate48.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate51 = serialDate45.getEndOfCurrentMonth(serialDate48);
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate51);
//        org.jfree.data.time.SerialDate serialDate54 = serialDate51.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate55 = spreadsheetDate29.getEndOfCurrentMonth(serialDate51);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        int int59 = day58.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate60 = day58.getSerialDate();
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        int int62 = day61.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate63 = day61.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate65 = serialDate63.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate66 = serialDate60.getEndOfCurrentMonth(serialDate63);
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate66);
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addDays(31, serialDate67);
//        boolean boolean69 = spreadsheetDate9.isInRange(serialDate51, serialDate68);
//        java.util.Date date70 = spreadsheetDate9.toDate();
//        java.util.TimeZone timeZone71 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date70, timeZone71);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 10 + "'", int59 == 10);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Object obj7 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (9) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate3.getEndOfCurrentMonth(serialDate6);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate9);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "", "Time", class13);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries14.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries12.removeAgedItems((long) (-1), false);
        java.lang.String str16 = timeSeries12.getDomainDescription();
        timeSeries12.removeAgedItems((long) (short) -1, true);
        int int20 = year6.compareTo((java.lang.Object) true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year6.next();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean15 = day13.equals((java.lang.Object) 5);
//        int int16 = day13.getDayOfMonth();
//        java.lang.String str17 = day13.toString();
//        long long18 = day13.getLastMillisecond();
//        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries23.removeAgedItems((long) (-1), false);
//        java.lang.String str27 = timeSeries23.getDomainDescription();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) year30);
//        long long33 = year28.getSerialIndex();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (byte) 1, year28);
//        long long35 = month34.getSerialIndex();
//        java.lang.Number number36 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) month34);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries38.removeAgedItems(false);
//        timeSeries38.clear();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent42 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries38);
//        timeSeries38.setDescription("2019");
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries10.addAndOrUpdate(timeSeries38);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries47.removeAgedItems((long) (-1), false);
//        java.lang.String str51 = timeSeries47.getDomainDescription();
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year52.previous();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year54.previous();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) year52, (org.jfree.data.time.RegularTimePeriod) year54);
//        try {
//            timeSeries45.add((org.jfree.data.time.RegularTimePeriod) year54, (double) (-452), false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 24229L + "'", long35 == 24229L);
//        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 10.0f + "'", number36.equals(10.0f));
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeSeries56);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, (int) (byte) 100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str2 = spreadsheetDate1.toString();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries7.removeAgedItems((long) (-1), false);
        java.lang.String str11 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        long long17 = year12.getSerialIndex();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, year12);
        long long19 = year12.getSerialIndex();
        int int20 = year12.getYear();
        java.util.Date date21 = year12.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond23.previous();
        java.util.Date date25 = fixedMillisecond23.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond26.previous();
        java.util.Date date28 = fixedMillisecond26.getTime();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28, timeZone29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date25, timeZone29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date21, timeZone29);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date4, timeZone29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5-January-1900" + "'", str2.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        boolean boolean7 = fixedMillisecond0.equals((java.lang.Object) 1560192445763L);
//        java.util.Date date8 = fixedMillisecond0.getTime();
//        java.util.Date date9 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192486963L + "'", long3 == 1560192486963L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560192486963L + "'", long5 == 1560192486963L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean5 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        java.lang.String str15 = serialDate14.getDescription();
//        boolean boolean16 = spreadsheetDate4.isBefore(serialDate14);
//        int int17 = spreadsheetDate4.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean20 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean25 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate28 = day26.getSerialDate();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day29.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate34 = serialDate28.getEndOfCurrentMonth(serialDate31);
//        java.lang.String str35 = serialDate34.getDescription();
//        boolean boolean36 = spreadsheetDate24.isBefore(serialDate34);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        int int39 = day38.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate40 = day38.getSerialDate();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        int int42 = day41.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = day41.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate45 = serialDate43.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate46 = serialDate40.getEndOfCurrentMonth(serialDate43);
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate46);
//        org.jfree.data.time.SerialDate serialDate49 = serialDate46.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate50 = spreadsheetDate24.getEndOfCurrentMonth(serialDate46);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        int int54 = day53.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate55 = day53.getSerialDate();
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        int int57 = day56.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate58 = day56.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate60 = serialDate58.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate61 = serialDate55.getEndOfCurrentMonth(serialDate58);
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate61);
//        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addDays(31, serialDate62);
//        boolean boolean64 = spreadsheetDate4.isInRange(serialDate46, serialDate63);
//        java.util.Date date65 = spreadsheetDate4.toDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(13, (org.jfree.data.time.SerialDate) spreadsheetDate4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNull(str35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 10 + "'", int54 == 10);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(date65);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries4.removeAgedItems((long) (-1), false);
        java.lang.String str8 = timeSeries4.getDomainDescription();
        timeSeries4.removeAgedItems((long) (short) -1, true);
        java.util.Collection collection12 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        timeSeries2.setRangeDescription("hi!");
        timeSeries2.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = timeSeries1.getMaximumItemAge();
        java.lang.String str12 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (java.lang.Number) (short) 10);
        timeSeries1.add(timeSeriesDataItem16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries1.getNextTimePeriod();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-3));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean10 = timeSeries5.getNotify();
        timeSeries5.removeAgedItems((long) 13, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.util.Date date16 = fixedMillisecond14.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
        java.util.Date date19 = fixedMillisecond17.getTime();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date16, timeZone20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day23, (double) (-60507964800000L), false);
        timeSeries5.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
        java.util.Date date31 = fixedMillisecond29.getTime();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date31);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day34, (double) (byte) 0);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        boolean boolean3 = day1.equals((java.lang.Object) 5);
//        int int4 = day1.getDayOfMonth();
//        java.lang.String str5 = day1.toString();
//        boolean boolean6 = month0.equals((java.lang.Object) str5);
//        int int7 = month0.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getLastMillisecond();
//        int int10 = month0.compareTo((java.lang.Object) fixedMillisecond8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560192488381L + "'", long9 == 1560192488381L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        java.lang.Comparable comparable12 = timeSeries1.getKey();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate18.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate15.getEndOfCurrentMonth(serialDate18);
//        java.lang.String str22 = serialDate21.getDescription();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(1900);
//        java.lang.String str26 = year25.toString();
//        long long27 = year25.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year25);
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener29);
//        timeSeries1.setDescription("1900");
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1900" + "'", str26.equals("1900"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2208960000000L) + "'", long27 == (-2208960000000L));
//        org.junit.Assert.assertNotNull(timeSeries28);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560192448827L);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2019, 1964, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 6);
//        java.lang.Object obj20 = null;
//        int int21 = fixedMillisecond14.compareTo(obj20);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries23.removeAgedItems(false);
//        timeSeries23.clear();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries23);
//        boolean boolean28 = fixedMillisecond14.equals((java.lang.Object) seriesChangeEvent27);
//        java.lang.Object obj29 = seriesChangeEvent27.getSource();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192489274L + "'", long16 == 1560192489274L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(obj29);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        timeSeries5.setMaximumItemAge((long) (byte) 100);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) 100L);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        java.lang.String str5 = year1.toString();
        long long6 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Last");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-43623), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        java.lang.Object obj10 = timeSeries1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.lang.String str12 = seriesChangeEvent11.toString();
        java.lang.String str13 = seriesChangeEvent11.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        int int10 = timeSeries9.getMaximumItemCount();
        java.lang.String str11 = timeSeries9.getRangeDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) 100L);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(8, year13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month16);
        long long18 = timeSeries9.getMaximumItemAge();
        long long19 = timeSeries9.getMaximumItemAge();
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560192434835L);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        boolean boolean3 = day1.equals((java.lang.Object) 5);
//        int int4 = day1.getDayOfMonth();
//        java.lang.String str5 = day1.toString();
//        boolean boolean6 = month0.equals((java.lang.Object) str5);
//        int int7 = month0.getMonth();
//        java.lang.String str8 = month0.toString();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = month0.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        timeSeries1.removeAgedItems((long) (short) 10, false);
        timeSeries1.setDomainDescription("Time");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.addChangeListener(seriesChangeListener10);
        java.util.List list12 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(list12);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems(false);
//        java.util.Collection collection8 = timeSeries5.getTimePeriods();
//        int int9 = day0.compareTo((java.lang.Object) timeSeries5);
//        java.lang.String str10 = timeSeries5.getRangeDescription();
//        int int11 = timeSeries5.getItemCount();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        int int5 = month3.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        int int11 = timeSeries1.getMaximumItemCount();
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        java.lang.String str16 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        java.lang.Object obj10 = timeSeries1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy(1964, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries8.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries12.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries12);
        boolean boolean17 = timeSeries16.getNotify();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        boolean boolean22 = day20.equals((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) day20);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = null;
        try {
            timeSeries26.delete(regularTimePeriod27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(2019, serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year8.getSerialIndex();
        long long12 = year8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries16.fireSeriesChanged();
        boolean boolean18 = timeSeriesDataItem14.equals((java.lang.Object) timeSeries16);
        java.lang.Object obj19 = timeSeriesDataItem14.clone();
        timeSeriesDataItem14.setValue((java.lang.Number) 1560192462382L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem14.getPeriod();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener14);
        try {
            timeSeries10.delete((int) (byte) 1, (-43623));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year8.getSerialIndex();
        long long12 = year8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries16.fireSeriesChanged();
        boolean boolean18 = timeSeriesDataItem14.equals((java.lang.Object) timeSeries16);
        try {
            java.lang.Number number20 = timeSeries16.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        long long2 = year1.getSerialIndex();
        long long3 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1900L + "'", long2 == 1900L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208960000000L) + "'", long3 == (-2208960000000L));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 9);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192490616L + "'", long2 == 1560192490616L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560192490616L + "'", long4 == 1560192490616L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560192490616L + "'", long6 == 1560192490616L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June" + "'", str1.equals("June"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries6.setMaximumItemCount(1900);
        int int9 = timeSeries6.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(1900);
        java.lang.String str14 = year13.toString();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 10, year13);
        long long16 = month15.getFirstMillisecond();
        int int17 = month15.getYearValue();
        boolean boolean18 = timeSeries10.equals((java.lang.Object) month15);
        java.lang.String str19 = month15.toString();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1900" + "'", str14.equals("1900"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2185372800000L) + "'", long16 == (-2185372800000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "October 1900" + "'", str19.equals("October 1900"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean4 = day2.equals((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1.0d);
        int int7 = day2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day2.next();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries12.removeAgedItems((long) (-1), false);
        java.lang.String str16 = timeSeries12.getDomainDescription();
        timeSeries12.removeAgedItems((long) (short) -1, true);
        int int20 = year6.compareTo((java.lang.Object) true);
        long long21 = year6.getLastMillisecond();
        java.lang.String str22 = year6.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        int int11 = timeSeries1.getMaximumItemCount();
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
        java.util.Date date18 = fixedMillisecond16.getTime();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18, timeZone19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.previous();
        java.util.Date date23 = fixedMillisecond21.getTime();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23, timeZone24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date18, timeZone24);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 1560192469181L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        timeSeries1.delete(regularTimePeriod7);
        timeSeries1.setRangeDescription("Last");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean7 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(13, serialDate13);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate18.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate20);
//        org.jfree.data.time.SerialDate serialDate22 = serialDate14.getEndOfCurrentMonth(serialDate20);
//        boolean boolean23 = spreadsheetDate4.isOn(serialDate22);
//        int int24 = day0.compareTo((java.lang.Object) spreadsheetDate4);
//        int int25 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day0.previous();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("1900");
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        boolean boolean4 = day0.equals((java.lang.Object) 100L);
//        long long5 = day0.getMiddleMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "10-June-2019", class8);
//        java.util.List list10 = timeSeries9.getItems();
//        java.lang.Class class11 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1560193199999L);
//        long long16 = timeSeries9.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193199999L + "'", long5 == 1560193199999L);
//        org.junit.Assert.assertNotNull(list10);
//        org.junit.Assert.assertNull(class11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = timeSeries1.getMaximumItemAge();
        java.lang.String str12 = timeSeries1.getRangeDescription();
        java.util.List list13 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertNotNull(list13);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        timeSeries1.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        long long6 = fixedMillisecond5.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate16 = serialDate10.getEndOfCurrentMonth(serialDate13);
//        java.lang.String str17 = serialDate16.getDescription();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears(6, serialDate16);
//        int int19 = fixedMillisecond5.compareTo((java.lang.Object) 6);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond5.getMiddleMillisecond(calendar20);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond5.getMiddleMillisecond(calendar22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond5.getMiddleMillisecond(calendar24);
//        java.lang.Number number26 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560192491780L + "'", long6 == 1560192491780L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560192491780L + "'", long21 == 1560192491780L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560192491780L + "'", long23 == 1560192491780L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560192491780L + "'", long25 == 1560192491780L);
//        org.junit.Assert.assertNull(number26);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(0, serialDate8);
//        java.lang.String str12 = serialDate11.getDescription();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate4.getEndOfCurrentMonth(serialDate11);
//        serialDate13.setDescription("October");
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(serialDate13);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.previous();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, class12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries15.removeAgedItems((long) (-1), false);
        java.lang.String str19 = timeSeries15.getDomainDescription();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year22.next();
        long long28 = year22.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        timeSeries1.delete(regularTimePeriod7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        boolean boolean4 = day0.equals((java.lang.Object) 100L);
//        long long5 = day0.getMiddleMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "10-June-2019", class8);
//        java.lang.String str10 = timeSeries9.getRangeDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.lang.String str13 = spreadsheetDate12.toString();
//        java.util.Date date14 = spreadsheetDate12.toDate();
//        java.util.Date date15 = spreadsheetDate12.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        long long18 = fixedMillisecond16.getSerialIndex();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getLastMillisecond(calendar19);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193199999L + "'", long5 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "5-January-1900" + "'", str13.equals("5-January-1900"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2208614399740L) + "'", long18 == (-2208614399740L));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208614399740L) + "'", long20 == (-2208614399740L));
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-43626));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1.0d);
//        long long7 = day2.getLastMillisecond();
//        int int8 = day2.getYear();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day2.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries11.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries15.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries11.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries11);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries22.removeAgedItems((long) (-1), false);
//        java.lang.String str26 = timeSeries22.getDomainDescription();
//        timeSeries22.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable30 = timeSeries22.getKey();
//        java.lang.Object obj31 = timeSeries22.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries22);
//        java.lang.Comparable comparable33 = timeSeries22.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries22.removePropertyChangeListener(propertyChangeListener34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond36.previous();
//        java.util.Date date38 = fixedMillisecond36.getTime();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date38);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries45.removeAgedItems(false);
//        int int48 = timeSeries45.getItemCount();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        boolean boolean51 = day49.equals((java.lang.Object) 5);
//        long long52 = day49.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day49, (double) '4');
//        long long55 = day49.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) day43, (org.jfree.data.time.RegularTimePeriod) day49);
//        int int57 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries59.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries63.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries59.addAndOrUpdate(timeSeries63);
//        int int68 = timeSeries67.getMaximumItemCount();
//        java.lang.String str69 = timeSeries67.getRangeDescription();
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
//        boolean boolean73 = year71.equals((java.lang.Object) 100L);
//        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month(8, year71);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries67.getDataItem((org.jfree.data.time.RegularTimePeriod) month74);
//        int int76 = month74.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month74, (java.lang.Number) (byte) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month74, (double) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = month74.next();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable30 + "' != '" + (byte) 10 + "'", comparable30.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj31);
//        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (byte) 10 + "'", comparable33.equals((byte) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560236399999L + "'", long52 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560150000000L + "'", long55 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2147483647 + "'", int68 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Value" + "'", str69.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 8 + "'", int76 == 8);
//        org.junit.Assert.assertNull(timeSeriesDataItem80);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 0);
        long long3 = month2.getFirstMillisecond();
        long long4 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62159500800000L) + "'", long3 == (-62159500800000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62159500800000L) + "'", long4 == (-62159500800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str13 = spreadsheetDate12.toString();
        java.util.Date date14 = spreadsheetDate12.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.previous();
        java.util.Date date17 = fixedMillisecond15.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date14, timeZone18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date14);
        int int22 = year21.getYear();
        long long23 = year21.getLastMillisecond();
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "5-January-1900" + "'", str13.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2177424000001L) + "'", long23 == (-2177424000001L));
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        int int4 = timeSeries1.getItemCount();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        boolean boolean7 = day5.equals((java.lang.Object) 5);
//        long long8 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) '4');
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries12.clear();
//        java.lang.Class class14 = timeSeries12.getTimePeriodClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean21 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate24 = day22.getSerialDate();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        int int26 = day25.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate27 = day25.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate30 = serialDate24.getEndOfCurrentMonth(serialDate27);
//        java.lang.String str31 = serialDate30.getDescription();
//        boolean boolean32 = spreadsheetDate20.isBefore(serialDate30);
//        int int33 = spreadsheetDate20.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean36 = spreadsheetDate20.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean41 = spreadsheetDate38.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        int int43 = day42.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate44 = day42.getSerialDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        int int46 = day45.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate47 = day45.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate49 = serialDate47.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate50 = serialDate44.getEndOfCurrentMonth(serialDate47);
//        java.lang.String str51 = serialDate50.getDescription();
//        boolean boolean52 = spreadsheetDate40.isBefore(serialDate50);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        int int55 = day54.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate56 = day54.getSerialDate();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        int int58 = day57.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate59 = day57.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate61 = serialDate59.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate62 = serialDate56.getEndOfCurrentMonth(serialDate59);
//        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate62);
//        org.jfree.data.time.SerialDate serialDate65 = serialDate62.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate66 = spreadsheetDate40.getEndOfCurrentMonth(serialDate62);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        int int70 = day69.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate71 = day69.getSerialDate();
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        int int73 = day72.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate74 = day72.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate76 = serialDate74.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate77 = serialDate71.getEndOfCurrentMonth(serialDate74);
//        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate77);
//        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.addDays(31, serialDate78);
//        boolean boolean80 = spreadsheetDate20.isInRange(serialDate62, serialDate79);
//        timeSeries16.setKey((java.lang.Comparable) serialDate79);
//        try {
//            timeSeries16.delete((-43616), (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -43616");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNull(str51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 10 + "'", int58 == 10);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 10 + "'", int70 == 10);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 10 + "'", int73 == 10);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.setDescription("hi!");
        long long4 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long14 = year7.getSerialIndex();
        int int15 = year7.getYear();
        java.util.Date date16 = year7.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.previous();
        java.util.Date date20 = fixedMillisecond18.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.previous();
        java.util.Date date23 = fixedMillisecond21.getTime();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23, timeZone24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date20, timeZone24);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date16, timeZone24);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean10 = timeSeries5.getNotify();
        timeSeries5.removeAgedItems((long) 13, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.util.Date date16 = fixedMillisecond14.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
        java.util.Date date19 = fixedMillisecond17.getTime();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date16, timeZone20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day23, (double) (-60507964800000L), false);
        timeSeries5.update((int) (short) 0, (java.lang.Number) 1);
        try {
            timeSeries5.update((-43616), (java.lang.Number) 1560192491780L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean5 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        java.lang.String str15 = serialDate14.getDescription();
//        boolean boolean16 = spreadsheetDate4.isBefore(serialDate14);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths((-3), serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(serialDate17);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        int int10 = timeSeries9.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
//        int int15 = fixedMillisecond11.compareTo((java.lang.Object) "2019");
//        java.lang.Object obj16 = null;
//        int int17 = fixedMillisecond11.compareTo(obj16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries9.addChangeListener(seriesChangeListener19);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560192493456L + "'", long13 == 1560192493456L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate5.getEndOfCurrentMonth(serialDate8);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate22 = serialDate16.getEndOfCurrentMonth(serialDate19);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate22);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate22.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate12.getEndOfCurrentMonth(serialDate25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate25);
//        boolean boolean28 = spreadsheetDate1.isOnOrBefore(serialDate25);
//        try {
//            org.jfree.data.time.SerialDate serialDate30 = serialDate25.getPreviousDayOfWeek(2958465);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1.0d);
//        long long7 = day2.getLastMillisecond();
//        int int8 = day2.getYear();
//        long long9 = day2.getLastMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day2.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        boolean boolean2 = year0.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 2958465);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries6.removeAgedItems((long) (-1), false);
//        int int10 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries6);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate14 = day12.getSerialDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate19 = serialDate17.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate20 = serialDate14.getEndOfCurrentMonth(serialDate17);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate20);
//        serialDate21.setDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
//        int int24 = timeSeriesDataItem4.compareTo((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: 2019");
//        java.lang.Number number25 = null;
//        timeSeriesDataItem4.setValue(number25);
//        timeSeriesDataItem4.setValue((java.lang.Number) 1560192432446L);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        boolean boolean3 = day1.equals((java.lang.Object) 5);
//        int int4 = day1.getDayOfMonth();
//        java.lang.String str5 = day1.toString();
//        boolean boolean6 = month0.equals((java.lang.Object) str5);
//        long long7 = month0.getLastMillisecond();
//        int int8 = month0.getMonth();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        int int4 = timeSeries1.getItemCount();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        boolean boolean7 = day5.equals((java.lang.Object) 5);
//        long long8 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) '4');
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries12.removeAgedItems((long) (-1), false);
//        java.lang.String str16 = timeSeries12.getDomainDescription();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries23.removeAgedItems((long) (-1), false);
//        java.lang.String str27 = timeSeries23.getDomainDescription();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) year30);
//        int int33 = year19.compareTo((java.lang.Object) year28);
//        long long34 = year19.getLastMillisecond();
//        boolean boolean35 = day5.equals((java.lang.Object) year19);
//        java.util.Date date36 = day5.getStart();
//        long long37 = day5.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean42 = spreadsheetDate39.isOn((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        int int45 = day44.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate46 = day44.getSerialDate();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        int int48 = day47.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate49 = day47.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate51 = serialDate49.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate52 = serialDate46.getEndOfCurrentMonth(serialDate49);
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate52);
//        boolean boolean54 = spreadsheetDate39.isOn(serialDate52);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        int int56 = day55.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate57 = day55.getSerialDate();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        int int59 = day58.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate60 = day58.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate62 = serialDate60.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate63 = serialDate57.getEndOfCurrentMonth(serialDate60);
//        int int64 = spreadsheetDate39.compare(serialDate57);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean67 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate66);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        int int72 = day71.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate73 = day71.getSerialDate();
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        int int75 = day74.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate76 = day74.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate78 = serialDate76.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate79 = serialDate73.getEndOfCurrentMonth(serialDate76);
//        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate79);
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day();
//        int int83 = day82.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate84 = day82.getSerialDate();
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day();
//        int int86 = day85.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate87 = day85.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate89 = serialDate87.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate90 = serialDate84.getEndOfCurrentMonth(serialDate87);
//        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate90);
//        org.jfree.data.time.SerialDate serialDate93 = serialDate90.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate94 = serialDate80.getEndOfCurrentMonth(serialDate93);
//        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(serialDate93);
//        boolean boolean96 = spreadsheetDate69.isOnOrBefore(serialDate93);
//        boolean boolean97 = spreadsheetDate39.isAfter(serialDate93);
//        int int98 = day5.compareTo((java.lang.Object) boolean97);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560150000000L + "'", long37 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 10 + "'", int48 == 10);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 10 + "'", int56 == 10);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 10 + "'", int59 == 10);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-43620) + "'", int64 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 10 + "'", int72 == 10);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 10 + "'", int75 == 10);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 10 + "'", int83 == 10);
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 10 + "'", int86 == 10);
//        org.junit.Assert.assertNotNull(serialDate87);
//        org.junit.Assert.assertNotNull(serialDate89);
//        org.junit.Assert.assertNotNull(serialDate90);
//        org.junit.Assert.assertNotNull(serialDate91);
//        org.junit.Assert.assertNotNull(serialDate93);
//        org.junit.Assert.assertNotNull(serialDate94);
//        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
//        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
//        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 1 + "'", int98 == 1);
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate5.getEndOfCurrentMonth(serialDate8);
//        java.lang.String str12 = serialDate11.getDescription();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(6, serialDate11);
//        int int14 = fixedMillisecond0.compareTo((java.lang.Object) 6);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond0.getMiddleMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560192494443L + "'", long1 == 1560192494443L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192494443L + "'", long16 == 1560192494443L);
//        org.junit.Assert.assertNotNull(date17);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean15 = day13.equals((java.lang.Object) 5);
//        int int16 = day13.getDayOfMonth();
//        java.lang.String str17 = day13.toString();
//        long long18 = day13.getLastMillisecond();
//        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries23.removeAgedItems((long) (-1), false);
//        java.lang.String str27 = timeSeries23.getDomainDescription();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) year30);
//        long long33 = year28.getSerialIndex();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (byte) 1, year28);
//        long long35 = month34.getSerialIndex();
//        java.lang.Number number36 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) month34);
//        long long37 = month34.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 24229L + "'", long35 == 24229L);
//        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 10.0f + "'", number36.equals(10.0f));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 24229L + "'", long37 == 24229L);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(0, serialDate3);
//        java.lang.String str7 = serialDate6.getDescription();
//        java.lang.String str8 = serialDate6.getDescription();
//        java.lang.Class<?> wildcardClass9 = serialDate6.getClass();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(13, serialDate10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate17);
//        org.jfree.data.time.SerialDate serialDate19 = serialDate11.getEndOfCurrentMonth(serialDate17);
//        boolean boolean20 = spreadsheetDate1.isOn(serialDate19);
//        spreadsheetDate1.setDescription("June 2019");
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        timeSeries10.setDescription("");
        int int13 = timeSeries10.getItemCount();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond0.peg(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getLastMillisecond(calendar4);
//        long long6 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560192494764L + "'", long5 == 1560192494764L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560192494764L + "'", long6 == 1560192494764L);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        int int5 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        int int7 = day0.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries11.clear();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int7, "Value", "ERROR : Relative To String", class13);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(class13);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.previous();
//        long long13 = fixedMillisecond11.getMiddleMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond11.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1560192430017L);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (short) 0);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries22.removeAgedItems((long) (-1), false);
//        java.lang.String str26 = timeSeries22.getDomainDescription();
//        timeSeries22.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable30 = timeSeries22.getKey();
//        java.lang.Object obj31 = timeSeries22.clone();
//        java.lang.Comparable comparable32 = timeSeries22.getKey();
//        boolean boolean33 = month20.equals((java.lang.Object) timeSeries22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond34.previous();
//        java.util.Date date36 = fixedMillisecond34.getTime();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36, timeZone37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(date36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond39.next();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        boolean boolean43 = year41.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year41, (java.lang.Number) 2958465);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeriesDataItem45.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, regularTimePeriod46);
//        try {
//            timeSeries1.add(regularTimePeriod46, (double) (-1), false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560192494818L + "'", long13 == 1560192494818L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192494818L + "'", long15 == 1560192494818L);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable30 + "' != '" + (byte) 10 + "'", comparable30.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj31);
//        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + (byte) 10 + "'", comparable32.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(timeSeries47);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(1900);
        java.lang.String str3 = year2.toString();
        long long4 = year2.getFirstMillisecond();
        java.lang.Class<?> wildcardClass5 = year2.getClass();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1, year2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1900" + "'", str3.equals("1900"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2208960000000L) + "'", long4 == (-2208960000000L));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate14);
//        boolean boolean16 = spreadsheetDate1.isOn(serialDate14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate19.getEndOfCurrentMonth(serialDate22);
//        int int26 = spreadsheetDate1.compare(serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean29 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        int int30 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean35 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int38 = day37.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        int int41 = day40.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate44 = serialDate42.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate39.getEndOfCurrentMonth(serialDate42);
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate45);
//        boolean boolean47 = spreadsheetDate32.isOn(serialDate45);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate50 = day48.getSerialDate();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        int int52 = day51.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate53 = day51.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate55 = serialDate53.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate56 = serialDate50.getEndOfCurrentMonth(serialDate53);
//        int int57 = spreadsheetDate32.compare(serialDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean60 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
//        boolean boolean61 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
//        int int62 = spreadsheetDate59.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-43620) + "'", int26 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-43620) + "'", int57 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        int int3 = day0.getDayOfMonth();
//        java.lang.String str4 = day0.toString();
//        long long5 = day0.getLastMillisecond();
//        java.lang.String str6 = day0.toString();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = timeSeries1.getMaximumItemAge();
        int int12 = timeSeries1.getMaximumItemCount();
        timeSeries1.fireSeriesChanged();
        try {
            java.lang.Number number15 = timeSeries1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(13, serialDate7);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate14);
//        int int17 = spreadsheetDate1.compare(serialDate14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate23 = day21.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate23);
//        int int27 = spreadsheetDate19.compare(serialDate26);
//        boolean boolean28 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.SerialDate serialDate29 = null;
//        try {
//            boolean boolean30 = spreadsheetDate19.isOn(serialDate29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-43616) + "'", int17 == (-43616));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-43626) + "'", int27 == (-43626));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries12.removeAgedItems((long) (-1), false);
        java.lang.String str16 = timeSeries12.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
        int int22 = year8.compareTo((java.lang.Object) year17);
        java.lang.String str23 = year17.toString();
        boolean boolean25 = year17.equals((java.lang.Object) 2958465);
        java.util.Calendar calendar26 = null;
        try {
            year17.peg(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-460));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate2.getEndOfCurrentMonth(serialDate5);
//        java.lang.String str9 = serialDate8.getDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate8);
//        java.lang.Object obj11 = null;
//        int int12 = day10.compareTo(obj11);
//        java.util.Calendar calendar13 = null;
//        try {
//            day10.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        timeSeries1.setNotify(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.previous();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond12.getFirstMillisecond(calendar14);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond12.getMiddleMillisecond(calendar16);
//        boolean boolean19 = fixedMillisecond12.equals((java.lang.Object) 1560192445763L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1560192455537L);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond12.getFirstMillisecond(calendar22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond12.getLastMillisecond(calendar24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate28 = day26.getSerialDate();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
//        boolean boolean30 = fixedMillisecond12.equals((java.lang.Object) day29);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192495438L + "'", long15 == 1560192495438L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560192495438L + "'", long17 == 1560192495438L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560192495438L + "'", long23 == 1560192495438L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560192495438L + "'", long25 == 1560192495438L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.setMaximumItemCount(1900);
        int int4 = timeSeries1.getItemCount();
        boolean boolean5 = timeSeries1.isEmpty();
        try {
            java.lang.Number number7 = timeSeries1.getValue(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        int int2 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.previous();
        java.lang.String str12 = year8.toString();
        int int13 = year8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.previous();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        timeSeries1.clear();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        boolean boolean13 = day11.equals((java.lang.Object) 5);
//        boolean boolean15 = day11.equals((java.lang.Object) 100L);
//        long long16 = day11.getMiddleMillisecond();
//        long long17 = day11.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (double) (-62159500800000L));
//        timeSeries1.removeAgedItems((long) 2147483647, true);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560193199999L + "'", long16 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(13, serialDate10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate17);
//        org.jfree.data.time.SerialDate serialDate19 = serialDate11.getEndOfCurrentMonth(serialDate17);
//        boolean boolean20 = spreadsheetDate1.isOn(serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean25 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate35 = serialDate29.getEndOfCurrentMonth(serialDate32);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate35);
//        boolean boolean37 = spreadsheetDate22.isOn(serialDate35);
//        boolean boolean38 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        int int39 = spreadsheetDate22.getYYYY();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        timeSeries1.setDescription("");
        long long6 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str3.equals("org.jfree.data.general.SeriesException: Value"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.String str6 = serialDate5.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(100, serialDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ERROR : Relative To String");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries1.setNotify(true);
        timeSeries1.setDomainDescription("August 52");
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        org.jfree.data.time.SerialDate serialDate2 = null;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate12 = serialDate6.getEndOfCurrentMonth(serialDate9);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate12);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate22 = serialDate20.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate17.getEndOfCurrentMonth(serialDate20);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate23);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate27 = serialDate13.getEndOfCurrentMonth(serialDate26);
//        try {
//            boolean boolean29 = spreadsheetDate1.isInRange(serialDate2, serialDate27, 1900);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getPreviousDayOfWeek(3);
//        try {
//            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(52, serialDate3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        java.lang.Object obj10 = timeSeries1.clone();
        timeSeries1.setDescription("December");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertNotNull(obj10);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(4);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths(13, serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate14 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate16);
//        org.jfree.data.time.SerialDate serialDate18 = serialDate10.getEndOfCurrentMonth(serialDate16);
//        int int19 = spreadsheetDate3.compare(serialDate16);
//        int int20 = spreadsheetDate1.compare(serialDate16);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-43616) + "'", int19 == (-43616));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-43617) + "'", int20 == (-43617));
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries3.removeAgedItems((long) (-1), false);
//        java.lang.String str7 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
//        java.lang.Number number15 = timeSeries12.getValue(regularTimePeriod14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 6);
//        java.lang.Object obj22 = null;
//        int int23 = fixedMillisecond16.compareTo(obj22);
//        java.lang.Object obj24 = null;
//        int int25 = fixedMillisecond16.compareTo(obj24);
//        int int26 = month0.compareTo((java.lang.Object) fixedMillisecond16);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate35 = day33.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate37 = serialDate35.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate32.getEndOfCurrentMonth(serialDate35);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate38);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        int int42 = day41.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = day41.getSerialDate();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        int int45 = day44.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate46 = day44.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate49 = serialDate43.getEndOfCurrentMonth(serialDate46);
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate49);
//        org.jfree.data.time.SerialDate serialDate52 = serialDate49.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate53 = serialDate39.getEndOfCurrentMonth(serialDate52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate52);
//        boolean boolean55 = spreadsheetDate28.isOnOrBefore(serialDate52);
//        int int56 = fixedMillisecond16.compareTo((java.lang.Object) spreadsheetDate28);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        boolean boolean61 = day59.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries58.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day59, (java.lang.Number) 1.0d);
//        long long64 = day59.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = day59.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = day59.previous();
//        int int67 = fixedMillisecond16.compareTo((java.lang.Object) regularTimePeriod66);
//        java.lang.Class class68 = null;
//        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int67, class68);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560192496619L + "'", long18 == 1560192496619L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560236399999L + "'", long64 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.clear();
//        timeSeries1.removeAgedItems(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
//        java.util.Date date7 = fixedMillisecond5.getTime();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.Year year9 = month8.getYear();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries12.removeAgedItems((long) (-1), false);
//        java.lang.String str16 = timeSeries12.getDomainDescription();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
//        long long22 = year17.getSerialIndex();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, year17);
//        long long24 = year17.getSerialIndex();
//        int int25 = year17.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year17.next();
//        int int27 = year9.compareTo((java.lang.Object) regularTimePeriod26);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries29.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        long long33 = fixedMillisecond32.getLastMillisecond();
//        int int34 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries1.createCopy(regularTimePeriod26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        long long36 = fixedMillisecond32.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560192497052L + "'", long33 == 1560192497052L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560192497052L + "'", long36 == 1560192497052L);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long14 = year7.getSerialIndex();
        int int15 = year7.getYear();
        java.util.Date date16 = year7.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.previous();
        java.util.Date date20 = fixedMillisecond18.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.previous();
        java.util.Date date23 = fixedMillisecond21.getTime();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23, timeZone24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date20, timeZone24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date16, timeZone24);
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date16, timeZone30);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date16);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date16);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(serialDate33);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate5.getEndOfCurrentMonth(serialDate8);
//        java.lang.String str12 = serialDate11.getDescription();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(6, serialDate11);
//        int int14 = fixedMillisecond0.compareTo((java.lang.Object) 6);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond0.getMiddleMillisecond(calendar15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond0.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond0.getMiddleMillisecond(calendar19);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond0.getMiddleMillisecond(calendar21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560192497498L + "'", long1 == 1560192497498L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192497498L + "'", long16 == 1560192497498L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560192497498L + "'", long18 == 1560192497498L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560192497498L + "'", long20 == 1560192497498L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560192497498L + "'", long22 == 1560192497498L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries11.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries15.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries11.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries11);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries22.removeAgedItems((long) (-1), false);
//        java.lang.String str26 = timeSeries22.getDomainDescription();
//        timeSeries22.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable30 = timeSeries22.getKey();
//        java.lang.Object obj31 = timeSeries22.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries22);
//        java.lang.Comparable comparable33 = timeSeries22.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries22.removePropertyChangeListener(propertyChangeListener34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond36.previous();
//        java.util.Date date38 = fixedMillisecond36.getTime();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date38);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries45.removeAgedItems(false);
//        int int48 = timeSeries45.getItemCount();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        boolean boolean51 = day49.equals((java.lang.Object) 5);
//        long long52 = day49.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day49, (double) '4');
//        long long55 = day49.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) day43, (org.jfree.data.time.RegularTimePeriod) day49);
//        int int57 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
//        java.lang.String str58 = day43.toString();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable30 + "' != '" + (byte) 10 + "'", comparable30.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj31);
//        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (byte) 10 + "'", comparable33.equals((byte) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560236399999L + "'", long52 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560150000000L + "'", long55 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "10-June-2019" + "'", str58.equals("10-June-2019"));
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 0);
        long long3 = month2.getLastMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) "September");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62125372800001L) + "'", long3 == (-62125372800001L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        long long5 = month3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month3.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month3.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        long long2 = year1.getSerialIndex();
        java.lang.String str3 = year1.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1900L + "'", long2 == 1900L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1900" + "'", str3.equals("1900"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        java.lang.String str9 = timeSeries5.getDomainDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries16.removeAgedItems((long) (-1), false);
        java.lang.String str20 = timeSeries16.getDomainDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year23);
        int int26 = year12.compareTo((java.lang.Object) year21);
        int int27 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries1.removeChangeListener(seriesChangeListener28);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getPreviousDayOfWeek(1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 0);
        long long3 = month2.getFirstMillisecond();
        long long4 = month2.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62159500800000L) + "'", long3 == (-62159500800000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62159500800000L) + "'", long4 == (-62159500800000L));
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries4.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries8.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries4.addAndOrUpdate(timeSeries8);
//        boolean boolean13 = day0.equals((java.lang.Object) timeSeries12);
//        java.lang.String str14 = day0.toString();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        timeSeries10.setDescription("2019");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 9);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2147483647);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate11 = serialDate9.getPreviousDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Feb");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        timeSeries1.clear();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        boolean boolean13 = day11.equals((java.lang.Object) 5);
//        boolean boolean15 = day11.equals((java.lang.Object) 100L);
//        long long16 = day11.getMiddleMillisecond();
//        long long17 = day11.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (double) (-62159500800000L));
//        boolean boolean20 = timeSeries1.getNotify();
//        timeSeries1.setNotify(false);
//        java.lang.String str23 = timeSeries1.getDescription();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560193199999L + "'", long16 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNull(str23);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate3.getEndOfCurrentMonth(serialDate6);
//        java.lang.String str10 = serialDate9.getDescription();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(6, serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        long long13 = day12.getSerialIndex();
//        long long14 = day12.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 45838L + "'", long13 == 45838L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 45838L + "'", long14 == 45838L);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries3.removeAgedItems((long) (-1), false);
        java.lang.String str7 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        long long13 = year8.getSerialIndex();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year8);
        long long15 = year8.getSerialIndex();
        int int16 = year8.getYear();
        java.util.Date date17 = year8.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        java.util.Date date21 = fixedMillisecond19.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.previous();
        java.util.Date date24 = fixedMillisecond22.getTime();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24, timeZone25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date21, timeZone25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date17, timeZone25);
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date17, timeZone31);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date17);
        try {
            org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(8, serialDate34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(serialDate34);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        java.lang.Comparable comparable12 = timeSeries1.getKey();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate18.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate15.getEndOfCurrentMonth(serialDate18);
//        java.lang.String str22 = serialDate21.getDescription();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(1900);
//        java.lang.String str26 = year25.toString();
//        long long27 = year25.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year25);
//        timeSeries28.setMaximumItemAge(1560192445763L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1900" + "'", str26.equals("1900"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2208960000000L) + "'", long27 == (-2208960000000L));
//        org.junit.Assert.assertNotNull(timeSeries28);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (short) 0);
        java.lang.String str3 = month2.toString();
        try {
            org.jfree.data.time.Year year4 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "October 0" + "'", str3.equals("October 0"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean10 = timeSeries5.getNotify();
        timeSeries5.removeAgedItems(true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.lang.String str3 = spreadsheetDate2.toString();
//        java.util.Date date4 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
//        boolean boolean7 = spreadsheetDate2.isOn(serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate18.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate15.getEndOfCurrentMonth(serialDate18);
//        java.lang.String str22 = serialDate21.getDescription();
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(6, serialDate21);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears(0, serialDate23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
//        boolean boolean28 = spreadsheetDate10.isInRange(serialDate24, serialDate26, 13);
//        boolean boolean29 = spreadsheetDate2.isOn(serialDate26);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5-January-1900" + "'", str3.equals("5-January-1900"));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year4 = month3.getYear();
        long long5 = month3.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month3.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year8.getSerialIndex();
        long long12 = year8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries16.fireSeriesChanged();
        boolean boolean18 = timeSeriesDataItem14.equals((java.lang.Object) timeSeries16);
        java.lang.Number number19 = timeSeriesDataItem14.getValue();
        timeSeriesDataItem14.setValue((java.lang.Number) 1560192437609L);
        timeSeriesDataItem14.setValue((java.lang.Number) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem14.getPeriod();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 5 + "'", number19.equals(5));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-43620));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.lang.Object obj6 = seriesChangeEvent5.getSource();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesChangeEvent5);
        java.lang.String str8 = seriesChangeEvent7.toString();
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        int int10 = timeSeries9.getMaximumItemCount();
//        java.lang.String str11 = timeSeries9.getRangeDescription();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        boolean boolean15 = year13.equals((java.lang.Object) 100L);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(8, year13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 100);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries9.removePropertyChangeListener(propertyChangeListener23);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 2958465);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries6.removeAgedItems((long) (-1), false);
        int int10 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries12.setMaximumItemCount(1900);
        int int15 = timeSeriesDataItem4.compareTo((java.lang.Object) 1900);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries17.removeAgedItems((long) (-1), false);
        java.lang.String str21 = timeSeries17.getDomainDescription();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) year22, (org.jfree.data.time.RegularTimePeriod) year24);
        int int27 = timeSeries17.getMaximumItemCount();
        boolean boolean28 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries17);
        timeSeriesDataItem4.setValue((java.lang.Number) 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        int int2 = month1.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries4.removeAgedItems((long) (-1), false);
//        java.lang.String str8 = timeSeries4.getDomainDescription();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year9, (org.jfree.data.time.RegularTimePeriod) year11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
//        java.lang.Number number16 = timeSeries13.getValue(regularTimePeriod15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond17.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 6);
//        java.lang.Object obj23 = null;
//        int int24 = fixedMillisecond17.compareTo(obj23);
//        java.lang.Object obj25 = null;
//        int int26 = fixedMillisecond17.compareTo(obj25);
//        int int27 = month1.compareTo((java.lang.Object) fixedMillisecond17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate33 = day31.getSerialDate();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate38 = serialDate36.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate39 = serialDate33.getEndOfCurrentMonth(serialDate36);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate39);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        int int43 = day42.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate44 = day42.getSerialDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        int int46 = day45.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate47 = day45.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate49 = serialDate47.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate50 = serialDate44.getEndOfCurrentMonth(serialDate47);
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate50);
//        org.jfree.data.time.SerialDate serialDate53 = serialDate50.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate54 = serialDate40.getEndOfCurrentMonth(serialDate53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate53);
//        boolean boolean56 = spreadsheetDate29.isOnOrBefore(serialDate53);
//        int int57 = fixedMillisecond17.compareTo((java.lang.Object) spreadsheetDate29);
//        try {
//            org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560192498677L + "'", long19 == 1560192498677L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = serialDate2.getPreviousDayOfWeek(3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate2);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate2);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-447) + "'", int1 == (-447));
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate10 = serialDate4.getEndOfCurrentMonth(serialDate7);
//        java.lang.String str11 = serialDate10.getDescription();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears(6, serialDate10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(52, serialDate12);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        boolean boolean4 = day0.equals((java.lang.Object) 100L);
//        long long5 = day0.getMiddleMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "10-June-2019", class8);
//        java.util.List list10 = timeSeries9.getItems();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries9.addOrUpdate(regularTimePeriod11, (java.lang.Number) (-452));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193199999L + "'", long5 == 1560193199999L);
//        org.junit.Assert.assertNotNull(list10);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560192438814L);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate5.getEndOfCurrentMonth(serialDate8);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate22 = serialDate16.getEndOfCurrentMonth(serialDate19);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate22);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate22.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate12.getEndOfCurrentMonth(serialDate25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate25);
//        boolean boolean28 = fixedMillisecond1.equals((java.lang.Object) serialDate25);
//        java.lang.String str29 = serialDate25.getDescription();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNull(str29);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate5.getEndOfCurrentMonth(serialDate8);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate22 = serialDate16.getEndOfCurrentMonth(serialDate19);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate22);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate22.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate12.getEndOfCurrentMonth(serialDate25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate25);
//        boolean boolean28 = spreadsheetDate1.isOnOrBefore(serialDate25);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean33 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int38 = day37.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate42 = serialDate36.getEndOfCurrentMonth(serialDate39);
//        java.lang.String str43 = serialDate42.getDescription();
//        boolean boolean44 = spreadsheetDate32.isBefore(serialDate42);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int47 = day46.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate48 = day46.getSerialDate();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        int int50 = day49.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate51 = day49.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate53 = serialDate51.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate54 = serialDate48.getEndOfCurrentMonth(serialDate51);
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate54);
//        org.jfree.data.time.SerialDate serialDate57 = serialDate54.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate58 = spreadsheetDate32.getEndOfCurrentMonth(serialDate54);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean63 = spreadsheetDate60.isOn((org.jfree.data.time.SerialDate) spreadsheetDate62);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        int int66 = day65.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate67 = day65.getSerialDate();
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        int int69 = day68.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate70 = day68.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate72 = serialDate70.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate73 = serialDate67.getEndOfCurrentMonth(serialDate70);
//        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate73);
//        boolean boolean75 = spreadsheetDate60.isOn(serialDate73);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
//        int int77 = day76.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate78 = day76.getSerialDate();
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
//        int int80 = day79.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate81 = day79.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate83 = serialDate81.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate84 = serialDate78.getEndOfCurrentMonth(serialDate81);
//        int int85 = spreadsheetDate60.compare(serialDate78);
//        boolean boolean87 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, serialDate78, (int) (byte) -1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 10 + "'", int66 == 10);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 10 + "'", int69 == 10);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 10 + "'", int77 == 10);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 10 + "'", int80 == 10);
//        org.junit.Assert.assertNotNull(serialDate81);
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-43620) + "'", int85 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 6);
//        java.lang.Object obj20 = null;
//        int int21 = fixedMillisecond14.compareTo(obj20);
//        java.lang.Object obj22 = null;
//        int int23 = fixedMillisecond14.compareTo(obj22);
//        long long24 = fixedMillisecond14.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192500687L + "'", long16 == 1560192500687L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560192500687L + "'", long24 == 1560192500687L);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate3.getEndOfCurrentMonth(serialDate6);
//        java.lang.String str10 = serialDate9.getDescription();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(6, serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        java.util.Calendar calendar13 = null;
//        try {
//            day12.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.lang.String str2 = spreadsheetDate1.toString();
//        java.util.Date date3 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean8 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate18 = serialDate12.getEndOfCurrentMonth(serialDate15);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate18);
//        boolean boolean20 = spreadsheetDate5.isOn(serialDate18);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate23 = day21.getSerialDate();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        int int25 = day24.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate26 = day24.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate28 = serialDate26.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate29 = serialDate23.getEndOfCurrentMonth(serialDate26);
//        int int30 = spreadsheetDate5.compare(serialDate23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean35 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        int int37 = day36.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate38 = day36.getSerialDate();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        int int40 = day39.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate41 = day39.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate44 = serialDate38.getEndOfCurrentMonth(serialDate41);
//        java.lang.String str45 = serialDate44.getDescription();
//        boolean boolean46 = spreadsheetDate34.isBefore(serialDate44);
//        int int47 = spreadsheetDate34.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean50 = spreadsheetDate34.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        boolean boolean51 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        int int54 = day53.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate55 = day53.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate57 = serialDate55.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addMonths(13, serialDate57);
//        boolean boolean59 = spreadsheetDate34.isOnOrBefore(serialDate58);
//        boolean boolean60 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = fixedMillisecond61.previous();
//        java.util.Date date63 = fixedMillisecond61.getTime();
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(date63);
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance(date63);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date63);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date63);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = day68.next();
//        org.jfree.data.time.SerialDate serialDate70 = day68.getSerialDate();
//        boolean boolean71 = spreadsheetDate34.isBefore(serialDate70);
//        spreadsheetDate34.setDescription("Value");
//        int int74 = spreadsheetDate34.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5-January-1900" + "'", str2.equals("5-January-1900"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-43620) + "'", int30 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNull(str45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 10 + "'", int54 == 10);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 6 + "'", int74 == 6);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
//        boolean boolean16 = spreadsheetDate1.isOnOrBefore(serialDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean21 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate25 = day23.getSerialDate();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate28 = day26.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate30 = serialDate28.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate25.getEndOfCurrentMonth(serialDate28);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate31);
//        boolean boolean33 = spreadsheetDate18.isOn(serialDate31);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int38 = day37.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate42 = serialDate36.getEndOfCurrentMonth(serialDate39);
//        int int43 = spreadsheetDate18.compare(serialDate36);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate36.getPreviousDayOfWeek(6);
//        boolean boolean46 = spreadsheetDate1.isOnOrBefore(serialDate45);
//        java.lang.Class<?> wildcardClass47 = serialDate45.getClass();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries50.removeAgedItems((long) (-1), false);
//        java.lang.String str54 = timeSeries50.getDomainDescription();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year55.previous();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year57.previous();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) year55, (org.jfree.data.time.RegularTimePeriod) year57);
//        long long60 = year55.getSerialIndex();
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month((int) (byte) 1, year55);
//        long long62 = year55.getSerialIndex();
//        int int63 = year55.getYear();
//        java.util.Date date64 = year55.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(date64);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = fixedMillisecond66.previous();
//        java.util.Date date68 = fixedMillisecond66.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond69.previous();
//        java.util.Date date71 = fixedMillisecond69.getTime();
//        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date71, timeZone72);
//        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month(date68, timeZone72);
//        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year(date64, timeZone72);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = fixedMillisecond76.previous();
//        java.util.Date date78 = fixedMillisecond76.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = fixedMillisecond79.previous();
//        java.util.Date date81 = fixedMillisecond79.getTime();
//        java.lang.Class class82 = null;
//        java.util.Date date83 = null;
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class82, date83, timeZone84);
//        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date81, timeZone84);
//        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date78, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date64, timeZone84);
//        java.lang.Class class89 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-43620) + "'", int43 == (-43620));
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Time" + "'", str54.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 2019L + "'", long62 == 2019L);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2019 + "'", int63 == 2019);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone72);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNull(regularTimePeriod85);
//        org.junit.Assert.assertNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(class89);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long14 = month13.getSerialIndex();
        org.jfree.data.time.Year year15 = month13.getYear();
        java.util.Calendar calendar16 = null;
        try {
            year15.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24229L + "'", long14 == 24229L);
        org.junit.Assert.assertNotNull(year15);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
        java.util.Collection collection13 = timeSeries10.getTimePeriods();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(collection13);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "2019", "hi!", "", class3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries6.removeAgedItems(false);
//        int int9 = timeSeries6.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 5);
//        long long13 = day10.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (double) '4');
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries17.removeAgedItems((long) (-1), false);
//        java.lang.String str21 = timeSeries17.getDomainDescription();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) year22, (org.jfree.data.time.RegularTimePeriod) year24);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries28.removeAgedItems((long) (-1), false);
//        java.lang.String str32 = timeSeries28.getDomainDescription();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.previous();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.previous();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) year33, (org.jfree.data.time.RegularTimePeriod) year35);
//        int int38 = year24.compareTo((java.lang.Object) year33);
//        long long39 = year24.getLastMillisecond();
//        boolean boolean40 = day10.equals((java.lang.Object) year24);
//        java.util.Date date41 = day10.getStart();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year42);
//        boolean boolean44 = timeSeries4.isEmpty();
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries12.removeAgedItems((long) (-1), false);
//        java.lang.String str16 = timeSeries12.getDomainDescription();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
//        int int22 = year8.compareTo((java.lang.Object) year17);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getDayOfMonth();
//        long long25 = day23.getSerialIndex();
//        int int26 = day23.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries28.removeAgedItems(false);
//        java.util.Collection collection31 = timeSeries28.getTimePeriods();
//        int int32 = day23.compareTo((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        java.lang.String str34 = year33.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) 1560192449430L);
//        int int37 = year17.compareTo((java.lang.Object) timeSeriesDataItem36);
//        java.util.Calendar calendar38 = null;
//        try {
//            year17.peg(calendar38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean15 = day13.equals((java.lang.Object) 5);
//        int int16 = day13.getDayOfMonth();
//        java.lang.String str17 = day13.toString();
//        long long18 = day13.getLastMillisecond();
//        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 10, (int) (short) 0);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries25.removeAgedItems((long) (-1), false);
//        java.lang.String str29 = timeSeries25.getDomainDescription();
//        timeSeries25.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable33 = timeSeries25.getKey();
//        java.lang.Object obj34 = timeSeries25.clone();
//        java.lang.Comparable comparable35 = timeSeries25.getKey();
//        boolean boolean36 = month23.equals((java.lang.Object) timeSeries25);
//        timeSeries10.setKey((java.lang.Comparable) month23);
//        timeSeries10.removeAgedItems(1560192426098L, false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (byte) 10 + "'", comparable33.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + (byte) 10 + "'", comparable35.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) true);
        boolean boolean4 = day0.equals((java.lang.Object) 1560192445731L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(9999);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        int int4 = timeSeries1.getItemCount();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        boolean boolean7 = day5.equals((java.lang.Object) 5);
//        long long8 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) '4');
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries12.removeAgedItems((long) (-1), false);
//        java.lang.String str16 = timeSeries12.getDomainDescription();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries23.removeAgedItems((long) (-1), false);
//        java.lang.String str27 = timeSeries23.getDomainDescription();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) year30);
//        int int33 = year19.compareTo((java.lang.Object) year28);
//        long long34 = year19.getLastMillisecond();
//        boolean boolean35 = day5.equals((java.lang.Object) year19);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries37.removeAgedItems(false);
//        java.util.Collection collection40 = timeSeries37.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries42.setMaximumItemCount(1900);
//        int int45 = timeSeries42.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries37.addAndOrUpdate(timeSeries42);
//        timeSeries37.removeAgedItems(false);
//        int int49 = day5.compareTo((java.lang.Object) timeSeries37);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        boolean boolean54 = day52.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day52, (java.lang.Number) 1.0d);
//        int int57 = day52.getDayOfMonth();
//        int int58 = day52.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day52, 0.0d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem60);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        timeSeries1.removeAgedItems((long) (short) 10, false);
        java.lang.Object obj8 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str6 = timePeriodFormatException5.toString();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Time", "1900", "Time", class8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class8);
        boolean boolean11 = timeSeries10.getNotify();
        timeSeries10.setDomainDescription("June 2019");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate14);
//        boolean boolean16 = spreadsheetDate1.isOn(serialDate14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate19.getEndOfCurrentMonth(serialDate22);
//        int int26 = spreadsheetDate1.compare(serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean31 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate37 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = serialDate37.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate34.getEndOfCurrentMonth(serialDate37);
//        java.lang.String str41 = serialDate40.getDescription();
//        boolean boolean42 = spreadsheetDate30.isBefore(serialDate40);
//        int int43 = spreadsheetDate30.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean46 = spreadsheetDate30.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        boolean boolean47 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        try {
//            org.jfree.data.time.SerialDate serialDate49 = spreadsheetDate30.getNearestDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-43620) + "'", int26 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str13 = spreadsheetDate12.toString();
        java.util.Date date14 = spreadsheetDate12.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.previous();
        java.util.Date date17 = fixedMillisecond15.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date14, timeZone18);
        long long21 = regularTimePeriod20.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "5-January-1900" + "'", str13.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2208571200001L) + "'", long21 == (-2208571200001L));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("September");
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7, 3, (-43617));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate14);
//        boolean boolean16 = spreadsheetDate1.isOn(serialDate14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate19.getEndOfCurrentMonth(serialDate22);
//        int int26 = spreadsheetDate1.compare(serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean31 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate37 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = serialDate37.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate34.getEndOfCurrentMonth(serialDate37);
//        java.lang.String str41 = serialDate40.getDescription();
//        boolean boolean42 = spreadsheetDate30.isBefore(serialDate40);
//        int int43 = spreadsheetDate30.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean46 = spreadsheetDate30.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        boolean boolean47 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        int int48 = spreadsheetDate1.getDayOfMonth();
//        int int49 = spreadsheetDate1.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-43620) + "'", int26 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 5 + "'", int48 == 5);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 5 + "'", int49 == 5);
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        boolean boolean15 = spreadsheetDate3.isBefore(serialDate13);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate19.getEndOfCurrentMonth(serialDate22);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate25);
//        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate3.getEndOfCurrentMonth(serialDate25);
//        int int30 = spreadsheetDate3.getDayOfWeek();
//        try {
//            int int32 = spreadsheetDate3.compareTo((java.lang.Object) 1560192495438L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.clear();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        long long4 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj5 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        int int10 = timeSeries9.getMaximumItemCount();
        java.lang.String str11 = timeSeries9.getRangeDescription();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int13 = month12.getMonth();
        int int14 = month12.getYearValue();
        long long15 = month12.getSerialIndex();
        timeSeries9.setKey((java.lang.Comparable) long15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries9.addChangeListener(seriesChangeListener17);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        java.util.Calendar calendar3 = null;
        fixedMillisecond0.peg(calendar3);
        java.util.Date date5 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        java.util.Date date7 = month6.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1964, (-43620), 1964);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1.0d);
//        long long7 = day2.getLastMillisecond();
//        int int8 = day2.getYear();
//        int int9 = day2.getYear();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "2019", "hi!", "", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        int int7 = timeSeries4.getMaximumItemCount();
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertNotNull(collection8);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
//        java.util.Date date5 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date2, timeZone6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date2);
//        int int10 = day9.getYear();
//        long long11 = day9.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        timeSeries1.clear();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate16.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate19 = serialDate13.getEndOfCurrentMonth(serialDate16);
//        java.lang.String str20 = serialDate19.getDescription();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate19);
//        long long22 = day21.getMiddleMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        try {
//            timeSeries1.update(regularTimePeriod27, (java.lang.Number) 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561921199999L + "'", long22 == 1561921199999L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560192506618L + "'", long26 == 1560192506618L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean10 = timeSeries5.getNotify();
        timeSeries5.removeAgedItems((long) 13, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.util.Date date16 = fixedMillisecond14.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
        java.util.Date date19 = fixedMillisecond17.getTime();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date16, timeZone20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day23, (double) (-60507964800000L), false);
        timeSeries5.update((int) (short) 0, (java.lang.Number) 1);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries31.removeAgedItems((long) (-1), false);
        timeSeries31.removeAgedItems((long) (short) 10, false);
        timeSeries31.setDomainDescription("Time");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
        timeSeries31.addChangeListener(seriesChangeListener40);
        java.util.Collection collection42 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        timeSeries31.setMaximumItemCount((int) '4');
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(collection42);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 0);
        long long3 = month2.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62125372800001L) + "'", long3 == (-62125372800001L));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(1900);
        java.lang.String str3 = year2.toString();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year2);
        int int5 = year2.getYear();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1900" + "'", str3.equals("1900"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year8.getSerialIndex();
        long long12 = year8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries16.fireSeriesChanged();
        boolean boolean18 = timeSeriesDataItem14.equals((java.lang.Object) timeSeries16);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries22.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries16.addAndOrUpdate(timeSeries22);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeSeries25);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate15 = serialDate9.getEndOfCurrentMonth(serialDate12);
//        java.lang.String str16 = serialDate15.getDescription();
//        boolean boolean17 = spreadsheetDate5.isBefore(serialDate15);
//        boolean boolean18 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.lang.String str20 = year19.toString();
//        int int21 = year19.getYear();
//        java.lang.Object obj22 = null;
//        int int23 = year19.compareTo(obj22);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries25.removeAgedItems((long) (-1), false);
//        java.lang.String str29 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) year32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year32.previous();
//        boolean boolean36 = year19.equals((java.lang.Object) year32);
//        try {
//            int int37 = spreadsheetDate1.compareTo((java.lang.Object) year19);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Year cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        boolean boolean3 = year1.equals((java.lang.Object) 100L);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
//        org.jfree.data.time.Year year5 = month4.getYear();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "10-June-2019", class8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries11.removeAgedItems(false);
//        int int14 = timeSeries11.getItemCount();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean17 = day15.equals((java.lang.Object) 5);
//        long long18 = day15.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) '4');
//        int int21 = day15.getYear();
//        int int22 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day15);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-43616), 1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean4 = day2.equals((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1.0d);
        timeSeries1.removeAgedItems(false);
        timeSeries1.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        int int5 = timeSeries1.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
//        boolean boolean16 = spreadsheetDate1.isOnOrBefore(serialDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean21 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate24 = day22.getSerialDate();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        int int26 = day25.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate27 = day25.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate30 = serialDate24.getEndOfCurrentMonth(serialDate27);
//        java.lang.String str31 = serialDate30.getDescription();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate30);
//        boolean boolean33 = spreadsheetDate18.isOnOrBefore(serialDate30);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.lang.String str36 = spreadsheetDate35.toString();
//        java.util.Date date37 = spreadsheetDate35.toDate();
//        java.util.Date date38 = spreadsheetDate35.toDate();
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, (org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "5-January-1900" + "'", str36.equals("5-January-1900"));
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        long long11 = timeSeries1.getMaximumItemAge();
//        java.lang.String str12 = timeSeries1.getRangeDescription();
//        timeSeries1.clear();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (java.lang.Number) (short) 10);
//        timeSeries1.add(timeSeriesDataItem16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        long long22 = day20.getSerialIndex();
//        int int23 = day20.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries25.removeAgedItems(false);
//        java.util.Collection collection28 = timeSeries25.getTimePeriods();
//        int int29 = day20.compareTo((java.lang.Object) timeSeries25);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 1560192478633L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43626L + "'", long22 == 43626L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test259");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        boolean boolean10 = timeSeries5.getNotify();
//        timeSeries5.removeAgedItems((long) 13, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
//        java.util.Date date16 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
//        java.util.Date date19 = fixedMillisecond17.getTime();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date16, timeZone20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day23, (double) (-60507964800000L), false);
//        timeSeries5.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
//        java.util.Date date31 = fixedMillisecond29.getTime();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date31);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate37 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = serialDate37.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addDays(0, serialDate37);
//        java.lang.String str41 = serialDate40.getDescription();
//        org.jfree.data.time.SerialDate serialDate42 = serialDate33.getEndOfCurrentMonth(serialDate40);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(serialDate42);
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) day43);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertNotNull(serialDate42);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        boolean boolean10 = timeSeries5.getNotify();
//        timeSeries5.removeAgedItems((long) 13, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
//        java.util.Date date16 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
//        java.util.Date date19 = fixedMillisecond17.getTime();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date16, timeZone20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day23, (double) (-60507964800000L), false);
//        timeSeries5.update((int) (short) 0, (java.lang.Number) 1);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries31.removeAgedItems(false);
//        int int34 = timeSeries31.getItemCount();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        boolean boolean37 = day35.equals((java.lang.Object) 5);
//        long long38 = day35.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) '4');
//        int int41 = day35.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 1560192500687L);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560236399999L + "'", long38 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(0, serialDate8);
//        java.lang.String str12 = serialDate11.getDescription();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate4.getEndOfCurrentMonth(serialDate11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean19 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate25 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate25.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate28 = serialDate22.getEndOfCurrentMonth(serialDate25);
//        java.lang.String str29 = serialDate28.getDescription();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate28);
//        boolean boolean31 = spreadsheetDate16.isOnOrBefore(serialDate28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean36 = spreadsheetDate33.isOn((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        int int39 = day38.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate40 = day38.getSerialDate();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        int int42 = day41.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = day41.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate45 = serialDate43.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate46 = serialDate40.getEndOfCurrentMonth(serialDate43);
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate46);
//        boolean boolean48 = spreadsheetDate33.isOn(serialDate46);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        int int50 = day49.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate51 = day49.getSerialDate();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        int int53 = day52.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate54 = day52.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate56 = serialDate54.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate57 = serialDate51.getEndOfCurrentMonth(serialDate54);
//        int int58 = spreadsheetDate33.compare(serialDate51);
//        org.jfree.data.time.SerialDate serialDate60 = serialDate51.getPreviousDayOfWeek(6);
//        boolean boolean61 = spreadsheetDate16.isOnOrBefore(serialDate60);
//        org.jfree.data.time.SerialDate serialDate62 = serialDate13.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-43620) + "'", int58 == (-43620));
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertNotNull(serialDate62);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1.0d);
//        int int7 = day2.getMonth();
//        long long8 = day2.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        java.lang.String str5 = month0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        boolean boolean15 = spreadsheetDate3.isBefore(serialDate13);
//        int int16 = spreadsheetDate3.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean19 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        java.lang.Class<?> wildcardClass21 = day20.getClass();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560192438814L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192438814L + "'", long3 == 1560192438814L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560192438814L + "'", long5 == 1560192438814L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        long long2 = timeSeries1.getMaximumItemAge();
        timeSeries1.setMaximumItemAge(1560192449216L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (short) -1, true);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries11.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries15.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries11.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries23.removeAgedItems((long) (-1), false);
        java.lang.String str27 = timeSeries23.getDomainDescription();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) year30);
        long long33 = year28.getSerialIndex();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (byte) 1, year28);
        long long35 = year28.getSerialIndex();
        int int36 = year28.getYear();
        java.util.Date date37 = year28.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        boolean boolean40 = timeSeries20.equals((java.lang.Object) serialDate39);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getMonth();
//        int int2 = month0.getYearValue();
//        int int3 = month0.getMonth();
//        int int4 = month0.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        boolean boolean14 = month0.equals((java.lang.Object) serialDate7);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries16.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries20.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries16.addAndOrUpdate(timeSeries20);
//        java.lang.Class class25 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.lang.String str28 = spreadsheetDate27.toString();
//        java.util.Date date29 = spreadsheetDate27.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond30.previous();
//        java.util.Date date32 = fixedMillisecond30.getTime();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date29, timeZone33);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        boolean boolean38 = year36.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) 2958465);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem40.getPeriod();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean43 = timeSeriesDataItem40.equals((java.lang.Object) timeZone42);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date29, timeZone42);
//        int int45 = month0.compareTo((java.lang.Object) date29);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "5-January-1900" + "'", str28.equals("5-January-1900"));
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries6.setMaximumItemCount(1900);
        int int9 = timeSeries6.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries6);
        boolean boolean11 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        long long5 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192509173L + "'", long2 == 1560192509173L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192509173L + "'", long3 == 1560192509173L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560192509173L + "'", long4 == 1560192509173L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560192509173L + "'", long5 == 1560192509173L);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate5.getEndOfCurrentMonth(serialDate8);
//        java.lang.String str12 = serialDate11.getDescription();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(6, serialDate11);
//        int int14 = fixedMillisecond0.compareTo((java.lang.Object) 6);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond0.getMiddleMillisecond(calendar15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond0.getMiddleMillisecond(calendar17);
//        java.lang.Object obj19 = null;
//        int int20 = fixedMillisecond0.compareTo(obj19);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560192509182L + "'", long1 == 1560192509182L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192509182L + "'", long16 == 1560192509182L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560192509182L + "'", long18 == 1560192509182L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        int int10 = timeSeries9.getMaximumItemCount();
        java.lang.String str11 = timeSeries9.getRangeDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) 100L);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(8, year13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month16);
        long long18 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = null;
        try {
            timeSeries9.add(regularTimePeriod19, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getLastMillisecond();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean9 = day7.equals((java.lang.Object) 5);
//        boolean boolean11 = day7.equals((java.lang.Object) 100L);
//        long long12 = day7.getMiddleMillisecond();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day7, "10-June-2019", "10-June-2019", class15);
//        java.util.List list17 = timeSeries16.getItems();
//        java.lang.Class class18 = timeSeries16.getTimePeriodClass();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.lang.String str20 = year19.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 1560193199999L);
//        timeSeries16.setDomainDescription("September");
//        boolean boolean25 = fixedMillisecond4.equals((java.lang.Object) timeSeries16);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560192509242L + "'", long5 == 1560192509242L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193199999L + "'", long12 == 1560193199999L);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNull(class18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        java.util.Date date5 = fixedMillisecond3.getTime();
        java.lang.Class class6 = null;
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date5, timeZone8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.previous();
        java.util.Date date13 = fixedMillisecond11.getTime();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date5, timeZone14);
        java.lang.Class<?> wildcardClass17 = year16.getClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560192428424L, "org.jfree.data.time.TimePeriodFormatException: 2019", "30-June-2019", (java.lang.Class) wildcardClass17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class19);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        java.lang.Comparable comparable12 = timeSeries1.getKey();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate18.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate15.getEndOfCurrentMonth(serialDate18);
//        java.lang.String str22 = serialDate21.getDescription();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(1900);
//        java.lang.String str26 = year25.toString();
//        long long27 = year25.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
//        java.util.Date date31 = fixedMillisecond29.getTime();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date31);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date31);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries38.removeAgedItems((long) (-1), false);
//        java.lang.String str42 = timeSeries38.getDomainDescription();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year43.previous();
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.previous();
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) year43, (org.jfree.data.time.RegularTimePeriod) year45);
//        long long48 = year43.getSerialIndex();
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (byte) 1, year43);
//        long long50 = year43.getSerialIndex();
//        int int51 = year43.getYear();
//        java.util.Date date52 = year43.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date52);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond54.previous();
//        java.util.Date date56 = fixedMillisecond54.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond57.previous();
//        java.util.Date date59 = fixedMillisecond57.getTime();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date59, timeZone60);
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date56, timeZone60);
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date52, timeZone60);
//        java.lang.Class class64 = null;
//        java.util.Date date65 = null;
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date65, timeZone66);
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date52, timeZone66);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date31, timeZone66);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day69, (double) 1560192445731L);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day72, (java.lang.Number) (short) 10);
//        java.util.Date date75 = day72.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = day72.next();
//        java.lang.Number number77 = timeSeries28.getValue(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1900" + "'", str26.equals("1900"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2208960000000L) + "'", long27 == (-2208960000000L));
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Time" + "'", str42.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2019L + "'", long50 == 2019L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNull(timeSeriesDataItem71);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNull(number77);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        boolean boolean15 = spreadsheetDate3.isBefore(serialDate13);
//        int int16 = spreadsheetDate3.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean19 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        int int20 = spreadsheetDate3.getDayOfWeek();
//        int int21 = spreadsheetDate3.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
//    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
//        java.util.Date date8 = fixedMillisecond6.getTime();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date8);
//        int int13 = fixedMillisecond0.compareTo((java.lang.Object) date8);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond0.getFirstMillisecond(calendar14);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192510523L + "'", long15 == 1560192510523L);
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(13, serialDate7);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate14);
//        int int17 = spreadsheetDate1.compare(serialDate14);
//        int int18 = spreadsheetDate1.getDayOfWeek();
//        java.util.Date date19 = spreadsheetDate1.toDate();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-43616) + "'", int17 == (-43616));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
//        org.junit.Assert.assertNotNull(date19);
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        timeSeries1.clear();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        boolean boolean13 = day11.equals((java.lang.Object) 5);
//        boolean boolean15 = day11.equals((java.lang.Object) 100L);
//        long long16 = day11.getMiddleMillisecond();
//        long long17 = day11.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (double) (-62159500800000L));
//        boolean boolean20 = timeSeries1.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries22.removeAgedItems(false);
//        int int25 = timeSeries22.getItemCount();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        boolean boolean28 = day26.equals((java.lang.Object) 5);
//        long long29 = day26.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (double) '4');
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries33.removeAgedItems((long) (-1), false);
//        java.lang.String str37 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.previous();
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.previous();
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) year38, (org.jfree.data.time.RegularTimePeriod) year40);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries44.removeAgedItems((long) (-1), false);
//        java.lang.String str48 = timeSeries44.getDomainDescription();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year49.previous();
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year51.previous();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) year49, (org.jfree.data.time.RegularTimePeriod) year51);
//        int int54 = year40.compareTo((java.lang.Object) year49);
//        long long55 = year40.getLastMillisecond();
//        boolean boolean56 = day26.equals((java.lang.Object) year40);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries58.removeAgedItems(false);
//        java.util.Collection collection61 = timeSeries58.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries63.setMaximumItemCount(1900);
//        int int66 = timeSeries63.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries58.addAndOrUpdate(timeSeries63);
//        timeSeries58.removeAgedItems(false);
//        int int70 = day26.compareTo((java.lang.Object) timeSeries58);
//        boolean boolean71 = timeSeries1.equals((java.lang.Object) int70);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560193199999L + "'", long16 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Time" + "'", str37.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Time" + "'", str48.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(collection61);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 100, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) -1, 30, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        timeSeries2.setMaximumItemAge(1560192481327L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, class1);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries4.removeAgedItems((long) (-1), false);
        java.lang.String str8 = timeSeries4.getDomainDescription();
        timeSeries4.removeAgedItems((long) (short) -1, true);
        java.util.Collection collection12 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        timeSeries4.setRangeDescription("June 2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries4.addChangeListener(seriesChangeListener15);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection12);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        timeSeries1.clear();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        boolean boolean13 = day11.equals((java.lang.Object) 5);
//        boolean boolean15 = day11.equals((java.lang.Object) 100L);
//        long long16 = day11.getMiddleMillisecond();
//        long long17 = day11.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (double) (-62159500800000L));
//        boolean boolean20 = timeSeries1.getNotify();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries1.getNextTimePeriod();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560193199999L + "'", long16 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        java.util.Date date5 = fixedMillisecond3.getTime();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date2, timeZone6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560192438814L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Date date4 = fixedMillisecond1.getEnd();
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year4 = month3.getYear();
        int int5 = month3.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month3.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        int int10 = timeSeries9.getMaximumItemCount();
        java.lang.String str11 = timeSeries9.getRangeDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) 100L);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(8, year13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month16);
        int int18 = month16.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) (byte) -1);
        java.lang.String str21 = month16.toString();
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "August 2019" + "'", str21.equals("August 2019"));
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate3.getEndOfCurrentMonth(serialDate6);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate14 = day12.getSerialDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate19 = serialDate17.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate20 = serialDate14.getEndOfCurrentMonth(serialDate17);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate10.getEndOfCurrentMonth(serialDate23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond25.previous();
//        java.util.Date date27 = fixedMillisecond25.getTime();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date27);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date27);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("2019");
//        java.lang.String str39 = timePeriodFormatException38.toString();
//        java.lang.Class<?> wildcardClass40 = timePeriodFormatException38.getClass();
//        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Time", "1900", "Time", class41);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class41);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year30, "", "org.jfree.data.general.SeriesException: Value", class41);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate24, class41);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str39.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(class41);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) '#', false);
        timeSeries1.setDomainDescription("December");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long14 = year7.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries16.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries20.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries16.addAndOrUpdate(timeSeries20);
        boolean boolean25 = year7.equals((java.lang.Object) timeSeries24);
        long long26 = year7.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries4.removeAgedItems((long) (-1), false);
//        java.lang.String str8 = timeSeries4.getDomainDescription();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year9, (org.jfree.data.time.RegularTimePeriod) year11);
//        boolean boolean14 = day0.equals((java.lang.Object) timeSeries13);
//        java.lang.Class<?> wildcardClass15 = timeSeries13.getClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 5);
//        int int3 = day0.getDayOfMonth();
//        java.lang.String str4 = day0.toString();
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "2019", "hi!", "", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        int int7 = timeSeries4.getMaximumItemCount();
        timeSeries4.setRangeDescription("September");
        timeSeries4.setKey((java.lang.Comparable) 43626L);
        try {
            java.lang.Number number13 = timeSeries4.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1.0d);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day2.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day2.previous();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day2.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        int int11 = timeSeries1.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries1.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            java.lang.Number number15 = timeSeries1.getValue(regularTimePeriod14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.previous();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, class12);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries15.removeAgedItems((long) (-1), false);
//        java.lang.String str19 = timeSeries15.getDomainDescription();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) year22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year22);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("2019");
//        java.lang.String str29 = timePeriodFormatException28.toString();
//        java.lang.Class<?> wildcardClass30 = timePeriodFormatException28.getClass();
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year22, (java.lang.Class) wildcardClass30);
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries36.removeAgedItems((long) (-1), false);
//        java.lang.String str40 = timeSeries36.getDomainDescription();
//        timeSeries36.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable44 = timeSeries36.getKey();
//        java.lang.Object obj45 = timeSeries36.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries36);
//        java.lang.Comparable comparable47 = timeSeries36.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener48 = null;
//        timeSeries36.removePropertyChangeListener(propertyChangeListener48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond50.previous();
//        java.util.Date date52 = fixedMillisecond50.getTime();
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date52);
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date52);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date52);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date52);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date52);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries59.removeAgedItems(false);
//        int int62 = timeSeries59.getItemCount();
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        boolean boolean65 = day63.equals((java.lang.Object) 5);
//        long long66 = day63.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries59.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day63, (double) '4');
//        long long69 = day63.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day57, (org.jfree.data.time.RegularTimePeriod) day63);
//        java.util.Date date71 = day63.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = fixedMillisecond72.previous();
//        java.util.Date date74 = fixedMillisecond72.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = fixedMillisecond75.previous();
//        java.util.Date date77 = fixedMillisecond75.getTime();
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date77, timeZone78);
//        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month(date74, timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date71, timeZone78);
//        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod81);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Time" + "'", str40.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + (byte) 10 + "'", comparable44.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj45);
//        org.junit.Assert.assertTrue("'" + comparable47 + "' != '" + (byte) 10 + "'", comparable47.equals((byte) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560236399999L + "'", long66 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560150000000L + "'", long69 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Last");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate14);
//        boolean boolean16 = spreadsheetDate1.isOn(serialDate14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate19.getEndOfCurrentMonth(serialDate22);
//        int int26 = spreadsheetDate1.compare(serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean31 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate37 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = serialDate37.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate34.getEndOfCurrentMonth(serialDate37);
//        java.lang.String str41 = serialDate40.getDescription();
//        boolean boolean42 = spreadsheetDate30.isBefore(serialDate40);
//        int int43 = spreadsheetDate30.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean46 = spreadsheetDate30.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        boolean boolean47 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        int int50 = day49.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate51 = day49.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate53 = serialDate51.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths(13, serialDate53);
//        boolean boolean55 = spreadsheetDate30.isOnOrBefore(serialDate54);
//        java.util.Date date56 = spreadsheetDate30.toDate();
//        java.util.Date date57 = spreadsheetDate30.toDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate59 = spreadsheetDate30.getPreviousDayOfWeek((-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-43620) + "'", int26 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(date57);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        java.lang.Comparable comparable12 = timeSeries1.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.previous();
//        java.util.Date date17 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate25 = day23.getSerialDate();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate28 = day26.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate30 = serialDate28.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate25.getEndOfCurrentMonth(serialDate28);
//        java.lang.String str32 = serialDate31.getDescription();
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addYears(6, serialDate31);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(serialDate33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond37.previous();
//        java.util.Date date39 = fixedMillisecond37.getTime();
//        java.lang.Class class40 = null;
//        java.util.Date date41 = null;
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date41, timeZone42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date39, timeZone42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond45.previous();
//        java.util.Date date47 = fixedMillisecond45.getTime();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47, timeZone48);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date39, timeZone48);
//        java.lang.Class<?> wildcardClass51 = year50.getClass();
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day34, "org.jfree.data.time.TimePeriodFormatException: 2019", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass51);
//        int int54 = day21.compareTo((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: 2019");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 1560192477281L);
//        java.lang.String str57 = timeSeries1.getDescription();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//        org.junit.Assert.assertNull(str57);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getMonth();
        java.lang.String str3 = month0.toString();
        long long4 = month0.getSerialIndex();
        long long5 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries5.removeAgedItems((long) (-1), false);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 2958465);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries16.removeAgedItems((long) (-1), false);
        int int20 = timeSeriesDataItem14.compareTo((java.lang.Object) timeSeries16);
        java.util.Collection collection21 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        timeSeries16.setMaximumItemAge((long) 52);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(collection21);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        boolean boolean10 = timeSeries5.getNotify();
//        timeSeries5.removeAgedItems((long) 13, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
//        java.util.Date date16 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
//        java.util.Date date19 = fixedMillisecond17.getTime();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date16, timeZone20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day23, (double) (-60507964800000L), false);
//        timeSeries5.update((int) (short) 0, (java.lang.Number) 1);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries31.removeAgedItems((long) (-1), false);
//        timeSeries31.removeAgedItems((long) (short) 10, false);
//        timeSeries31.setDomainDescription("Time");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries31.addChangeListener(seriesChangeListener40);
//        java.util.Collection collection42 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries31);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        boolean boolean45 = year43.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 2958465);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries49.removeAgedItems((long) (-1), false);
//        int int53 = timeSeriesDataItem47.compareTo((java.lang.Object) timeSeries49);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        int int56 = day55.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate57 = day55.getSerialDate();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        int int59 = day58.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate60 = day58.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate62 = serialDate60.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate63 = serialDate57.getEndOfCurrentMonth(serialDate60);
//        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate63);
//        serialDate64.setDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
//        int int67 = timeSeriesDataItem47.compareTo((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: 2019");
//        java.lang.Object obj68 = timeSeriesDataItem47.clone();
//        java.lang.Object obj69 = timeSeriesDataItem47.clone();
//        try {
//            timeSeries31.add(timeSeriesDataItem47);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 10 + "'", int56 == 10);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 10 + "'", int59 == 10);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(obj68);
//        org.junit.Assert.assertNotNull(obj69);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(13, serialDate12);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate19 = serialDate17.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate19);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate13.getEndOfCurrentMonth(serialDate19);
//        boolean boolean22 = spreadsheetDate3.isOn(serialDate21);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean27 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day29.getSerialDate();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate37 = serialDate31.getEndOfCurrentMonth(serialDate34);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate37);
//        boolean boolean39 = spreadsheetDate24.isOn(serialDate37);
//        boolean boolean40 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        int int41 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean46 = spreadsheetDate43.isOn((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate50 = day48.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate52 = serialDate50.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths(13, serialDate52);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        int int56 = day55.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate57 = day55.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate59 = serialDate57.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate59);
//        org.jfree.data.time.SerialDate serialDate61 = serialDate53.getEndOfCurrentMonth(serialDate59);
//        boolean boolean62 = spreadsheetDate43.isOn(serialDate61);
//        int int63 = spreadsheetDate43.getDayOfMonth();
//        boolean boolean64 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-3) + "'", int41 == (-3));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 10 + "'", int56 == 10);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 5 + "'", int63 == 5);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = serialDate2.getPreviousDayOfWeek(3);
//        try {
//            org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek((int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) 100L);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        long long5 = month4.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24236L + "'", long5 == 24236L);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate2.getEndOfCurrentMonth(serialDate5);
//        java.lang.String str9 = serialDate8.getDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate8);
//        java.lang.Object obj11 = null;
//        int int12 = day10.compareTo(obj11);
//        org.jfree.data.time.SerialDate serialDate13 = day10.getSerialDate();
//        long long14 = day10.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43646L + "'", long14 == 43646L);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str3 = spreadsheetDate2.toString();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        boolean boolean7 = spreadsheetDate2.isOn(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.lang.Class<?> wildcardClass9 = spreadsheetDate2.getClass();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5-January-1900" + "'", str3.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long14 = year7.getSerialIndex();
        long long15 = year7.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries3.removeAgedItems((long) (-1), false);
//        java.lang.String str7 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
//        java.lang.Number number15 = timeSeries12.getValue(regularTimePeriod14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 6);
//        java.lang.Object obj22 = null;
//        int int23 = fixedMillisecond16.compareTo(obj22);
//        java.lang.Object obj24 = null;
//        int int25 = fixedMillisecond16.compareTo(obj24);
//        int int26 = month0.compareTo((java.lang.Object) fixedMillisecond16);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate35 = day33.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate37 = serialDate35.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate32.getEndOfCurrentMonth(serialDate35);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate38);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        int int42 = day41.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = day41.getSerialDate();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        int int45 = day44.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate46 = day44.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate49 = serialDate43.getEndOfCurrentMonth(serialDate46);
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate49);
//        org.jfree.data.time.SerialDate serialDate52 = serialDate49.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate53 = serialDate39.getEndOfCurrentMonth(serialDate52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate52);
//        boolean boolean55 = spreadsheetDate28.isOnOrBefore(serialDate52);
//        int int56 = fixedMillisecond16.compareTo((java.lang.Object) spreadsheetDate28);
//        try {
//            org.jfree.data.time.SerialDate serialDate58 = spreadsheetDate28.getPreviousDayOfWeek((-3));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560192515092L + "'", long18 == 1560192515092L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries2.removeAgedItems((long) (-1), false);
        java.lang.String str6 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year9);
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long14 = year7.getSerialIndex();
        int int15 = year7.getYear();
        java.util.Date date16 = year7.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.previous();
        java.util.Date date20 = fixedMillisecond18.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.previous();
        java.util.Date date23 = fixedMillisecond21.getTime();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23, timeZone24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date20, timeZone24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date16, timeZone24);
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date16, timeZone30);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date16);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.previous();
        java.lang.String str12 = year8.toString();
        int int13 = year8.getYear();
        long long14 = year8.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test319");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate5.getEndOfCurrentMonth(serialDate8);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate22 = serialDate16.getEndOfCurrentMonth(serialDate19);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate22);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate22.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate12.getEndOfCurrentMonth(serialDate25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate25);
//        boolean boolean28 = spreadsheetDate1.isOnOrBefore(serialDate25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond30.previous();
//        java.util.Date date32 = fixedMillisecond30.getTime();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date32);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date32);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day37.next();
//        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate39);
//        org.jfree.data.time.SerialDate serialDate41 = spreadsheetDate1.getEndOfCurrentMonth(serialDate39);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate50 = day48.getSerialDate();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        int int52 = day51.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate53 = day51.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate55 = serialDate53.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate56 = serialDate50.getEndOfCurrentMonth(serialDate53);
//        java.lang.String str57 = serialDate56.getDescription();
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addYears(6, serialDate56);
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addYears(0, serialDate58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate61 = day60.getSerialDate();
//        boolean boolean63 = spreadsheetDate45.isInRange(serialDate59, serialDate61, 13);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        int int66 = day65.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate67 = day65.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate69 = serialDate67.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addMonths(13, serialDate69);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        int int73 = day72.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate74 = day72.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate76 = serialDate74.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate76);
//        org.jfree.data.time.SerialDate serialDate78 = serialDate70.getEndOfCurrentMonth(serialDate76);
//        java.lang.String str79 = serialDate76.getDescription();
//        serialDate76.setDescription("org.jfree.data.general.SeriesException: Value");
//        boolean boolean82 = spreadsheetDate43.isInRange(serialDate61, serialDate76);
//        boolean boolean83 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNull(str57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 10 + "'", int66 == 10);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 10 + "'", int73 == 10);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertNull(str79);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test320");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        java.lang.Comparable comparable12 = timeSeries1.getKey();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate18.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate15.getEndOfCurrentMonth(serialDate18);
//        java.lang.String str22 = serialDate21.getDescription();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(1900);
//        java.lang.String str26 = year25.toString();
//        long long27 = year25.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
//        java.util.Date date31 = fixedMillisecond29.getTime();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date31);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date31);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries38.removeAgedItems((long) (-1), false);
//        java.lang.String str42 = timeSeries38.getDomainDescription();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year43.previous();
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.previous();
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) year43, (org.jfree.data.time.RegularTimePeriod) year45);
//        long long48 = year43.getSerialIndex();
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (byte) 1, year43);
//        long long50 = year43.getSerialIndex();
//        int int51 = year43.getYear();
//        java.util.Date date52 = year43.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date52);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond54.previous();
//        java.util.Date date56 = fixedMillisecond54.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond57.previous();
//        java.util.Date date59 = fixedMillisecond57.getTime();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date59, timeZone60);
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date56, timeZone60);
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date52, timeZone60);
//        java.lang.Class class64 = null;
//        java.util.Date date65 = null;
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date65, timeZone66);
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date52, timeZone66);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date31, timeZone66);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day69, (double) 1560192445731L);
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
//        java.lang.String str73 = year72.toString();
//        int int74 = year72.getYear();
//        java.lang.Object obj75 = null;
//        int int76 = year72.compareTo(obj75);
//        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries78.removeAgedItems((long) (-1), false);
//        java.lang.String str82 = timeSeries78.getDomainDescription();
//        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = year83.previous();
//        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = year85.previous();
//        org.jfree.data.time.TimeSeries timeSeries87 = timeSeries78.createCopy((org.jfree.data.time.RegularTimePeriod) year83, (org.jfree.data.time.RegularTimePeriod) year85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = year85.previous();
//        boolean boolean89 = year72.equals((java.lang.Object) year85);
//        org.jfree.data.time.TimeSeries timeSeries91 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        timeSeries91.fireSeriesChanged();
//        timeSeries91.removeAgedItems((long) (short) 10, false);
//        boolean boolean96 = year85.equals((java.lang.Object) false);
//        int int97 = day69.compareTo((java.lang.Object) false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1900" + "'", str26.equals("1900"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2208960000000L) + "'", long27 == (-2208960000000L));
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Time" + "'", str42.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2019L + "'", long50 == 2019L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNull(timeSeriesDataItem71);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "2019" + "'", str73.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2019 + "'", int74 == 2019);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "Time" + "'", str82.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//        org.junit.Assert.assertNotNull(timeSeries87);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
//        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
//        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 1 + "'", int97 == 1);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        java.lang.Class class3 = null;
//        java.util.Date date4 = null;
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date2, timeZone5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.previous();
//        java.util.Date date10 = fixedMillisecond8.getTime();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10, timeZone11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date2, timeZone11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date2);
//        long long15 = fixedMillisecond14.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192517690L + "'", long15 == 1560192517690L);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        java.lang.Comparable comparable12 = timeSeries1.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.previous();
//        java.util.Date date17 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date17);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries24.removeAgedItems(false);
//        int int27 = timeSeries24.getItemCount();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 5);
//        long long31 = day28.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (double) '4');
//        long long34 = day28.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond36.previous();
//        java.util.Date date38 = fixedMillisecond36.getTime();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date38);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries45.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries49.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries45.addAndOrUpdate(timeSeries49);
//        java.lang.Class class54 = timeSeries49.getTimePeriodClass();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.lang.String str57 = spreadsheetDate56.toString();
//        java.util.Date date58 = spreadsheetDate56.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond59.previous();
//        java.util.Date date61 = fixedMillisecond59.getTime();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date61, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date58, timeZone62);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date38, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year65.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year65);
//        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
//        boolean boolean70 = year68.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year68, (java.lang.Number) 2958465);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = timeSeriesDataItem72.getPeriod();
//        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean75 = timeSeriesDataItem72.equals((java.lang.Object) timeZone74);
//        try {
//            timeSeries1.add(timeSeriesDataItem72);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560236399999L + "'", long31 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560150000000L + "'", long34 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "5-January-1900" + "'", str57.equals("5-January-1900"));
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertNotNull(timeZone74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1577865599999L);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 6);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond14.getLastMillisecond(calendar20);
//        long long22 = fixedMillisecond14.getFirstMillisecond();
//        long long23 = fixedMillisecond14.getLastMillisecond();
//        java.util.Date date24 = fixedMillisecond14.getTime();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192517782L + "'", long16 == 1560192517782L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560192517782L + "'", long21 == 1560192517782L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560192517782L + "'", long22 == 1560192517782L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560192517782L + "'", long23 == 1560192517782L);
//        org.junit.Assert.assertNotNull(date24);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        int int10 = timeSeries9.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean15 = day13.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 1.0d);
//        long long18 = day13.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day13.next();
//        java.lang.Number number20 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate(regularTimePeriod19, number20);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1549007999999L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Date date4 = fixedMillisecond2.getTime();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        long long6 = month5.getMiddleMillisecond();
        long long7 = month5.getFirstMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month5);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test327");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate10);
//        java.lang.String str14 = serialDate13.getDescription();
//        boolean boolean15 = spreadsheetDate3.isBefore(serialDate13);
//        int int16 = spreadsheetDate3.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean19 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean24 = spreadsheetDate21.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        int int26 = day25.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate27 = day25.getSerialDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate30 = day28.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate32 = serialDate30.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate27.getEndOfCurrentMonth(serialDate30);
//        java.lang.String str34 = serialDate33.getDescription();
//        boolean boolean35 = spreadsheetDate23.isBefore(serialDate33);
//        int int36 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean39 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean44 = spreadsheetDate41.isOn((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        int int46 = day45.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate47 = day45.getSerialDate();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate50 = day48.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate52 = serialDate50.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate53 = serialDate47.getEndOfCurrentMonth(serialDate50);
//        java.lang.String str54 = serialDate53.getDescription();
//        boolean boolean55 = spreadsheetDate43.isBefore(serialDate53);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        int int58 = day57.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate59 = day57.getSerialDate();
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        int int61 = day60.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate62 = day60.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate64 = serialDate62.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate65 = serialDate59.getEndOfCurrentMonth(serialDate62);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate65);
//        org.jfree.data.time.SerialDate serialDate68 = serialDate65.getPreviousDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate69 = spreadsheetDate43.getEndOfCurrentMonth(serialDate65);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        int int73 = day72.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate74 = day72.getSerialDate();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        int int76 = day75.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate77 = day75.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate79 = serialDate77.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate80 = serialDate74.getEndOfCurrentMonth(serialDate77);
//        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate80);
//        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addDays(31, serialDate81);
//        boolean boolean83 = spreadsheetDate23.isInRange(serialDate65, serialDate82);
//        boolean boolean84 = spreadsheetDate18.isOn(serialDate65);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNull(str34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNull(str54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 10 + "'", int58 == 10);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 10 + "'", int73 == 10);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 10 + "'", int76 == 10);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertNotNull(serialDate81);
//        org.junit.Assert.assertNotNull(serialDate82);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        timeSeries1.clear();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate16.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate19 = serialDate13.getEndOfCurrentMonth(serialDate16);
//        java.lang.String str20 = serialDate19.getDescription();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate19);
//        long long22 = day21.getMiddleMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day21);
//        timeSeries1.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561921199999L + "'", long22 == 1561921199999L);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long11 = year8.getSerialIndex();
        long long12 = year8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries16.fireSeriesChanged();
        boolean boolean18 = timeSeriesDataItem14.equals((java.lang.Object) timeSeries16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem14.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem14.getPeriod();
        java.lang.Number number21 = timeSeriesDataItem14.getValue();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 5 + "'", number21.equals(5));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-43620));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate14);
//        boolean boolean16 = spreadsheetDate1.isOn(serialDate14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate19.getEndOfCurrentMonth(serialDate22);
//        int int26 = spreadsheetDate1.compare(serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean29 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        int int30 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean35 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int38 = day37.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        int int41 = day40.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate44 = serialDate42.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate39.getEndOfCurrentMonth(serialDate42);
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate45);
//        boolean boolean47 = spreadsheetDate32.isOn(serialDate45);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate50 = day48.getSerialDate();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        int int52 = day51.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate53 = day51.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate55 = serialDate53.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate56 = serialDate50.getEndOfCurrentMonth(serialDate53);
//        int int57 = spreadsheetDate32.compare(serialDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean60 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
//        boolean boolean61 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
//        java.lang.String str62 = spreadsheetDate1.toString();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-43620) + "'", int26 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-43620) + "'", int57 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "5-January-1900" + "'", str62.equals("5-January-1900"));
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560192438814L);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test333");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(13, serialDate12);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate19 = serialDate17.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate19);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate13.getEndOfCurrentMonth(serialDate19);
//        boolean boolean22 = spreadsheetDate3.isOn(serialDate21);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean27 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day29.getSerialDate();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate37 = serialDate31.getEndOfCurrentMonth(serialDate34);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate37);
//        boolean boolean39 = spreadsheetDate24.isOn(serialDate37);
//        boolean boolean40 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        int int41 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean46 = spreadsheetDate43.isOn((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate50 = day48.getSerialDate();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        int int52 = day51.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate53 = day51.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate55 = serialDate53.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate56 = serialDate50.getEndOfCurrentMonth(serialDate53);
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate56);
//        boolean boolean58 = spreadsheetDate43.isOn(serialDate56);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        int int60 = day59.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate61 = day59.getSerialDate();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        int int63 = day62.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate64 = day62.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate66 = serialDate64.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate67 = serialDate61.getEndOfCurrentMonth(serialDate64);
//        int int68 = spreadsheetDate43.compare(serialDate61);
//        int int69 = spreadsheetDate1.compare(serialDate61);
//        java.lang.String str70 = serialDate61.toString();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-3) + "'", int41 == (-3));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-43620) + "'", int68 == (-43620));
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-43623) + "'", int69 == (-43623));
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "10-June-2019" + "'", str70.equals("10-June-2019"));
//    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        int int10 = timeSeries9.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
//        int int15 = fixedMillisecond11.compareTo((java.lang.Object) "2019");
//        java.lang.Object obj16 = null;
//        int int17 = fixedMillisecond11.compareTo(obj16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond11.previous();
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560192519793L + "'", long13 == 1560192519793L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries5.removeAgedItems(false);
//        java.util.Collection collection8 = timeSeries5.getTimePeriods();
//        int int9 = day0.compareTo((java.lang.Object) timeSeries5);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        java.lang.String str11 = year10.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 1560192449430L);
//        int int14 = year10.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        boolean boolean7 = year5.equals((java.lang.Object) 100L);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(8, year5);
//        java.lang.String str9 = year5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year5.previous();
//        boolean boolean11 = day3.equals((java.lang.Object) regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        java.lang.String str2 = year1.toString();
        long long3 = year1.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = year1.getClass();
        int int5 = year1.getYear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1900" + "'", str2.equals("1900"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208960000000L) + "'", long3 == (-2208960000000L));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate14);
//        boolean boolean16 = spreadsheetDate1.isOn(serialDate14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate19.getEndOfCurrentMonth(serialDate22);
//        int int26 = spreadsheetDate1.compare(serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean31 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate37 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = serialDate37.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate34.getEndOfCurrentMonth(serialDate37);
//        java.lang.String str41 = serialDate40.getDescription();
//        boolean boolean42 = spreadsheetDate30.isBefore(serialDate40);
//        int int43 = spreadsheetDate30.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
//        boolean boolean46 = spreadsheetDate30.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        boolean boolean47 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        int int50 = day49.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate51 = day49.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate53 = serialDate51.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths(13, serialDate53);
//        boolean boolean55 = spreadsheetDate30.isOnOrBefore(serialDate54);
//        java.util.Date date56 = spreadsheetDate30.toDate();
//        java.util.Date date57 = spreadsheetDate30.toDate();
//        org.jfree.data.time.SerialDate serialDate58 = null;
//        try {
//            boolean boolean59 = spreadsheetDate30.isOnOrAfter(serialDate58);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-43620) + "'", int26 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(date57);
//    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getPreviousDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate15 = serialDate9.getEndOfCurrentMonth(serialDate12);
//        java.lang.String str16 = serialDate15.getDescription();
//        boolean boolean17 = spreadsheetDate5.isBefore(serialDate15);
//        boolean boolean18 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        int int19 = spreadsheetDate5.getDayOfMonth();
//        java.util.Date date20 = spreadsheetDate5.toDate();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
//        org.junit.Assert.assertNotNull(date20);
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) "2019");
//        java.lang.Object obj5 = null;
//        int int6 = fixedMillisecond0.compareTo(obj5);
//        java.util.Date date7 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192519932L + "'", long2 == 1560192519932L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.lang.String str2 = spreadsheetDate1.toString();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5-January-1900" + "'", str2.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        timeSeries1.removeAgedItems((long) (-1), false);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) '#', false);
        java.lang.String str9 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNull(str9);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test343");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries1.removeAgedItems((long) (-1), false);
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        timeSeries1.removeAgedItems((long) (short) -1, true);
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        java.lang.Comparable comparable12 = timeSeries1.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.previous();
//        java.util.Date date17 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date17);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries24.removeAgedItems(false);
//        int int27 = timeSeries24.getItemCount();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 5);
//        long long31 = day28.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (double) '4');
//        long long34 = day28.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond36.previous();
//        java.util.Date date38 = fixedMillisecond36.getTime();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date38);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries45.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
//        timeSeries49.removeAgedItems((long) (-1), false);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries45.addAndOrUpdate(timeSeries49);
//        java.lang.Class class54 = timeSeries49.getTimePeriodClass();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.lang.String str57 = spreadsheetDate56.toString();
//        java.util.Date date58 = spreadsheetDate56.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond59.previous();
//        java.util.Date date61 = fixedMillisecond59.getTime();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date61, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date58, timeZone62);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date38, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year65.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year65);
//        long long68 = year65.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560236399999L + "'", long31 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560150000000L + "'", long34 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "5-January-1900" + "'", str57.equals("5-January-1900"));
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 2019L + "'", long68 == 2019L);
//    }
//}

