import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairValue(136.0d, true);
        java.awt.Color color12 = java.awt.Color.MAGENTA;
        xYPlot7.setDomainCrosshairPaint((java.awt.Paint) color12);
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint15, stroke16);
        org.jfree.chart.util.Layer layer18 = null;
        try {
            xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker17, layer18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace15, false);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot6.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.text.TextBlock textBlock22 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine23 = textBlock22.getLastLine();
        java.util.List list24 = textBlock22.getLines();
        java.util.List list25 = textBlock22.getLines();
        xYPlot6.drawDomainTickBands(graphics2D20, rectangle2D21, list25);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(textLine23);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 0, (double) 500, plotRenderingInfo5, point2D6);
        categoryPlot0.clearAnnotations();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation(100);
        try {
            categoryPlot0.setDomainAxisLocation((int) (short) -1, axisLocation20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot8);
        xYPlot8.setRangeCrosshairValue(136.0d, true);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        xYPlot8.setDomainCrosshairPaint((java.awt.Paint) color13);
        boolean boolean15 = ringPlot0.equals((java.lang.Object) color13);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = null;
        ringPlot0.setURLGenerator(pieURLGenerator16);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace15, false);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot6.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = piePlot25.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation27 = piePlot25.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator28 = piePlot25.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font22, (org.jfree.chart.plot.Plot) piePlot25, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = jFreeChart30.getPadding();
        legendTitle19.setLegendItemGraphicPadding(rectangleInsets31);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(rotation27);
        org.junit.Assert.assertNull(pieSectionLabelGenerator28);
        org.junit.Assert.assertNotNull(rectangleInsets31);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        org.jfree.chart.plot.Plot plot9 = null;
        dateAxis1.setPlot(plot9);
        dateAxis1.setLowerBound((double) 10L);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle5.setText("");
        boolean boolean8 = textTitle5.getExpandToFitSpace();
        boolean boolean9 = textTitle5.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = legendTitle12.getHorizontalAlignment();
        legendTitle12.setHeight(0.0d);
        java.awt.Font font16 = legendTitle12.getItemFont();
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font16, paint17);
        textTitle5.setFont(font16);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        textTitle5.setPaint((java.awt.Paint) color20);
        java.awt.Font font22 = textTitle5.getFont();
        java.awt.Image image26 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo30 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image26, "hi!", "hi!", "hi!");
        projectInfo30.addOptionalLibrary("hi!");
        blockContainer3.add((org.jfree.chart.block.Block) textTitle5, (java.lang.Object) "hi!");
        textTitle5.setToolTipText("Pie Plot");
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (java.lang.Comparable) 1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(pieDataset6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = legendTitle4.getHorizontalAlignment();
        legendTitle4.setHeight(0.0d);
        java.awt.Font font8 = legendTitle4.getItemFont();
        waferMapPlot2.setNoDataMessageFont(font8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat12 = null;
        dateAxis11.setDateFormatOverride(dateFormat12);
        java.awt.Color color14 = java.awt.Color.GRAY;
        dateAxis11.setTickLabelPaint((java.awt.Paint) color14);
        java.util.Date date16 = dateAxis11.getMinimumDate();
        java.text.DateFormat dateFormat17 = null;
        dateAxis11.setDateFormatOverride(dateFormat17);
        java.lang.String str19 = dateAxis11.getLabel();
        java.awt.Paint paint20 = dateAxis11.getTickLabelPaint();
        waferMapPlot2.setOutlinePaint(paint20);
        java.lang.String str22 = waferMapPlot2.getPlotType();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.Point2D point2D25 = null;
        org.jfree.chart.plot.PlotState plotState26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            waferMapPlot2.draw(graphics2D23, rectangle2D24, point2D25, plotState26, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "WMAP_Plot" + "'", str22.equals("WMAP_Plot"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range4 = org.jfree.data.Range.expand(range1, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range4, (double) (-1), false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean13 = range10.intersects((double) (byte) 1, (double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range7, lengthConstraintType8, (double) (-1), range10, lengthConstraintType14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint15.toFixedHeight((double) 15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint17.toFixedWidth(0.14d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = rectangleConstraint17.getWidthConstraintType();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        categoryPlot0.setAnchorValue((double) 1);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot6.getRendererForDataset(xYDataset11);
        java.awt.Paint paint14 = xYPlot6.getQuadrantPaint(0);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = null;
        xYPlot6.setFixedLegendItems(legendItemCollection15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot6.drawDomainTickBands(graphics2D17, rectangle2D18, list19);
        java.awt.Stroke stroke21 = xYPlot6.getRangeGridlineStroke();
        xYPlot6.clearRangeMarkers();
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4);
        java.awt.Stroke stroke6 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer(categoryItemRenderer7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = null;
        try {
            jFreeChart8.titleChanged(titleChangeEvent9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint1, stroke2);
        double double4 = valueMarker3.getValue();
        java.awt.Paint paint5 = valueMarker3.getLabelPaint();
        try {
            valueMarker3.setAlpha((float) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        int int7 = xYPlot6.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot6.getDomainAxis((int) (short) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot6.getDomainAxisEdge();
        xYPlot6.setForegroundAlpha((float) 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) (short) -1, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot0.setRenderer(categoryItemRenderer11, false);
        categoryPlot0.setWeight(1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        float float2 = piePlot1.getForegroundAlpha();
        double double3 = piePlot1.getShadowXOffset();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        piePlot1.setSectionOutlinesVisible(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer((int) '4', categoryItemRenderer5, false);
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            boolean boolean10 = categoryPlot0.removeDomainMarker(marker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint1, stroke2);
        double double4 = valueMarker3.getValue();
        java.awt.Paint paint5 = valueMarker3.getLabelPaint();
        java.awt.Paint paint6 = valueMarker3.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker3.setLabelAnchor(rectangleAnchor7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot0.setRenderer(categoryItemRenderer6, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomRangeAxes(3.0d, (double) 2, plotRenderingInfo11, point2D12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot0.setRenderer(10, categoryItemRenderer15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot22);
        xYPlot22.setRangeCrosshairValue(136.0d, true);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot22);
        xYPlot6.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart27);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getDarkerSides();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle15.setText("");
        boolean boolean18 = textTitle15.getExpandToFitSpace();
        boolean boolean19 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = legendTitle22.getHorizontalAlignment();
        legendTitle22.setHeight(0.0d);
        java.awt.Font font26 = legendTitle22.getItemFont();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font26, paint27);
        textTitle15.setFont(font26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = textTitle15.getVerticalAlignment();
        legendTitle12.setVerticalAlignment(verticalAlignment30);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) legendTitle12);
        java.awt.Paint paint33 = legendTitle12.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle12.getPadding();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat5 = null;
        dateAxis4.setDateFormatOverride(dateFormat5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color7);
        piePlot1.setBackgroundPaint((java.awt.Paint) color7);
        java.lang.Object obj10 = piePlot1.clone();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        xYPlot18.drawAnnotations(graphics2D19, rectangle2D20, plotRenderingInfo21);
        xYPlot18.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke25 = xYPlot18.getDomainZeroBaselineStroke();
        java.awt.Stroke stroke26 = xYPlot18.getRangeZeroBaselineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 128, stroke26);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator28 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator28);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleAnchor.RIGHT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range6 = org.jfree.data.Range.expand(range3, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range6, (double) (-1), false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean15 = range12.intersects((double) (byte) 1, (double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range9, lengthConstraintType10, (double) (-1), range12, lengthConstraintType16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint17.toUnconstrainedWidth();
        org.jfree.data.Range range19 = rectangleConstraint18.getWidthRange();
        boolean boolean20 = plotOrientation0.equals((java.lang.Object) range19);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        textTitle1.setID("RectangleEdge.BOTTOM");
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle1.setFont(font18);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat22 = null;
        dateAxis21.setDateFormatOverride(dateFormat22);
        java.awt.Color color24 = java.awt.Color.GRAY;
        dateAxis21.setTickLabelPaint((java.awt.Paint) color24);
        java.util.Date date26 = dateAxis21.getMinimumDate();
        java.text.DateFormat dateFormat27 = null;
        dateAxis21.setDateFormatOverride(dateFormat27);
        java.lang.String str29 = dateAxis21.getLabel();
        java.awt.Paint paint30 = dateAxis21.getTickLabelPaint();
        textTitle1.setBackgroundPaint(paint30);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent32 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.JFreeChart jFreeChart33 = null;
        titleChangeEvent32.setChart(jFreeChart33);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor17 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        boolean boolean18 = textTitle1.equals((java.lang.Object) pieLabelDistributor17);
        boolean boolean19 = textTitle1.getExpandToFitSpace();
        boolean boolean20 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        boolean boolean8 = categoryPlot0.render(graphics2D4, rectangle2D5, 1, plotRenderingInfo7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation((int) (byte) 0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle15.setText("");
        boolean boolean18 = textTitle15.getExpandToFitSpace();
        boolean boolean19 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = legendTitle22.getHorizontalAlignment();
        legendTitle22.setHeight(0.0d);
        java.awt.Font font26 = legendTitle22.getItemFont();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font26, paint27);
        textTitle15.setFont(font26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = textTitle15.getVerticalAlignment();
        legendTitle12.setVerticalAlignment(verticalAlignment30);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent35 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle34);
        jFreeChart10.addLegend(legendTitle34);
        org.jfree.chart.title.LegendTitle legendTitle37 = jFreeChart10.getLegend();
        java.awt.Font font38 = legendTitle37.getItemFont();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        try {
            legendTitle37.setBounds(rectangle2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(legendTitle37);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle10.setVerticalAlignment(verticalAlignment12);
        jFreeChart8.addLegend(legendTitle10);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle16.setText("");
        textTitle16.setText("UnitType.ABSOLUTE");
        jFreeChart8.setTitle(textTitle16);
        org.jfree.chart.title.Title title23 = jFreeChart8.getSubtitle(0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(title23);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        double double3 = piePlot1.getMaximumLabelWidth();
        org.jfree.chart.util.Rotation rotation4 = piePlot1.getDirection();
        java.lang.String str5 = rotation4.toString();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Rotation.CLOCKWISE" + "'", str5.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range9, (double) (short) 0, (double) (byte) 0);
        double double13 = range9.getLowerBound();
        dateAxis1.setRangeWithMargins(range9);
        org.jfree.data.Range range17 = org.jfree.data.Range.shift(range9, (double) 10, false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get((int) '4');
        java.lang.Object obj3 = objectList0.clone();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("hi!");
        java.lang.String str10 = projectInfo7.getVersion();
        java.util.List list11 = projectInfo7.getContributors();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNull(list11);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.awt.Paint paint5 = multiplePiePlot4.getNoDataMessagePaint();
        org.jfree.data.category.CategoryDataset categoryDataset6 = multiplePiePlot4.getDataset();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(categoryDataset6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color5 = java.awt.Color.GRAY;
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { paint1, paint2, color3, paint4, color5, paint6 };
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color9 = java.awt.Color.GRAY;
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color8, color9, color10, paint11, color12, color13 };
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color16 = java.awt.Color.GRAY;
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color15, color16, paint17 };
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke20 = null;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke20 };
        java.awt.Shape[] shapeArray22 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray14, paintArray18, strokeArray19, strokeArray21, shapeArray22);
        java.lang.Object obj24 = defaultDrawingSupplier23.clone();
        java.awt.Paint paint25 = defaultDrawingSupplier23.getNextPaint();
        org.jfree.chart.StrokeMap strokeMap26 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo27 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str28 = basicProjectInfo27.getVersion();
        boolean boolean29 = strokeMap26.equals((java.lang.Object) str28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        xYPlot36.drawAnnotations(graphics2D37, rectangle2D38, plotRenderingInfo39);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double47 = rectangleInsets45.calculateLeftOutset((double) 10.0f);
        xYPlot36.setAxisOffset(rectangleInsets45);
        xYPlot36.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke51 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot36.setDomainZeroBaselineStroke(stroke51);
        boolean boolean53 = strokeMap26.equals((java.lang.Object) stroke51);
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        ringPlot54.setSectionDepth(0.08d);
        java.awt.Paint paint57 = ringPlot54.getSeparatorPaint();
        org.jfree.data.xy.XYDataset xYDataset58 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset58, (org.jfree.chart.axis.ValueAxis) numberAxis3D60, (org.jfree.chart.axis.ValueAxis) dateAxis62, xYItemRenderer63);
        java.awt.Graphics2D graphics2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        xYPlot64.drawAnnotations(graphics2D65, rectangle2D66, plotRenderingInfo67);
        xYPlot64.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke71 = xYPlot64.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker73 = new org.jfree.chart.plot.ValueMarker(2.0d, paint25, stroke51, paint57, stroke71, (float) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset74 = null;
        org.jfree.chart.plot.PiePlot piePlot75 = new org.jfree.chart.plot.PiePlot(pieDataset74);
        float float76 = piePlot75.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat84 = null;
        dateAxis83.setDateFormatOverride(dateFormat84);
        java.awt.Color color86 = java.awt.Color.GRAY;
        dateAxis83.setTickLabelPaint((java.awt.Paint) color86);
        boolean boolean88 = rectangleInsets81.equals((java.lang.Object) color86);
        float[] floatArray95 = new float[] { 100L, '#', (byte) 100, (short) 1, (-1L), (byte) -1 };
        float[] floatArray96 = color86.getRGBColorComponents(floatArray95);
        piePlot75.setLabelShadowPaint((java.awt.Paint) color86);
        valueMarker73.setLabelPaint((java.awt.Paint) color86);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 35.0d + "'", double47 == 35.0d);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertTrue("'" + float76 + "' != '" + 1.0f + "'", float76 == 1.0f);
        org.junit.Assert.assertNotNull(color86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(floatArray95);
        org.junit.Assert.assertNotNull(floatArray96);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D0.setTickUnit(numberTickUnit1, true, false);
        java.text.NumberFormat numberFormat5 = numberAxis3D0.getNumberFormatOverride();
        java.lang.String str6 = numberAxis3D0.getLabel();
        java.text.NumberFormat numberFormat7 = numberAxis3D0.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(numberFormat7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        waferMapPlot6.setNoDataMessageFont(font12);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 100L, font12);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis3D0.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = legendTitle21.getLegendItemGraphicEdge();
        try {
            double double23 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor16, (int) '#', 1, rectangle2D19, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace15, false);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot6.getFixedLegendItems();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer25);
        int int27 = xYPlot26.getDatasetCount();
        java.awt.Paint paint28 = xYPlot26.getDomainGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer35);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot36.getDomainAxisLocation(100);
        xYPlot26.setRangeAxisLocation(axisLocation39, false);
        xYPlot6.setRangeAxisLocation(0, axisLocation39, false);
        try {
            xYPlot6.setBackgroundImageAlpha((float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation39);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot7.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot7.zoomDomainAxes(0.08d, (double) 1.0f, plotRenderingInfo15, point2D16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot7.getRangeAxisLocation();
        xYPlot7.configureRangeAxes();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYPlot7.rendererChanged(rendererChangeEvent20);
        boolean boolean22 = xYPlot7.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel(0, attributedString2);
        java.lang.Object obj4 = null;
        boolean boolean5 = standardPieSectionLabelGenerator0.equals(obj4);
        java.lang.Object obj6 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = numberAxis3D0.getNumberFormatOverride();
        java.awt.Paint paint2 = numberAxis3D0.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.String str6 = rectangleEdge5.toString();
        try {
            double double7 = numberAxis3D0.java2DToValue(100.0d, rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleEdge.BOTTOM" + "'", str6.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace15, false);
        java.awt.Stroke stroke18 = null;
        try {
            xYPlot6.setRangeGridlineStroke(stroke18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat5 = null;
        dateAxis4.setDateFormatOverride(dateFormat5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color7);
        piePlot1.setBackgroundPaint((java.awt.Paint) color7);
        java.lang.Object obj10 = piePlot1.clone();
        piePlot1.setLabelLinksVisible(false);
        java.awt.Paint paint13 = piePlot1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range8, false, false);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat14 = null;
        dateAxis13.setDateFormatOverride(dateFormat14);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        dateAxis17.setFixedDimension((double) 1.0f);
        dateAxis17.setTickMarkOutsideLength((float) 1);
        java.util.Date date22 = dateAxis17.getMaximumDate();
        dateAxis13.setMinimumDate(date22);
        dateAxis5.setMaximumDate(date22);
        double double25 = dateAxis5.getUpperMargin();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis5.getTickUnit();
        boolean boolean27 = chartChangeEventType0.equals((java.lang.Object) dateAxis5);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        xYPlot6.setRangeCrosshairLockedOnData(true);
        xYPlot6.clearAnnotations();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = null;
        try {
            xYPlot6.setSeriesRenderingOrder(seriesRenderingOrder14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str2 = basicProjectInfo1.getVersion();
        boolean boolean3 = strokeMap0.equals((java.lang.Object) str2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYPlot10.drawAnnotations(graphics2D11, rectangle2D12, plotRenderingInfo13);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double21 = rectangleInsets19.calculateLeftOutset((double) 10.0f);
        xYPlot10.setAxisOffset(rectangleInsets19);
        xYPlot10.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot10.setDomainZeroBaselineStroke(stroke25);
        boolean boolean27 = strokeMap0.equals((java.lang.Object) stroke25);
        java.awt.Stroke stroke29 = strokeMap0.getStroke((java.lang.Comparable) "Rotation.CLOCKWISE");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 35.0d + "'", double21 == 35.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(stroke29);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("PlotOrientation.HORIZONTAL");
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot6.setDomainZeroBaselineStroke(stroke21);
        xYPlot6.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        waferMapPlot6.setNoDataMessageFont(font12);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 100L, font12);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis3D0.getCategoryLabelPositions();
        categoryAxis3D0.setLowerMargin((-7.0d));
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = legendTitle20.getHorizontalAlignment();
        legendTitle20.setHeight(0.0d);
        java.awt.Font font24 = legendTitle20.getItemFont();
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=1.0]", font24);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, (org.jfree.chart.axis.ValueAxis) dateAxis33, xYItemRenderer34);
        int int36 = xYPlot35.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot35.getDomainAxis((int) (short) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot35.getDomainAxisEdge();
        try {
            double double40 = categoryAxis3D0.getCategoryStart((int) '4', (int) (byte) -1, rectangle2D28, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(valueAxis38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        float[] floatArray4 = null;
        float[] floatArray5 = color1.getComponents(colorSpace3, floatArray4);
        java.awt.Color color6 = java.awt.Color.GRAY;
        java.awt.Color color7 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        float[] floatArray9 = null;
        float[] floatArray10 = color6.getComponents(colorSpace8, floatArray9);
        float[] floatArray11 = color0.getComponents(colorSpace3, floatArray10);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairValue(136.0d, true);
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot7.getDataset();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        double double15 = legendTitle14.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle14.setVerticalAlignment(verticalAlignment16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat20 = null;
        dateAxis19.setDateFormatOverride(dateFormat20);
        java.awt.Color color22 = java.awt.Color.GRAY;
        dateAxis19.setTickLabelPaint((java.awt.Paint) color22);
        boolean boolean24 = verticalAlignment16.equals((java.lang.Object) color22);
        java.awt.Color color25 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace26 = color25.getColorSpace();
        java.awt.Color color27 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace28 = color27.getColorSpace();
        java.awt.color.ColorSpace colorSpace29 = color27.getColorSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat37 = null;
        dateAxis36.setDateFormatOverride(dateFormat37);
        java.awt.Color color39 = java.awt.Color.GRAY;
        dateAxis36.setTickLabelPaint((java.awt.Paint) color39);
        boolean boolean41 = rectangleInsets34.equals((java.lang.Object) color39);
        float[] floatArray48 = new float[] { 100L, '#', (byte) 100, (short) 1, (-1L), (byte) -1 };
        float[] floatArray49 = color39.getRGBColorComponents(floatArray48);
        float[] floatArray50 = color27.getRGBColorComponents(floatArray49);
        float[] floatArray51 = color22.getComponents(colorSpace26, floatArray49);
        xYPlot7.setRangeZeroBaselinePaint((java.awt.Paint) color22);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(colorSpace26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Color color4 = java.awt.Color.GRAY;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (short) 1, 0.12d, 0.14d, (double) ' ', (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        int int7 = xYPlot6.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot6.getDomainAxis((int) (short) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot6.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace11, false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot6.getRendererForDataset(xYDataset11);
        java.awt.Paint paint14 = xYPlot6.getQuadrantPaint(0);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = null;
        xYPlot6.setFixedLegendItems(legendItemCollection15);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        xYPlot24.drawAnnotations(graphics2D25, rectangle2D26, plotRenderingInfo27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.util.List list31 = null;
        xYPlot24.drawRangeTickBands(graphics2D29, rectangle2D30, list31);
        org.jfree.chart.StrokeMap strokeMap33 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint35, stroke36);
        boolean boolean38 = strokeMap33.equals((java.lang.Object) valueMarker37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = valueMarker37.getLabelOffset();
        xYPlot24.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker37);
        java.lang.String str41 = valueMarker37.getLabel();
        org.jfree.chart.util.Layer layer42 = null;
        try {
            boolean boolean43 = xYPlot6.removeRangeMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker37, layer42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNull(str41);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D0.setTickUnit(numberTickUnit1, true, false);
        java.text.NumberFormat numberFormat5 = numberAxis3D0.getNumberFormatOverride();
        numberAxis3D0.setPositiveArrowVisible(true);
        boolean boolean8 = numberAxis3D0.isTickMarksVisible();
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot9);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle12.setVerticalAlignment(verticalAlignment14);
        jFreeChart10.addLegend(legendTitle12);
        float float17 = jFreeChart10.getBackgroundImageAlpha();
        java.lang.Object obj18 = jFreeChart10.clone();
        boolean boolean19 = legendItemCollection0.equals(obj18);
        try {
            org.jfree.chart.LegendItem legendItem21 = legendItemCollection0.get((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setSectionDepth(0.08d);
        java.awt.Paint paint5 = ringPlot2.getSeparatorPaint();
        boolean boolean6 = standardPieSectionLabelGenerator0.equals((java.lang.Object) ringPlot2);
        java.awt.Paint paint7 = ringPlot2.getSeparatorPaint();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "hi!", "hi!");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo12 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
        basicProjectInfo12.setName("");
        basicProjectInfo12.setCopyright("");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo12);
        java.lang.String str18 = basicProjectInfo12.getInfo();
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat5 = null;
        dateAxis4.setDateFormatOverride(dateFormat5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color7);
        piePlot1.setBackgroundPaint((java.awt.Paint) color7);
        java.lang.Object obj10 = piePlot1.clone();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        xYPlot18.drawAnnotations(graphics2D19, rectangle2D20, plotRenderingInfo21);
        xYPlot18.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke25 = xYPlot18.getDomainZeroBaselineStroke();
        java.awt.Stroke stroke26 = xYPlot18.getRangeZeroBaselineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 128, stroke26);
        java.awt.Paint paint28 = piePlot1.getLabelShadowPaint();
        java.awt.Color color29 = java.awt.Color.BLUE;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color29);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        int int7 = xYPlot6.getDatasetCount();
        java.awt.Paint paint8 = xYPlot6.getDomainGridlinePaint();
        double double9 = xYPlot6.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot6.getRendererForDataset(xYDataset11);
        java.awt.Paint paint14 = xYPlot6.getQuadrantPaint(0);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = null;
        xYPlot6.setFixedLegendItems(legendItemCollection15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot6.drawDomainTickBands(graphics2D17, rectangle2D18, list19);
        java.awt.Stroke stroke21 = xYPlot6.getRangeGridlineStroke();
        xYPlot6.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint25, stroke26);
        double double28 = valueMarker27.getValue();
        java.awt.Paint paint29 = valueMarker27.getLabelPaint();
        java.awt.Paint paint30 = valueMarker27.getOutlinePaint();
        xYPlot6.setDomainCrosshairPaint(paint30);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot6.getRendererForDataset(xYDataset11);
        java.awt.Paint paint14 = xYPlot6.getQuadrantPaint(0);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = null;
        xYPlot6.setFixedLegendItems(legendItemCollection15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot6.drawDomainTickBands(graphics2D17, rectangle2D18, list19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = xYPlot6.getFixedLegendItems();
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(legendItemCollection21);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        waferMapPlot6.setNoDataMessageFont(font12);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 100L, font12);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis3D0.getCategoryLabelPositions();
        categoryAxis3D0.setMaximumCategoryLabelLines((int) '#');
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer27);
        int int29 = xYPlot28.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot28.getDomainAxis((int) (short) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot28.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        try {
            org.jfree.chart.axis.AxisState axisState34 = categoryAxis3D0.draw(graphics2D18, (-7.0d), rectangle2D20, rectangle2D21, rectangleEdge32, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(valueAxis31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(1.0E-5d, 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.setDomainCrosshairLockedOnData(false);
        java.awt.Color color21 = java.awt.Color.GRAY;
        java.awt.Color color22 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        float[] floatArray24 = null;
        float[] floatArray25 = color21.getComponents(colorSpace23, floatArray24);
        xYPlot6.setDomainCrosshairPaint((java.awt.Paint) color21);
        int int27 = xYPlot6.getRangeAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = xYPlot6.getFixedLegendItems();
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = xYPlot6.getRangeMarkers((-1), layer30);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot6.getDomainAxisForDataset((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 52 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(legendItemCollection28);
        org.junit.Assert.assertNull(collection31);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = legendTitle4.getHorizontalAlignment();
        legendTitle4.setHeight(0.0d);
        java.awt.Font font8 = legendTitle4.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = legendTitle4.getLegendItemGraphicEdge();
        boolean boolean10 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge9);
        try {
            double double11 = numberAxis0.valueToJava2D((double) (-1L), rectangle2D2, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        java.lang.String str3 = horizontalAlignment2.toString();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        boolean boolean5 = horizontalAlignment2.equals((java.lang.Object) textAnchor4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment6, 4.0d, (double) (short) 0);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString(" version .\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!", graphics2D1, 0.0f, 2.0f, textAnchor4, 3.0d, 2.0f, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("RectangleEdge.BOTTOM");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleEdge.BOTTOM");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color9 = java.awt.Color.GRAY;
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { paint5, paint6, color7, paint8, color9, paint10 };
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color13 = java.awt.Color.GRAY;
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color12, color13, color14, paint15, color16, color17 };
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color20 = java.awt.Color.GRAY;
        java.awt.Paint paint21 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color19, color20, paint21 };
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke24 = null;
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] { stroke24 };
        java.awt.Shape[] shapeArray26 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray11, paintArray18, paintArray22, strokeArray23, strokeArray25, shapeArray26);
        java.lang.Object obj28 = defaultDrawingSupplier27.clone();
        java.awt.Paint paint29 = defaultDrawingSupplier27.getNextPaint();
        org.jfree.chart.StrokeMap strokeMap30 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo31 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str32 = basicProjectInfo31.getVersion();
        boolean boolean33 = strokeMap30.equals((java.lang.Object) str32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) numberAxis3D36, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer39);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        xYPlot40.drawAnnotations(graphics2D41, rectangle2D42, plotRenderingInfo43);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double51 = rectangleInsets49.calculateLeftOutset((double) 10.0f);
        xYPlot40.setAxisOffset(rectangleInsets49);
        xYPlot40.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot40.setDomainZeroBaselineStroke(stroke55);
        boolean boolean57 = strokeMap30.equals((java.lang.Object) stroke55);
        org.jfree.chart.plot.RingPlot ringPlot58 = new org.jfree.chart.plot.RingPlot();
        ringPlot58.setSectionDepth(0.08d);
        java.awt.Paint paint61 = ringPlot58.getSeparatorPaint();
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D64 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset62, (org.jfree.chart.axis.ValueAxis) numberAxis3D64, (org.jfree.chart.axis.ValueAxis) dateAxis66, xYItemRenderer67);
        java.awt.Graphics2D graphics2D69 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        xYPlot68.drawAnnotations(graphics2D69, rectangle2D70, plotRenderingInfo71);
        xYPlot68.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke75 = xYPlot68.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker77 = new org.jfree.chart.plot.ValueMarker(2.0d, paint29, stroke55, paint61, stroke75, (float) (byte) 0);
        categoryPlot0.setOutlineStroke(stroke55);
        org.jfree.chart.axis.ValueAxis valueAxis80 = categoryPlot0.getRangeAxisForDataset((int) (byte) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis82 = categoryPlot0.getDomainAxisForDataset(0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 35.0d + "'", double51 == 35.0d);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNull(valueAxis80);
        org.junit.Assert.assertNull(categoryAxis82);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("WMAP_Plot", "", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setFixedDimension((double) 1.0f);
        dateAxis1.setTickMarkOutsideLength((float) 1);
        dateAxis1.setLabel("Range[0.0,1.0]");
        boolean boolean9 = dateAxis1.isHiddenValue((long) 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat6 = null;
        dateAxis5.setDateFormatOverride(dateFormat6);
        java.awt.Color color8 = java.awt.Color.GRAY;
        dateAxis5.setTickLabelPaint((java.awt.Paint) color8);
        java.util.Date date10 = dateAxis5.getMinimumDate();
        boolean boolean11 = rectangleAnchor3.equals((java.lang.Object) dateAxis5);
        java.lang.String str12 = rectangleAnchor3.toString();
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleAnchor.RIGHT" + "'", str12.equals("RectangleAnchor.RIGHT"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range3, 136.0d);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (short) 1);
        java.lang.Comparable comparable3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYPlot10.drawAnnotations(graphics2D11, rectangle2D12, plotRenderingInfo13);
        xYPlot10.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke17 = xYPlot10.getDomainZeroBaselineStroke();
        java.awt.Stroke stroke18 = xYPlot10.getRangeZeroBaselineStroke();
        try {
            strokeMap0.put(comparable3, stroke18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("Other", font4);
        objectList0.set((int) (byte) 1, (java.lang.Object) "Other");
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot0.setRenderer(categoryItemRenderer6, false);
        try {
            categoryPlot0.zoom(90.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.mapDatasetToRangeAxis(15, (int) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer27);
        int int29 = xYPlot28.getDatasetCount();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot28.setDomainCrosshairStroke(stroke30);
        xYPlot6.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.StrokeMap strokeMap33 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint35, stroke36);
        boolean boolean38 = strokeMap33.equals((java.lang.Object) valueMarker37);
        java.awt.Paint paint39 = valueMarker37.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        piePlot41.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = piePlot41.getInsets();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator45 = null;
        piePlot41.setLegendLabelURLGenerator(pieURLGenerator45);
        java.awt.Paint paint47 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot41.setLabelOutlinePaint(paint47);
        valueMarker37.setOutlinePaint(paint47);
        java.awt.Stroke stroke50 = valueMarker37.getStroke();
        xYPlot6.setDomainZeroBaselineStroke(stroke50);
        int int52 = xYPlot6.getDomainAxisCount();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder53 = null;
        try {
            xYPlot6.setSeriesRenderingOrder(seriesRenderingOrder53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 0, (double) 500, plotRenderingInfo5, point2D6);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        java.lang.Object obj10 = null;
        boolean boolean11 = plotOrientation9.equals(obj10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot7.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot7.getRangeAxis();
        int int14 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot7.getDomainAxis(0);
        org.junit.Assert.assertNotNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(valueAxis16);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace15, false);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot6.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        xYPlot6.clearAnnotations();
        org.junit.Assert.assertNull(legendItemCollection18);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset3, false);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset3, (java.lang.Comparable) 'a');
        org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset8, (java.lang.Comparable) 15.0d, 100.0d);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNotNull(pieDataset11);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer((int) '4', categoryItemRenderer5, false);
        boolean boolean8 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat11 = null;
        dateAxis10.setDateFormatOverride(dateFormat11);
        java.awt.Color color13 = java.awt.Color.GRAY;
        dateAxis10.setTickLabelPaint((java.awt.Paint) color13);
        java.util.Date date15 = dateAxis10.getMinimumDate();
        java.awt.Color color16 = java.awt.Color.GRAY;
        dateAxis10.setTickMarkPaint((java.awt.Paint) color16);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D2.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = legendTitle10.getHorizontalAlignment();
        legendTitle10.setHeight(0.0d);
        java.awt.Font font14 = legendTitle10.getItemFont();
        waferMapPlot8.setNoDataMessageFont(font14);
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) 100L, font14);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle18.setText("");
        boolean boolean21 = textTitle18.getExpandToFitSpace();
        boolean boolean22 = categoryAxis3D2.equals((java.lang.Object) boolean21);
        categoryAxis3D2.removeCategoryLabelToolTip((java.lang.Comparable) "{0}");
        boolean boolean25 = legendItemCollection0.equals((java.lang.Object) "{0}");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        java.lang.String str9 = dateAxis1.getLabel();
        dateAxis1.setVisible(true);
        org.jfree.chart.axis.Timeline timeline12 = null;
        dateAxis1.setTimeline(timeline12);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairValue(136.0d, true);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot7);
        java.awt.Paint paint13 = xYPlot7.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        xYPlot6.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = xYPlot6.getAxisOffset();
        java.awt.Paint paint11 = xYPlot6.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint2 = categoryPlot1.getDomainGridlinePaint();
        boolean boolean3 = blockBorder0.equals((java.lang.Object) paint2);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle15.setText("");
        boolean boolean18 = textTitle15.getExpandToFitSpace();
        boolean boolean19 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = legendTitle22.getHorizontalAlignment();
        legendTitle22.setHeight(0.0d);
        java.awt.Font font26 = legendTitle22.getItemFont();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font26, paint27);
        textTitle15.setFont(font26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = textTitle15.getVerticalAlignment();
        legendTitle12.setVerticalAlignment(verticalAlignment30);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = legendTitle12.getHorizontalAlignment();
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = legendTitle35.getHorizontalAlignment();
        java.lang.String str37 = horizontalAlignment36.toString();
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        boolean boolean39 = horizontalAlignment36.equals((java.lang.Object) textAnchor38);
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = legendTitle41.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement46 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment42, verticalAlignment43, (double) 0, 35.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment36, verticalAlignment43, 0.0d, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement52 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment33, verticalAlignment43, 1.0E-8d, 0.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "HorizontalAlignment.CENTER" + "'", str37.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment42);
        org.junit.Assert.assertNotNull(verticalAlignment43);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot0.setRenderer(categoryItemRenderer6, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(plotOrientation9);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.util.Iterator iterator1 = legendItemCollection0.iterator();
        org.junit.Assert.assertNotNull(iterator1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "hi!", "hi!");
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot12.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot12.drawRangeTickBands(graphics2D17, rectangle2D18, list19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot12.setFixedRangeAxisSpace(axisSpace21, false);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot12.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot12);
        boolean boolean26 = basicProjectInfo5.equals((java.lang.Object) xYPlot12);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (double) '4');
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleInsets[t=0.0,l=10.0,b=0.0,r=32.0]", "TextAnchor.CENTER_LEFT");
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D0.setTickUnit(numberTickUnit1, true, false);
        java.text.NumberFormat numberFormat5 = numberAxis3D0.getNumberFormatOverride();
        java.lang.String str6 = numberAxis3D0.getLabel();
        numberAxis3D0.setAutoRange(false);
        boolean boolean9 = numberAxis3D0.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint2, stroke3);
        boolean boolean5 = strokeMap0.equals((java.lang.Object) valueMarker4);
        java.awt.Paint paint6 = valueMarker4.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = piePlot8.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation10 = piePlot8.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot8.getLegendLabelToolTipGenerator();
        valueMarker4.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot8);
        java.awt.Paint paint13 = piePlot8.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat3 = null;
        dateAxis2.setDateFormatOverride(dateFormat3);
        java.awt.Color color5 = java.awt.Color.GRAY;
        dateAxis2.setTickLabelPaint((java.awt.Paint) color5);
        java.util.Date date7 = dateAxis2.getMinimumDate();
        boolean boolean8 = rectangleAnchor0.equals((java.lang.Object) dateAxis2);
        dateAxis2.setAutoRangeMinimumSize((double) 4);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4);
        boolean boolean6 = categoryPlot0.getDrawSharedDomainAxis();
        boolean boolean7 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint2, stroke3);
        boolean boolean5 = strokeMap0.equals((java.lang.Object) valueMarker4);
        java.awt.Paint paint6 = valueMarker4.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = piePlot8.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation10 = piePlot8.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot8.getLegendLabelToolTipGenerator();
        valueMarker4.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot8);
        piePlot8.setIgnoreZeroValues(false);
        java.awt.Paint paint15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color19 = java.awt.Color.GRAY;
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { paint15, paint16, color17, paint18, color19, paint20 };
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color23 = java.awt.Color.GRAY;
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Paint paint25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color22, color23, color24, paint25, color26, color27 };
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color30 = java.awt.Color.GRAY;
        java.awt.Paint paint31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { color29, color30, paint31 };
        java.awt.Stroke[] strokeArray33 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke34 = null;
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] { stroke34 };
        java.awt.Shape[] shapeArray36 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray21, paintArray28, paintArray32, strokeArray33, strokeArray35, shapeArray36);
        java.lang.Object obj38 = defaultDrawingSupplier37.clone();
        piePlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier37);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.08d);
        ringPlot0.setSeparatorsVisible(true);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setSeparatorStroke(stroke5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat14 = null;
        dateAxis13.setDateFormatOverride(dateFormat14);
        java.awt.Color color16 = java.awt.Color.GRAY;
        dateAxis13.setTickLabelPaint((java.awt.Paint) color16);
        java.util.Date date18 = dateAxis13.getMinimumDate();
        java.awt.Color color19 = java.awt.Color.GRAY;
        dateAxis13.setTickMarkPaint((java.awt.Paint) color19);
        boolean boolean21 = dateAxis13.isVerticalTickLabels();
        boolean boolean23 = dateAxis13.isHiddenValue(10L);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = piePlot25.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat29 = null;
        dateAxis28.setDateFormatOverride(dateFormat29);
        java.awt.Color color31 = java.awt.Color.GRAY;
        dateAxis28.setTickLabelPaint((java.awt.Paint) color31);
        piePlot25.setBackgroundPaint((java.awt.Paint) color31);
        dateAxis13.setPlot((org.jfree.chart.plot.Plot) piePlot25);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat37 = null;
        dateAxis36.setDateFormatOverride(dateFormat37);
        java.awt.Shape shape39 = dateAxis36.getDownArrow();
        piePlot25.setLegendItemShape(shape39);
        piePlot3D11.setLegendItemShape(shape39);
        java.lang.String str42 = piePlot3D11.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.chart.plot.PiePlotState piePlotState45 = ringPlot0.initialise(graphics2D8, rectangle2D9, (org.jfree.chart.plot.PiePlot) piePlot3D11, (java.lang.Integer) 3, plotRenderingInfo44);
        piePlotState45.setPieWRadius(0.14d);
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        piePlotState45.setLinkArea(rectangle2D48);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Pie 3D Plot" + "'", str42.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(piePlotState45);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle15.setText("");
        boolean boolean18 = textTitle15.getExpandToFitSpace();
        boolean boolean19 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = legendTitle22.getHorizontalAlignment();
        legendTitle22.setHeight(0.0d);
        java.awt.Font font26 = legendTitle22.getItemFont();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font26, paint27);
        textTitle15.setFont(font26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = textTitle15.getVerticalAlignment();
        legendTitle12.setVerticalAlignment(verticalAlignment30);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = legendTitle12.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle12.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double36 = rectangleInsets35.getRight();
        double double38 = rectangleInsets35.calculateLeftOutset(0.14d);
        legendTitle12.setPadding(rectangleInsets35);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.0d + "'", double36 == 3.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.0d + "'", double38 == 3.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        boolean boolean3 = categoryAxis3D0.isAxisLineVisible();
        categoryAxis3D0.setMaximumCategoryLabelLines((int) (short) 10);
        categoryAxis3D0.setTickLabelsVisible(false);
        categoryAxis3D0.setCategoryLabelPositionOffset((-1));
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer18);
        int int20 = xYPlot19.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot19.getDomainAxis((int) (short) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot19.getDomainAxisEdge();
        java.lang.String str24 = rectangleEdge23.toString();
        try {
            double double25 = categoryAxis3D0.getCategoryEnd((int) (short) 0, (int) (byte) 1, rectangle2D12, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(valueAxis22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleEdge.BOTTOM" + "'", str24.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint2, stroke3);
        boolean boolean5 = strokeMap0.equals((java.lang.Object) valueMarker4);
        java.awt.Paint paint6 = valueMarker4.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        piePlot8.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot8.getInsets();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        piePlot8.setLegendLabelURLGenerator(pieURLGenerator12);
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot8.setLabelOutlinePaint(paint14);
        valueMarker4.setOutlinePaint(paint14);
        float float17 = valueMarker4.getAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat26 = null;
        dateAxis25.setDateFormatOverride(dateFormat26);
        java.awt.Color color28 = java.awt.Color.GRAY;
        dateAxis25.setTickLabelPaint((java.awt.Paint) color28);
        boolean boolean30 = rectangleInsets23.equals((java.lang.Object) color28);
        float[] floatArray37 = new float[] { 100L, '#', (byte) 100, (short) 1, (-1L), (byte) -1 };
        float[] floatArray38 = color28.getRGBColorComponents(floatArray37);
        java.lang.Class<?> wildcardClass39 = color28.getClass();
        java.net.URL uRL40 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=1.0]", (java.lang.Class) wildcardClass39);
        try {
            java.util.EventListener[] eventListenerArray41 = valueMarker4.getListeners((java.lang.Class) wildcardClass39);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.Color; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNull(uRL40);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation3 = piePlot1.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        java.awt.Paint paint5 = null;
        piePlot1.setOutlinePaint(paint5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot1.drawOutline(graphics2D7, rectangle2D8);
        org.jfree.chart.plot.Plot plot10 = piePlot1.getRootPlot();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = numberAxis3D0.getNumberFormatOverride();
        boolean boolean2 = numberAxis3D0.getAutoRangeIncludesZero();
        numberAxis3D0.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.08d);
        ringPlot0.setSeparatorsVisible(true);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setSeparatorStroke(stroke5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot0.getLegendLabelToolTipGenerator();
        boolean boolean8 = ringPlot0.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.08d);
        ringPlot0.setSeparatorsVisible(true);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setSeparatorStroke(stroke5);
        double double7 = ringPlot0.getStartAngle();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace15, false);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot6.getFixedLegendItems();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer25);
        int int27 = xYPlot26.getDatasetCount();
        java.awt.Paint paint28 = xYPlot26.getDomainGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer35);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot36.getDomainAxisLocation(100);
        xYPlot26.setRangeAxisLocation(axisLocation39, false);
        xYPlot6.setRangeAxisLocation(0, axisLocation39, false);
        xYPlot6.setRangeCrosshairValue(0.0d, true);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation39);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot6.setDomainZeroBaselineStroke(stroke21);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot6.getDomainMarkers(layer23);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle15.setText("");
        boolean boolean18 = textTitle15.getExpandToFitSpace();
        boolean boolean19 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = legendTitle22.getHorizontalAlignment();
        legendTitle22.setHeight(0.0d);
        java.awt.Font font26 = legendTitle22.getItemFont();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font26, paint27);
        textTitle15.setFont(font26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = textTitle15.getVerticalAlignment();
        legendTitle12.setVerticalAlignment(verticalAlignment30);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent35 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle34);
        jFreeChart10.addLegend(legendTitle34);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle38.setText("");
        boolean boolean41 = textTitle38.getExpandToFitSpace();
        boolean boolean42 = textTitle38.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = legendTitle45.getHorizontalAlignment();
        legendTitle45.setHeight(0.0d);
        java.awt.Font font49 = legendTitle45.getItemFont();
        java.awt.Paint paint50 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine51 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font49, paint50);
        textTitle38.setFont(font49);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor54 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        boolean boolean55 = textTitle38.equals((java.lang.Object) pieLabelDistributor54);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) textTitle38);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = null;
        try {
            org.jfree.chart.util.Size2D size2D59 = textTitle38.arrange(graphics2D57, rectangleConstraint58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.StrokeMap strokeMap1 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint3, stroke4);
        boolean boolean6 = strokeMap1.equals((java.lang.Object) valueMarker5);
        java.awt.Paint paint7 = valueMarker5.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker5.getLabelAnchor();
        try {
            java.awt.geom.Point2D point2D9 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.08d);
        ringPlot0.setSeparatorsVisible(true);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setSeparatorStroke(stroke5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        ringPlot10.setSectionDepth(0.08d);
        ringPlot10.setSeparatorsVisible(true);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot10.setSeparatorStroke(stroke15);
        java.awt.Paint paint17 = ringPlot10.getShadowPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.plot.PiePlotState piePlotState20 = ringPlot0.initialise(graphics2D8, rectangle2D9, (org.jfree.chart.plot.PiePlot) ringPlot10, (java.lang.Integer) 2, plotRenderingInfo19);
        boolean boolean21 = ringPlot10.getSeparatorsVisible();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(piePlotState20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) 10L, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        dateAxis13.setFixedDimension((double) 1.0f);
        dateAxis13.setTickMarkOutsideLength((float) 1);
        java.util.Date date18 = dateAxis13.getMaximumDate();
        dateAxis13.resizeRange((double) 'a');
        categoryPlot0.setRangeAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color4 = java.awt.Color.GRAY;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { paint0, paint1, color2, paint3, color4, paint5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color8 = java.awt.Color.GRAY;
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color7, color8, color9, paint10, color11, color12 };
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color15 = java.awt.Color.GRAY;
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color14, color15, paint16 };
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke19 };
        java.awt.Shape[] shapeArray21 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray13, paintArray17, strokeArray18, strokeArray20, shapeArray21);
        java.lang.Object obj23 = defaultDrawingSupplier22.clone();
        java.awt.Paint paint24 = defaultDrawingSupplier22.getNextPaint();
        java.lang.Object obj25 = defaultDrawingSupplier22.clone();
        java.awt.Stroke stroke26 = defaultDrawingSupplier22.getNextOutlineStroke();
        java.lang.Object obj27 = null;
        boolean boolean28 = defaultDrawingSupplier22.equals(obj27);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        java.util.List list2 = textBlock0.getLines();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot3.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot3.getColumnRenderingOrder();
        categoryPlot3.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = categoryPlot3.getOrientation();
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot3.getRowRenderingOrder();
        boolean boolean12 = textBlock0.equals((java.lang.Object) sortOrder11);
        org.jfree.chart.text.TextLine textLine13 = textBlock0.getLastLine();
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(textLine13);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 0, (double) 500, plotRenderingInfo5, point2D6);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomDomainAxes(0.2d, (double) 100, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot6.getRendererForDataset(xYDataset11);
        java.awt.Paint paint14 = xYPlot6.getQuadrantPaint(0);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = null;
        xYPlot6.setFixedLegendItems(legendItemCollection15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot6.drawDomainTickBands(graphics2D17, rectangle2D18, list19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.text.TextBlock textBlock23 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine24 = textBlock23.getLastLine();
        java.util.List list25 = textBlock23.getLines();
        java.util.List list26 = textBlock23.getLines();
        xYPlot6.drawRangeTickBands(graphics2D21, rectangle2D22, list26);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(textLine24);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYPlot10.drawAnnotations(graphics2D11, rectangle2D12, plotRenderingInfo13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.util.List list17 = null;
        xYPlot10.drawRangeTickBands(graphics2D15, rectangle2D16, list17);
        org.jfree.chart.StrokeMap strokeMap19 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint21, stroke22);
        boolean boolean24 = strokeMap19.equals((java.lang.Object) valueMarker23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = valueMarker23.getLabelOffset();
        xYPlot10.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker23);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double32 = rectangleInsets31.getRight();
        double double34 = rectangleInsets31.calculateLeftOutset((double) ' ');
        valueMarker23.setLabelOffset(rectangleInsets31);
        textTitle1.setPadding(rectangleInsets31);
        java.lang.Object obj37 = null;
        boolean boolean38 = rectangleInsets31.equals(obj37);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 35.0d + "'", double34 == 35.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        xYPlot6.setRangeCrosshairLockedOnData(true);
        xYPlot6.clearDomainMarkers((int) (byte) 1);
        xYPlot6.mapDatasetToDomainAxis(15, (int) (byte) 10);
        java.awt.Paint paint18 = xYPlot6.getDomainZeroBaselinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = xYPlot6.getFixedLegendItems();
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(legendItemCollection19);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4);
        boolean boolean6 = categoryPlot0.getDrawSharedDomainAxis();
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 1);
        categoryPlot0.setDataset(categoryDataset10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setFixedDimension((double) 1.0f);
        boolean boolean4 = dateAxis1.isAxisLineVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.String str8 = rectangleEdge7.toString();
        try {
            double double9 = dateAxis1.java2DToValue((double) 'a', rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.BOTTOM" + "'", str8.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle5.setText("");
        boolean boolean8 = textTitle5.getExpandToFitSpace();
        boolean boolean9 = textTitle5.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = legendTitle12.getHorizontalAlignment();
        legendTitle12.setHeight(0.0d);
        java.awt.Font font16 = legendTitle12.getItemFont();
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font16, paint17);
        textTitle5.setFont(font16);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        textTitle5.setPaint((java.awt.Paint) color20);
        java.awt.Font font22 = textTitle5.getFont();
        java.awt.Image image26 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo30 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image26, "hi!", "hi!", "hi!");
        projectInfo30.addOptionalLibrary("hi!");
        blockContainer3.add((org.jfree.chart.block.Block) textTitle5, (java.lang.Object) "hi!");
        java.lang.Object obj34 = blockContainer3.clone();
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle36.setText("");
        boolean boolean39 = textTitle36.getExpandToFitSpace();
        blockContainer3.add((org.jfree.chart.block.Block) textTitle36);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.data.Range range43 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range46 = org.jfree.data.Range.expand(range43, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range49 = org.jfree.data.Range.shift(range46, (double) (-1), false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType50 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range52 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean55 = range52.intersects((double) (byte) 1, (double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType56 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range49, lengthConstraintType50, (double) (-1), range52, lengthConstraintType56);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = rectangleConstraint57.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D59 = blockContainer3.arrange(graphics2D41, rectangleConstraint58);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(lengthConstraintType50);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType56);
        org.junit.Assert.assertNotNull(rectangleConstraint58);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo10, point2D11);
        int int13 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        legendTitle1.setNotify(false);
        java.awt.Paint paint6 = legendTitle1.getBackgroundPaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint10.toUnconstrainedHeight();
        try {
            org.jfree.chart.util.Size2D size2D13 = legendTitle1.arrange(graphics2D7, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) (short) -1, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot0.setRenderer(categoryItemRenderer11, false);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(drawingSupplier16);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getContentXOffset();
        boolean boolean3 = legendTitle1.getNotify();
        org.jfree.chart.block.BlockFrame blockFrame4 = legendTitle1.getFrame();
        legendTitle1.setNotify(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(blockFrame4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot7.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot7.zoomDomainAxes(0.08d, (double) 1.0f, plotRenderingInfo15, point2D16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer23);
        int int25 = xYPlot24.getDatasetCount();
        java.awt.Paint paint26 = xYPlot24.getDomainGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) dateAxis32, xYItemRenderer33);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot34.getDomainAxisLocation(100);
        xYPlot24.setRangeAxisLocation(axisLocation37, false);
        xYPlot7.setDomainAxisLocation(axisLocation37, false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D0.setTickUnit(numberTickUnit1, true, false);
        java.text.NumberFormat numberFormat5 = numberAxis3D0.getNumberFormatOverride();
        java.lang.String str6 = numberAxis3D0.getLabel();
        double double7 = numberAxis3D0.getUpperBound();
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double6 = rectangleInsets4.extendWidth((double) (short) 100);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets4.createOutsetRectangle(rectangle2D7, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 136.0d + "'", double6 == 136.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("HorizontalAlignment.LEFT", "RectangleAnchor.CENTER", "Pie Plot", "UnitType.ABSOLUTE");
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot9.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot9.drawRangeTickBands(graphics2D14, rectangle2D15, list16);
        org.jfree.chart.StrokeMap strokeMap18 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint20, stroke21);
        boolean boolean23 = strokeMap18.equals((java.lang.Object) valueMarker22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = valueMarker22.getLabelOffset();
        xYPlot9.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker22);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine29 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font28);
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = piePlot31.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation33 = piePlot31.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator34 = piePlot31.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font28, (org.jfree.chart.plot.Plot) piePlot31, false);
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        double double39 = legendTitle38.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle41.setText("");
        boolean boolean44 = textTitle41.getExpandToFitSpace();
        boolean boolean45 = textTitle41.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment49 = legendTitle48.getHorizontalAlignment();
        legendTitle48.setHeight(0.0d);
        java.awt.Font font52 = legendTitle48.getItemFont();
        java.awt.Paint paint53 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine54 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font52, paint53);
        textTitle41.setFont(font52);
        org.jfree.chart.util.VerticalAlignment verticalAlignment56 = textTitle41.getVerticalAlignment();
        legendTitle38.setVerticalAlignment(verticalAlignment56);
        jFreeChart36.addSubtitle((org.jfree.chart.title.Title) legendTitle38);
        xYPlot9.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart36);
        categoryAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot9);
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = categoryAxis3D0.getTickLabelInsets();
        java.awt.Stroke stroke62 = categoryAxis3D0.getTickMarkStroke();
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(drawingSupplier32);
        org.junit.Assert.assertNotNull(rotation33);
        org.junit.Assert.assertNull(pieSectionLabelGenerator34);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment49);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(verticalAlignment56);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertNotNull(stroke62);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        java.lang.String str2 = horizontalAlignment1.toString();
        textBlock0.setLineAlignment(horizontalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HorizontalAlignment.LEFT" + "'", str2.equals("HorizontalAlignment.LEFT"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        categoryPlot0.setAnchorValue((double) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat17 = null;
        dateAxis16.setDateFormatOverride(dateFormat17);
        java.awt.Color color19 = java.awt.Color.GRAY;
        dateAxis16.setTickLabelPaint((java.awt.Paint) color19);
        boolean boolean21 = rectangleInsets14.equals((java.lang.Object) color19);
        float[] floatArray28 = new float[] { 100L, '#', (byte) 100, (short) 1, (-1L), (byte) -1 };
        float[] floatArray29 = color19.getRGBColorComponents(floatArray28);
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.StrokeMap strokeMap31 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint33, stroke34);
        boolean boolean36 = strokeMap31.equals((java.lang.Object) valueMarker35);
        java.awt.Paint paint37 = valueMarker35.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.PiePlot piePlot39 = new org.jfree.chart.plot.PiePlot(pieDataset38);
        piePlot39.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = piePlot39.getInsets();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator43 = null;
        piePlot39.setLegendLabelURLGenerator(pieURLGenerator43);
        java.awt.Paint paint45 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot39.setLabelOutlinePaint(paint45);
        valueMarker35.setOutlinePaint(paint45);
        org.jfree.chart.util.Layer layer48 = null;
        try {
            boolean boolean49 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker35, layer48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        categoryAxis3D0.configure();
        categoryAxis3D0.clearCategoryLabelToolTips();
        double double5 = categoryAxis3D0.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Paint paint4 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot6.getRendererForDataset(xYDataset11);
        java.awt.Paint paint14 = xYPlot6.getQuadrantPaint(0);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = null;
        xYPlot6.setFixedLegendItems(legendItemCollection15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot6.drawDomainTickBands(graphics2D17, rectangle2D18, list19);
        java.awt.Stroke stroke21 = xYPlot6.getRangeGridlineStroke();
        xYPlot6.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace24 = xYPlot6.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(axisSpace24);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double5 = rectangleInsets4.getRight();
        double double7 = rectangleInsets4.calculateLeftOutset((double) ' ');
        double double9 = rectangleInsets4.trimWidth((double) 3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-33.0d) + "'", double9 == (-33.0d));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        categoryPlot0.setAnchorValue((double) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat17 = null;
        dateAxis16.setDateFormatOverride(dateFormat17);
        java.awt.Color color19 = java.awt.Color.GRAY;
        dateAxis16.setTickLabelPaint((java.awt.Paint) color19);
        boolean boolean21 = rectangleInsets14.equals((java.lang.Object) color19);
        float[] floatArray28 = new float[] { 100L, '#', (byte) 100, (short) 1, (-1L), (byte) -1 };
        float[] floatArray29 = color19.getRGBColorComponents(floatArray28);
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color19);
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray33);
        java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset34);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset34);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot37 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset34);
        categoryPlot0.setDataset(categoryDataset34);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 0.0d + "'", number35.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.0d + "'", number36.equals(0.0d));
        org.junit.Assert.assertNull(range39);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Font font3 = textTitle2.getFont();
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint5, stroke6);
        double double8 = valueMarker7.getValue();
        java.awt.Paint paint9 = valueMarker7.getLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer15);
        int int17 = xYPlot16.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot16.getDomainAxis((int) (short) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot16.getDomainAxisEdge();
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine24 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font23);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = piePlot26.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation28 = piePlot26.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator29 = piePlot26.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font23, (org.jfree.chart.plot.Plot) piePlot26, false);
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        double double34 = legendTitle33.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle36.setText("");
        boolean boolean39 = textTitle36.getExpandToFitSpace();
        boolean boolean40 = textTitle36.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = legendTitle43.getHorizontalAlignment();
        legendTitle43.setHeight(0.0d);
        java.awt.Font font47 = legendTitle43.getItemFont();
        java.awt.Paint paint48 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine49 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font47, paint48);
        textTitle36.setFont(font47);
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = textTitle36.getVerticalAlignment();
        legendTitle33.setVerticalAlignment(verticalAlignment51);
        jFreeChart31.addSubtitle((org.jfree.chart.title.Title) legendTitle33);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment54 = legendTitle33.getHorizontalAlignment();
        org.jfree.chart.LegendItemSource legendItemSource55 = null;
        org.jfree.chart.title.LegendTitle legendTitle56 = new org.jfree.chart.title.LegendTitle(legendItemSource55);
        double double57 = legendTitle56.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle56.setVerticalAlignment(verticalAlignment58);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat62 = null;
        dateAxis61.setDateFormatOverride(dateFormat62);
        java.awt.Color color64 = java.awt.Color.GRAY;
        dateAxis61.setTickLabelPaint((java.awt.Paint) color64);
        boolean boolean66 = verticalAlignment58.equals((java.lang.Object) color64);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle68 = new org.jfree.chart.title.TextTitle("", font3, paint9, rectangleEdge20, horizontalAlignment54, verticalAlignment58, rectangleInsets67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'spacer' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(drawingSupplier27);
        org.junit.Assert.assertNotNull(rotation28);
        org.junit.Assert.assertNull(pieSectionLabelGenerator29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(verticalAlignment51);
        org.junit.Assert.assertNotNull(horizontalAlignment54);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.StrokeMap strokeMap15 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint17, stroke18);
        boolean boolean20 = strokeMap15.equals((java.lang.Object) valueMarker19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = valueMarker19.getLabelOffset();
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        java.awt.Paint paint23 = null;
        try {
            xYPlot6.setRangeCrosshairPaint(paint23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Shape shape7 = dateAxis4.getUpArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        try {
            java.util.Date date9 = dateAxis4.calculateHighestVisibleTickValue(dateTickUnit8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("HorizontalAlignment.LEFT");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        dateAxis3.setFixedDimension((double) 1.0f);
        dateAxis3.setTickMarkOutsideLength((float) 1);
        java.util.Date date8 = dateAxis3.getMaximumDate();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = legendTitle11.getHorizontalAlignment();
        legendTitle11.setHeight(0.0d);
        java.awt.Font font15 = legendTitle11.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle11.getLegendItemGraphicEdge();
        try {
            double double17 = dateAxis1.dateToJava2D(date8, rectangle2D9, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 100, (float) (short) 1, 1.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.setDomainCrosshairLockedOnData(false);
        java.awt.Color color21 = java.awt.Color.GRAY;
        java.awt.Color color22 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        float[] floatArray24 = null;
        float[] floatArray25 = color21.getComponents(colorSpace23, floatArray24);
        xYPlot6.setDomainCrosshairPaint((java.awt.Paint) color21);
        int int27 = xYPlot6.getRangeAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = xYPlot6.getFixedLegendItems();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot6.setRenderer(xYItemRenderer29);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(legendItemCollection28);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("Other", font1);
        org.jfree.chart.text.TextFragment textFragment3 = textLine2.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(textFragment3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getContentXOffset();
        boolean boolean3 = legendTitle1.getNotify();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot11);
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        double double15 = legendTitle14.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle14.setVerticalAlignment(verticalAlignment16);
        jFreeChart12.addLegend(legendTitle14);
        org.jfree.chart.plot.Plot plot19 = jFreeChart12.getPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean3, jFreeChart12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(plot19);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat5 = null;
        dateAxis4.setDateFormatOverride(dateFormat5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color7);
        piePlot1.setBackgroundPaint((java.awt.Paint) color7);
        boolean boolean10 = piePlot1.getIgnoreNullValues();
        org.jfree.data.general.PieDataset pieDataset11 = piePlot1.getDataset();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(pieDataset11);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        legendTitle1.setNotify(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        java.lang.String str11 = unitType10.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType10, (double) 0, (double) 10L, (double) (short) 0, (double) ' ');
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets16);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font20);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot23.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation25 = piePlot23.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator26 = piePlot23.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font20, (org.jfree.chart.plot.Plot) piePlot23, false);
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        double double31 = legendTitle30.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle33.setText("");
        boolean boolean36 = textTitle33.getExpandToFitSpace();
        boolean boolean37 = textTitle33.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource39 = null;
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle(legendItemSource39);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = legendTitle40.getHorizontalAlignment();
        legendTitle40.setHeight(0.0d);
        java.awt.Font font44 = legendTitle40.getItemFont();
        java.awt.Paint paint45 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font44, paint45);
        textTitle33.setFont(font44);
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = textTitle33.getVerticalAlignment();
        legendTitle30.setVerticalAlignment(verticalAlignment48);
        jFreeChart28.addSubtitle((org.jfree.chart.title.Title) legendTitle30);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment51 = legendTitle30.getHorizontalAlignment();
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment54 = legendTitle53.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer55 = legendTitle53.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement56 = blockContainer55.getArrangement();
        org.jfree.chart.block.Block block57 = null;
        blockContainer55.add(block57);
        org.jfree.chart.block.Arrangement arrangement59 = blockContainer55.getArrangement();
        legendTitle30.setWrapper(blockContainer55);
        org.jfree.chart.ChartColor chartColor64 = new org.jfree.chart.ChartColor(0, 15, (int) ' ');
        legendTitle30.setBackgroundPaint((java.awt.Paint) chartColor64);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = legendTitle30.getMargin();
        legendTitle1.setItemLabelPadding(rectangleInsets66);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnitType.ABSOLUTE" + "'", str11.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(rotation25);
        org.junit.Assert.assertNull(pieSectionLabelGenerator26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertNotNull(horizontalAlignment51);
        org.junit.Assert.assertNotNull(horizontalAlignment54);
        org.junit.Assert.assertNotNull(blockContainer55);
        org.junit.Assert.assertNotNull(arrangement56);
        org.junit.Assert.assertNotNull(arrangement59);
        org.junit.Assert.assertNotNull(rectangleInsets66);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ThreadContext", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) (-1L));
        ringPlot0.setSectionDepth((double) 500);
        ringPlot0.setStartAngle((double) 100L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D0.setTickUnit(numberTickUnit1, true, false);
        java.text.NumberFormat numberFormat5 = numberAxis3D0.getNumberFormatOverride();
        numberAxis3D0.setPositiveArrowVisible(true);
        numberAxis3D0.setFixedDimension(1.0E-8d);
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertNull(numberFormat5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        xYPlot6.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke13 = xYPlot6.getDomainZeroBaselineStroke();
        xYPlot6.configureDomainAxes();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CrosshairState crosshairState19 = null;
        boolean boolean20 = xYPlot6.render(graphics2D15, rectangle2D16, 0, plotRenderingInfo18, crosshairState19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = xYPlot6.getFixedLegendItems();
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(legendItemCollection21);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        legendTitle1.setNotify(false);
        java.awt.Paint paint6 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer10 = legendTitle8.getItemContainer();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle12.setText("");
        boolean boolean15 = textTitle12.getExpandToFitSpace();
        boolean boolean16 = textTitle12.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = legendTitle19.getHorizontalAlignment();
        legendTitle19.setHeight(0.0d);
        java.awt.Font font23 = legendTitle19.getItemFont();
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font23, paint24);
        textTitle12.setFont(font23);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        textTitle12.setPaint((java.awt.Paint) color27);
        java.awt.Font font29 = textTitle12.getFont();
        java.awt.Image image33 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo37 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image33, "hi!", "hi!", "hi!");
        projectInfo37.addOptionalLibrary("hi!");
        blockContainer10.add((org.jfree.chart.block.Block) textTitle12, (java.lang.Object) "hi!");
        legendTitle1.setWrapper(blockContainer10);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(blockContainer10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation3 = piePlot1.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        java.awt.Paint paint5 = null;
        piePlot1.setOutlinePaint(paint5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot1.getLabelGenerator();
        double double8 = piePlot1.getShadowYOffset();
        piePlot1.setIgnoreZeroValues(false);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle15.setVerticalAlignment(verticalAlignment17);
        jFreeChart13.addLegend(legendTitle15);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle21.setText("");
        textTitle21.setText("UnitType.ABSOLUTE");
        jFreeChart13.setTitle(textTitle21);
        try {
            multiplePiePlot4.setPieChart(jFreeChart13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'pieChart' argument must be a chart based on a PiePlot.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment17);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list1 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(list1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getInsets();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator5);
        java.lang.String str7 = piePlot1.getPlotType();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.JFreeChart jFreeChart10 = plotChangeEvent9.getChart();
        org.jfree.chart.JFreeChart jFreeChart11 = plotChangeEvent9.getChart();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(jFreeChart10);
        org.junit.Assert.assertNull(jFreeChart11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = categoryPlot0.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(sortOrder1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        dateAxis4.setLabelURL("Other");
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        dateAxis10.setFixedDimension((double) 1.0f);
        dateAxis10.setAutoTickUnitSelection(false);
        boolean boolean15 = dateAxis10.isAxisLineVisible();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis10.getTickMarkPosition();
        dateAxis4.setTickMarkPosition(dateTickMarkPosition16);
        dateAxis4.setLabel("RectangleEdge.BOTTOM");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        boolean boolean8 = categoryPlot0.render(graphics2D4, rectangle2D5, 1, plotRenderingInfo7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.08d);
        ringPlot0.setSeparatorsVisible(true);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setSeparatorStroke(stroke5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = piePlot10.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation12 = piePlot10.getDirection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot0.initialise(graphics2D7, rectangle2D8, piePlot10, (java.lang.Integer) 0, plotRenderingInfo14);
        boolean boolean16 = ringPlot0.isCircular();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertNotNull(rotation12);
        org.junit.Assert.assertNotNull(piePlotState15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        boolean boolean9 = dateAxis1.isVerticalTickLabels();
        boolean boolean11 = dateAxis1.isHiddenValue(10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        int int14 = categoryPlot12.getIndexOf(categoryItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot12.zoomRangeAxes((double) (byte) 0, (double) 500, plotRenderingInfo17, point2D18);
        categoryPlot12.clearAnnotations();
        java.awt.Color color21 = java.awt.Color.WHITE;
        categoryPlot12.setRangeGridlinePaint((java.awt.Paint) color21);
        dateAxis1.setTickLabelPaint((java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        double double3 = piePlot1.getMaximumLabelWidth();
        double double4 = piePlot1.getStartAngle();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLegendLabelToolTipGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot1.getSimpleLabelOffset();
        double double7 = piePlot1.getMaximumExplodePercent();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint2, stroke3);
        boolean boolean5 = strokeMap0.equals((java.lang.Object) valueMarker4);
        java.awt.Paint paint6 = valueMarker4.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker4.getLabelAnchor();
        java.lang.Object obj8 = valueMarker4.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = valueMarker4.getLabelOffsetType();
        valueMarker4.setLabel("RectangleInsets[t=0.0,l=10.0,b=0.0,r=32.0]");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle10.setVerticalAlignment(verticalAlignment12);
        jFreeChart8.addLegend(legendTitle10);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle16.setText("");
        textTitle16.setText("UnitType.ABSOLUTE");
        jFreeChart8.setTitle(textTitle16);
        org.jfree.chart.plot.Plot plot22 = jFreeChart8.getPlot();
        jFreeChart8.setTitle(" version .\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!");
        java.lang.Object obj25 = null;
        try {
            jFreeChart8.setTextAntiAlias(obj25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(plot22);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        double double3 = piePlot1.getMaximumLabelWidth();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = legendTitle5.getHorizontalAlignment();
        legendTitle5.setNotify(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.util.UnitType unitType14 = rectangleInsets13.getUnitType();
        java.lang.String str15 = unitType14.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets(unitType14, (double) 0, (double) 10L, (double) (short) 0, (double) ' ');
        legendTitle5.setLegendItemGraphicPadding(rectangleInsets20);
        piePlot1.setLabelPadding(rectangleInsets20);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnitType.ABSOLUTE" + "'", str15.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 0, (double) 500, plotRenderingInfo5, point2D6);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10);
        int int12 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        int int15 = categoryPlot13.getIndexOf(categoryItemRenderer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot13.getColumnRenderingOrder();
        categoryPlot13.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot13.zoomDomainAxes((double) (short) -1, plotRenderingInfo21, point2D22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot13.getDomainAxisLocation((int) (byte) 10);
        categoryPlot0.setDomainAxisLocation(axisLocation25, false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range4 = org.jfree.data.Range.expand(range1, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range4, (double) (-1), false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean13 = range10.intersects((double) (byte) 1, (double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range7, lengthConstraintType8, (double) (-1), range10, lengthConstraintType14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint15.toFixedHeight((double) 15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint17.toFixedWidth((double) 0);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairValue(136.0d, true);
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot7.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot7.getDomainAxisLocation();
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D1.setRightArrow(shape2);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!");
        chartEntity5.setURLText("Pie 3D Plot");
        java.lang.Object obj8 = chartEntity5.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer8);
        java.lang.String str10 = dateAxis7.getLabelToolTip();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle13.getHorizontalAlignment();
        legendTitle13.setHeight(0.0d);
        java.awt.Font font17 = legendTitle13.getItemFont();
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font17, paint18);
        org.jfree.chart.text.TextFragment textFragment20 = textLine19.getFirstTextFragment();
        boolean boolean21 = dateAxis7.equals((java.lang.Object) textFragment20);
        textLine2.removeFragment(textFragment20);
        java.awt.Graphics2D graphics2D23 = null;
        try {
            org.jfree.chart.util.Size2D size2D24 = textLine2.calculateDimensions(graphics2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(textFragment20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        waferMapPlot6.setNoDataMessageFont(font12);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 100L, font12);
        categoryAxis3D0.removeCategoryLabelToolTip((java.lang.Comparable) 1.0E-8d);
        float float17 = categoryAxis3D0.getTickMarkInsideLength();
        categoryAxis3D0.setTickLabelsVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = categoryAxis3D0.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = null;
        try {
            numberAxis0.setRangeType(rangeType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Other");
        textTitle1.setHeight((double) 2.0f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle12.setText("");
        boolean boolean15 = textTitle12.getExpandToFitSpace();
        boolean boolean16 = textTitle12.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = legendTitle19.getHorizontalAlignment();
        legendTitle19.setHeight(0.0d);
        java.awt.Font font23 = legendTitle19.getItemFont();
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font23, paint24);
        textTitle12.setFont(font23);
        piePlot5.setLabelFont(font23);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        dateAxis5.setFixedDimension((double) 1.0f);
        dateAxis5.setTickMarkOutsideLength((float) 1);
        java.util.Date date10 = dateAxis5.getMaximumDate();
        dateAxis1.setMinimumDate(date10);
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range15 = org.jfree.data.Range.expand(range12, (double) (short) 0, (double) (byte) 0);
        double double16 = range12.getUpperBound();
        dateAxis1.setRange(range12);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.setDomainCrosshairLockedOnData(false);
        java.awt.Color color21 = java.awt.Color.GRAY;
        java.awt.Color color22 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        float[] floatArray24 = null;
        float[] floatArray25 = color21.getComponents(colorSpace23, floatArray24);
        xYPlot6.setDomainCrosshairPaint((java.awt.Paint) color21);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace27, true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle1.removeChangeListener(titleChangeListener3);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot13);
        jFreeChart14.setBackgroundImageAlpha((float) (short) 0);
        jFreeChart14.clearSubtitles();
        titleChangeEvent5.setChart(jFreeChart14);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getInsets();
        java.lang.String str5 = piePlot1.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot1.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Range[0.0,1.0]" + "'", str5.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat5 = null;
        dateAxis4.setDateFormatOverride(dateFormat5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color7);
        piePlot1.setBackgroundPaint((java.awt.Paint) color7);
        java.lang.Object obj10 = piePlot1.clone();
        piePlot1.setLabelGap((double) 100);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(10.0d, (double) (-1));
        size2D2.setHeight((double) (-1));
        size2D2.setWidth((double) (byte) 100);
        size2D2.width = (-1L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle6.setText("");
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle6.getBounds();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        xYPlot16.drawAnnotations(graphics2D17, rectangle2D18, plotRenderingInfo19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.util.List list23 = null;
        xYPlot16.drawRangeTickBands(graphics2D21, rectangle2D22, list23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        xYPlot16.setFixedRangeAxisSpace(axisSpace25, false);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = xYPlot16.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot16);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer36);
        int int38 = xYPlot37.getDatasetCount();
        java.awt.Paint paint39 = xYPlot37.getDomainGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, (org.jfree.chart.axis.ValueAxis) dateAxis45, xYItemRenderer46);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot47);
        org.jfree.chart.axis.AxisLocation axisLocation50 = xYPlot47.getDomainAxisLocation(100);
        xYPlot37.setRangeAxisLocation(axisLocation50, false);
        xYPlot16.setRangeAxisLocation((int) 'a', axisLocation50, true);
        try {
            java.lang.Object obj55 = blockContainer3.draw(graphics2D4, rectangle2D9, (java.lang.Object) axisLocation50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNull(legendItemCollection28);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(axisLocation50);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("hi!");
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.08d);
        ringPlot0.setSeparatorsVisible(true);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setSeparatorStroke(stroke5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat14 = null;
        dateAxis13.setDateFormatOverride(dateFormat14);
        java.awt.Color color16 = java.awt.Color.GRAY;
        dateAxis13.setTickLabelPaint((java.awt.Paint) color16);
        java.util.Date date18 = dateAxis13.getMinimumDate();
        java.awt.Color color19 = java.awt.Color.GRAY;
        dateAxis13.setTickMarkPaint((java.awt.Paint) color19);
        boolean boolean21 = dateAxis13.isVerticalTickLabels();
        boolean boolean23 = dateAxis13.isHiddenValue(10L);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = piePlot25.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat29 = null;
        dateAxis28.setDateFormatOverride(dateFormat29);
        java.awt.Color color31 = java.awt.Color.GRAY;
        dateAxis28.setTickLabelPaint((java.awt.Paint) color31);
        piePlot25.setBackgroundPaint((java.awt.Paint) color31);
        dateAxis13.setPlot((org.jfree.chart.plot.Plot) piePlot25);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat37 = null;
        dateAxis36.setDateFormatOverride(dateFormat37);
        java.awt.Shape shape39 = dateAxis36.getDownArrow();
        piePlot25.setLegendItemShape(shape39);
        piePlot3D11.setLegendItemShape(shape39);
        java.lang.String str42 = piePlot3D11.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.chart.plot.PiePlotState piePlotState45 = ringPlot0.initialise(graphics2D8, rectangle2D9, (org.jfree.chart.plot.PiePlot) piePlot3D11, (java.lang.Integer) 3, plotRenderingInfo44);
        piePlotState45.setPieWRadius(0.14d);
        java.awt.geom.Rectangle2D rectangle2D48 = piePlotState45.getExplodedPieArea();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Pie 3D Plot" + "'", str42.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(piePlotState45);
        org.junit.Assert.assertNull(rectangle2D48);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint1, stroke2);
        double double4 = valueMarker3.getValue();
        java.awt.Paint paint5 = valueMarker3.getLabelPaint();
        java.awt.Paint paint6 = valueMarker3.getOutlinePaint();
        java.awt.Font font7 = null;
        try {
            valueMarker3.setLabelFont(font7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot7.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot7.getRangeAxis();
        org.jfree.chart.StrokeMap strokeMap14 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint16, stroke17);
        boolean boolean19 = strokeMap14.equals((java.lang.Object) valueMarker18);
        java.awt.Paint paint20 = valueMarker18.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = valueMarker18.getLabelAnchor();
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker18);
        java.awt.Paint paint23 = valueMarker18.getOutlinePaint();
        org.junit.Assert.assertNotNull(valueAxis13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.StrokeMap strokeMap15 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint17, stroke18);
        boolean boolean20 = strokeMap15.equals((java.lang.Object) valueMarker19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = valueMarker19.getLabelOffset();
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = valueMarker19.getLabelOffsetType();
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        xYPlot6.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        java.lang.Object obj10 = null;
        try {
            jFreeChart9.setTextAntiAlias(obj10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Paint paint4 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        int int7 = categoryPlot5.getIndexOf(categoryItemRenderer6);
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot5.getColumnRenderingOrder();
        categoryPlot5.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot5.getOrientation();
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot5.getRowRenderingOrder();
        categoryPlot0.setRowRenderingOrder(sortOrder13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(sortOrder13);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset();
        java.lang.String str4 = categoryPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range0.intersects((double) (byte) 1, (double) (short) 10);
        java.lang.String str4 = range0.toString();
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range0, (double) (byte) -1, false);
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 0.5f);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,1.0]" + "'", str4.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        dateAxis8.setFixedDimension((double) 1.0f);
        dateAxis8.setFixedAutoRange((double) (short) 1);
        org.jfree.data.Range range13 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis8);
        boolean boolean14 = dateAxis8.isInverted();
        boolean boolean15 = dateAxis8.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.08d);
        boolean boolean3 = ringPlot0.isCircular();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        waferMapPlot6.setNoDataMessageFont(font12);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 100L, font12);
        categoryAxis3D0.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
        double double17 = categoryAxis3D0.getLowerMargin();
        java.lang.Object obj18 = categoryAxis3D0.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = xYPlot6.getDatasetRenderingOrder();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.text.TextBlock textBlock22 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine23 = textBlock22.getLastLine();
        java.util.List list24 = textBlock22.getLines();
        java.util.List list25 = textBlock22.getLines();
        xYPlot6.drawDomainTickBands(graphics2D20, rectangle2D21, list25);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        dateAxis29.setFixedDimension((double) 1.0f);
        dateAxis29.setTickMarkOutsideLength((float) 1);
        java.util.Date date34 = dateAxis29.getMaximumDate();
        xYPlot6.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis29);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertNull(textLine23);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot2.getInsets();
        piePlot2.setMinimumArcAngleToDraw((double) (byte) 100);
        boolean boolean8 = piePlot2.getSimpleLabels();
        java.awt.Font font9 = piePlot2.getNoDataMessageFont();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = piePlot11.getInsets();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = null;
        piePlot11.setLegendLabelURLGenerator(pieURLGenerator15);
        java.lang.String str17 = piePlot11.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        xYPlot24.drawAnnotations(graphics2D25, rectangle2D26, plotRenderingInfo27);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double35 = rectangleInsets33.calculateLeftOutset((double) 10.0f);
        xYPlot24.setAxisOffset(rectangleInsets33);
        xYPlot24.setDomainCrosshairLockedOnData(false);
        java.awt.Color color39 = java.awt.Color.GRAY;
        java.awt.Color color40 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace41 = color40.getColorSpace();
        float[] floatArray42 = null;
        float[] floatArray43 = color39.getComponents(colorSpace41, floatArray42);
        xYPlot24.setDomainCrosshairPaint((java.awt.Paint) color39);
        piePlot11.setShadowPaint((java.awt.Paint) color39);
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("", font9, (java.awt.Paint) color39);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pie Plot" + "'", str17.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 35.0d + "'", double35 == 35.0d);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(colorSpace41);
        org.junit.Assert.assertNotNull(floatArray43);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint2, stroke3);
        boolean boolean5 = strokeMap0.equals((java.lang.Object) valueMarker4);
        java.awt.Paint paint6 = valueMarker4.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = piePlot8.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation10 = piePlot8.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot8.getLegendLabelToolTipGenerator();
        valueMarker4.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot8);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot19.drawAnnotations(graphics2D20, rectangle2D21, plotRenderingInfo22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = xYPlot19.getRendererForDataset(xYDataset24);
        java.awt.Paint paint27 = xYPlot19.getQuadrantPaint(0);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        xYPlot19.setFixedLegendItems(legendItemCollection28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.util.List list32 = null;
        xYPlot19.drawDomainTickBands(graphics2D30, rectangle2D31, list32);
        java.awt.Stroke stroke34 = xYPlot19.getRangeGridlineStroke();
        valueMarker4.setStroke(stroke34);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNull(xYItemRenderer25);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        jFreeChart8.setBackgroundImageAlpha((float) (short) 0);
        int int11 = jFreeChart8.getSubtitleCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        int int14 = categoryPlot12.getIndexOf(categoryItemRenderer13);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot12.getColumnRenderingOrder();
        categoryPlot12.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = categoryPlot12.getOrientation();
        categoryPlot12.setAnchorValue((double) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat29 = null;
        dateAxis28.setDateFormatOverride(dateFormat29);
        java.awt.Color color31 = java.awt.Color.GRAY;
        dateAxis28.setTickLabelPaint((java.awt.Paint) color31);
        boolean boolean33 = rectangleInsets26.equals((java.lang.Object) color31);
        float[] floatArray40 = new float[] { 100L, '#', (byte) 100, (short) 1, (-1L), (byte) -1 };
        float[] floatArray41 = color31.getRGBColorComponents(floatArray40);
        categoryPlot12.setBackgroundPaint((java.awt.Paint) color31);
        jFreeChart8.setBorderPaint((java.awt.Paint) color31);
        boolean boolean44 = jFreeChart8.getAntiAlias();
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = numberAxis3D0.getNumberFormatOverride();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        numberAxis3D0.setStandardTickUnits(tickUnitSource2);
        double double4 = numberAxis3D0.getLowerMargin();
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.lang.Object[][] objArray2 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = legendTitle3.getHorizontalAlignment();
        legendTitle3.setHeight(0.0d);
        java.awt.Font font7 = legendTitle3.getItemFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font7, paint8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat12 = null;
        dateAxis11.setDateFormatOverride(dateFormat12);
        java.awt.Color color14 = java.awt.Color.GRAY;
        dateAxis11.setTickLabelPaint((java.awt.Paint) color14);
        java.util.Date date16 = dateAxis11.getMinimumDate();
        java.awt.Color color17 = java.awt.Color.GRAY;
        dateAxis11.setTickMarkPaint((java.awt.Paint) color17);
        boolean boolean19 = dateAxis11.isVerticalTickLabels();
        boolean boolean21 = dateAxis11.isHiddenValue(10L);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot23.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat27 = null;
        dateAxis26.setDateFormatOverride(dateFormat27);
        java.awt.Color color29 = java.awt.Color.GRAY;
        dateAxis26.setTickLabelPaint((java.awt.Paint) color29);
        piePlot23.setBackgroundPaint((java.awt.Paint) color29);
        dateAxis11.setPlot((org.jfree.chart.plot.Plot) piePlot23);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat35 = null;
        dateAxis34.setDateFormatOverride(dateFormat35);
        java.awt.Shape shape37 = dateAxis34.getDownArrow();
        piePlot23.setLegendItemShape(shape37);
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", font7, (org.jfree.chart.plot.Plot) piePlot23, true);
        java.awt.Color color41 = java.awt.Color.BLUE;
        piePlot23.setShadowPaint((java.awt.Paint) color41);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        xYPlot6.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(axisSpace9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getInsets();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator5);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot1.setLabelOutlinePaint(paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot1.setBaseSectionOutlineStroke(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.setDomainCrosshairLockedOnData(false);
        java.awt.Color color21 = java.awt.Color.GRAY;
        java.awt.Color color22 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        float[] floatArray24 = null;
        float[] floatArray25 = color21.getComponents(colorSpace23, floatArray24);
        xYPlot6.setDomainCrosshairPaint((java.awt.Paint) color21);
        float[] floatArray27 = null;
        float[] floatArray28 = color21.getComponents(floatArray27);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray28);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (short) 10, (float) '#', textAnchor4, (double) 0, 100.0f, (float) (-1));
        java.lang.Object obj9 = null;
        boolean boolean10 = textAnchor4.equals(obj9);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxis((int) (short) -1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D6, true);
        float float9 = categoryAxis3D6.getTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis3D6.getTickLabelInsets();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Category Plot", "");
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer((int) (short) 0);
        categoryPlot0.mapDatasetToRangeAxis(500, 0);
        double double9 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        textTitle1.setText("UnitType.ABSOLUTE");
        java.awt.Paint paint6 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        textTitle1.setPaint(paint6);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot6.getRendererForDataset(xYDataset11);
        xYPlot6.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot6.getRangeAxisLocation(1);
        java.awt.Stroke stroke17 = xYPlot6.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        waferMapPlot6.setNoDataMessageFont(font12);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 100L, font12);
        categoryAxis3D0.removeCategoryLabelToolTip((java.lang.Comparable) 1.0E-8d);
        float float17 = categoryAxis3D0.getTickMarkInsideLength();
        categoryAxis3D0.setTickLabelsVisible(true);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle23.setText("");
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle23.getBounds();
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = legendTitle28.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = legendTitle31.getHorizontalAlignment();
        legendTitle31.setHeight(0.0d);
        java.awt.Font font35 = legendTitle31.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = legendTitle31.getLegendItemGraphicEdge();
        legendTitle28.setLegendItemGraphicEdge(rectangleEdge36);
        double double38 = categoryAxis3D0.getCategoryEnd(2, (int) (byte) 100, rectangle2D26, rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString(" version .\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!", graphics2D1, (float) (short) 100, 0.5f, (double) 100, (float) 500, (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle15.setText("");
        boolean boolean18 = textTitle15.getExpandToFitSpace();
        boolean boolean19 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = legendTitle22.getHorizontalAlignment();
        legendTitle22.setHeight(0.0d);
        java.awt.Font font26 = legendTitle22.getItemFont();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font26, paint27);
        textTitle15.setFont(font26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = textTitle15.getVerticalAlignment();
        legendTitle12.setVerticalAlignment(verticalAlignment30);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = legendTitle12.getHorizontalAlignment();
        org.jfree.chart.StrokeMap strokeMap34 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint36, stroke37);
        boolean boolean39 = strokeMap34.equals((java.lang.Object) valueMarker38);
        java.awt.Paint paint40 = valueMarker38.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = valueMarker38.getLabelAnchor();
        legendTitle12.setLegendItemGraphicLocation(rectangleAnchor41);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        try {
            legendTitle12.draw(graphics2D43, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = legendTitle2.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer4 = legendTitle2.getItemContainer();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font7);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("Other", font7);
        legendTitle2.setItemFont(font7);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        ringPlot11.setSectionDepth((double) (-1L));
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("Category Plot", font7, (org.jfree.chart.plot.Plot) ringPlot11, true);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(blockContainer4);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.StrokeMap strokeMap15 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint17, stroke18);
        boolean boolean20 = strokeMap15.equals((java.lang.Object) valueMarker19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = valueMarker19.getLabelOffset();
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font25);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = piePlot28.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation30 = piePlot28.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator31 = piePlot28.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font25, (org.jfree.chart.plot.Plot) piePlot28, false);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle38.setText("");
        boolean boolean41 = textTitle38.getExpandToFitSpace();
        boolean boolean42 = textTitle38.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = legendTitle45.getHorizontalAlignment();
        legendTitle45.setHeight(0.0d);
        java.awt.Font font49 = legendTitle45.getItemFont();
        java.awt.Paint paint50 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine51 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font49, paint50);
        textTitle38.setFont(font49);
        org.jfree.chart.util.VerticalAlignment verticalAlignment53 = textTitle38.getVerticalAlignment();
        legendTitle35.setVerticalAlignment(verticalAlignment53);
        jFreeChart33.addSubtitle((org.jfree.chart.title.Title) legendTitle35);
        xYPlot6.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart33);
        java.awt.Stroke stroke57 = xYPlot6.getDomainGridlineStroke();
        java.awt.Paint paint59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke60 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker61 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint59, stroke60);
        double double62 = valueMarker61.getValue();
        java.awt.Paint paint63 = valueMarker61.getLabelPaint();
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker61);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(rotation30);
        org.junit.Assert.assertNull(pieSectionLabelGenerator31);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(verticalAlignment53);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(paint63);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.08d);
        ringPlot0.setSeparatorsVisible(true);
        ringPlot0.setSectionOutlinesVisible(false);
        ringPlot0.setLabelGap(0.14d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        xYPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot6.getDataset();
        org.junit.Assert.assertNull(xYDataset13);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = numberAxis3D0.getNumberFormatOverride();
        boolean boolean2 = numberAxis3D0.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat3 = numberAxis3D0.getNumberFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYPlot10.drawAnnotations(graphics2D11, rectangle2D12, plotRenderingInfo13);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double21 = rectangleInsets19.calculateLeftOutset((double) 10.0f);
        xYPlot10.setAxisOffset(rectangleInsets19);
        xYPlot10.setDomainCrosshairLockedOnData(false);
        java.awt.Color color25 = java.awt.Color.GRAY;
        java.awt.Color color26 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace27 = color26.getColorSpace();
        float[] floatArray28 = null;
        float[] floatArray29 = color25.getComponents(colorSpace27, floatArray28);
        xYPlot10.setDomainCrosshairPaint((java.awt.Paint) color25);
        java.awt.Color color31 = color25.brighter();
        numberAxis3D0.setTickLabelPaint((java.awt.Paint) color25);
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 35.0d + "'", double21 == 35.0d);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(colorSpace27);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer((int) '4', categoryItemRenderer5, false);
        boolean boolean8 = categoryPlot0.isRangeZoomable();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot10.getIndexOf(categoryItemRenderer11);
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot10.getColumnRenderingOrder();
        categoryPlot0.setRowRenderingOrder(sortOrder13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = null;
        try {
            categoryPlot0.setOrientation(plotOrientation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNull(axisSpace15);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getDepthFactor();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        piePlot3D1.setSectionPaint((java.lang.Comparable) 3.0d, paint4);
        java.lang.Object obj6 = piePlot3D1.clone();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setText("");
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle9.getBounds();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot19.drawAnnotations(graphics2D20, rectangle2D21, plotRenderingInfo22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double30 = rectangleInsets28.calculateLeftOutset((double) 10.0f);
        xYPlot19.setAxisOffset(rectangleInsets28);
        java.awt.Paint paint32 = xYPlot19.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) numberAxis3D38, (org.jfree.chart.axis.ValueAxis) dateAxis40, xYItemRenderer41);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot42);
        xYPlot42.setRangeCrosshairValue(136.0d, true);
        java.awt.geom.Point2D point2D47 = xYPlot42.getQuadrantOrigin();
        xYPlot19.zoomRangeAxes((double) (short) 1, plotRenderingInfo34, point2D47);
        org.jfree.chart.plot.PlotState plotState49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        try {
            piePlot3D1.draw(graphics2D7, rectangle2D12, point2D47, plotState49, plotRenderingInfo50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12d + "'", double2 == 0.12d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 35.0d + "'", double30 == 35.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(point2D47);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.08d);
        ringPlot0.setSeparatorsVisible(true);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setSeparatorStroke(stroke5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot0.getLegendLabelToolTipGenerator();
        float float8 = ringPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        textTitle1.setID("RectangleEdge.BOTTOM");
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle1.setFont(font18);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat22 = null;
        dateAxis21.setDateFormatOverride(dateFormat22);
        java.awt.Color color24 = java.awt.Color.GRAY;
        dateAxis21.setTickLabelPaint((java.awt.Paint) color24);
        java.util.Date date26 = dateAxis21.getMinimumDate();
        java.text.DateFormat dateFormat27 = null;
        dateAxis21.setDateFormatOverride(dateFormat27);
        java.lang.String str29 = dateAxis21.getLabel();
        java.awt.Paint paint30 = dateAxis21.getTickLabelPaint();
        textTitle1.setBackgroundPaint(paint30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = textTitle1.getPosition();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer((int) (short) 0);
        categoryPlot0.mapDatasetToRangeAxis(500, 0);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray9 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(categoryAxisArray9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.08d);
        ringPlot0.setSeparatorsVisible(true);
        ringPlot0.setSectionOutlinesVisible(false);
        boolean boolean7 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat4 = null;
        dateAxis3.setDateFormatOverride(dateFormat4);
        java.awt.Color color6 = java.awt.Color.GRAY;
        dateAxis3.setTickLabelPaint((java.awt.Paint) color6);
        java.util.Date date8 = dateAxis3.getMinimumDate();
        java.awt.Color color9 = java.awt.Color.GRAY;
        dateAxis3.setTickMarkPaint((java.awt.Paint) color9);
        boolean boolean11 = dateAxis3.isVerticalTickLabels();
        boolean boolean13 = dateAxis3.isHiddenValue(10L);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = piePlot15.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat19 = null;
        dateAxis18.setDateFormatOverride(dateFormat19);
        java.awt.Color color21 = java.awt.Color.GRAY;
        dateAxis18.setTickLabelPaint((java.awt.Paint) color21);
        piePlot15.setBackgroundPaint((java.awt.Paint) color21);
        dateAxis3.setPlot((org.jfree.chart.plot.Plot) piePlot15);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat27 = null;
        dateAxis26.setDateFormatOverride(dateFormat27);
        java.awt.Shape shape29 = dateAxis26.getDownArrow();
        piePlot15.setLegendItemShape(shape29);
        piePlot3D1.setLegendItemShape(shape29);
        java.lang.String str32 = piePlot3D1.getPlotType();
        boolean boolean33 = piePlot3D1.getDarkerSides();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Pie 3D Plot" + "'", str32.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.LEFT" + "'", str1.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.2d, (-2.0d), (double) 0.0f, 0.0d);
        java.lang.String str6 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.RELATIVE" + "'", str6.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        java.lang.String str3 = horizontalAlignment2.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, 0.0d, (double) 1.0f);
        java.lang.Object obj8 = null;
        boolean boolean9 = verticalAlignment4.equals(obj8);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        textTitle1.setPaint((java.awt.Paint) color16);
        textTitle1.setToolTipText("WMAP_Plot");
        boolean boolean20 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer10);
        java.awt.Shape shape12 = dateAxis9.getLeftArrow();
        int int13 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        int int7 = xYPlot6.getDatasetCount();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot6.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot13.setOrientation(plotOrientation14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot13.getDomainAxisEdge();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat19 = null;
        dateAxis18.setDateFormatOverride(dateFormat19);
        java.awt.Color color21 = java.awt.Color.GRAY;
        dateAxis18.setTickLabelPaint((java.awt.Paint) color21);
        java.util.Date date23 = dateAxis18.getMinimumDate();
        java.awt.Color color24 = java.awt.Color.GRAY;
        dateAxis18.setTickMarkPaint((java.awt.Paint) color24);
        boolean boolean26 = dateAxis18.isVerticalTickLabels();
        dateAxis18.setLabelURL("");
        int int29 = categoryPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis18);
        boolean boolean30 = dateAxis18.isTickMarksVisible();
        xYPlot6.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) dateAxis18, false);
        java.awt.Paint paint33 = dateAxis18.getLabelPaint();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = legendTitle3.getHorizontalAlignment();
        legendTitle3.setHeight(0.0d);
        java.awt.Font font7 = legendTitle3.getItemFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font7, paint8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat12 = null;
        dateAxis11.setDateFormatOverride(dateFormat12);
        java.awt.Color color14 = java.awt.Color.GRAY;
        dateAxis11.setTickLabelPaint((java.awt.Paint) color14);
        java.util.Date date16 = dateAxis11.getMinimumDate();
        java.awt.Color color17 = java.awt.Color.GRAY;
        dateAxis11.setTickMarkPaint((java.awt.Paint) color17);
        boolean boolean19 = dateAxis11.isVerticalTickLabels();
        boolean boolean21 = dateAxis11.isHiddenValue(10L);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot23.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat27 = null;
        dateAxis26.setDateFormatOverride(dateFormat27);
        java.awt.Color color29 = java.awt.Color.GRAY;
        dateAxis26.setTickLabelPaint((java.awt.Paint) color29);
        piePlot23.setBackgroundPaint((java.awt.Paint) color29);
        dateAxis11.setPlot((org.jfree.chart.plot.Plot) piePlot23);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat35 = null;
        dateAxis34.setDateFormatOverride(dateFormat35);
        java.awt.Shape shape37 = dateAxis34.getDownArrow();
        piePlot23.setLegendItemShape(shape37);
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", font7, (org.jfree.chart.plot.Plot) piePlot23, true);
        jFreeChart40.fireChartChanged();
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(shape37);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        java.lang.Object obj3 = categoryAxis3D0.clone();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle8.setText("");
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double13 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor4, 0, (int) ' ', rectangle2D11, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset10, false);
        boolean boolean14 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset10);
        categoryPlot0.setDataset((int) (byte) 100, categoryDataset10);
        org.jfree.data.KeyToGroupMap keyToGroupMap16 = null;
        try {
            org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, keyToGroupMap16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double5 = rectangleInsets4.getRight();
        double double7 = rectangleInsets4.calculateLeftOutset((double) ' ');
        double double9 = rectangleInsets4.calculateLeftInset(0.0d);
        double double10 = rectangleInsets4.getLeft();
        double double12 = rectangleInsets4.trimWidth((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 35.0d + "'", double10 == 35.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-35.0d) + "'", double12 == (-35.0d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        double double5 = legendTitle4.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle4.setVerticalAlignment(verticalAlignment6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat10 = null;
        dateAxis9.setDateFormatOverride(dateFormat10);
        java.awt.Color color12 = java.awt.Color.GRAY;
        dateAxis9.setTickLabelPaint((java.awt.Paint) color12);
        boolean boolean14 = verticalAlignment6.equals((java.lang.Object) color12);
        java.awt.Color color15 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace16 = color15.getColorSpace();
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        java.awt.color.ColorSpace colorSpace19 = color17.getColorSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat27 = null;
        dateAxis26.setDateFormatOverride(dateFormat27);
        java.awt.Color color29 = java.awt.Color.GRAY;
        dateAxis26.setTickLabelPaint((java.awt.Paint) color29);
        boolean boolean31 = rectangleInsets24.equals((java.lang.Object) color29);
        float[] floatArray38 = new float[] { 100L, '#', (byte) 100, (short) 1, (-1L), (byte) -1 };
        float[] floatArray39 = color29.getRGBColorComponents(floatArray38);
        float[] floatArray40 = color17.getRGBColorComponents(floatArray39);
        float[] floatArray41 = color12.getComponents(colorSpace16, floatArray39);
        float[] floatArray42 = java.awt.Color.RGBtoHSB(1, 1, (int) (byte) 1, floatArray41);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(colorSpace19);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.Object obj0 = null;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = legendTitle2.getHorizontalAlignment();
        legendTitle2.setNotify(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets10.getUnitType();
        java.lang.String str12 = unitType11.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType11, (double) 0, (double) 10L, (double) (short) 0, (double) ' ');
        legendTitle2.setLegendItemGraphicPadding(rectangleInsets17);
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) legendTitle2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnitType.ABSOLUTE" + "'", str12.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint2, stroke3);
        boolean boolean5 = strokeMap0.equals((java.lang.Object) valueMarker4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = valueMarker4.getLabelOffset();
        try {
            valueMarker4.setAlpha((float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = multiplePiePlot0.getDataExtractOrder();
        java.lang.String str2 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range0.intersects((double) (byte) 1, (double) (short) 10);
        java.lang.String str4 = range0.toString();
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range0, (double) (byte) -1, false);
        boolean boolean9 = range7.contains((double) (short) 1);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,1.0]" + "'", str4.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.mapDatasetToRangeAxis(15, (int) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer28);
        dateAxis27.setLabelURL("Other");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis27.getStandardTickUnits();
        xYPlot6.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) dateAxis27, true);
        xYPlot6.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(tickUnitSource32);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxis((int) (short) -1);
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot6.getIndexOf(categoryItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomRangeAxes((double) (byte) 0, (double) 500, plotRenderingInfo11, point2D12);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot6.getRangeAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation15, true);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer14);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range16, false, false);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat22 = null;
        dateAxis21.setDateFormatOverride(dateFormat22);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        dateAxis25.setFixedDimension((double) 1.0f);
        dateAxis25.setTickMarkOutsideLength((float) 1);
        java.util.Date date30 = dateAxis25.getMaximumDate();
        dateAxis21.setMinimumDate(date30);
        dateAxis13.setMaximumDate(date30);
        double double33 = dateAxis13.getUpperMargin();
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = dateAxis13.getTickUnit();
        java.util.Date date35 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit34);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit34);
        org.junit.Assert.assertNotNull(date35);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle15.setText("");
        boolean boolean18 = textTitle15.getExpandToFitSpace();
        boolean boolean19 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = legendTitle22.getHorizontalAlignment();
        legendTitle22.setHeight(0.0d);
        java.awt.Font font26 = legendTitle22.getItemFont();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font26, paint27);
        textTitle15.setFont(font26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = textTitle15.getVerticalAlignment();
        legendTitle12.setVerticalAlignment(verticalAlignment30);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent35 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle34);
        jFreeChart10.addLegend(legendTitle34);
        java.lang.Object obj37 = jFreeChart10.getTextAntiAlias();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNull(obj37);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double6 = rectangleInsets4.calculateTopInset((double) 1.0f);
        double double8 = rectangleInsets4.calculateTopInset((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.setDomainCrosshairLockedOnData(false);
        java.awt.Color color21 = java.awt.Color.GRAY;
        java.awt.Color color22 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        float[] floatArray24 = null;
        float[] floatArray25 = color21.getComponents(colorSpace23, floatArray24);
        xYPlot6.setDomainCrosshairPaint((java.awt.Paint) color21);
        int int27 = xYPlot6.getRangeAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = xYPlot6.getFixedLegendItems();
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = xYPlot6.getRangeMarkers((-1), layer30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat34 = null;
        dateAxis33.setDateFormatOverride(dateFormat34);
        java.awt.Color color36 = java.awt.Color.GRAY;
        dateAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.util.Date date38 = dateAxis33.getMinimumDate();
        java.text.DateFormat dateFormat39 = null;
        dateAxis33.setDateFormatOverride(dateFormat39);
        java.lang.String str41 = dateAxis33.getLabel();
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int43 = color42.getGreen();
        dateAxis33.setTickLabelPaint((java.awt.Paint) color42);
        xYPlot6.setRangeGridlinePaint((java.awt.Paint) color42);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(legendItemCollection28);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint1, stroke2);
        double double4 = valueMarker3.getValue();
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor(0, 15, (int) ' ');
        valueMarker3.setLabelPaint((java.awt.Paint) chartColor8);
        java.awt.Paint paint10 = valueMarker3.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer((int) (short) 0);
        int int6 = categoryPlot0.getWeight();
        boolean boolean7 = categoryPlot0.isRangeCrosshairVisible();
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray10);
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot0.getRendererForDataset(categoryDataset11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
        org.junit.Assert.assertNull(categoryItemRenderer13);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "Size2D[width=10.0, height=-1.0]", 0.2d, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        double double4 = blockContainer3.getContentXOffset();
        java.lang.Object obj5 = blockContainer3.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getDepthFactor();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        piePlot3D1.setSectionPaint((java.lang.Comparable) 3.0d, paint4);
        java.lang.Object obj6 = piePlot3D1.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat9 = null;
        dateAxis8.setDateFormatOverride(dateFormat9);
        java.awt.Color color11 = java.awt.Color.GRAY;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color11);
        java.util.Date date13 = dateAxis8.getMinimumDate();
        java.text.DateFormat dateFormat14 = null;
        dateAxis8.setDateFormatOverride(dateFormat14);
        java.lang.String str16 = dateAxis8.getLabel();
        java.awt.Paint paint17 = dateAxis8.getTickLabelPaint();
        java.awt.Shape shape18 = dateAxis8.getUpArrow();
        piePlot3D1.setLegendItemShape(shape18);
        piePlot3D1.setDarkerSides(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12d + "'", double2 == 0.12d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.getAttributedLabel((int) 'a');
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNull(attributedString3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.08d);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        double double5 = piePlot3D4.getDepthFactor();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        piePlot3D4.setSectionPaint((java.lang.Comparable) 3.0d, paint7);
        ringPlot0.setSeparatorPaint(paint7);
        java.awt.Paint paint10 = ringPlot0.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.12d + "'", double5 == 0.12d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("Range[0.0,1.0]", font3, (java.awt.Paint) color4, (float) (short) 100);
        textLine1.addFragment(textFragment6);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range4 = org.jfree.data.Range.expand(range1, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range4, (double) (-1), false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean13 = range10.intersects((double) (byte) 1, (double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range7, lengthConstraintType8, (double) (-1), range10, lengthConstraintType14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint15.toUnconstrainedWidth();
        org.jfree.chart.util.Size2D size2D19 = new org.jfree.chart.util.Size2D(10.0d, (double) (-1));
        size2D19.setHeight((double) (-1));
        org.jfree.chart.util.Size2D size2D22 = rectangleConstraint16.calculateConstrainedSize(size2D19);
        java.lang.Object obj23 = size2D19.clone();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot0.getDataRange(valueAxis8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        java.lang.String str9 = dateAxis1.getLabel();
        java.awt.Paint paint10 = dateAxis1.getTickLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis1.getLabelInsets();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = xYPlot6.getDatasetRenderingOrder();
        xYPlot6.mapDatasetToRangeAxis((int) 'a', 3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        xYPlot32.drawAnnotations(graphics2D33, rectangle2D34, plotRenderingInfo35);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double43 = rectangleInsets41.calculateLeftOutset((double) 10.0f);
        xYPlot32.setAxisOffset(rectangleInsets41);
        java.awt.Paint paint45 = xYPlot32.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D51 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) numberAxis3D51, (org.jfree.chart.axis.ValueAxis) dateAxis53, xYItemRenderer54);
        org.jfree.chart.JFreeChart jFreeChart56 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot55);
        xYPlot55.setRangeCrosshairValue(136.0d, true);
        java.awt.geom.Point2D point2D60 = xYPlot55.getQuadrantOrigin();
        xYPlot32.zoomRangeAxes((double) (short) 1, plotRenderingInfo47, point2D60);
        xYPlot6.zoomRangeAxes((double) (short) 1, (double) 1L, plotRenderingInfo25, point2D60);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 35.0d + "'", double43 == 35.0d);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(point2D60);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.StrokeMap strokeMap15 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint17, stroke18);
        boolean boolean20 = strokeMap15.equals((java.lang.Object) valueMarker19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = valueMarker19.getLabelOffset();
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font25);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = piePlot28.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation30 = piePlot28.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator31 = piePlot28.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font25, (org.jfree.chart.plot.Plot) piePlot28, false);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle38.setText("");
        boolean boolean41 = textTitle38.getExpandToFitSpace();
        boolean boolean42 = textTitle38.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = legendTitle45.getHorizontalAlignment();
        legendTitle45.setHeight(0.0d);
        java.awt.Font font49 = legendTitle45.getItemFont();
        java.awt.Paint paint50 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine51 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font49, paint50);
        textTitle38.setFont(font49);
        org.jfree.chart.util.VerticalAlignment verticalAlignment53 = textTitle38.getVerticalAlignment();
        legendTitle35.setVerticalAlignment(verticalAlignment53);
        jFreeChart33.addSubtitle((org.jfree.chart.title.Title) legendTitle35);
        xYPlot6.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart33);
        java.awt.Stroke stroke57 = xYPlot6.getDomainGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset58 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = xYPlot6.getRendererForDataset(xYDataset58);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(rotation30);
        org.junit.Assert.assertNull(pieSectionLabelGenerator31);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(verticalAlignment53);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNull(xYItemRenderer59);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D1.setRightArrow(shape2);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!");
        chartEntity5.setURLText("Pie 3D Plot");
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = piePlot13.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation15 = piePlot13.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = piePlot13.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font10, (org.jfree.chart.plot.Plot) piePlot13, false);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        double double21 = legendTitle20.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle23.setText("");
        boolean boolean26 = textTitle23.getExpandToFitSpace();
        boolean boolean27 = textTitle23.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = legendTitle30.getHorizontalAlignment();
        legendTitle30.setHeight(0.0d);
        java.awt.Font font34 = legendTitle30.getItemFont();
        java.awt.Paint paint35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine36 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font34, paint35);
        textTitle23.setFont(font34);
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = textTitle23.getVerticalAlignment();
        legendTitle20.setVerticalAlignment(verticalAlignment38);
        jFreeChart18.addSubtitle((org.jfree.chart.title.Title) legendTitle20);
        org.jfree.chart.LegendItemSource legendItemSource41 = null;
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle(legendItemSource41);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent43 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle42);
        jFreeChart18.addLegend(legendTitle42);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle46.setText("");
        boolean boolean49 = textTitle46.getExpandToFitSpace();
        boolean boolean50 = textTitle46.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment54 = legendTitle53.getHorizontalAlignment();
        legendTitle53.setHeight(0.0d);
        java.awt.Font font57 = legendTitle53.getItemFont();
        java.awt.Paint paint58 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine59 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font57, paint58);
        textTitle46.setFont(font57);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor62 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        boolean boolean63 = textTitle46.equals((java.lang.Object) pieLabelDistributor62);
        jFreeChart18.addSubtitle((org.jfree.chart.title.Title) textTitle46);
        textTitle46.setText("");
        java.lang.Object obj67 = textTitle46.clone();
        boolean boolean68 = chartEntity5.equals((java.lang.Object) textTitle46);
        java.lang.String str69 = chartEntity5.getShapeCoords();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(drawingSupplier14);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNull(pieSectionLabelGenerator16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment54);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(obj67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "-4,-4,4,4" + "'", str69.equals("-4,-4,4,4"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = legendTitle3.getHorizontalAlignment();
        legendTitle3.setHeight(0.0d);
        java.awt.Font font7 = legendTitle3.getItemFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font7, paint8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat12 = null;
        dateAxis11.setDateFormatOverride(dateFormat12);
        java.awt.Color color14 = java.awt.Color.GRAY;
        dateAxis11.setTickLabelPaint((java.awt.Paint) color14);
        java.util.Date date16 = dateAxis11.getMinimumDate();
        java.awt.Color color17 = java.awt.Color.GRAY;
        dateAxis11.setTickMarkPaint((java.awt.Paint) color17);
        boolean boolean19 = dateAxis11.isVerticalTickLabels();
        boolean boolean21 = dateAxis11.isHiddenValue(10L);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot23.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat27 = null;
        dateAxis26.setDateFormatOverride(dateFormat27);
        java.awt.Color color29 = java.awt.Color.GRAY;
        dateAxis26.setTickLabelPaint((java.awt.Paint) color29);
        piePlot23.setBackgroundPaint((java.awt.Paint) color29);
        dateAxis11.setPlot((org.jfree.chart.plot.Plot) piePlot23);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat35 = null;
        dateAxis34.setDateFormatOverride(dateFormat35);
        java.awt.Shape shape37 = dateAxis34.getDownArrow();
        piePlot23.setLegendItemShape(shape37);
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", font7, (org.jfree.chart.plot.Plot) piePlot23, true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator41 = piePlot23.getURLGenerator();
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot(pieDataset42);
        piePlot43.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = piePlot43.getInsets();
        java.lang.String str47 = piePlot43.getNoDataMessage();
        java.awt.Paint paint48 = piePlot43.getLabelLinkPaint();
        piePlot23.setBackgroundPaint(paint48);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNull(pieURLGenerator41);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Range[0.0,1.0]" + "'", str47.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairValue(136.0d, true);
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot7.getDataset();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot7.getRangeMarkers(layer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot7.zoomDomainAxes(35.0d, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot29);
        xYPlot29.setRangeCrosshairValue(136.0d, true);
        java.awt.geom.Point2D point2D34 = xYPlot29.getQuadrantOrigin();
        xYPlot7.zoomDomainAxes((double) 1, plotRenderingInfo21, point2D34);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(point2D34);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        dateAxis10.setFixedDimension((double) 1.0f);
        dateAxis10.setTickMarkOutsideLength((float) 1);
        java.util.Date date15 = dateAxis10.getMaximumDate();
        dateAxis10.resizeRange((double) 'a');
        dateAxis10.setLowerMargin(3.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot21.getRangeAxisForDataset(15);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(valueAxis23);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        categoryPlot0.setAnchorValue((double) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat17 = null;
        dateAxis16.setDateFormatOverride(dateFormat17);
        java.awt.Color color19 = java.awt.Color.GRAY;
        dateAxis16.setTickLabelPaint((java.awt.Paint) color19);
        boolean boolean21 = rectangleInsets14.equals((java.lang.Object) color19);
        float[] floatArray28 = new float[] { 100L, '#', (byte) 100, (short) 1, (-1L), (byte) -1 };
        float[] floatArray29 = color19.getRGBColorComponents(floatArray28);
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        ringPlot31.setSectionDepth(0.08d);
        ringPlot31.setSeparatorsVisible(true);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot31.setSeparatorStroke(stroke36);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator38 = ringPlot31.getLegendLabelToolTipGenerator();
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot();
        ringPlot41.setSectionDepth(0.08d);
        ringPlot41.setSeparatorsVisible(true);
        java.awt.Stroke stroke46 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot41.setSeparatorStroke(stroke46);
        java.awt.Paint paint48 = ringPlot41.getShadowPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        org.jfree.chart.plot.PiePlotState piePlotState51 = ringPlot31.initialise(graphics2D39, rectangle2D40, (org.jfree.chart.plot.PiePlot) ringPlot41, (java.lang.Integer) 2, plotRenderingInfo50);
        ringPlot31.setSectionDepth(1.0E-8d);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("");
        dateAxis56.setFixedDimension((double) 1.0f);
        dateAxis56.setTickMarkOutsideLength((float) 1);
        java.util.Date date61 = dateAxis56.getMaximumDate();
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        int int64 = categoryPlot62.getIndexOf(categoryItemRenderer63);
        org.jfree.chart.util.SortOrder sortOrder65 = categoryPlot62.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace66 = null;
        categoryPlot62.setFixedRangeAxisSpace(axisSpace66);
        java.awt.Stroke stroke68 = categoryPlot62.getOutlineStroke();
        dateAxis56.setTickMarkStroke(stroke68);
        ringPlot31.setSectionOutlineStroke((java.lang.Comparable) 0.5f, stroke68);
        categoryPlot0.setDomainGridlineStroke(stroke68);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(pieSectionLabelGenerator38);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(piePlotState51);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(sortOrder65);
        org.junit.Assert.assertNotNull(stroke68);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat18 = null;
        dateAxis17.setDateFormatOverride(dateFormat18);
        java.awt.Color color20 = java.awt.Color.GRAY;
        dateAxis17.setTickLabelPaint((java.awt.Paint) color20);
        java.util.Date date22 = dateAxis17.getMinimumDate();
        java.text.DateFormat dateFormat23 = null;
        dateAxis17.setDateFormatOverride(dateFormat23);
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range28 = org.jfree.data.Range.expand(range25, (double) (short) 0, (double) (byte) 0);
        double double29 = range25.getLowerBound();
        dateAxis17.setRangeWithMargins(range25);
        xYPlot6.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) dateAxis17, false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis4.setRange(range7, false, false);
        boolean boolean11 = dateAxis4.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        jFreeChart8.setBackgroundImageAlpha((float) (short) 0);
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint12 = jFreeChart8.getBorderPaint();
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        categoryPlot0.clearDomainMarkers(0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(128);
        objectList0.clear();
        java.lang.Object obj5 = objectList0.get(0);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = piePlot3.getDrawingSupplier();
        double double5 = piePlot3.getMaximumLabelWidth();
        double double6 = piePlot3.getStartAngle();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.14d + "'", double5 == 0.14d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 90.0d + "'", double6 == 90.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement4 = blockContainer3.getArrangement();
        org.jfree.chart.text.TextBlock textBlock5 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.util.List list7 = textBlock5.getLines();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape[] shapeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        boolean boolean13 = textBlockAnchor11.equals((java.lang.Object) shapeArray12);
        textBlock5.draw(graphics2D8, 0.5f, 0.0f, textBlockAnchor11, (float) (byte) 10, (float) (byte) -1, 1.0E-8d);
        boolean boolean18 = blockContainer3.equals((java.lang.Object) 1.0E-8d);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(arrangement4);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleAnchor.CENTER", "");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleAnchor.CENTER" + "'", str3.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot7.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot7.getRangeAxis();
        org.jfree.chart.StrokeMap strokeMap14 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint16, stroke17);
        boolean boolean19 = strokeMap14.equals((java.lang.Object) valueMarker18);
        java.awt.Paint paint20 = valueMarker18.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = valueMarker18.getLabelAnchor();
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = xYPlot7.getFixedLegendItems();
        org.junit.Assert.assertNotNull(valueAxis13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNull(legendItemCollection23);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle1.getVerticalAlignment();
        java.awt.Paint paint17 = textTitle1.getPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot6.getRendererForDataset(xYDataset11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot6.setFixedDomainAxisSpace(axisSpace13, false);
        xYPlot6.clearDomainMarkers(128);
        org.junit.Assert.assertNull(xYItemRenderer12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairValue(136.0d, true);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat16 = null;
        dateAxis15.setDateFormatOverride(dateFormat16);
        java.awt.Color color18 = java.awt.Color.GRAY;
        dateAxis15.setTickLabelPaint((java.awt.Paint) color18);
        java.util.Date date20 = dateAxis15.getMinimumDate();
        java.text.DateFormat dateFormat21 = null;
        dateAxis15.setDateFormatOverride(dateFormat21);
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range26 = org.jfree.data.Range.expand(range23, (double) (short) 0, (double) (byte) 0);
        double double27 = range23.getLowerBound();
        dateAxis15.setRangeWithMargins(range23);
        xYPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        int int32 = categoryPlot30.getIndexOf(categoryItemRenderer31);
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot30.getColumnRenderingOrder();
        categoryPlot30.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = categoryPlot30.getOrientation();
        categoryPlot30.setAnchorValue((double) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat47 = null;
        dateAxis46.setDateFormatOverride(dateFormat47);
        java.awt.Color color49 = java.awt.Color.GRAY;
        dateAxis46.setTickLabelPaint((java.awt.Paint) color49);
        boolean boolean51 = rectangleInsets44.equals((java.lang.Object) color49);
        float[] floatArray58 = new float[] { 100L, '#', (byte) 100, (short) 1, (-1L), (byte) -1 };
        float[] floatArray59 = color49.getRGBColorComponents(floatArray58);
        categoryPlot30.setBackgroundPaint((java.awt.Paint) color49);
        boolean boolean61 = dateAxis15.equals((java.lang.Object) categoryPlot30);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.String str1 = rectangleEdge0.toString();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str3 = rectangleAnchor2.toString();
        boolean boolean4 = rectangleEdge0.equals((java.lang.Object) rectangleAnchor2);
        java.lang.String str5 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.BOTTOM" + "'", str1.equals("RectangleEdge.BOTTOM"));
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleAnchor.CENTER" + "'", str3.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleEdge.BOTTOM" + "'", str5.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = legendTitle4.getHorizontalAlignment();
        legendTitle4.setHeight(0.0d);
        java.awt.Font font8 = legendTitle4.getItemFont();
        waferMapPlot2.setNoDataMessageFont(font8);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        waferMapPlot2.setDataset(waferMapDataset10);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle2.setText("");
        java.awt.geom.Rectangle2D rectangle2D5 = textTitle2.getBounds();
        java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createInsetRectangle(rectangle2D5, false, false);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangle2D8);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getInsets();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator5);
        java.lang.String str7 = piePlot1.getPlotType();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.JFreeChart jFreeChart10 = plotChangeEvent9.getChart();
        java.lang.Object obj11 = plotChangeEvent9.getSource();
        org.jfree.chart.JFreeChart jFreeChart12 = plotChangeEvent9.getChart();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(jFreeChart10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(jFreeChart12);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3, false);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) '#', (float) 15, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairValue(136.0d, true);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat16 = null;
        dateAxis15.setDateFormatOverride(dateFormat16);
        java.awt.Color color18 = java.awt.Color.GRAY;
        dateAxis15.setTickLabelPaint((java.awt.Paint) color18);
        java.util.Date date20 = dateAxis15.getMinimumDate();
        java.text.DateFormat dateFormat21 = null;
        dateAxis15.setDateFormatOverride(dateFormat21);
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range26 = org.jfree.data.Range.expand(range23, (double) (short) 0, (double) (byte) 0);
        double double27 = range23.getLowerBound();
        dateAxis15.setRangeWithMargins(range23);
        xYPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        boolean boolean30 = dateAxis15.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot6.getIndexOf(categoryItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomRangeAxes((double) (byte) 0, (double) 500, plotRenderingInfo11, point2D12);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot6.getDomainAxisLocation();
        categoryPlot0.setDomainAxisLocation(0, axisLocation15, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot0.setRenderer((int) (short) 0, categoryItemRenderer19, true);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        categoryAxis3D0.configure();
        categoryAxis3D0.clearCategoryLabelToolTips();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        int int7 = categoryPlot5.getIndexOf(categoryItemRenderer6);
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot5.getColumnRenderingOrder();
        categoryPlot5.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot5.getOrientation();
        categoryPlot5.setAnchorValue((double) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat22 = null;
        dateAxis21.setDateFormatOverride(dateFormat22);
        java.awt.Color color24 = java.awt.Color.GRAY;
        dateAxis21.setTickLabelPaint((java.awt.Paint) color24);
        boolean boolean26 = rectangleInsets19.equals((java.lang.Object) color24);
        float[] floatArray33 = new float[] { 100L, '#', (byte) 100, (short) 1, (-1L), (byte) -1 };
        float[] floatArray34 = color24.getRGBColorComponents(floatArray33);
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color24);
        categoryAxis3D0.setLabelPaint((java.awt.Paint) color24);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint2, stroke3);
        boolean boolean5 = strokeMap0.equals((java.lang.Object) valueMarker4);
        java.awt.Paint paint6 = valueMarker4.getLabelPaint();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer10 = legendTitle8.getItemContainer();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font13);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("Other", font13);
        legendTitle8.setItemFont(font13);
        valueMarker4.setLabelFont(font13);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(blockContainer10);
        org.junit.Assert.assertNotNull(font13);
    }
}

