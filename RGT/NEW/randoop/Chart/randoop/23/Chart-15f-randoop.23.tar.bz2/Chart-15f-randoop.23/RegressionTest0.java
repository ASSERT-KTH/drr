import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        try {
            org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            legendTitle1.setLegendItemGraphicPadding(rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setFixedDimension((double) 1.0f);
        java.awt.Shape shape4 = null;
        try {
            dateAxis1.setRightArrow(shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.awt.Font font2 = null;
        try {
            dateAxis1.setLabelFont(font2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (int) (short) 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = null;
        try {
            dateAxis1.setMinimumDate(date2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Shape shape1 = null;
        try {
            numberAxis3D0.setLeftArrow(shape1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (-1.0d), keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            legendTitle1.setBounds(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            legendTitle1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Range[0.0,1.0]", graphics2D1, 10.0f, (float) 100, textAnchor4, (double) (short) -1, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        try {
            dateAxis1.setLeftArrow(shape9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (-1.0f), (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.Arrangement arrangement1 = null;
        org.jfree.chart.block.Arrangement arrangement2 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, arrangement1, arrangement2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color4 = java.awt.Color.GRAY;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { paint0, paint1, color2, paint3, color4, paint5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color8 = java.awt.Color.GRAY;
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color7, color8, color9, paint10, color11, color12 };
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color15 = java.awt.Color.GRAY;
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color14, color15, paint16 };
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke19 };
        java.awt.Shape[] shapeArray21 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray13, paintArray17, strokeArray18, strokeArray20, shapeArray21);
        try {
            java.awt.Stroke stroke23 = defaultDrawingSupplier22.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        try {
            dateAxis1.setRange((double) (short) 100, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateFormat2, jFreeChart4, chartChangeEventType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        org.jfree.chart.plot.Plot plot9 = null;
        dateAxis1.setPlot(plot9);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat13 = null;
        dateAxis12.setDateFormatOverride(dateFormat13);
        java.awt.Color color15 = java.awt.Color.GRAY;
        dateAxis12.setTickLabelPaint((java.awt.Paint) color15);
        java.util.Date date17 = dateAxis12.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat20 = null;
        dateAxis19.setDateFormatOverride(dateFormat20);
        java.awt.Color color22 = java.awt.Color.GRAY;
        dateAxis19.setTickLabelPaint((java.awt.Paint) color22);
        java.util.Date date24 = dateAxis19.getMinimumDate();
        try {
            dateAxis1.setRange(date17, date24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double6 = rectangleInsets4.calculateTopInset((double) 1.0f);
        double double8 = rectangleInsets4.calculateTopOutset((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            org.jfree.chart.axis.AxisState axisState7 = categoryAxis3D0.draw(graphics2D1, (double) 0L, rectangle2D3, rectangle2D4, rectangleEdge5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range9, (double) (short) 0, (double) (byte) 0);
        dateAxis1.setRange(range9, false, false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Range[0.0,1.0]", graphics2D1, (float) (byte) 1, 1.0f, textAnchor4, (double) 1L, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "hi!", "hi!");
        java.lang.String str6 = basicProjectInfo5.getVersion();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat4 = null;
        dateAxis3.setDateFormatOverride(dateFormat4);
        java.awt.Color color6 = java.awt.Color.GRAY;
        dateAxis3.setTickLabelPaint((java.awt.Paint) color6);
        java.util.Date date8 = dateAxis3.getMinimumDate();
        boolean boolean9 = rectangleAnchor1.equals((java.lang.Object) dateAxis3);
        try {
            java.awt.geom.Point2D point2D10 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparable0, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            org.jfree.chart.axis.AxisState axisState7 = categoryAxis3D0.draw(graphics2D1, 136.0d, rectangle2D3, rectangle2D4, rectangleEdge5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (double) (-1.0f), (float) (-1), (float) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) (byte) 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        java.awt.Paint paint6 = null;
        try {
            textTitle1.setPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.FIXED" + "'", str1.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        piePlot5.setNoDataMessage("Range[0.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace11 = dateAxis1.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) piePlot5, rectangle2D8, rectangleEdge9, axisSpace10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
        java.lang.String str5 = basicProjectInfo4.getInfo();
        basicProjectInfo4.setName("");
        java.lang.String str8 = basicProjectInfo4.getName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        java.lang.Class class1 = null;
//        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", class1);
//        org.junit.Assert.assertNotNull(inputStream2);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.Range range4 = null;
        try {
            dateAxis1.setRange(range4, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("UnitType.ABSOLUTE", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        dateAxis1.setTickMarkOutsideLength((float) (byte) 0);
        java.lang.Object obj11 = dateAxis1.clone();
        org.jfree.data.Range range12 = null;
        try {
            dateAxis1.setRange(range12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        int int2 = pieLabelDistributor1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (double) '4');
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range0.intersects((double) (byte) 1, (double) (short) 10);
        java.lang.String str4 = range0.toString();
        java.lang.String str5 = range0.toString();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,1.0]" + "'", str4.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Range[0.0,1.0]" + "'", str5.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset3);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset3);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.chart.util.TableOrder tableOrder7 = null;
        try {
            multiplePiePlot6.setDataExtractOrder(tableOrder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        dateAxis1.resizeRange(1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint1, stroke2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        valueMarker3.notifyListeners(markerChangeEvent4);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = legendTitle2.getHorizontalAlignment();
        legendTitle2.setHeight(0.0d);
        java.awt.Font font6 = legendTitle2.getItemFont();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font6, paint7);
        org.jfree.chart.text.TextFragment textFragment9 = null;
        textLine8.addFragment(textFragment9);
        org.jfree.chart.text.TextFragment textFragment11 = null;
        textLine8.removeFragment(textFragment11);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint1, stroke2);
        java.awt.Paint paint4 = null;
        try {
            valueMarker3.setPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        boolean boolean9 = dateAxis1.isVerticalTickLabels();
        java.util.TimeZone timeZone10 = null;
        try {
            dateAxis1.setTimeZone(timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range0.intersects((double) (byte) 1, (double) (short) 10);
        double double4 = range0.getUpperBound();
        boolean boolean6 = range0.contains(1.0E-8d);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle1.getVerticalAlignment();
        java.awt.Graphics2D graphics2D17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = textTitle1.arrange(graphics2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(verticalAlignment16);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (double) '4');
        try {
            org.jfree.chart.util.Size2D size2D6 = textTitle1.arrange(graphics2D2, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        textTitle1.setURLText("HorizontalAlignment.CENTER");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double6 = rectangleInsets4.calculateLeftOutset((double) 10.0f);
        double double8 = rectangleInsets4.calculateRightOutset(0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        try {
            xYPlot6.setDomainAxisLocation(axisLocation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.CENTER", graphics2D1, (-1.0f), (float) (short) -1, textAnchor4, (double) 0, (float) 1, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = rendererState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color4 = java.awt.Color.GRAY;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { paint0, paint1, color2, paint3, color4, paint5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color8 = java.awt.Color.GRAY;
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color7, color8, color9, paint10, color11, color12 };
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color15 = java.awt.Color.GRAY;
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color14, color15, paint16 };
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke19 };
        java.awt.Shape[] shapeArray21 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray13, paintArray17, strokeArray18, strokeArray20, shapeArray21);
        java.awt.Stroke stroke23 = defaultDrawingSupplier22.getNextOutlineStroke();
        try {
            java.awt.Shape shape24 = defaultDrawingSupplier22.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNull(stroke23);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        categoryAxis3D0.configure();
        java.lang.Object obj4 = categoryAxis3D0.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        boolean boolean9 = dateAxis1.isVerticalTickLabels();
        boolean boolean11 = dateAxis1.isHiddenValue(10L);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = piePlot13.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat17 = null;
        dateAxis16.setDateFormatOverride(dateFormat17);
        java.awt.Color color19 = java.awt.Color.GRAY;
        dateAxis16.setTickLabelPaint((java.awt.Paint) color19);
        piePlot13.setBackgroundPaint((java.awt.Paint) color19);
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        java.lang.Number number27 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset26);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot29);
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        try {
            multiplePiePlot29.setPieChart(jFreeChart31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'pieChart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(drawingSupplier14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 0.0d + "'", number27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0.0d + "'", number28.equals(0.0d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot6.getDomainAxisForDataset((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("hi!");
        java.awt.Image image10 = null;
        projectInfo7.setLogo(image10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            jFreeChart10.draw(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("PlotOrientation.HORIZONTAL", graphics2D1, (float) 100, (float) (-1), (double) (short) 100, (float) 0, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 1L, 0.08d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.08).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        waferMapPlot6.setNoDataMessageFont(font12);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 100L, font12);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle16.setText("");
        boolean boolean19 = textTitle16.getExpandToFitSpace();
        boolean boolean20 = categoryAxis3D0.equals((java.lang.Object) boolean19);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double25 = categoryAxis3D0.getCategoryStart((int) (byte) 10, (int) (byte) 0, rectangle2D23, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        try {
            org.jfree.chart.title.Title title12 = jFreeChart10.getSubtitle((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (short) -1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle2.setText("");
        textTitle2.setText("UnitType.ABSOLUTE");
        boolean boolean7 = lengthConstraintType0.equals((java.lang.Object) "UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("LengthConstraintType.FIXED", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        java.lang.String str9 = dateAxis1.getLabel();
        java.awt.Paint paint10 = dateAxis1.getTickLabelPaint();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat14 = null;
        dateAxis13.setDateFormatOverride(dateFormat14);
        java.awt.Color color16 = java.awt.Color.GRAY;
        dateAxis13.setTickLabelPaint((java.awt.Paint) color16);
        java.util.Date date18 = dateAxis13.getMinimumDate();
        try {
            dateAxis1.setRange(date11, date18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
        java.lang.String str5 = basicProjectInfo4.getInfo();
        basicProjectInfo4.setName("");
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo4.getLibraries();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D7, (float) (short) 10, (float) '#', textAnchor10, (double) 0, 100.0f, (float) (-1));
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleEdge.BOTTOM", graphics2D1, (float) (-1L), 0.0f, textAnchor4, (double) (-1), textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (byte) -1, 0.0f, 0.0d, (float) '#', (float) 0L);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        try {
            org.jfree.chart.plot.XYPlot xYPlot11 = jFreeChart10.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint1, stroke2);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = null;
        try {
            valueMarker3.setLabelOffsetType(lengthAdjustmentType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setExplodePercent((java.lang.Comparable) (byte) 1, 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (short) 1);
        java.awt.Stroke stroke4 = strokeMap0.getStroke((java.lang.Comparable) 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        float float5 = multiplePiePlot4.getForegroundAlpha();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset3);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset3);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.lang.Comparable comparable7 = multiplePiePlot6.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "Other" + "'", comparable7.equals("Other"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = null;
        try {
            dateAxis1.setTimeZone(timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setAutoTickUnitSelection(true, false);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = legendTitle10.getHorizontalAlignment();
        legendTitle10.setHeight(0.0d);
        java.awt.Font font14 = legendTitle10.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle10.getLegendItemGraphicEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            org.jfree.chart.axis.AxisState axisState17 = dateAxis1.draw(graphics2D5, (double) 1, rectangle2D7, rectangle2D8, rectangleEdge15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range4 = org.jfree.data.Range.expand(range1, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range4, (double) (-1), false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean13 = range10.intersects((double) (byte) 1, (double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range7, lengthConstraintType8, (double) (-1), range10, lengthConstraintType14);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getHeightConstraintType();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = legendTitle11.getHorizontalAlignment();
        legendTitle11.setHeight(0.0d);
        java.awt.Font font15 = legendTitle11.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle11.getLegendItemGraphicEdge();
        try {
            java.util.List list17 = numberAxis3D2.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        boolean boolean15 = xYPlot6.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = legendTitle4.getHorizontalAlignment();
        legendTitle4.setHeight(0.0d);
        java.awt.Font font8 = legendTitle4.getItemFont();
        waferMapPlot2.setNoDataMessageFont(font8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat12 = null;
        dateAxis11.setDateFormatOverride(dateFormat12);
        java.awt.Color color14 = java.awt.Color.GRAY;
        dateAxis11.setTickLabelPaint((java.awt.Paint) color14);
        java.util.Date date16 = dateAxis11.getMinimumDate();
        java.text.DateFormat dateFormat17 = null;
        dateAxis11.setDateFormatOverride(dateFormat17);
        java.lang.String str19 = dateAxis11.getLabel();
        java.awt.Paint paint20 = dateAxis11.getTickLabelPaint();
        waferMapPlot2.setOutlinePaint(paint20);
        int int22 = waferMapPlot2.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.StrokeMap strokeMap15 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint17, stroke18);
        boolean boolean20 = strokeMap15.equals((java.lang.Object) valueMarker19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = valueMarker19.getLabelOffset();
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        try {
            xYPlot6.zoomDomainAxes((double) 100.0f, 1.0E-5d, plotRenderingInfo25, point2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (105.0) <= upper (1.0500000000000001E-5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel(0, attributedString2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        try {
            java.text.AttributedString attributedString6 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset4, (java.lang.Comparable) 136.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str2 = plotOrientation1.toString();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str2.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = legendTitle4.getHorizontalAlignment();
        legendTitle4.setHeight(0.0d);
        java.awt.Font font8 = legendTitle4.getItemFont();
        waferMapPlot2.setNoDataMessageFont(font8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat12 = null;
        dateAxis11.setDateFormatOverride(dateFormat12);
        java.awt.Color color14 = java.awt.Color.GRAY;
        dateAxis11.setTickLabelPaint((java.awt.Paint) color14);
        java.util.Date date16 = dateAxis11.getMinimumDate();
        java.text.DateFormat dateFormat17 = null;
        dateAxis11.setDateFormatOverride(dateFormat17);
        java.lang.String str19 = dateAxis11.getLabel();
        java.awt.Paint paint20 = dateAxis11.getTickLabelPaint();
        waferMapPlot2.setOutlinePaint(paint20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            waferMapPlot2.drawBackground(graphics2D22, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor17 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        boolean boolean18 = textTitle1.equals((java.lang.Object) pieLabelDistributor17);
        pieLabelDistributor17.distributeLabels((double) 1L, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 0, (double) 0.5f, 35.0d, 1.0E-5d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        java.util.Locale locale1 = null;
//        java.lang.Class class2 = null;
//        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
//        java.util.ResourceBundle.Control control4 = null;
//        try {
//            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("RectangleEdge.BOTTOM", locale1, classLoader3, control4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(classLoader3);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3, (double) 100.0f);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("UnitType.ABSOLUTE", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        boolean boolean9 = dateAxis1.isVerticalTickLabels();
        boolean boolean11 = dateAxis1.isHiddenValue(10L);
        double double12 = dateAxis1.getFixedDimension();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            piePlot3D1.drawOutline(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel(0, attributedString2);
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle10.setVerticalAlignment(verticalAlignment12);
        jFreeChart8.addLegend(legendTitle10);
        org.jfree.chart.title.Title title15 = null;
        try {
            jFreeChart8.addSubtitle(title15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        java.lang.Object obj4 = blockContainer3.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Color color2 = java.awt.Color.getColor("HorizontalAlignment.CENTER", (int) (short) 100);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double6 = rectangleInsets4.calculateLeftOutset((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets4.createOutsetRectangle(rectangle2D7, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6 == 35.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (double) 1L);
        java.lang.String str3 = rectangleConstraint2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=1.0]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=1.0]"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range4 = org.jfree.data.Range.expand(range1, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range4, (double) (-1), false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean13 = range10.intersects((double) (byte) 1, (double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range7, lengthConstraintType8, (double) (-1), range10, lengthConstraintType14);
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range10, (double) 'a');
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat5 = null;
        dateAxis4.setDateFormatOverride(dateFormat5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color7);
        piePlot1.setBackgroundPaint((java.awt.Paint) color7);
        java.lang.Object obj10 = piePlot1.clone();
        java.awt.Paint paint11 = piePlot1.getOutlinePaint();
        boolean boolean12 = piePlot1.isOutlineVisible();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace15, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            xYPlot6.handleClick((int) '4', 10, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAxisLineVisible();
        try {
            dateAxis1.setRangeWithMargins((double) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle10.setVerticalAlignment(verticalAlignment12);
        jFreeChart8.addLegend(legendTitle10);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle16.setText("");
        textTitle16.setText("UnitType.ABSOLUTE");
        jFreeChart8.setTitle(textTitle16);
        textTitle16.setURLText("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=1.0]");
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment12);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (double) '4');
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedWidth((double) (-1.0f));
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.lang.String str7 = dateAxis4.getLabelToolTip();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = legendTitle10.getHorizontalAlignment();
        legendTitle10.setHeight(0.0d);
        java.awt.Font font14 = legendTitle10.getItemFont();
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font14, paint15);
        org.jfree.chart.text.TextFragment textFragment17 = textLine16.getFirstTextFragment();
        boolean boolean18 = dateAxis4.equals((java.lang.Object) textFragment17);
        java.awt.Font font19 = textFragment17.getFont();
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textFragment17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getInsets();
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 100);
        org.jfree.chart.util.Rotation rotation7 = piePlot1.getDirection();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rotation7);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        boolean boolean6 = dateAxis1.isAutoRange();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation3 = piePlot1.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        java.awt.Paint paint5 = null;
        piePlot1.setOutlinePaint(paint5);
        double double8 = piePlot1.getExplodePercent((java.lang.Comparable) 136.0d);
        boolean boolean10 = piePlot1.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace15, false);
        java.awt.Color color19 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        try {
            xYPlot6.setQuadrantPaint((int) ' ', (java.awt.Paint) color19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (32) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) (short) 0, (double) (byte) 0);
        boolean boolean5 = range3.contains((double) 1.0f);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            waferMapPlot2.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.StrokeMap strokeMap15 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint17, stroke18);
        boolean boolean20 = strokeMap15.equals((java.lang.Object) valueMarker19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = valueMarker19.getLabelOffset();
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double28 = rectangleInsets27.getRight();
        double double30 = rectangleInsets27.calculateLeftOutset((double) ' ');
        valueMarker19.setLabelOffset(rectangleInsets27);
        try {
            valueMarker19.setAlpha((float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 35.0d + "'", double30 == 35.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = legendTitle6.getHorizontalAlignment();
        legendTitle6.setHeight(0.0d);
        java.awt.Font font10 = legendTitle6.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = legendTitle6.getLegendItemGraphicEdge();
        try {
            java.util.List list12 = numberAxis3D1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Paint paint2 = null;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = legendTitle4.getHorizontalAlignment();
        legendTitle4.setHeight(0.0d);
        java.awt.Font font8 = legendTitle4.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = legendTitle4.getLegendItemGraphicEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = null;
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle12.setVerticalAlignment(verticalAlignment14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        try {
            org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("Range[0.0,1.0]", font1, paint2, rectangleEdge9, horizontalAlignment10, verticalAlignment14, rectangleInsets16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Shape shape4 = dateAxis1.getDownArrow();
        dateAxis1.setLabelToolTip("WMAP_Plot");
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100, (float) 1L, 1.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("HorizontalAlignment.CENTER", graphics2D1, (float) (short) -1, (float) (short) 100, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("WMAP_Plot", "hi!", "LengthConstraintType.FIXED", "hi!", "UnitType.ABSOLUTE");
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        java.lang.String str5 = textTitle1.getToolTipText();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Other", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            xYPlot7.addRangeMarker(marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setFixedDimension((double) 1.0f);
        dateAxis1.setTickMarkOutsideLength((float) 1);
        java.util.Date date6 = dateAxis1.getMaximumDate();
        dateAxis1.setFixedAutoRange((double) '4');
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat5 = null;
        dateAxis4.setDateFormatOverride(dateFormat5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color7);
        piePlot1.setBackgroundPaint((java.awt.Paint) color7);
        java.lang.Object obj10 = piePlot1.clone();
        piePlot1.setShadowXOffset((double) 1);
        java.lang.String str13 = piePlot1.getPlotType();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pie Plot" + "'", str13.equals("Pie Plot"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        waferMapPlot6.setNoDataMessageFont(font12);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 100L, font12);
        categoryAxis3D0.removeCategoryLabelToolTip((java.lang.Comparable) 1.0E-8d);
        float float17 = categoryAxis3D0.getTickMarkInsideLength();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double22 = categoryAxis3D0.getCategoryStart((int) '#', 0, rectangle2D20, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = legendTitle2.getHorizontalAlignment();
        legendTitle2.setHeight(0.0d);
        java.awt.Font font6 = legendTitle2.getItemFont();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font6, paint7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            textLine8.draw(graphics2D9, 0.5f, (float) 0L, textAnchor12, (float) (-1), (float) (-1), 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        java.util.Date date3 = dateAxis1.getMinimumDate();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str1.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat3 = null;
        dateAxis2.setDateFormatOverride(dateFormat3);
        java.awt.Color color5 = java.awt.Color.GRAY;
        dateAxis2.setTickLabelPaint((java.awt.Paint) color5);
        java.util.Date date7 = dateAxis2.getMinimumDate();
        boolean boolean8 = rectangleAnchor0.equals((java.lang.Object) dateAxis2);
        boolean boolean9 = dateAxis2.isAutoTickUnitSelection();
        double double10 = dateAxis2.getAutoRangeMinimumSize();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        try {
            java.util.Date date12 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        textTitle1.setID("RectangleEdge.BOTTOM");
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle1.setFont(font18);
        java.awt.Graphics2D graphics2D20 = null;
        try {
            org.jfree.chart.util.Size2D size2D21 = textTitle1.arrange(graphics2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D1.setRightArrow(shape2);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator6 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator7 = null;
        try {
            java.lang.String str8 = chartEntity5.getImageMapAreaTag(toolTipTagFragmentGenerator6, uRLTagFragmentGenerator7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
        java.lang.String str5 = basicProjectInfo4.getInfo();
        basicProjectInfo4.setName("");
        basicProjectInfo4.setName("{0}");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = legendTitle4.getHorizontalAlignment();
        legendTitle4.setHeight(0.0d);
        java.awt.Font font8 = legendTitle4.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = legendTitle4.getLegendItemGraphicEdge();
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            java.lang.Object obj14 = legendTitle1.draw(graphics2D11, rectangle2D12, (java.lang.Object) textAnchor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace15, false);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot6.getDomainAxisForDataset((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 97 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        dateAxis1.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle10.setVerticalAlignment(verticalAlignment12);
        jFreeChart8.addLegend(legendTitle10);
        jFreeChart8.setAntiAlias(true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment12);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        boolean boolean9 = dateAxis1.isVerticalTickLabels();
        boolean boolean11 = dateAxis1.isHiddenValue(10L);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = piePlot13.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat17 = null;
        dateAxis16.setDateFormatOverride(dateFormat17);
        java.awt.Color color19 = java.awt.Color.GRAY;
        dateAxis16.setTickLabelPaint((java.awt.Paint) color19);
        piePlot13.setBackgroundPaint((java.awt.Paint) color19);
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        java.lang.Number number27 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset26);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot29);
        double double31 = dateAxis1.getFixedDimension();
        dateAxis1.centerRange((double) (byte) 10);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(drawingSupplier14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 0.0d + "'", number27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0.0d + "'", number28.equals(0.0d));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = legendTitle4.getHorizontalAlignment();
        legendTitle4.setHeight(0.0d);
        java.awt.Font font8 = legendTitle4.getItemFont();
        waferMapPlot2.setNoDataMessageFont(font8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat12 = null;
        dateAxis11.setDateFormatOverride(dateFormat12);
        java.awt.Color color14 = java.awt.Color.GRAY;
        dateAxis11.setTickLabelPaint((java.awt.Paint) color14);
        java.util.Date date16 = dateAxis11.getMinimumDate();
        java.text.DateFormat dateFormat17 = null;
        dateAxis11.setDateFormatOverride(dateFormat17);
        java.lang.String str19 = dateAxis11.getLabel();
        java.awt.Paint paint20 = dateAxis11.getTickLabelPaint();
        waferMapPlot2.setOutlinePaint(paint20);
        java.lang.String str22 = waferMapPlot2.getPlotType();
        waferMapPlot2.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer25 = null;
        waferMapPlot2.setRenderer(waferMapRenderer25);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "WMAP_Plot" + "'", str22.equals("WMAP_Plot"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
        java.lang.String str5 = basicProjectInfo4.getName();
        java.lang.String str6 = basicProjectInfo4.getName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.String str3 = titleChangeEvent2.toString();
        java.lang.Object obj4 = titleChangeEvent2.getSource();
        java.lang.String str5 = titleChangeEvent2.toString();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset();
        org.jfree.chart.StrokeMap strokeMap4 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint6, stroke7);
        boolean boolean9 = strokeMap4.equals((java.lang.Object) valueMarker8);
        java.awt.Paint paint10 = valueMarker8.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = piePlot12.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation14 = piePlot12.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot12.getLegendLabelToolTipGenerator();
        valueMarker8.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot12);
        try {
            boolean boolean17 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNotNull(rotation14);
        org.junit.Assert.assertNull(pieSectionLabelGenerator15);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        textTitle1.setPaint((java.awt.Paint) color16);
        java.awt.Font font18 = textTitle1.getFont();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            textTitle1.setBounds(rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(10.0d, (double) (-1));
        double double3 = size2D2.height;
        java.lang.String str4 = size2D2.toString();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Size2D[width=10.0, height=-1.0]" + "'", str4.equals("Size2D[width=10.0, height=-1.0]"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation3 = piePlot1.getDirection();
        org.jfree.data.general.DatasetGroup datasetGroup4 = piePlot1.getDatasetGroup();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(datasetGroup4);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        java.lang.String str3 = horizontalAlignment2.toString();
        java.lang.String str4 = horizontalAlignment2.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HorizontalAlignment.CENTER" + "'", str4.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        boolean boolean9 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setLabelURL("");
        double double12 = dateAxis1.getUpperBound();
        dateAxis1.resizeRange((double) 0L, (double) (short) 1);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = piePlot18.getDrawingSupplier();
        double double20 = piePlot18.getMaximumLabelWidth();
        double double21 = piePlot18.getStartAngle();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace25 = dateAxis1.reserveSpace(graphics2D16, (org.jfree.chart.plot.Plot) piePlot18, rectangle2D22, rectangleEdge23, axisSpace24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.14d + "'", double20 == 0.14d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle5.setText("");
        boolean boolean8 = textTitle5.getExpandToFitSpace();
        boolean boolean9 = textTitle5.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = legendTitle12.getHorizontalAlignment();
        legendTitle12.setHeight(0.0d);
        java.awt.Font font16 = legendTitle12.getItemFont();
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font16, paint17);
        textTitle5.setFont(font16);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 1L, font16);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double25 = categoryAxis3D0.getCategoryMiddle((int) (short) 1, (int) 'a', rectangle2D23, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        xYPlot6.rendererChanged(rendererChangeEvent7);
        xYPlot6.configureRangeAxes();
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle10.setVerticalAlignment(verticalAlignment12);
        jFreeChart8.addLegend(legendTitle10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart8.createBufferedImage(500, 15, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment12);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = legendTitle4.getHorizontalAlignment();
        legendTitle4.setHeight(0.0d);
        java.awt.Font font8 = legendTitle4.getItemFont();
        waferMapPlot2.setNoDataMessageFont(font8);
        java.awt.Paint paint10 = waferMapPlot2.getNoDataMessagePaint();
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        waferMapPlot2.setDataset(waferMapDataset11);
        java.lang.String str13 = waferMapPlot2.getPlotType();
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "WMAP_Plot" + "'", str13.equals("WMAP_Plot"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setFixedDimension((double) 1.0f);
        dateAxis1.setTickMarkOutsideLength((float) 1);
        java.util.Date date6 = dateAxis1.getMaximumDate();
        dateAxis1.resizeRange((double) 'a');
        org.jfree.data.Range range9 = dateAxis1.getRange();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) (short) -1, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            categoryPlot0.handleClick((int) '4', (int) (short) 100, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range0.intersects((double) (byte) 1, (double) (short) 10);
        java.lang.String str4 = range0.toString();
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range0, (double) (byte) 10, false);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,1.0]" + "'", str4.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=1.0]", "WMAP_Plot", "Other", "Other");
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getPercentFormat();
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat5 = null;
        dateAxis4.setDateFormatOverride(dateFormat5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color7);
        piePlot1.setBackgroundPaint((java.awt.Paint) color7);
        java.lang.Object obj10 = piePlot1.clone();
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setPieIndex(100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = piePlot1.getDrawingSupplier();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(drawingSupplier15);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle1.getVerticalAlignment();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.lang.Object obj19 = null;
        java.lang.Object obj20 = textTitle1.draw(graphics2D17, rectangle2D18, obj19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNull(obj20);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.lang.String str7 = dateAxis4.getLabelToolTip();
        java.awt.Shape shape8 = dateAxis4.getRightArrow();
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairValue(136.0d, true);
        try {
            java.awt.Paint paint13 = xYPlot7.getQuadrantPaint((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle6.setText("");
        boolean boolean9 = textTitle6.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = legendTitle11.getHorizontalAlignment();
        java.lang.String str13 = horizontalAlignment12.toString();
        textTitle6.setTextAlignment(horizontalAlignment12);
        textTitle1.setHorizontalAlignment(horizontalAlignment12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "HorizontalAlignment.CENTER" + "'", str13.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("HorizontalAlignment.CENTER", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range4 = org.jfree.data.Range.expand(range1, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range4, (double) (-1), false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean13 = range10.intersects((double) (byte) 1, (double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range7, lengthConstraintType8, (double) (-1), range10, lengthConstraintType14);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range19 = org.jfree.data.Range.expand(range16, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range22 = org.jfree.data.Range.shift(range19, (double) (-1), false);
        org.jfree.data.Range range23 = org.jfree.data.Range.combine(range10, range19);
        org.jfree.data.Range range26 = org.jfree.data.Range.expand(range23, (double) (byte) -1, 1.0d);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D0.setTickUnit(numberTickUnit1, true, false);
        boolean boolean5 = numberAxis3D0.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = null;
        try {
            xYPlot6.setRangeAxes(valueAxisArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle1.getVerticalAlignment();
        double double17 = textTitle1.getContentYOffset();
        java.lang.Object obj18 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle1.getVerticalAlignment();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(verticalAlignment19);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.awt.Paint paint5 = multiplePiePlot4.getNoDataMessagePaint();
        org.jfree.chart.util.TableOrder tableOrder6 = null;
        try {
            multiplePiePlot4.setDataExtractOrder(tableOrder6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = legendTitle10.getHorizontalAlignment();
        legendTitle10.setHeight(0.0d);
        jFreeChart8.addLegend(legendTitle10);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "RectangleEdge.BOTTOM", "Other", image3, "VerticalAlignment.BOTTOM", "WMAP_Plot", "LengthConstraintType.FIXED");
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        waferMapPlot6.setNoDataMessageFont(font12);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 100L, font12);
        categoryAxis3D0.removeCategoryLabelToolTip((java.lang.Comparable) 1.0E-8d);
        float float17 = categoryAxis3D0.getTickMarkInsideLength();
        categoryAxis3D0.setTickLabelsVisible(true);
        categoryAxis3D0.setCategoryMargin(0.12d);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        boolean boolean9 = dateAxis1.isVerticalTickLabels();
        boolean boolean11 = dateAxis1.isHiddenValue(10L);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = piePlot13.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat17 = null;
        dateAxis16.setDateFormatOverride(dateFormat17);
        java.awt.Color color19 = java.awt.Color.GRAY;
        dateAxis16.setTickLabelPaint((java.awt.Paint) color19);
        piePlot13.setBackgroundPaint((java.awt.Paint) color19);
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat25 = null;
        dateAxis24.setDateFormatOverride(dateFormat25);
        java.awt.Shape shape27 = dateAxis24.getDownArrow();
        piePlot13.setLegendItemShape(shape27);
        java.lang.Comparable comparable29 = null;
        try {
            java.awt.Paint paint30 = piePlot13.getSectionPaint(comparable29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(drawingSupplier14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        try {
            xYPlot6.setRenderer((int) (short) -1, xYItemRenderer8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("{0}", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot6.getDomainAxis();
        org.junit.Assert.assertNotNull(valueAxis15);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Range[0.0,1.0]");
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("LengthConstraintType.FIXED");
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer((int) '4', categoryItemRenderer5, false);
        boolean boolean8 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes(136.0d, plotRenderingInfo10, point2D11, true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D1.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5, waferMapRenderer6);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = legendTitle9.getHorizontalAlignment();
        legendTitle9.setHeight(0.0d);
        java.awt.Font font13 = legendTitle9.getItemFont();
        waferMapPlot7.setNoDataMessageFont(font13);
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) 100L, font13);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("RectangleAnchor.CENTER", font13);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 1, 0.0f, (float) 1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double[] doubleArray5 = new double[] { 100.0d, (-1.0d), (-1.0d) };
        double[] doubleArray9 = new double[] { 100.0d, (-1.0d), (-1.0d) };
        double[] doubleArray13 = new double[] { 100.0d, (-1.0d), (-1.0d) };
        double[][] doubleArray14 = new double[][] { doubleArray5, doubleArray9, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "Range[0.0,1.0]", doubleArray14);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1.0d) + "'", number16.equals((-1.0d)));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = numberAxis3D0.getNumberFormatOverride();
        boolean boolean2 = numberAxis3D0.getAutoRangeIncludesZero();
        double double3 = numberAxis3D0.getLowerMargin();
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.08d);
        java.awt.Font font3 = ringPlot0.getLabelFont();
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.lang.String str7 = numberAxis3D2.getLabelURL();
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) (short) 0, (double) (byte) 0);
        java.lang.String str4 = range3.toString();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,1.0]" + "'", str4.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str2 = basicProjectInfo1.getVersion();
        boolean boolean3 = strokeMap0.equals((java.lang.Object) str2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        boolean boolean5 = strokeMap0.equals((java.lang.Object) textAnchor4);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("UnitType.ABSOLUTE", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle10.setVerticalAlignment(verticalAlignment12);
        jFreeChart8.addLegend(legendTitle10);
        java.lang.Object obj15 = jFreeChart8.clone();
        jFreeChart8.setAntiAlias(true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        try {
            dateAxis1.setRange((double) 100.0f, (-7.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        dateAxis1.setAutoRange(false);
        dateAxis1.setAutoTickUnitSelection(true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) (short) -1, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot0.setRenderer(categoryItemRenderer11, false);
        try {
            categoryPlot0.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot12.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot12.drawRangeTickBands(graphics2D17, rectangle2D18, list19);
        org.jfree.chart.StrokeMap strokeMap21 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint23, stroke24);
        boolean boolean26 = strokeMap21.equals((java.lang.Object) valueMarker25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = valueMarker25.getLabelOffset();
        xYPlot12.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker25);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double34 = rectangleInsets33.getRight();
        double double36 = rectangleInsets33.calculateLeftOutset((double) ' ');
        valueMarker25.setLabelOffset(rectangleInsets33);
        double double38 = rectangleInsets33.getLeft();
        textTitle1.setMargin(rectangleInsets33);
        double double41 = rectangleInsets33.calculateRightOutset((double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 35.0d + "'", double36 == 35.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 35.0d + "'", double38 == 35.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot6.setDomainZeroBaselineStroke(stroke21);
        java.awt.Paint paint23 = xYPlot6.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getInsets();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator5);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle8.setText("");
        boolean boolean11 = textTitle8.getExpandToFitSpace();
        boolean boolean12 = textTitle8.getExpandToFitSpace();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot19.drawAnnotations(graphics2D20, rectangle2D21, plotRenderingInfo22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.util.List list26 = null;
        xYPlot19.drawRangeTickBands(graphics2D24, rectangle2D25, list26);
        org.jfree.chart.StrokeMap strokeMap28 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint30, stroke31);
        boolean boolean33 = strokeMap28.equals((java.lang.Object) valueMarker32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = valueMarker32.getLabelOffset();
        xYPlot19.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker32);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double41 = rectangleInsets40.getRight();
        double double43 = rectangleInsets40.calculateLeftOutset((double) ' ');
        valueMarker32.setLabelOffset(rectangleInsets40);
        double double45 = rectangleInsets40.getLeft();
        textTitle8.setMargin(rectangleInsets40);
        piePlot1.setLabelPadding(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 35.0d + "'", double43 == 35.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 35.0d + "'", double45 == 35.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D0.setTickUnit(numberTickUnit1, true, false);
        java.text.NumberFormat numberFormat5 = numberAxis3D0.getNumberFormatOverride();
        java.lang.String str6 = numberAxis3D0.getLabel();
        boolean boolean7 = numberAxis3D0.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairValue(136.0d, true);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = null;
        try {
            xYPlot7.setSeriesRenderingOrder(seriesRenderingOrder12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        double double3 = piePlot1.getMaximumLabelWidth();
        double double4 = piePlot1.getStartAngle();
        boolean boolean5 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        java.lang.String str6 = unitType5.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType5, (double) 0, (double) 10L, (double) (short) 0, (double) ' ');
        java.lang.String str12 = rectangleInsets11.toString();
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=0.0,l=10.0,b=0.0,r=32.0]" + "'", str12.equals("RectangleInsets[t=0.0,l=10.0,b=0.0,r=32.0]"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.data.KeyToGroupMap keyToGroupMap5 = null;
        try {
            org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3, keyToGroupMap5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation3 = piePlot1.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        piePlot1.setNoDataMessage("UnitType.ABSOLUTE");
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        piePlot1.setLegendItemShape(shape7);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer((int) '4', categoryItemRenderer5, false);
        boolean boolean8 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.StrokeMap strokeMap9 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke12);
        boolean boolean14 = strokeMap9.equals((java.lang.Object) valueMarker13);
        java.awt.Paint paint15 = valueMarker13.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint17, stroke18);
        valueMarker13.setStroke(stroke18);
        try {
            boolean boolean21 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.String str3 = titleChangeEvent2.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        titleChangeEvent2.setType(chartChangeEventType4);
        java.lang.Object obj6 = null;
        boolean boolean7 = chartChangeEventType4.equals(obj6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer13);
        int int15 = xYPlot14.getDatasetCount();
        java.awt.Paint paint16 = xYPlot14.getDomainGridlinePaint();
        boolean boolean17 = chartChangeEventType4.equals((java.lang.Object) paint16);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        categoryPlot0.setDataset(categoryDataset10);
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset10);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle10.setVerticalAlignment(verticalAlignment12);
        jFreeChart8.addLegend(legendTitle10);
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = legendTitle16.getHorizontalAlignment();
        java.lang.String str18 = horizontalAlignment17.toString();
        boolean boolean19 = legendTitle10.equals((java.lang.Object) str18);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "HorizontalAlignment.CENTER" + "'", str18.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        boolean boolean3 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.mapDatasetToRangeAxis(15, (int) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer28);
        dateAxis27.setLabelURL("Other");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis27.getStandardTickUnits();
        xYPlot6.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) dateAxis27, true);
        dateAxis27.setPositiveArrowVisible(false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(tickUnitSource32);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        boolean boolean3 = categoryAxis3D0.isAxisLineVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.axis.AxisState axisState10 = categoryAxis3D0.draw(graphics2D4, (double) (short) 1, rectangle2D6, rectangle2D7, rectangleEdge8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) (short) -1, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation12, plotOrientation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.plot.Plot plot1 = waferMapPlot0.getParent();
        org.junit.Assert.assertNull(plot1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = legendTitle2.getHorizontalAlignment();
        legendTitle2.setHeight(0.0d);
        java.awt.Font font6 = legendTitle2.getItemFont();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font6, paint7);
        java.awt.Graphics2D graphics2D9 = null;
        try {
            org.jfree.chart.util.Size2D size2D10 = textLine8.calculateDimensions(graphics2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset3, false);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset3);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Size2D[width=10.0, height=-1.0]");
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        categoryPlot0.setDataset(categoryDataset10);
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset10);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 0, (double) 500, plotRenderingInfo5, point2D6);
        categoryPlot0.clearAnnotations();
        java.awt.Color color9 = java.awt.Color.WHITE;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color9);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint12, stroke13);
        double double15 = valueMarker14.getValue();
        double double16 = valueMarker14.getValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        valueMarker14.notifyListeners(markerChangeEvent17);
        try {
            boolean boolean19 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("WMAP_Plot", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        legendTitle1.setNotify(false);
        java.awt.Paint paint5 = legendTitle1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4);
        java.awt.Stroke stroke6 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Size2D[width=10.0, height=-1.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.StrokeMap strokeMap15 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint17, stroke18);
        boolean boolean20 = strokeMap15.equals((java.lang.Object) valueMarker19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = valueMarker19.getLabelOffset();
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        java.awt.Stroke stroke23 = xYPlot6.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint2, stroke3);
        boolean boolean5 = strokeMap0.equals((java.lang.Object) valueMarker4);
        java.awt.Paint paint6 = valueMarker4.getLabelPaint();
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint8, stroke9);
        valueMarker4.setStroke(stroke9);
        valueMarker4.setValue(35.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = null;
        try {
            xYPlot6.setInsets(rectangleInsets19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation3 = piePlot1.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        java.awt.Paint paint5 = null;
        piePlot1.setOutlinePaint(paint5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot1.drawOutline(graphics2D7, rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot1.getLabelPadding();
        double double11 = piePlot1.getStartAngle();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("VerticalAlignment.BOTTOM", "");
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot7.getDomainAxisLocation(100);
        java.awt.Paint paint11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot7.setRangeCrosshairPaint(paint11);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot6.getRendererForDataset(xYDataset11);
        java.awt.Paint paint14 = xYPlot6.getQuadrantPaint(0);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = null;
        xYPlot6.setFixedLegendItems(legendItemCollection15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot6.drawDomainTickBands(graphics2D17, rectangle2D18, list19);
        java.awt.Stroke stroke21 = xYPlot6.getRangeGridlineStroke();
        int int22 = xYPlot6.getWeight();
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range0.intersects((double) (byte) 1, (double) (short) 10);
        double double4 = range0.getUpperBound();
        double double5 = range0.getUpperBound();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        java.lang.String str9 = dateAxis1.getLabel();
        java.awt.Paint paint10 = dateAxis1.getTickLabelPaint();
        dateAxis1.zoomRange((double) 0.0f, 0.0d);
        double double14 = dateAxis1.getLabelAngle();
        java.lang.String str15 = dateAxis1.getLabelURL();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        java.lang.String str9 = dateAxis1.getLabel();
        boolean boolean10 = dateAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setFixedDimension((double) 1.0f);
        dateAxis1.setTickMarkOutsideLength((float) 1);
        dateAxis1.setLabel("Range[0.0,1.0]");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D8.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle13.setText("");
        boolean boolean16 = textTitle13.getExpandToFitSpace();
        boolean boolean17 = textTitle13.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = legendTitle20.getHorizontalAlignment();
        legendTitle20.setHeight(0.0d);
        java.awt.Font font24 = legendTitle20.getItemFont();
        java.awt.Paint paint25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font24, paint25);
        textTitle13.setFont(font24);
        categoryAxis3D8.setTickLabelFont((java.lang.Comparable) 1L, font24);
        dateAxis1.setLabelFont(font24);
        double double30 = dateAxis1.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        categoryPlot0.setDataset(categoryDataset10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            categoryPlot0.handleClick((-1), (int) (short) 0, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.mapDatasetToRangeAxis(15, (int) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer27);
        int int29 = xYPlot28.getDatasetCount();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot28.setDomainCrosshairStroke(stroke30);
        xYPlot6.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        int int34 = xYPlot6.getIndexOf(xYItemRenderer33);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "hi!", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceText();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        legendTitle1.setNotify(false);
        org.jfree.chart.block.BlockContainer blockContainer5 = legendTitle1.getItemContainer();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(blockContainer5);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        xYPlot28.drawAnnotations(graphics2D29, rectangle2D30, plotRenderingInfo31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot28.drawRangeTickBands(graphics2D33, rectangle2D34, list35);
        org.jfree.chart.StrokeMap strokeMap37 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint39, stroke40);
        boolean boolean42 = strokeMap37.equals((java.lang.Object) valueMarker41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = valueMarker41.getLabelOffset();
        xYPlot28.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker41);
        org.jfree.chart.LegendItemSource legendItemSource45 = null;
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle(legendItemSource45);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = legendTitle46.getHorizontalAlignment();
        legendTitle46.setNotify(false);
        java.awt.Paint paint50 = legendTitle46.getItemPaint();
        valueMarker41.setLabelPaint(paint50);
        try {
            boolean boolean52 = xYPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        dateAxis1.zoomRange((double) (short) -1, 90.0d);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setFixedDimension((double) 1.0f);
        dateAxis1.setTickMarkOutsideLength((float) 1);
        dateAxis1.setLabel("Range[0.0,1.0]");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D8.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle13.setText("");
        boolean boolean16 = textTitle13.getExpandToFitSpace();
        boolean boolean17 = textTitle13.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = legendTitle20.getHorizontalAlignment();
        legendTitle20.setHeight(0.0d);
        java.awt.Font font24 = legendTitle20.getItemFont();
        java.awt.Paint paint25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font24, paint25);
        textTitle13.setFont(font24);
        categoryAxis3D8.setTickLabelFont((java.lang.Comparable) 1L, font24);
        dateAxis1.setLabelFont(font24);
        java.util.TimeZone timeZone30 = null;
        try {
            dateAxis1.setTimeZone(timeZone30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range4 = org.jfree.data.Range.expand(range1, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range4, (double) (-1), false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean13 = range10.intersects((double) (byte) 1, (double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range7, lengthConstraintType8, (double) (-1), range10, lengthConstraintType14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint15.toFixedHeight((double) 15);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = rectangleConstraint17.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint17.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        waferMapPlot6.setNoDataMessageFont(font12);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 100L, font12);
        categoryAxis3D0.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset22, false);
        boolean boolean26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset22);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = legendTitle30.getLegendItemGraphicEdge();
        try {
            double double32 = categoryAxis3D0.getCategorySeriesMiddle((java.lang.Comparable) 500, (java.lang.Comparable) ' ', categoryDataset22, (double) (short) 100, rectangle2D28, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        xYPlot6.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke13 = xYPlot6.getDomainZeroBaselineStroke();
        xYPlot6.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle1.getVerticalAlignment();
        double double17 = textTitle1.getContentYOffset();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.Object obj21 = textTitle1.draw(graphics2D18, rectangle2D19, (java.lang.Object) plotOrientation20);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNull(obj21);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createOutsetRectangle(rectangle2D5, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart21.clearSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        try {
            jFreeChart21.handleClick((int) (short) -1, (int) (short) 0, chartRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        xYPlot6.setRangeCrosshairLockedOnData(true);
        xYPlot6.setRangeCrosshairVisible(false);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot6.getDomainMarkers((int) (short) 100, layer16);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateLeftOutset(0.14d);
        java.lang.String str4 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str4.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        java.util.List list2 = textBlock0.getLines();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot3.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot3.getColumnRenderingOrder();
        categoryPlot3.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = categoryPlot3.getOrientation();
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot3.getRowRenderingOrder();
        boolean boolean12 = textBlock0.equals((java.lang.Object) sortOrder11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = null;
        java.awt.Shape shape20 = textBlock0.calculateBounds(graphics2D13, (-1.0f), (float) (-1L), textBlockAnchor16, 0.0f, 1.0f, (double) 1L);
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        textTitle1.setText("UnitType.ABSOLUTE");
        textTitle1.setID("RectangleAnchor.CENTER");
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint1, stroke2);
        double double4 = valueMarker3.getValue();
        double double5 = valueMarker3.getValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        valueMarker3.notifyListeners(markerChangeEvent6);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        try {
            valueMarker3.setLabelOffsetType(lengthAdjustmentType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        java.awt.Paint paint19 = xYPlot6.getDomainZeroBaselinePaint();
        java.lang.String str20 = xYPlot6.getPlotType();
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "XY Plot" + "'", str20.equals("XY Plot"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        waferMapPlot6.setNoDataMessageFont(font12);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 100L, font12);
        categoryAxis3D0.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
        double double17 = categoryAxis3D0.getLowerMargin();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = legendTitle23.getLegendItemGraphicEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            org.jfree.chart.axis.AxisState axisState26 = categoryAxis3D0.draw(graphics2D18, (double) 100, rectangle2D20, rectangle2D21, rectangleEdge24, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Range[0.0,1.0]");
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot7.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot7.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            xYPlot7.handleClick(0, (int) (short) 100, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxis13);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        float float2 = piePlot1.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D1.setRightArrow(shape2);
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor17 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        boolean boolean18 = textTitle1.equals((java.lang.Object) pieLabelDistributor17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.lang.Object obj21 = null;
        java.lang.Object obj22 = textTitle1.draw(graphics2D19, rectangle2D20, obj21);
        textTitle1.setURLText("");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(obj22);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double8 = rectangleInsets7.getRight();
        double double10 = rectangleInsets7.calculateLeftOutset((double) ' ');
        double double12 = rectangleInsets7.calculateLeftInset(0.0d);
        dateAxis1.setTickLabelInsets(rectangleInsets7);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        dateAxis15.setAutoTickUnitSelection(true, false);
        dateAxis15.setTickMarkOutsideLength(1.0f);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range25 = org.jfree.data.Range.expand(range22, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range28 = org.jfree.data.Range.shift(range25, (double) (-1), false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType29 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean34 = range31.intersects((double) (byte) 1, (double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType35 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range28, lengthConstraintType29, (double) (-1), range31, lengthConstraintType35);
        dateAxis15.setRange(range31, true, false);
        dateAxis1.setRange(range31, true, true);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 35.0d + "'", double10 == 35.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 35.0d + "'", double12 == 35.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(lengthConstraintType29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType35);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, 10.0f, (float) 100, 3.0d, (float) 10, (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range3, (double) (-1), false);
        double double7 = range6.getCentralValue();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.5d) + "'", double7 == (-0.5d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 0, (double) 500, plotRenderingInfo5, point2D6);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomDomainAxes(0.2d, (double) 100, plotRenderingInfo12, point2D13);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot22);
        xYPlot22.setRangeCrosshairValue(136.0d, true);
        java.awt.Color color27 = java.awt.Color.MAGENTA;
        xYPlot22.setDomainCrosshairPaint((java.awt.Paint) color27);
        boolean boolean29 = categoryPlot0.equals((java.lang.Object) xYPlot22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        categoryPlot0.setWeight(100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot6.getRendererForDataset(xYDataset11);
        java.awt.Paint paint14 = xYPlot6.getQuadrantPaint(0);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = null;
        xYPlot6.setFixedLegendItems(legendItemCollection15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot6.drawDomainTickBands(graphics2D17, rectangle2D18, list19);
        java.awt.Stroke stroke21 = xYPlot6.getRangeGridlineStroke();
        xYPlot6.setRangeGridlinesVisible(true);
        xYPlot6.clearRangeMarkers((int) 'a');
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState6 = ringPlot0.initialise(graphics2D1, rectangle2D2, piePlot3, (java.lang.Integer) 2, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat5 = null;
        dateAxis4.setDateFormatOverride(dateFormat5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color7);
        piePlot1.setBackgroundPaint((java.awt.Paint) color7);
        java.lang.Object obj10 = piePlot1.clone();
        piePlot1.setShadowXOffset((double) 1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.String str14 = standardPieSectionLabelGenerator13.getLabelFormat();
        java.lang.Object obj15 = standardPieSectionLabelGenerator13.clone();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator13);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0}" + "'", str14.equals("{0}"));
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str2 = plotOrientation1.toString();
        boolean boolean3 = plotOrientation0.equals((java.lang.Object) str2);
        java.lang.String str4 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str2.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str4.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
        basicProjectInfo4.setCopyright("");
        basicProjectInfo4.setCopyright("VerticalAlignment.BOTTOM");
        basicProjectInfo4.addOptionalLibrary("");
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        multiplePiePlot4.zoom((double) 10.0f);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset3);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset3);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset3);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        java.util.List list2 = textBlock0.getLines();
        java.util.List list3 = textBlock0.getLines();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle7.setText("");
        boolean boolean10 = textTitle7.getExpandToFitSpace();
        boolean boolean11 = textTitle7.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = legendTitle14.getHorizontalAlignment();
        legendTitle14.setHeight(0.0d);
        java.awt.Font font18 = legendTitle14.getItemFont();
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font18, paint19);
        textTitle7.setFont(font18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        textTitle7.setPaint((java.awt.Paint) color22);
        textBlock0.addLine("", font5, (java.awt.Paint) color22);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = textBlock0.getLineAlignment();
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle1.removeChangeListener(titleChangeListener3);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.JFreeChart jFreeChart6 = titleChangeEvent5.getChart();
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot7.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
        xYPlot7.setForegroundAlpha((float) 10L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        java.lang.String str9 = dateAxis1.getLabel();
        java.awt.Paint paint10 = dateAxis1.getTickLabelPaint();
        dateAxis1.zoomRange((double) 0.0f, 0.0d);
        double double14 = dateAxis1.getAutoRangeMinimumSize();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            java.util.List list19 = dateAxis1.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getDepthFactor();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor((int) (short) 1, (int) ' ', 1);
        boolean boolean8 = piePlot3D1.equals((java.lang.Object) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12d + "'", double2 == 0.12d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor17 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        boolean boolean18 = textTitle1.equals((java.lang.Object) pieLabelDistributor17);
        java.lang.String str19 = pieLabelDistributor17.toString();
        pieLabelDistributor17.sort();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(10.0d, (double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot3.setOrientation(plotOrientation4);
        boolean boolean6 = size2D2.equals((java.lang.Object) categoryPlot3);
        double double7 = size2D2.height;
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle1.removeChangeListener(titleChangeListener3);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.String str6 = titleChangeEvent5.toString();
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.12d, (-0.5d), (double) 100, 0.14d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, 0, (int) (byte) 100);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimWidth(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0d) + "'", double2 == (-2.0d));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        java.lang.String str16 = textTitle1.getToolTipText();
        textTitle1.setID("Other");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat7 = null;
        dateAxis6.setDateFormatOverride(dateFormat7);
        java.awt.Color color9 = java.awt.Color.GRAY;
        dateAxis6.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets4.equals((java.lang.Object) color9);
        int int12 = color9.getRed();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 128 + "'", int12 == 128);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.awt.Paint paint5 = multiplePiePlot4.getNoDataMessagePaint();
        java.awt.Paint paint6 = multiplePiePlot4.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        textTitle1.setID("RectangleEdge.BOTTOM");
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle1.setFont(font18);
        double double20 = textTitle1.getWidth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getContentXOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle10.setVerticalAlignment(verticalAlignment12);
        jFreeChart8.addLegend(legendTitle10);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle16.setText("");
        textTitle16.setText("UnitType.ABSOLUTE");
        jFreeChart8.setTitle(textTitle16);
        org.jfree.chart.title.TextTitle textTitle22 = jFreeChart8.getTitle();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(textTitle22);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = legendTitle2.getHorizontalAlignment();
        legendTitle2.setHeight(0.0d);
        java.awt.Font font6 = legendTitle2.getItemFont();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font6, paint7);
        org.jfree.chart.text.TextFragment textFragment9 = textLine8.getFirstTextFragment();
        java.awt.Paint paint10 = textFragment9.getPaint();
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textFragment9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D1.setCategoryLabelPositionOffset((int) (byte) 10);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5, waferMapRenderer6);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = legendTitle9.getHorizontalAlignment();
        legendTitle9.setHeight(0.0d);
        java.awt.Font font13 = legendTitle9.getItemFont();
        waferMapPlot7.setNoDataMessageFont(font13);
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) 100L, font13);
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) 1.0E-8d);
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D1);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(legendItemCollection19);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        java.lang.String str9 = dateAxis1.getLabel();
        dateAxis1.setVisible(true);
        java.util.Date date12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle15.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = legendTitle18.getHorizontalAlignment();
        legendTitle18.setHeight(0.0d);
        java.awt.Font font22 = legendTitle18.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle18.getLegendItemGraphicEdge();
        legendTitle15.setLegendItemGraphicEdge(rectangleEdge23);
        try {
            double double25 = dateAxis1.dateToJava2D(date12, rectangle2D13, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Shape shape4 = dateAxis1.getDownArrow();
        boolean boolean6 = dateAxis1.equals((java.lang.Object) "XY Plot");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 100);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setText("");
        boolean boolean12 = textTitle9.getExpandToFitSpace();
        boolean boolean13 = plotOrientation7.equals((java.lang.Object) boolean12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range4 = org.jfree.data.Range.expand(range1, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range4, (double) (-1), false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean13 = range10.intersects((double) (byte) 1, (double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range7, lengthConstraintType8, (double) (-1), range10, lengthConstraintType14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint15.toUnconstrainedWidth();
        org.jfree.chart.util.Size2D size2D19 = new org.jfree.chart.util.Size2D(10.0d, (double) (-1));
        size2D19.setHeight((double) (-1));
        org.jfree.chart.util.Size2D size2D22 = rectangleConstraint16.calculateConstrainedSize(size2D19);
        double double23 = size2D19.height;
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-1.0d) + "'", double23 == (-1.0d));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("PlotOrientation.HORIZONTAL");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name PlotOrientation.HORIZONTAL, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.08d);
        ringPlot0.setSeparatorsVisible(true);
        java.awt.Paint paint5 = ringPlot0.getSeparatorPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = legendTitle3.getHorizontalAlignment();
        legendTitle3.setHeight(0.0d);
        java.awt.Font font7 = legendTitle3.getItemFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font7, paint8);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font7, paint10);
        java.awt.Graphics2D graphics2D12 = null;
        try {
            org.jfree.chart.util.Size2D size2D13 = textLine11.calculateDimensions(graphics2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.setDomainCrosshairLockedOnData(false);
        java.awt.Color color21 = java.awt.Color.GRAY;
        java.awt.Color color22 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        float[] floatArray24 = null;
        float[] floatArray25 = color21.getComponents(colorSpace23, floatArray24);
        xYPlot6.setDomainCrosshairPaint((java.awt.Paint) color21);
        int int27 = xYPlot6.getRangeAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = xYPlot6.getFixedLegendItems();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer36);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat39 = numberAxis3D38.getNumberFormatOverride();
        java.awt.Paint paint40 = numberAxis3D38.getTickMarkPaint();
        boolean boolean41 = numberAxis3D38.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D42.setTickUnit(numberTickUnit43, true, false);
        numberAxis3D38.setTickUnit(numberTickUnit43, true, true);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { dateAxis30, numberAxis3D33, numberAxis3D38 };
        xYPlot6.setRangeAxes(valueAxisArray50);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(legendItemCollection28);
        org.junit.Assert.assertNull(numberFormat39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(numberTickUnit43);
        org.junit.Assert.assertNotNull(valueAxisArray50);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.StrokeMap strokeMap15 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint17, stroke18);
        boolean boolean20 = strokeMap15.equals((java.lang.Object) valueMarker19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = valueMarker19.getLabelOffset();
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font25);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = piePlot28.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation30 = piePlot28.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator31 = piePlot28.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font25, (org.jfree.chart.plot.Plot) piePlot28, false);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle38.setText("");
        boolean boolean41 = textTitle38.getExpandToFitSpace();
        boolean boolean42 = textTitle38.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = legendTitle45.getHorizontalAlignment();
        legendTitle45.setHeight(0.0d);
        java.awt.Font font49 = legendTitle45.getItemFont();
        java.awt.Paint paint50 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine51 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font49, paint50);
        textTitle38.setFont(font49);
        org.jfree.chart.util.VerticalAlignment verticalAlignment53 = textTitle38.getVerticalAlignment();
        legendTitle35.setVerticalAlignment(verticalAlignment53);
        jFreeChart33.addSubtitle((org.jfree.chart.title.Title) legendTitle35);
        xYPlot6.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart33);
        xYPlot6.setRangeCrosshairValue((double) '4');
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(rotation30);
        org.junit.Assert.assertNull(pieSectionLabelGenerator31);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(verticalAlignment53);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        xYPlot6.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke13 = xYPlot6.getDomainZeroBaselineStroke();
        java.util.List list14 = xYPlot6.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace15);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str2 = basicProjectInfo1.getVersion();
        boolean boolean3 = strokeMap0.equals((java.lang.Object) str2);
        boolean boolean5 = strokeMap0.containsKey((java.lang.Comparable) (short) 100);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D1.setRightArrow(shape2);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!");
        java.lang.String str6 = chartEntity5.getToolTipText();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat9 = null;
        dateAxis8.setDateFormatOverride(dateFormat9);
        java.awt.Shape shape11 = dateAxis8.getDownArrow();
        chartEntity5.setArea(shape11);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.mapDatasetToRangeAxis(15, (int) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer27);
        int int29 = xYPlot28.getDatasetCount();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot28.setDomainCrosshairStroke(stroke30);
        xYPlot6.setDomainCrosshairStroke(stroke30);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        xYPlot6.setDataset(xYDataset33);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        xYPlot6.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke13 = xYPlot6.getDomainZeroBaselineStroke();
        xYPlot6.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace15, true);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot6.getDomainAxisForDataset(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset((double) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor17 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        boolean boolean18 = textTitle1.equals((java.lang.Object) pieLabelDistributor17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.lang.Object obj21 = null;
        java.lang.Object obj22 = textTitle1.draw(graphics2D19, rectangle2D20, obj21);
        java.awt.Paint paint23 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle15.setText("");
        boolean boolean18 = textTitle15.getExpandToFitSpace();
        boolean boolean19 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = legendTitle22.getHorizontalAlignment();
        legendTitle22.setHeight(0.0d);
        java.awt.Font font26 = legendTitle22.getItemFont();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font26, paint27);
        textTitle15.setFont(font26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = textTitle15.getVerticalAlignment();
        legendTitle12.setVerticalAlignment(verticalAlignment30);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = legendTitle12.getHorizontalAlignment();
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = legendTitle35.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer37 = legendTitle35.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement38 = blockContainer37.getArrangement();
        org.jfree.chart.block.Block block39 = null;
        blockContainer37.add(block39);
        org.jfree.chart.block.Arrangement arrangement41 = blockContainer37.getArrangement();
        legendTitle12.setWrapper(blockContainer37);
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        blockContainer37.add((org.jfree.chart.block.Block) legendTitle44);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
        org.junit.Assert.assertNotNull(blockContainer37);
        org.junit.Assert.assertNotNull(arrangement38);
        org.junit.Assert.assertNotNull(arrangement41);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setTickMarkOutsideLength(1.0f);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range11 = org.jfree.data.Range.expand(range8, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift(range11, (double) (-1), false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean20 = range17.intersects((double) (byte) 1, (double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range14, lengthConstraintType15, (double) (-1), range17, lengthConstraintType21);
        dateAxis1.setRange(range17, true, false);
        org.jfree.chart.axis.Timeline timeline26 = null;
        dateAxis1.setTimeline(timeline26);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint1, stroke2);
        double double4 = valueMarker3.getValue();
        double double5 = valueMarker3.getValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = valueMarker3.getLabelOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("hi!");
        java.lang.String str10 = projectInfo7.getLicenceText();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 10, (int) ' ');
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = legendTitle3.getHorizontalAlignment();
        legendTitle3.setHeight(0.0d);
        java.awt.Font font7 = legendTitle3.getItemFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font7, paint8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat12 = null;
        dateAxis11.setDateFormatOverride(dateFormat12);
        java.awt.Color color14 = java.awt.Color.GRAY;
        dateAxis11.setTickLabelPaint((java.awt.Paint) color14);
        java.util.Date date16 = dateAxis11.getMinimumDate();
        java.awt.Color color17 = java.awt.Color.GRAY;
        dateAxis11.setTickMarkPaint((java.awt.Paint) color17);
        boolean boolean19 = dateAxis11.isVerticalTickLabels();
        boolean boolean21 = dateAxis11.isHiddenValue(10L);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot23.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat27 = null;
        dateAxis26.setDateFormatOverride(dateFormat27);
        java.awt.Color color29 = java.awt.Color.GRAY;
        dateAxis26.setTickLabelPaint((java.awt.Paint) color29);
        piePlot23.setBackgroundPaint((java.awt.Paint) color29);
        dateAxis11.setPlot((org.jfree.chart.plot.Plot) piePlot23);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat35 = null;
        dateAxis34.setDateFormatOverride(dateFormat35);
        java.awt.Shape shape37 = dateAxis34.getDownArrow();
        piePlot23.setLegendItemShape(shape37);
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", font7, (org.jfree.chart.plot.Plot) piePlot23, true);
        org.jfree.chart.plot.Plot plot41 = jFreeChart40.getPlot();
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(plot41);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textBlock0.getLineAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        double double3 = piePlot1.getMaximumLabelWidth();
        double double4 = piePlot1.getStartAngle();
        boolean boolean5 = piePlot1.getSimpleLabels();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot12.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        xYPlot12.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        piePlot1.setLabelOutlineStroke(stroke19);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        int int7 = xYPlot6.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot6.getDomainAxis((int) (short) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot6.getDomainAxisEdge();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint12, stroke13);
        double double15 = valueMarker14.getValue();
        java.awt.Paint paint16 = valueMarker14.getLabelPaint();
        org.jfree.chart.util.Layer layer17 = null;
        xYPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14, layer17);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Color color0 = java.awt.Color.GRAY;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        java.lang.Object obj9 = jFreeChart8.clone();
        java.lang.Object obj10 = jFreeChart8.getTextAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot11.setOrientation(plotOrientation12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot11.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        boolean boolean19 = categoryPlot11.render(graphics2D15, rectangle2D16, 1, plotRenderingInfo18);
        try {
            jFreeChart8.setTextAntiAlias((java.lang.Object) rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        dateAxis4.setLabelURL("Other");
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        java.awt.Shape shape10 = dateAxis4.getDownArrow();
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(10.0d, (double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot3.setOrientation(plotOrientation4);
        boolean boolean6 = size2D2.equals((java.lang.Object) categoryPlot3);
        java.awt.Paint paint8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { paint8, paint9, color10, paint11, color12, paint13 };
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color16 = java.awt.Color.GRAY;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color15, color16, color17, paint18, color19, color20 };
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color23 = java.awt.Color.GRAY;
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color22, color23, paint24 };
        java.awt.Stroke[] strokeArray26 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke27 = null;
        java.awt.Stroke[] strokeArray28 = new java.awt.Stroke[] { stroke27 };
        java.awt.Shape[] shapeArray29 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray21, paintArray25, strokeArray26, strokeArray28, shapeArray29);
        java.lang.Object obj31 = defaultDrawingSupplier30.clone();
        java.awt.Paint paint32 = defaultDrawingSupplier30.getNextPaint();
        org.jfree.chart.StrokeMap strokeMap33 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo34 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str35 = basicProjectInfo34.getVersion();
        boolean boolean36 = strokeMap33.equals((java.lang.Object) str35);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, (org.jfree.chart.axis.ValueAxis) dateAxis41, xYItemRenderer42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        xYPlot43.drawAnnotations(graphics2D44, rectangle2D45, plotRenderingInfo46);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double54 = rectangleInsets52.calculateLeftOutset((double) 10.0f);
        xYPlot43.setAxisOffset(rectangleInsets52);
        xYPlot43.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke58 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot43.setDomainZeroBaselineStroke(stroke58);
        boolean boolean60 = strokeMap33.equals((java.lang.Object) stroke58);
        org.jfree.chart.plot.RingPlot ringPlot61 = new org.jfree.chart.plot.RingPlot();
        ringPlot61.setSectionDepth(0.08d);
        java.awt.Paint paint64 = ringPlot61.getSeparatorPaint();
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D67 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        org.jfree.chart.plot.XYPlot xYPlot71 = new org.jfree.chart.plot.XYPlot(xYDataset65, (org.jfree.chart.axis.ValueAxis) numberAxis3D67, (org.jfree.chart.axis.ValueAxis) dateAxis69, xYItemRenderer70);
        java.awt.Graphics2D graphics2D72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        xYPlot71.drawAnnotations(graphics2D72, rectangle2D73, plotRenderingInfo74);
        xYPlot71.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke78 = xYPlot71.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker80 = new org.jfree.chart.plot.ValueMarker(2.0d, paint32, stroke58, paint64, stroke78, (float) (byte) 0);
        try {
            boolean boolean81 = categoryPlot3.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 35.0d + "'", double54 == 35.0d);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(stroke78);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.lang.Object obj0 = null;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = piePlot6.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation8 = piePlot6.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot6.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font3, (org.jfree.chart.plot.Plot) piePlot6, false);
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        double double14 = legendTitle13.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle16.setText("");
        boolean boolean19 = textTitle16.getExpandToFitSpace();
        boolean boolean20 = textTitle16.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = legendTitle23.getHorizontalAlignment();
        legendTitle23.setHeight(0.0d);
        java.awt.Font font27 = legendTitle23.getItemFont();
        java.awt.Paint paint28 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine29 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font27, paint28);
        textTitle16.setFont(font27);
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = textTitle16.getVerticalAlignment();
        legendTitle13.setVerticalAlignment(verticalAlignment31);
        jFreeChart11.addSubtitle((org.jfree.chart.title.Title) legendTitle13);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent36 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle35);
        jFreeChart11.addLegend(legendTitle35);
        int int38 = jFreeChart11.getSubtitleCount();
        org.jfree.chart.LegendItemSource legendItemSource39 = null;
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle(legendItemSource39);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent41 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle40);
        java.lang.String str42 = titleChangeEvent41.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType43 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        titleChangeEvent41.setType(chartChangeEventType43);
        jFreeChart11.titleChanged(titleChangeEvent41);
        org.jfree.chart.LegendItemSource legendItemSource46 = null;
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle(legendItemSource46);
        double double48 = legendTitle47.getContentXOffset();
        boolean boolean49 = legendTitle47.getNotify();
        jFreeChart11.addLegend(legendTitle47);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertNotNull(chartChangeEventType43);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace15, false);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot6.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer26);
        int int28 = xYPlot27.getDatasetCount();
        java.awt.Paint paint29 = xYPlot27.getDomainGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot37);
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot37.getDomainAxisLocation(100);
        xYPlot27.setRangeAxisLocation(axisLocation40, false);
        xYPlot6.setRangeAxisLocation((int) 'a', axisLocation40, true);
        java.lang.String str45 = xYPlot6.getNoDataMessage();
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNull(str45);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
        basicProjectInfo4.setInfo("");
        basicProjectInfo4.setInfo("RectangleAnchor.RIGHT");
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        piePlot5.setMaximumLabelWidth((double) 15);
        double double13 = piePlot5.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 15.0d + "'", double13 == 15.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("HorizontalAlignment.CENTER", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        boolean boolean9 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setLabelURL("");
        double double12 = dateAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        boolean boolean9 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setLowerMargin((double) 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairValue(136.0d, true);
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot7.getDataset();
        boolean boolean13 = xYPlot7.isDomainZoomable();
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat4 = null;
        dateAxis3.setDateFormatOverride(dateFormat4);
        java.awt.Color color6 = java.awt.Color.GRAY;
        dateAxis3.setTickLabelPaint((java.awt.Paint) color6);
        java.util.Date date8 = dateAxis3.getMinimumDate();
        java.text.DateFormat dateFormat9 = null;
        dateAxis3.setDateFormatOverride(dateFormat9);
        java.lang.String str11 = dateAxis3.getLabel();
        java.awt.Paint paint12 = dateAxis3.getTickLabelPaint();
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("LengthConstraintType.FIXED", font1, paint12);
        org.jfree.chart.text.TextFragment textFragment14 = null;
        textLine13.removeFragment(textFragment14);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getDepthFactor();
        boolean boolean3 = piePlot3D1.getDarkerSides();
        java.awt.Paint paint5 = piePlot3D1.getSectionPaint((java.lang.Comparable) false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12d + "'", double2 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = legendTitle4.getHorizontalAlignment();
        legendTitle4.setHeight(0.0d);
        java.awt.Font font8 = legendTitle4.getItemFont();
        waferMapPlot2.setNoDataMessageFont(font8);
        java.lang.String str10 = waferMapPlot2.getPlotType();
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "WMAP_Plot" + "'", str10.equals("WMAP_Plot"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot0.setOrientation(plotOrientation1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat6 = null;
        dateAxis5.setDateFormatOverride(dateFormat6);
        java.awt.Color color8 = java.awt.Color.GRAY;
        dateAxis5.setTickLabelPaint((java.awt.Paint) color8);
        java.util.Date date10 = dateAxis5.getMinimumDate();
        java.awt.Color color11 = java.awt.Color.GRAY;
        dateAxis5.setTickMarkPaint((java.awt.Paint) color11);
        boolean boolean13 = dateAxis5.isVerticalTickLabels();
        dateAxis5.setLabelURL("");
        int int16 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis5);
        int int17 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 10);
        boolean boolean3 = categoryAxis3D0.isAxisLineVisible();
        java.awt.Paint paint4 = categoryAxis3D0.getLabelPaint();
        categoryAxis3D0.setMaximumCategoryLabelLines(1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (short) 10, (float) '#', textAnchor4, (double) 0, 100.0f, (float) (-1));
        java.lang.String str9 = textAnchor4.toString();
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.CENTER_LEFT" + "'", str9.equals("TextAnchor.CENTER_LEFT"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        legendTitle8.setHeight(0.0d);
        java.awt.Font font12 = legendTitle8.getItemFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font12, paint13);
        textTitle1.setFont(font12);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor17 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        boolean boolean18 = textTitle1.equals((java.lang.Object) pieLabelDistributor17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.lang.Object obj21 = null;
        java.lang.Object obj22 = textTitle1.draw(graphics2D19, rectangle2D20, obj21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle1.getPadding();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("hi!");
        java.lang.String str10 = projectInfo7.toString();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " version .\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!" + "'", str10.equals(" version .\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateLeftOutset(0.14d);
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "RectangleAnchor.CENTER", "HorizontalAlignment.CENTER", image3, "UnitType.ABSOLUTE", "{0}", "RectangleAnchor.RIGHT");
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = legendTitle11.getHorizontalAlignment();
        legendTitle11.setHeight(0.0d);
        java.awt.Font font15 = legendTitle11.getItemFont();
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font15, paint16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat20 = null;
        dateAxis19.setDateFormatOverride(dateFormat20);
        java.awt.Color color22 = java.awt.Color.GRAY;
        dateAxis19.setTickLabelPaint((java.awt.Paint) color22);
        java.util.Date date24 = dateAxis19.getMinimumDate();
        java.awt.Color color25 = java.awt.Color.GRAY;
        dateAxis19.setTickMarkPaint((java.awt.Paint) color25);
        boolean boolean27 = dateAxis19.isVerticalTickLabels();
        boolean boolean29 = dateAxis19.isHiddenValue(10L);
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = piePlot31.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat35 = null;
        dateAxis34.setDateFormatOverride(dateFormat35);
        java.awt.Color color37 = java.awt.Color.GRAY;
        dateAxis34.setTickLabelPaint((java.awt.Paint) color37);
        piePlot31.setBackgroundPaint((java.awt.Paint) color37);
        dateAxis19.setPlot((org.jfree.chart.plot.Plot) piePlot31);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat43 = null;
        dateAxis42.setDateFormatOverride(dateFormat43);
        java.awt.Shape shape45 = dateAxis42.getDownArrow();
        piePlot31.setLegendItemShape(shape45);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", font15, (org.jfree.chart.plot.Plot) piePlot31, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = null;
        java.awt.image.BufferedImage bufferedImage53 = jFreeChart48.createBufferedImage((int) '#', (int) (byte) 1, 10, chartRenderingInfo52);
        projectInfo7.setLogo((java.awt.Image) bufferedImage53);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(drawingSupplier32);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(bufferedImage53);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        xYPlot6.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke13 = xYPlot6.getDomainZeroBaselineStroke();
        xYPlot6.configureDomainAxes();
        xYPlot6.configureDomainAxes();
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str1.equals("RectangleAnchor.TOP_RIGHT"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        float float3 = piePlot2.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat11 = null;
        dateAxis10.setDateFormatOverride(dateFormat11);
        java.awt.Color color13 = java.awt.Color.GRAY;
        dateAxis10.setTickLabelPaint((java.awt.Paint) color13);
        boolean boolean15 = rectangleInsets8.equals((java.lang.Object) color13);
        float[] floatArray22 = new float[] { 100L, '#', (byte) 100, (short) 1, (-1L), (byte) -1 };
        float[] floatArray23 = color13.getRGBColorComponents(floatArray22);
        piePlot2.setLabelShadowPaint((java.awt.Paint) color13);
        boolean boolean25 = lengthConstraintType0.equals((java.lang.Object) piePlot2);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = xYPlot6.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot6.setRenderer(xYItemRenderer20);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateLeftOutset(0.14d);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createInsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        java.awt.Paint paint19 = xYPlot6.getOutlinePaint();
        org.jfree.chart.StrokeMap strokeMap21 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint23, stroke24);
        boolean boolean26 = strokeMap21.equals((java.lang.Object) valueMarker25);
        org.jfree.chart.util.Layer layer27 = null;
        try {
            boolean boolean28 = xYPlot6.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) valueMarker25, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("UnitType.ABSOLUTE", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        int int1 = categoryAxis3D0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        xYPlot6.setAxisOffset(rectangleInsets15);
        xYPlot6.setDomainCrosshairLockedOnData(false);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot6.getDomainAxisForDataset(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color4 = java.awt.Color.GRAY;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { paint0, paint1, color2, paint3, color4, paint5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color8 = java.awt.Color.GRAY;
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color7, color8, color9, paint10, color11, color12 };
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color15 = java.awt.Color.GRAY;
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color14, color15, paint16 };
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke19 };
        java.awt.Shape[] shapeArray21 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray13, paintArray17, strokeArray18, strokeArray20, shapeArray21);
        java.awt.Stroke stroke23 = defaultDrawingSupplier22.getNextOutlineStroke();
        java.awt.Paint paint24 = defaultDrawingSupplier22.getNextPaint();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation3 = piePlot1.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        java.awt.Paint paint5 = null;
        piePlot1.setOutlinePaint(paint5);
        double double7 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.14d + "'", double7 == 0.14d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleAnchor.CENTER", "");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setFixedDimension((double) 1.0f);
        dateAxis1.setTickMarkOutsideLength((float) 1);
        java.util.Date date6 = dateAxis1.getMaximumDate();
        dateAxis1.resizeRange((double) 'a');
        dateAxis1.setFixedAutoRange(0.05d);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot7.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot7.getRangeAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = xYPlot7.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(valueAxis13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot6.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot6.getRendererForDataset(xYDataset11);
        java.awt.Paint paint14 = xYPlot6.getQuadrantPaint(0);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = null;
        xYPlot6.setFixedLegendItems(legendItemCollection15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot6.drawDomainTickBands(graphics2D17, rectangle2D18, list19);
        java.awt.Stroke stroke21 = xYPlot6.getRangeGridlineStroke();
        org.jfree.chart.plot.Marker marker22 = null;
        try {
            boolean boolean23 = xYPlot6.removeDomainMarker(marker22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset3);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset3);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (int) (short) 1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleAnchor.RIGHT", font2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot5.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation7 = piePlot5.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot5.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", font2, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle15.setText("");
        boolean boolean18 = textTitle15.getExpandToFitSpace();
        boolean boolean19 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = legendTitle22.getHorizontalAlignment();
        legendTitle22.setHeight(0.0d);
        java.awt.Font font26 = legendTitle22.getItemFont();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font26, paint27);
        textTitle15.setFont(font26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = textTitle15.getVerticalAlignment();
        legendTitle12.setVerticalAlignment(verticalAlignment30);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) legendTitle12);
        jFreeChart10.clearSubtitles();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(verticalAlignment30);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("hi!");
        projectInfo7.setCopyright("");
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(dateTickUnit6);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat5 = null;
        dateAxis4.setDateFormatOverride(dateFormat5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color7);
        piePlot1.setBackgroundPaint((java.awt.Paint) color7);
        boolean boolean10 = piePlot1.getSimpleLabels();
        double double11 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(10.0d, (double) (-1));
        size2D2.setHeight((double) (-1));
        org.jfree.chart.StrokeMap strokeMap5 = new org.jfree.chart.StrokeMap();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint7, stroke8);
        boolean boolean10 = strokeMap5.equals((java.lang.Object) valueMarker9);
        java.awt.Paint paint11 = valueMarker9.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = piePlot13.getInsets();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = null;
        piePlot13.setLegendLabelURLGenerator(pieURLGenerator17);
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot13.setLabelOutlinePaint(paint19);
        valueMarker9.setOutlinePaint(paint19);
        boolean boolean22 = size2D2.equals((java.lang.Object) paint19);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) (short) 0, (double) (byte) 0);
        boolean boolean6 = range3.intersects((double) 1.0f, 0.0d);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setNoDataMessage("Range[0.0,1.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getInsets();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator5);
        java.lang.String str7 = piePlot1.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        xYPlot14.drawAnnotations(graphics2D15, rectangle2D16, plotRenderingInfo17);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) '#', 0.0d, (double) (byte) 1);
        double double25 = rectangleInsets23.calculateLeftOutset((double) 10.0f);
        xYPlot14.setAxisOffset(rectangleInsets23);
        xYPlot14.setDomainCrosshairLockedOnData(false);
        java.awt.Color color29 = java.awt.Color.GRAY;
        java.awt.Color color30 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace31 = color30.getColorSpace();
        float[] floatArray32 = null;
        float[] floatArray33 = color29.getComponents(colorSpace31, floatArray32);
        xYPlot14.setDomainCrosshairPaint((java.awt.Paint) color29);
        piePlot1.setShadowPaint((java.awt.Paint) color29);
        double double36 = piePlot1.getShadowXOffset();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 35.0d + "'", double25 == 35.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(colorSpace31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation3 = piePlot1.getDirection();
        float float4 = piePlot1.getBackgroundAlpha();
        piePlot1.setSimpleLabels(true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator7);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        jFreeChart8.setBackgroundImageAlpha((float) (short) 0);
        jFreeChart8.fireChartChanged();
        org.jfree.chart.plot.Plot plot12 = jFreeChart8.getPlot();
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer((int) '4', categoryItemRenderer5, false);
        boolean boolean8 = categoryPlot0.isRangeZoomable();
        categoryPlot0.configureDomainAxes();
        java.awt.Stroke stroke10 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Color color4 = java.awt.Color.GRAY;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.awt.Color color7 = java.awt.Color.GRAY;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        boolean boolean9 = dateAxis1.isVerticalTickLabels();
        boolean boolean11 = dateAxis1.isHiddenValue(10L);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = piePlot13.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat17 = null;
        dateAxis16.setDateFormatOverride(dateFormat17);
        java.awt.Color color19 = java.awt.Color.GRAY;
        dateAxis16.setTickLabelPaint((java.awt.Paint) color19);
        piePlot13.setBackgroundPaint((java.awt.Paint) color19);
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.data.Range range23 = dateAxis1.getRange();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(drawingSupplier14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        java.util.List list2 = textBlock0.getLines();
        java.util.List list3 = textBlock0.getLines();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle7.setText("");
        boolean boolean10 = textTitle7.getExpandToFitSpace();
        boolean boolean11 = textTitle7.getExpandToFitSpace();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = legendTitle14.getHorizontalAlignment();
        legendTitle14.setHeight(0.0d);
        java.awt.Font font18 = legendTitle14.getItemFont();
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font18, paint19);
        textTitle7.setFont(font18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        textTitle7.setPaint((java.awt.Paint) color22);
        textBlock0.addLine("", font5, (java.awt.Paint) color22);
        java.util.List list25 = textBlock0.getLines();
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        java.lang.Object obj2 = objectList0.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment2, verticalAlignment3, (double) 0, 35.0d);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle8.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer10 = legendTitle8.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement11 = blockContainer10.getArrangement();
        org.jfree.chart.block.Block block12 = null;
        blockContainer10.add(block12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range19 = org.jfree.data.Range.expand(range16, (double) (short) 0, (double) (byte) 0);
        org.jfree.data.Range range22 = org.jfree.data.Range.shift(range19, (double) (-1), false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean28 = range25.intersects((double) (byte) 1, (double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType29 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range22, lengthConstraintType23, (double) (-1), range25, lengthConstraintType29);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = rectangleConstraint30.toFixedHeight((double) 15);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = rectangleConstraint32.getWidthConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D34 = columnArrangement6.arrange(blockContainer10, graphics2D14, rectangleConstraint32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(blockContainer10);
        org.junit.Assert.assertNotNull(arrangement11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(lengthConstraintType23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType29);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
        org.junit.Assert.assertNotNull(lengthConstraintType33);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.text.DateFormat dateFormat3 = null;
        dateAxis2.setDateFormatOverride(dateFormat3);
        java.awt.Color color5 = java.awt.Color.GRAY;
        dateAxis2.setTickLabelPaint((java.awt.Paint) color5);
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot7.getDomainAxisLocation(100);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot7.getRangeMarkers((int) '#', layer12);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        try {
            xYPlot7.addAnnotation(xYAnnotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(collection13);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairValue(136.0d, true);
        java.awt.Color color12 = java.awt.Color.MAGENTA;
        xYPlot7.setDomainCrosshairPaint((java.awt.Paint) color12);
        java.awt.Stroke stroke14 = xYPlot7.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer((int) '4', categoryItemRenderer5, false);
        boolean boolean8 = categoryPlot0.isRangeZoomable();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot10.getIndexOf(categoryItemRenderer11);
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot10.getColumnRenderingOrder();
        categoryPlot0.setRowRenderingOrder(sortOrder13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint17, stroke18);
        double double20 = valueMarker19.getValue();
        java.awt.Paint paint21 = valueMarker19.getLabelPaint();
        java.awt.Paint paint22 = valueMarker19.getOutlinePaint();
        try {
            boolean boolean23 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        int int2 = categoryPlot0.getIndexOf(categoryItemRenderer1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 0, (double) 500, plotRenderingInfo5, point2D6);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(plotOrientation9);
    }
}

